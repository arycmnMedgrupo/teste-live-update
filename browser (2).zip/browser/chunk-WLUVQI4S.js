import{b as a,c as b}from"./chunk-JWIEPCRG.js";import"./chunk-XUQR5L7Y.js";export{a as GESTURE_CONTROLLER,b as createGesture};
