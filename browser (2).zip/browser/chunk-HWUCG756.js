import{b as c,v as m}from"./chunk-V46EGHU6.js";import{j as r}from"./chunk-XUQR5L7Y.js";var p={data:[{id:"6d0fbd8a-c735-4860-a485-69c80f54ecc9",nome:"Acalasia",categoria:2,termosDeBusca:"acalasia, megaesofago",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"45bf13b4-6e46-4585-9172-f706a9f94c34",nome:"Acalasia",favorito:!0,ordem:1,secoes:[{item:"NITRATO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"bbac333b-be34-49b2-9ab6-e5e6db2bae01",opcoes:[{id:"78b0da85-ec53-4455-aa6d-8d38c1bff28a",descr:"Dinitrato de isossorbida (5mg/cp) 5 mg SL antes das refei\xE7\xF5es",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:1},{item:"NITRATO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"035920f4-ef1d-4dc3-b389-b1705800a5c8",opcoes:[{id:"40ffed8c-9d1d-41ed-8f8a-fc51631c7265",descr:"Dinitrato de isossorbida (5mg/cp) 5 mg SL antes das refei\xE7\xF5es",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:1},{item:"NITRATO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"6aa59fc3-e593-4256-aa2d-8a7e2ca9c629",opcoes:[{id:"3c40bc70-8e72-4db7-8224-a2ff2adb373b",descr:"Dinitrato de isossorbida (5mg/cp) 5 mg SL antes das refei\xE7\xF5es",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:1},{item:"NITRATO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"d8884a6c-ab4b-4720-906c-9631092d0876",opcoes:[{id:"795a5d7d-922f-484e-8b71-ef681e365a96",descr:"Dinitrato de isossorbida (5mg/cp) 5 mg SL antes das refei\xE7\xF5es",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:1},{item:"BLOQUEADOR DE CANAL DE C\xC1LCIO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"12335363-f2f1-48d1-be85-82df57f8bc4a",opcoes:[{id:"b02049b3-c557-49ee-b531-499040262446",descr:"Nifedipino (10-30mg/cp) 10-30 mg SL antes das refei\xE7\xF5es",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:2},{item:"BLOQUEADOR DE CANAL DE C\xC1LCIO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"00523be1-687a-45a9-8ac1-3e54bd23268a",opcoes:[{id:"d860e97f-4f21-4b47-905f-74e0c9b76b85",descr:"Nifedipino (10-30mg/cp) 10-30 mg SL antes das refei\xE7\xF5es",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:2},{item:"BLOQUEADOR DE CANAL DE C\xC1LCIO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"2b36012c-2c38-4cb9-a2d6-97016593c6e7",opcoes:[{id:"1d3c8b6f-9b77-4065-8beb-ec067e919b57",descr:"Nifedipino (10-30mg/cp) 10-30 mg SL antes das refei\xE7\xF5es",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:2},{item:"BLOQUEADOR DE CANAL DE C\xC1LCIO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"4fb47fe7-f56f-447d-9b56-34259d3e05fa",opcoes:[{id:"146c13d9-4899-4ca7-a1f2-640bfdb7e909",descr:"Nifedipino (10-30mg/cp) 10-30 mg SL antes das refei\xE7\xF5es",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:2}],conceitosPraticos:[{conceito:"Realizar EDA para excluir obstru\xE7\xE3o mec\xE2nica.",ordem:1},{conceito:"Padr\xE3o-ouro: esofagomanometria de alta resolu\xE7\xE3o.",ordem:2},{conceito:"Tipo I e II: dilata\xE7\xE3o pneum\xE1tica, miotomia a Heller ou POEM.",ordem:3},{conceito:"Tipo III: miotomia a Heller ou POEM.",ordem:4},{conceito:"F\xE1rmacos: apenas se n\xE3o candidato a terapias definitivas (toxina botull\xEDnica preferencial em compara\xE7\xE3o com drogas orais).",ordem:5}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">A acalasia \xE9 uma rara desordem motora prim\xE1ria do es\xF4fago caracterizada pela perda da peristalse do corpo esofagiano e pela insufici\xEAncia do relaxamento do esf\xEDncter esofagiano inferior, afetando igualmente homens e mulheres com pico de incid\xEAncia entre 30 e 60 anos. Sua ocorr\xEAncia est\xE1 associada \xE0 degenera\xE7\xE3o de neur\xF4nios do plexo mioent\xE9rico, que pode ser idiop\xE1tica ou associada a algumas condi\xE7\xF5es como a Doen\xE7a de Chagas.</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">As manifesta\xE7\xF5es cl\xEDnicas mais cl\xE1ssicas envolvem disfagia para alimentos s\xF3lidos e l\xEDquidos, regurgita\xE7\xE3o e dor tor\xE1cica ocasional, acompanhada ou n\xE3o de perda de peso.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Pacientes inicialmente diagnosticados como portadores de Doen\xE7a do Refluxo Gastroesof\xE1gico (DRGE) que n\xE3o responderem ao tratamento com inibidor de bomba de pr\xF3ton (IBP) devem ser investigados para acalasia, uma vez que 27-42% dos casos podem se apresentar com queima\xE7\xE3o retroesternal.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">
      <img src="https://d55mnj1ee66xh.cloudfront.net/academico/a9fde36c-d91f-4896-ad69-3eb83b61ee95.jpg" alt="" width="100%" height="auto">
    </span>
  </em>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">Em todo quadro suspeito de acalasia, uma endoscopia digestiva alta deve ser realizada a fim de excluir causas de obstru\xE7\xE3o mec\xE2nica que podem mimetizar a apresenta\xE7\xE3o cl\xEDnica, al\xE9m de ter a possibilidade de evidenciar achados sugestivos de acalasia, como a reten\xE7\xE3o de saliva. Outro exame que pode ser feito \xE9 o esofagograma baritado, o qual, em casos mais avan\xE7ados, pode demonstrar dilata\xE7\xE3o esofagiana e o cl\xE1ssico sinal do \u201Cpico de p\xE1ssaro\u201D.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Atualmente, h\xE1 a op\xE7\xE3o do esofagograma baritado cronometrado em que imagens coletadas com 1, 2 e 5 minutos ap\xF3s a ingest\xE3o de um grande bolus de b\xE1rio s\xE3o \xFAteis para avalia\xE7\xE3o inicial da doen\xE7a e da resposta ao tratamento.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">De qualquer forma, o padr\xE3o-ouro para confirma\xE7\xE3o diagn\xF3stica \xE9 a manometria de alta resolu\xE7\xE3o, que ainda divide a acalasia em 3 subtipos distintos (Classifica\xE7\xE3o de Chicago):</span>
</p><p>
  <span style="font-weight: 400;">- Tipo I \u2013 Acalasia Cl\xE1ssica (20-40% dos casos): aperistalse e aus\xEAncia de pressuriza\xE7\xE3o esof\xE1gica.</span>
</p><p>
  <span style="font-weight: 400;">- Tipo II \u2013 Acalasia com Compress\xE3o Esof\xE1gica (50-70% dos casos): aperistalse, mas com pressuriza\xE7\xE3o panesof\xE1gica (superior a 30 mmHg) em pelo menos 20% das degluti\xE7\xF5es; constitui o subtipo de melhor progn\xF3stico.</span>
</p><p>
  <span style="font-weight: 400;">- Tipo III \u2013 Acalasia Esp\xE1stica (5% dos casos): contra\xE7\xF5es esp\xE1sticas (pelo menos 20% das degluti\xE7\xF5es t\xEAm contra\xE7\xF5es prematuras intensas); constitui o subtipo de pior progn\xF3stico.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Em todos os subtipos, h\xE1 eleva\xE7\xE3o de um par\xE2metro manom\xE9trico denominado \u201Cintegral da press\xE3o de relaxamento\u201D (IRP, do ingl\xEAs Integrated Relaxation Pressure), que corresponde \xE0 m\xE9dia da press\xE3o na altura do esf\xEDncter esofagiano inferior aferida em uma janela de 10 segundos (valor normal \xE9 &lt; 15 mmHg ou &lt; 28 mmHg, a depender da t\xE9cnica usada). A Classifica\xE7\xE3o de Chicago tamb\xE9m define a entidade \u201CObstru\xE7\xE3o ao Fluxo pela Jun\xE7\xE3o Esofagog\xE1strica\u201D (OFJEG), situa\xE7\xE3o em que o IRP est\xE1 aumentado, mas n\xE3o h\xE1 outras altera\xE7\xF5es de peristalse.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">
      <img src="https://d55mnj1ee66xh.cloudfront.net/academico/913ea7d8-9733-4465-b512-955d15db6465.jpg" alt="" width="100%" height="auto">
    </span>
  </em>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">Para avalia\xE7\xE3o da intensidade dos sintomas e resposta \xE0s estrat\xE9gias terap\xEAuticas, recomenda-se o uso do Escore de Eckardt (pontua\xE7\xE3o &lt; 3 est\xE1 associada a melhor desfecho), de modo que, em casos refrat\xE1rios, pode-se tamb\xE9m realizar o esofagograma baritado cronometrado (imagens coletadas com 1, 2 e 5 minutos ap\xF3s a ingest\xE3o de um grande bolus de b\xE1rio s\xE3o \xFAteis para buscar evid\xEAncia de reten\xE7\xE3o, como uma coluna de b\xE1rio &gt; 5 cm no 5\xBA minuto).</span>
</p><p>
  <span style="font-weight: 400;">Quanto ao tratamento, mesmo que conceitualmente a doen\xE7a possa n\xE3o ter cura, as estrat\xE9gias s\xE3o direcionadas para a redu\xE7\xE3o do t\xF4nus do esf\xEDncter esofagiano inferior.</span>
</p><p>
  <strong>Tratamento definitivo (dilata\xE7\xE3o pneum\xE1tica, miotomia a Heller, POEM) \u2013</strong>
  <span style="font-weight: 400;">As op\xE7\xF5es com melhores resultados incluem a dilata\xE7\xE3o pneum\xE1tica (risco de perfura\xE7\xE3o e DRGE ap\xF3s o procedimento), a miotomia laparosc\xF3pica de Heller (associada \xE0 fundoplicatura de Dor ou Toupet para evitar DRGE) e a miotomia endosc\xF3pica peroral (POEM, do ingl\xEAs</span>
  <em>
    <span style="font-weight: 400;">PerOral Endoscopic Myotomy</span>
  </em>
  <span style="font-weight: 400;">, que tem mais incid\xEAncia de DRGE no p\xF3s-operat\xF3rio). Para acalasia dos subtipos I e II, qualquer um desses m\xE9todos parece ser adequado como estrat\xE9gia inicial, por\xE9m o subtipo III responde melhor \xE0 POEM ou \xE0 cirurgia de Heller, que permitem miotomias sob medida para incluir segmento esp\xE1stico observado na manometria.</span>
</p><p>
  <strong>Tratamento farmacol\xF3gico (toxina botul\xEDnica, f\xE1rmaco oral) \u2013</strong>
  <span style="font-weight: 400;">Se n\xE3o houver condi\xE7\xF5es para que o paciente seja submetido a um tratamento definitivo (por conta de comorbidades, por exemplo), h\xE1 op\xE7\xF5es farmacol\xF3gicas, como a inje\xE7\xE3o endosc\xF3pica de toxina botul\xEDnica (preferencial) e o uso de drogas orais, como bloqueador de canal de c\xE1lcio e nitrato administrados antes das refei\xE7\xF5es.</span>
</p><p>
  <strong>Esofagectomia \u2013</strong>
  <span style="font-weight: 400;">No est\xE1gio mais avan\xE7ado de acalasia, o es\xF4fago apresenta importante dilata\xE7\xE3o e tortuosidade (dolicomegaes\xF4fago), sendo indicada a esofagectomia, especialmente nos casos que falharam em outras interven\xE7\xF5es.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- C\xE2ncer \u2013</strong>
  <span style="font-weight: 400;">Portadores de acalasia t\xEAm maior risco de c\xE2ncer escamoso de es\xF4fago hipoteticamente a partir de uma displasia induzida por uma inflama\xE7\xE3o secund\xE1ria \xE0 estase. De qualquer forma, n\xE3o h\xE1 indica\xE7\xE3o formal de rastreio para tal condi\xE7\xE3o.</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<ol>
  <ol>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Vaezi MF, Pandolfino JE, Yadlapati RH, Greer KB, Kavitt RT. ACG Clinical Guidelines: Diagnosis and Management of Achalasia.</span>
      <em>
        <span style="font-weight: 400;">Am J Gastroenterol</span>
      </em>
      <span style="font-weight: 400;">2020;115:1393-1411.</span>
    </li>
  </ol>
</ol><ol>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Vaezi MF, Pandolfino JE, Yadlapati RH, Greer KB, Kavitt RT. ACG Clinical Guidelines: Diagnosis and Management of Achalasia.</span>
      <em>
        <span style="font-weight: 400;">Am J Gastroenterol</span>
      </em>
      <span style="font-weight: 400;">2020;115:1393-1411.</span>
    </li>
  </ol><ul>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Khashab MA, Vela MF, Thosani N, et al. ASGE guideline on the management of acalasia.</span>
    <em>
      <span style="font-weight: 400;">Gastrointest Endosc</span>
    </em>
    <span style="font-weight: 400;">2020;91(2):213-227</span>
  </li>
</ul><ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Oude Nijhuis R, Zaninotto G, Roman S, et al. European guidelines on achalasia: United European Gastroenterology and European Society of Neurogastroenterology and Motility recommendations.</span>
    <em>
      <span style="font-weight: 400;">United European Gastroenterology Journal</span>
    </em>
    <span style="font-weight: 400;">2020;8(1):13\u201333.</span>
  </li>
</ol><p>
  <span style="font-weight: 400;">Zaninotto G, Bennett C, Boeckxstaens G, et al. The 2018 ISDE achalasia guidelines.</span>
  <em>
    <span style="font-weight: 400;">Diseases of the Esophagus</span>
  </em>
  <span style="font-weight: 400;">2018;31(9):1-29.</span>
</p>`,ordem:6}],videos:[{id:"d3304632-5f07-418b-b602-7928352010a9",titulo:"T\xEDtulo  para Acalasia",duracao:5,thumbUrl:"https://i.vimeocdn.com/video/716648184_1920x1273.jpg?r=pad"},{id:"31074669-5644-4d31-b9f2-50b864728c5c",titulo:"V\xEDdeo do Bleggi",duracao:5,thumbUrl:"https://i.vimeocdn.com/video/716648184_1920x1273.jpg?r=pad"},{id:"c3c5899c-7502-4739-aa57-8c27d6679c56",titulo:"T\xEDtulo  para Acalasia",duracao:6,thumbUrl:"https://i.vimeocdn.com/video/716648141_1920x1273.jpg?r=pad"},{id:"68296103-f5f9-4673-b2e9-140a97063b7c",titulo:"T\xEDtulo  para Acalasia",duracao:5,thumbUrl:"https://i.vimeocdn.com/video/716648133_1920x1273.jpg?r=pad"}],fluxogramas:[],tags:["Megaes\xF4fago"]},{id:"9275293b-ee73-4300-b0f3-100cd5dd5b14",nome:"Apendicite Aguda",categoria:1,termosDeBusca:"apendicite aguda, apendice",favoritado:!1,ordem:0,especialidades:[{nome:"CIRURGIA"}],prescricoes:[{id:"e5cb8d0b-4c43-4b20-8e40-921e0d71287b",nome:"Apendicite N\xE3o-Complicada",favorito:!0,ordem:1,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"583c112c-00d9-43af-a16b-0f4d6c554e6f",opcoes:[{id:"d77790e6-0f5d-440b-b497-88083a9735e4",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s retorno da peristalse no p\xF3s-operat\xF3rio.",ordem:1},{item:"Hidrata\xE7\xE3o",grupos:[{grupo:"Analg\xE9sico",idGrupo:"8b4d9d85-f06a-45e6-8f90-210eae81426c",opcoes:[{id:"17a91a47-de60-4721-a70e-25e22116f5e3",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"Antibioticoprofilaxia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"bd354a6c-3ff2-402d-a2d0-c1a6327f0fed",opcoes:[{id:"f20b17ab-3b25-4a72-8d7e-0cba1d78455c",descr:"Ciprofloxacina 400 mg IV + Metronidazol\xA0 500 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"e5624152-4ba7-4a5d-b7fb-fe3d985b2356",descr:"Cefoxitina 2g IV + Metronidazol 500 mg IV",recomendado:!1,favorito:!1,ordem:2},{id:"d1754112-3c32-4d30-a5b9-df81790d2eba",descr:"Levofloxacina 500 mg IV + Metronidazol\xA0 500 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:3},{id:"f1b06eea-7cc0-4910-90f2-df08678246d4",descr:"Gentamicina 5 mg/Kg IV + Metronidazol\xA0 500 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:4},{id:"969c93ec-38ec-4529-b04a-27809148528f",descr:"Ciprofloxacina 400 mg IV + Clindamicina 900 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:5},{id:"436a017f-7862-493b-9292-46e23aa2e921",descr:"Levofloxacina 500 mg IV + Clindamicina 900 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:6},{id:"449e0928-6dd0-4973-b7bc-4ec32a42ae38",descr:"Aztreonam 2 g IV + Clindamicina 900 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:7},{id:"f6389d49-2e77-487c-9149-20bb4a7fbcfa",descr:"Gentamicina 5 mg/Kg IV + Clindamicina 900 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:8}],ordem:1}],academico:"Os casos n\xE3o-complicados recebem antibi\xF3tico apenas no pr\xE9-operat\xF3rio como profilaxia.",ordem:3},{item:"Analgesia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f6ec7f0b-ab36-43fe-bdf0-67c6ea27c4b0",opcoes:[{id:"b8159f00-7671-4063-9df6-fa0215542088",descr:"Cetorolaco (30mg/mL) 30 mg IV 6/6h - administrar em bolus de 15 segundos (para idoso, fazer metade da dose) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"73c36fdf-a86d-4d47-b804-9b4890f7bf57",descr:`Morfina (10 mg/mL) 1 mL + \xC1gua Destilada 9 mL (solu\xE7\xE3o: 1mg/mL) 2-4 mg IV agora\r
Repetir a cada 5/15 min at\xE9 controle da dor ou ocorr\xEAncia de efeitos colaterais`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Oferecer conforto ao paciente.",ordem:4},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"1a1af946-db3f-44d1-8956-b4c7f1d2f7c9",opcoes:[{id:"433ede09-a678-4afd-84ea-86fa4ca7977e",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"f383fca4-f1c2-4f15-a5e5-259ba55648cd",opcoes:[{id:"ef5592a6-3e77-4f89-ba2f-534e894a6f7d",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"779a6777-61f5-46a6-afe3-ba1636380f8e",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO)",recomendado:!1,favorito:!1,ordem:2},{id:"e6f545f4-6c4e-460c-b841-32e2cfea4626",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:5},{item:"Cuidados Gerais",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2fd5c3d6-45a0-43c5-84e0-e123c035b8b5",opcoes:[{id:"afca2692-faf5-4e74-9e0e-b11a00ba3f1e",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:6}],conceitosPraticos:[{conceito:"Em casos de alta probabilidade diagn\xF3stica, o exame de imagem confirmat\xF3rio (TC ou USG) n\xE3o \xE9 obrigat\xF3rio.",ordem:1},{conceito:"Apendicite n\xE3o-complicada \xE9 aquela que n\xE3o evoluiu com perfura\xE7\xE3o.",ordem:2},{conceito:"O tratamento resolutivo ideal envolve apendicectomia, preferencialmente laparosc\xF3pica.",ordem:3}]},{id:"b8280d73-b0a2-4d83-9ce2-031e2a238918",nome:"Apendicite Complicada",favorito:!1,ordem:2,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b7da7a56-f489-45d1-a318-195572d02db6",opcoes:[{id:"43277772-7a90-4938-ac8a-c558c61bdabf",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s retorno da peristalse no p\xF3s-operat\xF3rio.",ordem:1},{item:"Hidrata\xE7\xE3o",grupos:[],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"Antibioticoprofilaxia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"3695f5fa-76ec-490a-9f29-d9a99edaa30c",opcoes:[{id:"4b4cf0e7-492b-4bb5-bc56-e4d3b403bc1b",descr:"Ciprofloxacina 400 mg IV + Metronidazol\xA0 500 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"f13de1a7-83bb-4ebb-a485-839ff620d619",descr:"Cefazolina 2g IV + Metronidazol 500 mg IV",recomendado:!1,favorito:!1,ordem:2},{id:"7f090a9d-64ff-4cf2-aab6-3af1a32640e1",descr:"Cefotetan 2g IV + Metronidazol 500 mg IV",recomendado:!1,favorito:!1,ordem:3},{id:"3d5f1d03-882c-4957-b506-f3fa36d1f0b9",descr:"Cefoxitina 2g IV + Metronidazol 500 mg IV",recomendado:!1,favorito:!1,ordem:4},{id:"a93b8307-caa8-4d19-baff-3c8b9f6202fe",descr:"Levofloxacina 500 mg IV + Metronidazol\xA0 500 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:5},{id:"b12e76f1-ba86-4881-9d7a-a23c56b6311a",descr:"Gentamicina 5 mg/Kg IV + Metronidazol\xA0 500 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:6},{id:"0621ad33-53b5-4bef-8048-7eab47f397ac",descr:"Ciprofloxacina 400 mg IV + Clindamicina 900 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:7},{id:"95eb49d8-165e-4573-b2f1-33528a76bc09",descr:"Levofloxacina 500 mg IV + Clindamicina 900 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:8},{id:"955d5e29-2d29-4755-a518-0ba71e6a2006",descr:"Aztreonam 2 g IV + Clindamicina 900 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:9},{id:"b7c657fc-c232-470a-9a93-6983aa2fce21",descr:"Gentamicina 5 mg/Kg IV + Clindamicina 900 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:10}],ordem:1}],academico:"Empregada para a cirurgia.",ordem:3},{item:"Antibioticoterapia",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"276c29f2-dfdc-4994-a2b6-077a62cae84e",opcoes:[{id:"a2e3e50b-9839-42d6-aab4-7658d3a33093",descr:"Ciprofloxacina 400 mg IV 12/12h + Metronidazol 500 mg IV 8/8h (boa op\xE7\xE3o em caso de alergia \xE0 penicilina) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"f8db1ed5-dc3c-41d2-b902-cfa0065a7cfd",descr:"Levofloxacina 750 mg IV 1x/dia + Metronidazol 500 mg IV 8/8h (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:2},{id:"76e58a5f-1049-4bb7-8f84-e9285206981b",descr:"Cefepime 1 g IV 8/8h + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:3},{id:"8ee0a371-0854-4bfc-a997-a6e537612488",descr:"Piperacilina/Tazobactam 3,375-4,5 g IV 6/6h",recomendado:!1,favorito:!1,ordem:4},{id:"30a46d01-c904-4873-aadc-e378fb2a9a9c",descr:"Ertapenem\xA0 1g IV 1x/dia",recomendado:!1,favorito:!1,ordem:5},{id:"2f656617-55d6-45c7-889e-8831b6b6ddb0",descr:"Imipenem 500 mg IV 6/6h (reservado para casos mais graves)",recomendado:!1,favorito:!1,ordem:6},{id:"4c0f5878-0de5-4897-b53f-b98d4c608416",descr:"Meropenem 1g IV 8/8h (reservado para casos mais graves)",recomendado:!1,favorito:!1,ordem:7}],ordem:1}],academico:"Prescrita por 3-5 dias no p\xF3s-operat\xF3rio. N\xE3o prescrever ertapenem em casos graves ou de infec\xE7\xE3o hospitalar pela aus\xEAncia de cobertura adequada contra Acinetobacter e Pseudomonas.",ordem:4},{item:"Analgesia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ef87dea1-3f4c-4459-bcde-0ab8a9acc649",opcoes:[{id:"dac5737b-ea70-4992-bfc9-76ec91c6eae3",descr:"Cetorolaco (30mg/mL) 30 mg IV 6/6h - administrar em bolus de 15 segundos (para idoso, fazer metade da dose) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"35ce6b70-c72e-4e62-83a6-fe0809f0c5f3",descr:`Morfina (10 mg/mL) 1 mL + \xC1gua Destilada 9 mL (solu\xE7\xE3o: 1mg/mL) 2-4 mg IV agora\r
Repetir a cada 5/15 min at\xE9 controle da dor ou ocorr\xEAncia de efeitos colaterais`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Oferecer conforto ao paciente.",ordem:5},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f707e7f9-895e-4ada-9e13-6f3aa16db1c7",opcoes:[{id:"7b11f591-d441-44c9-8e69-0527715c215a",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"ffb01c1b-8ea5-46fe-85ac-34afccb5793d",opcoes:[{id:"58675547-ce37-4552-9aae-7534b266e20a",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"b8ce51c6-ef30-48a5-8ce9-0295f3d98239",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"3a61668b-a398-484b-90d8-af8177f1d923",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:6},{item:"Cuidados Gerais",grupos:[{grupo:"Analg\xE9sico",idGrupo:"514ca67a-c091-4fb4-b6a1-78208884fe79",opcoes:[{id:"2a58335a-5a9f-4673-8cea-4e5889aa77fd",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:7}],conceitosPraticos:[{conceito:"Em casos de alta probabilidade diagn\xF3stica, o exame de imagem confirmat\xF3rio (TC ou USG) n\xE3o \xE9 obrigat\xF3rio.",ordem:1},{conceito:"Apendicite complicada \xE9 aquela que evoluiu com perfura\xE7\xE3o.",ordem:2},{conceito:"O tratamento resolutivo ideal envolve apendicectomia, preferencialmente laparosc\xF3pica.",ordem:3},{conceito:"Apendicite complicada com abscesso \xE9 preferencialmente tratada sem cirurgia , associando-se drenagem percut\xE2nea \xE0 antibioticoterapia: a apendicectomia de intervalo (em 6-8 semanas) \xE9 reservada para casos com queixas recorrentes ou persistentes.",ordem:4}]},{id:"f585e1ec-5928-4a9b-9107-9f8acba91ba0",nome:"Apendicite sem Cirurgia",favorito:!1,ordem:3,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"5743a613-75f8-4b08-a1f9-2c6f1f5f3aa0",opcoes:[{id:"1d6c2cb2-7b10-4214-8671-cc759e4eafd7",descr:"Dieta oral conforme aceita\xE7\xE3o (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"b5492829-aa90-4917-a891-79ca00d20141",descr:"Dieta oral zero",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Nos primeiros dias, manter em dieta zero em caso de dor mais intensa.",ordem:1},{item:"Hidrata\xE7\xE3o",grupos:[{grupo:"Analg\xE9sico",idGrupo:"c0370963-0dcb-4b1e-b3de-8bfd97b3df82",opcoes:[{id:"ab3afeab-5a91-4d3f-ada8-20c2ac6e55c4",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"Antibioticoterapia IV",grupos:[{grupo:"Analg\xE9sico",idGrupo:"06d2cc5a-b7b2-441b-b09f-8f851614fa43",opcoes:[{id:"994f9a47-2de2-4ec3-ade6-8efbec25cce2",descr:"Ciprofloxacina 400 mg IV + Metronidazol\xA0 500 mg IV (boa op\xE7\xE3o em caso de alergia \xE0 penicilina) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"f35bfb16-e9db-4dc2-bb6d-a893d71cbb75",descr:"Piperacilina/Tazobactam 3,375-4,5 g IV 6/6h",recomendado:!1,favorito:!1,ordem:2},{id:"6eec9280-d2e2-4335-8fec-23937610970c",descr:"Ertapenem 1g IV 1x/dia",recomendado:!1,favorito:!1,ordem:3},{id:"25ce424f-bfd2-4d52-a62c-b445e8589609",descr:"Levofloxacina 750 mg IV 1x/dia + Metronidazol 500 mg IV 8/8h (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Empregada nos primeiros 3 dias.",ordem:3},{item:"Antibioticoterapia VO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"4231ac83-d29c-4060-9a74-11750cb57032",opcoes:[{id:"6e51d410-a351-455e-b5c0-19f0fd60bfc2",descr:"Ciprofloxacina 500 mg VO 12/12h + Metronidazol 500 mg VO 6/6h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"499652c9-b68d-4a79-b5d1-1897d5590f11",descr:"Levofloxacina 750 mg VO 1x/dia + Metronidazol 500 mg VO 6/6h",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Empregada por 7 dias (ap\xF3s t\xE9rmino dos 3 dias parenterais).",ordem:4},{item:"Analgesia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2d7e99ea-0605-46fb-9fbb-77884cbb08e8",opcoes:[{id:"86196f2e-28ce-4759-885b-b938b409aac1",descr:"Cetorolaco (30mg/mL) 30 mg IV 6/6h - administrar em bolus de 15 segundos (para idoso, fazer metade da dose) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"3e809817-ce11-49da-ae63-aa6ff943901c",descr:`Morfina (10 mg/mL) 1 mL + \xC1gua Destilada 9 mL (solu\xE7\xE3o: 1mg/mL) 2-4 mg IV agora\r
Repetir a cada 5/15 min at\xE9 controle da dor ou ocorr\xEAncia de efeitos colaterais`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Oferecer conforto ao paciente.",ordem:5},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2cb04531-99f2-4ebe-94b5-8a8a77279e4f",opcoes:[{id:"8848cdf0-2f72-4518-b0ea-0eaeba65e6da",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"b7540c86-1281-430c-bf06-ca5b8b1a433a",opcoes:[{id:"dbfca505-21a9-4eef-8bdb-0356c49db63d",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"6bb77450-d9e6-4984-91a9-2b35b1849c5a",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"e8e6e4c3-3513-4ec4-bd6b-ff8af39793e4",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:6},{item:"Cuidados Gerais",grupos:[{grupo:"Analg\xE9sico",idGrupo:"6427de3d-1875-430c-b95f-9f4952b2efb6",opcoes:[{id:"668811b8-8e2a-45a2-b03a-b696fa7bf38a",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:7}],conceitosPraticos:[{conceito:"Em casos de alta probabilidade diagn\xF3stica, o exame de imagem confirmat\xF3rio (TC ou USG) n\xE3o \xE9 obrigat\xF3rio.",ordem:1},{conceito:"O tratamento cl\xEDnico \xE9 pouco empregado, mas \xE9 uma op\xE7\xE3o para aqueles que desejam evitar a cirurgia e ainda aceitem o risco de recorr\xEAncia de at\xE9 38%, que ir\xE1 acaba levando \xE0 apendicectomia.",ordem:2}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">Apendicite aguda \xE9 a inflama\xE7\xE3o do ap\xEAndice vermiforme, sendo uma causa frequente de abdome agudo, com risco de evolu\xE7\xE3o com perfura\xE7\xE3o e peritonite. Sua frequ\xEAncia ao longo da vida atinge cerca de 1 em cada 10 pessoas, sendo discretamente mais comum em homens, especialmente entre 10 e 30 anos.</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">As manifesta\xE7\xF5es cl\xEDnicas iniciais incluem anorexia, n\xE1usea, v\xF4mito e dor abdominal, que inicialmente costuma ser periumbilical, mas classicamente, ap\xF3s cerca de 12 horas, pode migrar para fossa il\xEDaca direita, especialmente no chamado ponto de McBurney (entre ter\xE7o m\xE9dio e lateral da linha entre a cicatriz umbilical e a espinha il\xEDaca anterossuperior). H\xE1 possibilidade do quadro cl\xEDnico sofrer varia\xE7\xE3o na depend\xEAncia da posi\xE7\xE3o do ap\xEAndice: dor em flanco quando a localiza\xE7\xE3o for retrocecal; dor suprap\xFAbica associada a dis\xFAria, tenesmo e diarreia quando a localiza\xE7\xE3o for p\xE9lvica. Muitos sinais cl\xEDnicos ao exame f\xEDsico j\xE1 foram descritos para apendicite, mas nenhum \xE9 capaz de confirmar o diagn\xF3stico.</span>
</p><p>
  <span style="font-weight: 400;">Por conta do processo inflamat\xF3rio, pode ocorrer febre, leucocitose e eleva\xE7\xE3o da prote\xEDna C-reativa, que costumam aparecer de maneira mais acentuada em quadros de maior gravidade.</span>
</p><p>&nbsp;</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/672f652b-cb3f-4289-8bb4-055d33e52122.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>&nbsp;</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">O diagn\xF3stico \xE9 aventado a partir da reuni\xE3o de dados da hist\xF3ria, exame f\xEDsico e laborat\xF3rio. V\xE1rios escores j\xE1 foram desenvolvidos para avalia\xE7\xE3o da probabilidade diagn\xF3stica, sendo o Escore de Alvarado e o Escore Appendicitis Inflammatory Response (AIR) os mais utilizados no Plant\xE3o M\xE9dico.</span>
</p><p>
  <br>
</p><p>
  <img src="https://d55mnj1ee66xh.cloudfront.net/academico/763b9d1b-57f1-4ee4-af1b-4534b95aaa66.jpg" alt="" width="100%" height="auto">
</p><p>&nbsp;</p><p>
  <em>
    <span style="font-weight: 400;">Interpreta\xE7\xE3o: 0-4 = probabilidade baixa / 5-8 = probabilidade intermedi\xE1ria / \u2265 9 = probabilidade alta</span>
  </em>
</p><p>
  <span style="font-weight: 400;">A preocupa\xE7\xE3o inicial diante de um paciente com suspeita de apendicite aguda \xE9 buscar a confirma\xE7\xE3o diagn\xF3stica e estabelecer a necessidade de interven\xE7\xE3o cir\xFArgica. Em rela\xE7\xE3o \xE0 avalia\xE7\xE3o laboratorial, s\xE3o necess\xE1rios minimamente: hemograma (em especial, para avalia\xE7\xE3o do leucograma), prote\xEDna C-reativa, eletr\xF3litos, fun\xE7\xE3o renal e, para mulheres em idade f\xE9rtil,</span> 
  <span style="font-weight: 400;">\xDF</span> 
  <span style="font-weight: 400;">-HCG.&nbsp;</span>
</p><p>
  <strong>Exame de Imagem -</strong> 
  <span style="font-weight: 400;">Uma defini\xE7\xE3o que se imp\xF5e diz respeito \xE0 solicita\xE7\xE3o de exames de imagem para confirma\xE7\xE3o diagn\xF3stica, que acaba se baseando na probabilidade diagn\xF3stica estabelecida pela avalia\xE7\xE3o cl\xEDnica:</span>
</p><p>
  <span style="font-weight: 400;">- Probabilidade Alta: o exame de imagem, em tese, n\xE3o \xE9 obrigat\xF3rio (especialmente se o paciente for jovem), muito embora seja frequentemente realizado.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">- Probabilidade Intermedi\xE1ria: a realiza\xE7\xE3o do exame de imagem se imp\xF5e.</span>
</p><p>
  <span style="font-weight: 400;">- Probabilidade Baixa: embora o paciente possa ser mantido em observa\xE7\xE3o para uma nova avalia\xE7\xE3o em 6-8 horas, outros diagn\xF3sticos deveriam ser pensados, como diverticulite cecal, diverticulite de Meckel, ile\xEDte aguda, Doen\xE7a de Crohn, Doen\xE7a inflamat\xF3ria P\xE9lvica, Mittelschmerz, prenhez ect\xF3pica e nefrolit\xEDase.</span>
</p><p>
  <span style="font-weight: 400;">Os m\xE9todos de imagem recomendados s\xE3o a Tomografia Computadorizada (maior acur\xE1cia, mas com o inconveniente da radia\xE7\xE3o) e a Ultrassonografia (desvantagem de ser operador dependente). Atualmente, a tend\xEAncia tem sido optar primeiro pela USG \u2013 desde que haja possibilidade de exame de alta qualidade.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Em caso de popula\xE7\xE3o radiossens\xEDvel, como gestantes e crian\xE7as, tamb\xE9m n\xE3o h\xE1 d\xFAvidas sobre a prefer\xEAncia pela ultrassonografia, tendo a Resson\xE2ncia Magn\xE9tica como alternativa.</span>
  </em>
</p><p>
  <br>
  <img src="https://d55mnj1ee66xh.cloudfront.net/academico/fd9699af-31b6-4aa5-a9c8-17b1c022eb2a.jpg" alt="" width="100%" height="auto">
  <br>
  <br>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">A princ\xEDpio a abordagem terap\xEAutica da apendicite aguda \xE9 a apendicectomia, preferencialmente por laparoscopia por apresentar menos dor, menor incid\xEAncia de infec\xE7\xE3o de ferida operat\xF3ria, menor tempo de interna\xE7\xE3o e retorno mais r\xE1pido \xE0s atividades laborativas quando em compara\xE7\xE3o com a via aberta.</span>
</p><p>
  <strong>Antibi\xF3tico -</strong> 
  <span style="font-weight: 400;">Os casos n\xE3o-perfurados (n\xE3o-complicados) recebem antibi\xF3tico apenas no pr\xE9-operat\xF3rio como profilaxia. J\xE1, em situa\xE7\xF5es de apendicite perfurada (complicada), um esquema antimicrobiano \xE9 mantido no p\xF3s-operat\xF3rio at\xE9 melhora de par\xE2metros cl\xEDnicos e laboratoriais, como febre e leucocitose, o que ocorre, em geral, com 3-5 dias.</span>
</p><p>
  <span style="font-weight: 400;">Os esquemas antibi\xF3ticos \u2013 sejam eles para profilaxia ou terapia \u2013 devem cobrir germes gram-negativos e anaer\xF3bios</span>
</p><p>
  <strong>Apendicite Complicada com Abscesso ou Fleim\xE3o -</strong> 
  <span style="font-weight: 400;">Alguns casos de apendicite perfurada ainda evoluem com abscesso e, nesta situa\xE7\xE3o, embora a cirurgia seja uma op\xE7\xE3o terap\xEAutica, o tratamento de 1</span> 
  <span style="font-weight: 400;">a</span> 
  <span style="font-weight: 400;">linha \xE9 a drenagem percut\xE2nea associada \xE0 antibioticoterapia, ou seja, \xE9 um tratamento muito mais cl\xEDnico. Nos casos de pacientes acima de 40 anos tratados com essa abordagem n\xE3o-cir\xFArgica, deve ser realizada colonoscopia (ou enema baritado) ap\xF3s 4-6 semanas para afastar malignidade col\xF4nica.</span>
</p><p>
  <span style="font-weight: 400;">Nesses casos, tradicionalmente era cl\xE1ssica a indica\xE7\xE3o da chamada apendicectomia de intervalo em 6-8 semanas, entretanto atualmente ela n\xE3o deve ser rotineiramente recomendada, ficando reservada apenas para pacientes com queixas recorrentes ou persistentes.</span>
</p><p>
  <strong>Tratamento Cl\xEDnico da Apendicite</strong> 
  <span style="font-weight: 400;">- Antes, essa op\xE7\xE3o era restrita para os casos complicados com abscesso ou fleim\xE3o, como citado anteriormente. Evid\xEAncias recentes mostram a possibilidade do tratamento antibi\xF3tico por 10 dias, inicialmente por via intravenosa (2-3 dias) com subsequente convers\xE3o para via oral. Esta estrat\xE9gia poderia ser utilizada em pacientes que desejam evitar a cirurgia e ainda aceitem o risco de recorr\xEAncia de at\xE9 38%, que ir\xE1 acaba levando \xE0 apendicectomia mesmo assim. \xC9 uma op\xE7\xE3o ainda pouco empregada.
    <br>
  </span>
</p><p>&nbsp;</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/002ca3bf-f688-4a2c-9200-e0df0a04d041.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>&nbsp;</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Ap\xEAndice Normal na Cirurgia -</strong> 
  <span style="font-weight: 400;">Ainda n\xE3o h\xE1 um consenso absoluto em rela\xE7\xE3o ao tema, mas a tend\xEAncia \xE9 retirar o ap\xEAndice mesmo assim. Isso se justifica pelo fato do julgamento macrosc\xF3pico do cirurgi\xE3o ser impreciso e, assim, um ap\xEAndice com apar\xEAncia normal pode conter altera\xE7\xF5es que apenas uma avalia\xE7\xE3o histopatol\xF3gica pode interpretar.</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<p>
  <strong>&nbsp;</strong>
</p><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Di Saverio S, Birindelli A, Kelly MD, Catena F, Weber DG, et al. WSES Jerusalem guidelines for diagnosis and treatment of acute appendicitis.&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery 2016</span>
    </em> 
    <em>
      <span style="font-weight: 400;">,&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">11:</span>
    </em> 
    <em>
      <span style="font-weight: 400;">34.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Sartelli M, Pierluigi V, Catena F, Ansaloni L, et al. 2013 WSES guidelines for management of intra-abdominal infections.</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery 2013</span>
    </em> 
    <em>
      <span style="font-weight: 400;">,&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">8:</span>
    </em> 
    <em>
      <span style="font-weight: 400;">3.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Sartelli M, Catena F, Abu-Zidan FM, Ansaloni L, et al. Management of intra-abdominal infections: recommendations by the WSES 2016 consensus conference.</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery 2017</span>
    </em> 
    <em>
      <span style="font-weight: 400;">,&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">12:</span>
    </em> 
    <em>
      <span style="font-weight: 400;">22.&nbsp;</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">American College of Surgeons. Operation brochures: appendectomy, 2014 (https://www.facs.org/education/patient-education/ patient-resources/operations).</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Society for Surgery of the Alimentary Tract. SSAT patient care guidelines: appendicitis (http://ssat.com/guidelines/Appendicitis.cgi).</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Flum DR. Clinical practice: Acute Appendicitis - Appendectomy or the "Antibiotics First" Strategy. New England Journal of Medicine 2015,372:1937\u201343.</span>
    </em>
  </li>
</ul><p>&nbsp;</p>`,ordem:6}],videos:[{id:"392ba01b-6884-41d6-9160-5bd216451285",titulo:"T\xEDtulo  para Apendicite Aguda",duracao:10,thumbUrl:"https://i.vimeocdn.com/video/716647851_1920x1273.jpg?r=pad"}],fluxogramas:[{id:"8c2ae223-2af5-4d8b-ae9c-31e1a4eadfe8",nome:"Fluxograma de Apendicite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/d85327aa-fa38-4f11-bc0c-bf3ee1100905.jpg",orientacao:"horizontal"},{id:"6ce258c0-7a81-49e7-ba8d-464781824edb",nome:"Fluxograma de Apendicite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/7f1d7eaf-1e55-4ab2-b526-b02956326675.jpg",orientacao:"vertical"},{id:"b3b40207-d8d0-4a3a-bd03-7d8b9a115d1d",nome:"Fluxograma de Apendicite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/5028dd13-3388-4e27-902f-6de3845be39c.jpg",orientacao:"horizontal"},{id:"12205bca-5c9a-4508-ac93-3f24f1422f89",nome:"Fluxograma de Apendicite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/78c95027-003d-4ca1-bd6a-79874187937e.jpg",orientacao:"vertical"},{id:"65774bf4-f3a4-42cd-a1c8-93320f563bf1",nome:"Fluxograma de Apendicite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/dd59c188-5792-4d7b-b713-0f8ae67a4a49.jpg",orientacao:"horizontal"},{id:"27b01b88-01cd-4d6e-925d-689b801f0bcb",nome:"Fluxograma de Apendicite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/eb9bc378-2419-4c5b-bf3d-08f616428a8d.jpg",orientacao:"vertical"}],tags:["Ap\xEAndice"]},{id:"d5659be3-2ec2-4102-be22-17454e493f9f",nome:"Colecistite Aguda",categoria:1,termosDeBusca:"colecistite aguda, vesicula",favoritado:!1,ordem:0,especialidades:[{nome:"CIRURGIA"}],prescricoes:[{id:"73e95777-d460-4193-8c1a-9b32c7d2b026",nome:"Colecistite Aguda Leve-Moderada",favorito:!0,ordem:1,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"bb9dcab6-bfaa-4141-ac5a-77ac34e723cf",opcoes:[{id:"19742b1a-4987-4965-8028-1be79b2aefd7",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s retorno da peristalse no p\xF3s-operat\xF3rio.",ordem:1},{item:"Hidrata\xE7\xE3o",grupos:[{grupo:"Analg\xE9sico",idGrupo:"1c60e84a-84f9-4441-9a68-3b9a8265d18f",opcoes:[{id:"8c5639f6-a99d-4270-aa83-6afeea1e5869",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"Antibioticoterapia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e847feea-e73d-4c5e-9c19-74f06024f0e3",opcoes:[{id:"98b9682e-b149-4c01-a72c-2bd1e27ca38e",descr:"Ciprofloxacina 400 mg IV 12/12h + Metronidazol 500 mg IV 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"7d96d84c-0abb-4a8a-a870-2df450dbbc1c",descr:"Levofloxacina 750 mg IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:2},{id:"93c55aef-0d96-426f-ba7e-fa12845a2ad8",descr:"Ceftriaxone 1 g IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:3},{id:"f0723a7e-9bdd-4884-a417-036891a91d14",descr:"Cefotaxima 1-2 g IV 6/6h + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:4},{id:"658550b9-6654-4a20-8739-067fb3f518ac",descr:"Ertapenem 1 g IV 1x/dia",recomendado:!1,favorito:!1,ordem:5},{id:"e641f2ed-24e2-4b74-9508-a306420b0e74",descr:"Piperacilina/tazobactam 3,375 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:6},{id:"87644b76-53ea-4e98-b359-7b53aa95533a",descr:"Moxifloxacina 400 mg IV 1x/dia",recomendado:!1,favorito:!1,ordem:7}],ordem:1}],academico:"Nos casos de infec\xE7\xF5es hospitalares, acrescenta-se vancomicina ao esquema.",ordem:3},{item:"Analgesia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e3807472-381d-406c-ae29-5e8ebbd7fc8b",opcoes:[{id:"d89ee3d1-0031-46df-bca4-7443483ce264",descr:"Cetorolaco (30mg/mL) 30 mg IV 6/6h - administrar em bolus de 15 segundos (para idoso, fazer metade da dose) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"0422791a-c929-4a96-8c51-4049db8e6952",descr:"Meperidina 2 mL (50mg/mL) + \xC1gua Destilada 8 mL (solu\xE7\xE3o: 10mg/mL) 25-100 mg IV 4/4h",recomendado:!1,favorito:!1,ordem:2},{id:"fc2af051-79a6-4713-9294-151728cbac28",descr:"Morfina 1 mL (10mg/mL) + \xC1gua Destilada 9 mL (solu\xE7\xE3o: 1mg/mL) 5 mg IV 4/4h",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Uso regular na fase aguda",ordem:4},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"db6c139c-c411-4fc4-8ba8-e090152975d6",opcoes:[{id:"355b1ff1-591f-45b1-aac4-e75afbfb8df4",descr:"Paracetamol (500-750mg/comp) 750-1000 mg VO em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1},{id:"e22001d9-b35e-4001-8049-fb199bd70303",descr:"Dipirona (500-1000mg/comp) 500-1000 mg VO em caso de dor ou febre (at\xE9 6/6h)",recomendado:!1,favorito:!1,ordem:2}],ordem:1},{grupo:"antiem\xE9tico",idGrupo:"aee2bfb8-7ba1-4669-bea8-7a660c55bd68",opcoes:[{id:"390d213c-19b6-47f6-87dd-a7f689ec00bc",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"c9eaa8c0-126e-4af1-8f70-8c5d0f1a6222",descr:"Metoclopramida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"7cc6f7ad-d17f-4961-a70e-0c2136067112",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:3},{id:"7429419a-9811-4921-8d7f-1e2b35d96fb0",descr:"Bromoprida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:4},{id:"c8dbdbe0-37b6-42e8-8c61-6a5c47f03e9d",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:5}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:5},{item:"Cuidados Gerais",grupos:[{grupo:"Analg\xE9sico",idGrupo:"3be0c058-c3ed-44fe-ba3c-0fb137cf9b33",opcoes:[{id:"012ba803-a613-417e-b579-c1820bec2c59",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:6}],conceitosPraticos:[{conceito:"Colecistite grave: associada \xE0 a disfun\xE7\xE3o org\xE2nica, como hipotens\xE3o com necessidade de amina; redu\xE7\xE3o do n\xEDvel de consci\xEAncia; PaO2/FiO2 < 300; olig\xFAria ou creatinina > 2,0 mg/dL; INR > 1,5; plaquetas < 100.000/mm3.",ordem:1},{conceito:"Suspender antibi\xF3tico no dia seguinte \xE0 cirurgia nos casos n\xE3o-complicados e manter por mais 4-7 dias nos casos graves ou que apresentem complica\xE7\xF5es na ves\xEDcula durante a cirurgia (necrose, perfura\xE7\xE3o ou altera\xE7\xE3o enfisematosa).",ordem:2}]},{id:"3363b705-b26b-4b86-8c4d-61d440bfda6f",nome:"Colecistite Aguda Grave",favorito:!1,ordem:2,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b66c0e1c-091d-440d-81c2-e764fd955748",opcoes:[{id:"43a0c896-2794-4209-b055-df9aea041a2e",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s retorno da peristalse no p\xF3s-operat\xF3rio.",ordem:1},{item:"Hidrata\xE7\xE3o",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7c444fc1-c0cb-4c37-b201-c044f564c1a7",opcoes:[{id:"63589944-ea5f-4201-8f67-80436b47070c",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"Antibioticoterapia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"4fa7b9b5-45b5-4c67-9027-728f07515af5",opcoes:[{id:"5d865f02-8406-4fb1-96f9-579584dc6b38",descr:"Cefepime 2g IV 8/8h + Metronidazol 500 mg IV 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"66465e73-57c6-4bc8-b1fa-102937e57a36",descr:"Imipenem 500 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:2},{id:"0bb9be2d-751b-42ba-ad4b-edf2de67c602",descr:"Meropenem 1 g IV 8/8h",recomendado:!1,favorito:!1,ordem:3},{id:"078782ee-65e1-4ca0-8f15-c4aeb9fd117d",descr:"Piperacilina/tazobactam 4,5 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Nos casos de infec\xE7\xF5es hospitalares, acrescenta-se vancomicina ao esquema.",ordem:3},{item:"Analgesia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7fd5dd77-dd5a-41f4-89e0-48826c007e7c",opcoes:[{id:"ae4122af-2e22-4cc7-8672-1b4a98d0822a",descr:"Cetorolaco (30mg/mL) 30 mg IV 6/6h - administrar em bolus de 15 segundos (para idoso, fazer metade da dose) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Uso regular na fase aguda",ordem:4},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"fe70a65f-51f8-49de-884f-91f7c9da4203",opcoes:[{id:"c71a4c01-5f40-4593-aba0-6e9e5ae232d5",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"fe528e45-db67-4938-9aaf-8b47d3c9c42b",descr:"Dipirona (500-1000mg/comp) 500-1000 mg VO em caso de dor ou febre (at\xE9 6/6h)",recomendado:!1,favorito:!1,ordem:2},{id:"55e591f6-edb3-4b89-a416-44db736dd026",descr:"Paracetamol (500-750mg/comp) 750-1000 mg VO em caso de dor ou febre (at\xE9 6/6h)",recomendado:!1,favorito:!1,ordem:3}],ordem:1},{grupo:"antiem\xE9tico",idGrupo:"5d43ea99-64a7-4b35-ab45-2ab5599ace74",opcoes:[{id:"77518ca7-b56c-4a09-9897-583c703a7b55",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"3dafe93e-f5b1-454e-a07a-45177f0401bc",descr:"Metoclopramida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"6382c6a4-f048-4347-b05e-c25a3d41be49",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:3},{id:"1428b390-fa7d-4dc5-97e9-7dc92e3c42b5",descr:"Bromoprida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:4},{id:"ed939cb5-73f0-454e-b0d9-4c21604797cc",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:5},{id:"b93968a3-fe6f-449b-8eb4-e8fa9bda62a4",descr:"Ondansetrona (4-8mg/comp) 4-8 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:6}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:5},{item:"Cuidados Gerais",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7aadfc8f-9a90-45a3-8812-8b6f91584437",opcoes:[{id:"ce90f69b-329c-4051-95b0-8ae74ba1d878",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:6}],conceitosPraticos:[{conceito:"Colecistite grave: associada \xE0 a disfun\xE7\xE3o org\xE2nica, como hipotens\xE3o com necessidade de amina; redu\xE7\xE3o do n\xEDvel de consci\xEAncia; PaO2/FiO2 < 300; olig\xFAria ou creatinina > 2,0 mg/dL; INR > 1,5; plaquetas < 100.000/mm3.",ordem:1},{conceito:"Suspender antibi\xF3tico no dia seguinte \xE0 cirurgia nos casos n\xE3o-complicados e manter por mais 4-7 dias nos casos graves ou que apresentem complica\xE7\xF5es na ves\xEDcula durante a cirurgia (necrose, perfura\xE7\xE3o ou altera\xE7\xE3o enfisematosa).",ordem:2}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">Colecistite aguda \xE9 a inflama\xE7\xE3o da ves\xEDcula biliar, que, na maioria das vezes, decorre de uma obstru\xE7\xE3o do \xF3rg\xE3o por um c\xE1lculo biliar. Se ocorrer na aus\xEAncia de c\xE1lculo, \xE9 denominada de colecistite acalculosa, sendo encontrada, com maior frequ\xEAncia, em pacientes criticamente enfermos (em geral, v\xEDtimas de trauma, queimaduras, interna\xE7\xE3o prolongada em terapia intensiva ou em nutri\xE7\xE3o parenteral) e geralmente associada \xE0 obstru\xE7\xE3o da ves\xEDcula por lama biliar (bile mais espessa), al\xE9m de ter um progn\xF3stico mais reservado, com maiores taxas de mortalidade.</span>
</p><p>&nbsp;</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/3fbc3a00-3a63-4c24-b582-6c8fdaa52886.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>&nbsp;</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">A manifesta\xE7\xE3o mais cl\xE1ssica \xE9 uma intensa dor abdominal em hipoc\xF4ndrio direito (eventualmente referida tamb\xE9m em epigastro) com dura\xE7\xE3o maior do que 4-6 horas e frequentemente associada \xE0 ingesta de alimenta\xE7\xE3o gordurosa, pelo menos, 1 hora antes do in\xEDcio do quadro \xE1lgico. Manifesta\xE7\xF5es como febre, n\xE1usea, v\xF4mito e anorexia podem ocorrer.</span>
</p><p>
  <span style="font-weight: 400;">Ao exame f\xEDsico, os pacientes costumam apresentar o \u201CSinal de Murphy\u201D, que consiste na interrup\xE7\xE3o s\xFAbita da inspira\xE7\xE3o profunda durante a palpa\xE7\xE3o do hipoc\xF4ndrio direito pelo examinador.</span>
</p><p>
  <span style="font-weight: 400;">Na pr\xE1tica, a maior dificuldade \xE9 diferenciar a colecistite aguda de algo muito mais comum que \xE9 a c\xF3lica biliar decorrente apenas da contra\xE7\xE3o da ves\xEDcula que pressiona um c\xE1lculo contra o seu trato de sa\xEDda, mas sem a indu\xE7\xE3o da inflama\xE7\xE3o do \xF3rg\xE3o. Nessa \u201Csimples\u201D c\xF3lica biliar, a dor costuma atingir um auge e depois atenuar em um per\xEDodo inferior a 4-6 horas, al\xE9m de n\xE3o cursar com febre e nem com o \u201CSinal de Murphy\u201D.</span>
</p><p>
  <br>
</p><p>
  <img src="https://d55mnj1ee66xh.cloudfront.net/academico/d33ebe4f-2968-47f5-951d-26c77fe9d28e.jpg" alt="" width="100%" height="auto">
</p><p>&nbsp;</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">A avalia\xE7\xE3o laboratorial inclui a solicita\xE7\xE3o de hemograma (\xE9 comum a presen\xE7a de leucocitose com desvio para esquerda), eletr\xF3litos, prote\xEDna C-reativa, transminases, fosfatase alcalina, gama-GT, bilirrubina e, para mulheres em idade f\xE9rtil, beta-HCG.&nbsp; A eleva\xE7\xE3o de marcadores de colestase, como fosfatase alcalina e bilirrubina direta n\xE3o \xE9 esperada, ocorrendo principalmente em casos complicados com colangite, coledocolit\xEDase ou S\xEDndrome de Mirizzi.</span>
</p><p>
  <span style="font-weight: 400;">A confirma\xE7\xE3o diagn\xF3stica exige a realiza\xE7\xE3o de um exame de imagem. Em geral, o primeiro exame realizado (e, na maioria das vezes, suficiente para a conclus\xE3o) \xE9 a ultrassonografia abdominal, que pode visualizar a ves\xEDcula biliar com c\xE1lculos no interior e parede espessada, al\xE9m de permitir a pesquisa do \u201CSinal de Murphy ultrassonogr\xE1fico\u201D, que \xE9 a pesquisa do sinal usando o transdutor do ultrassom em substitui\xE7\xE3o \xE0 m\xE3o do examinador para a compress\xE3o da parede abdominal.</span>
</p><p>
  <span style="font-weight: 400;">Se a ultrassonografia for inconclusiva, deve ser utilizada a colecintigrafia (ou cintilografia biliar), que, entretanto, \xE9 um exame com baixa disponibilidade. As evid\xEAncias em rela\xE7\xE3o \xE0 acur\xE1cia da tomografia e da resson\xE2ncia s\xE3o escassas.</span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">O paciente deve ser internado, deixado em jejum, com reposi\xE7\xE3o h\xEDdrica, corre\xE7\xE3o eletrol\xEDtica, analgesia parenteral e antibi\xF3tico intravenoso, al\xE9m de ser planejada, com precocidade, uma colecistectomia preferencialmente laparosc\xF3pica. O ideal \xE9 que a cirurgia seja realizada nos primeiros 10 dias, idealmente nas primeiras 72 horas do in\xEDcio do quadro cl\xEDnico, uma vez que, quanto mais precoce for a cirurgia, mais curta ser\xE1 interna\xE7\xE3o e menos frequentes ser\xE3o as complica\xE7\xF5es. Caso a cirurgia n\xE3o seja feita nesse prazo, o mais adequado \xE9 que se planeje uma abordagem eletiva mais tardia \u2013 depois de, pelo menos, 45 dias (em geral, realizada em 3 meses).</span>
</p><p>
  <span style="font-weight: 400;">Os casos excessivamente graves \u2013 pacientes inst\xE1veis na terapia intensiva com disfun\xE7\xE3o org\xE2nica \u2013 podem ser abordados inicialmente com antibi\xF3tico e drenagem biliar (tamb\xE9m conhecida como colecistostomia). Nesta situa\xE7\xE3o, em caso de melhora, \xE9 planejada uma colecistectomia eletiva e, em caso contr\xE1rio, o mais prov\xE1vel \xE9 que tenha ocorrido gangrena da ves\xEDcula, sendo recomendada uma colecistectomia mesmo com o paciente em condi\xE7\xF5es cl\xEDnicas n\xE3o ideais.</span>
</p><p>
  <span style="font-weight: 400;">Nos pacientes de alto risco cir\xFArgico por conta de outras comorbidades significativas, \xE9 poss\xEDvel tentar inicialmente um tratamento conservador farmacol\xF3gico (apenas com antibioticoterapia e jejum) ou associ\xE1-lo \xE0 drenagem biliar, planejando a cirurgia eletiva posteriormente. O problema \xE9 que, al\xE9m de n\xE3o haver consenso sobre quem seria esse \u201Cpaciente de alto risco\u201D, tais abordagens n\xE3o se mostraram superiores \xE0 colecistectomia laparosc\xF3pica precoce.</span>
</p><p>
  <strong>Analgesia \u2013</strong> 
  <span style="font-weight: 400;">A analgesia pode ser feita com anti-inflamat\xF3rios (como cetorolaco) ou at\xE9 mesmo opioides (como morfina e meperidina) \u2013 esses \xFAltimos podem aumentar a press\xE3o no esf\xEDncter de Oddi (final da via biliar), mas tal fato n\xE3o contraindica o uso destas medica\xE7\xF5es.</span>
</p><p>
  <strong>Antibioticoterapia \u2013</strong> 
  <span style="font-weight: 400;">Embora alguns centros prescrevam antibi\xF3ticos apenas para casos com evid\xEAncias mais claras de infec\xE7\xE3o (leucocitose intensa, febre alta, imagem sugestiva de perfura\xE7\xE3o da ves\xEDcula), o mais cl\xE1ssico \xE9 que essa estrat\xE9gia seja utilizada rotineiramente. As op\xE7\xF5es dependem da gravidade do quadro:</span>
</p><p>
  <span style="font-weight: 400;">- Caso leve/moderado: ertapenem 1 mg 1x/dia OU piperacilina/tazobactam 3,375 mg 6/6h OU moxifloxacina 400 mg 1x/dia</span> 
  <span style="font-weight: 400;">OU (ceftriaxone 1 g 1x/dia ou cefotaxima 1-2 g 6/6h ou ciprofloxacina 400 mg 12/12h ou levofloxacina 750 mg 1x/dia) + metronidazol 500 mg 8/8h.</span>
</p><p>
  <span style="font-weight: 400;">- Caso grave ou imunodepress\xE3o: imipenem 500 mg 6/6h OU meropenem 1 g 8/8h OU piperacilina/tazobactam 4,5 mg 6/6h OU cefepime 2 g 8/8h + metronidazol 500 mg 8/8h</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Nos casos de infec\xE7\xF5es hospitalares, acrescenta-se vancomicina ao esquema. Se o paciente for colonizado por VRE (enterococo resistente \xE0 vancomicina) ou tiver feito uso recente de vancomicina, deve-se dar prefer\xEAncia \xE0 linezolida.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">A dura\xE7\xE3o da antibioticoterapia \xE9 individualizada pela situa\xE7\xE3o cl\xEDnica. De um modo geral, o antibi\xF3tico pode ser suspenso no dia seguinte \xE0 cirurgia nos casos n\xE3o-complicados. Entrentanto, nos casos graves ou que apresentem complica\xE7\xF5es na ves\xEDcula durante a cirurgia (necrose, perfura\xE7\xE3o ou altera\xE7\xE3o enfisematosa) \xE9 prudente manter o antibi\xF3tico por mais 4-7 dias.</span>
</p>`,ordem:4},{titulo:"COMPLICA\xC7\xD5ES",texto:`<p>
  <span style="font-weight: 400;">A colecistite pode evoluir com gangrena da parede da ves\xEDcula, com o risco de posterior perfura\xE7\xE3o do \xF3rg\xE3o. Nesses casos, o paciente costuma apresentar-se mais grave, com febre alta, instabilidade hemodin\xE2mica e dor intrat\xE1vel, sendo necess\xE1ria uma interven\xE7\xE3o de urg\xEAncia (cirurgia ou drenagem). Outra complica\xE7\xE3o evolutiva poss\xEDvel \xE9 o \xEDleo biliar, que consiste em uma obstru\xE7\xE3o intestinal no \xEDleo terminal por um c\xE1lculo que alcan\xE7ou o trato intestinal atrav\xE9s de uma f\xEDstula colecistoent\xE9rica resultante da perfura\xE7\xE3o da ves\xEDcula na dire\xE7\xE3o do duodeno ou jejuno.</span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/fe0c04ee-a453-4a59-bae5-21f3d51c78f3.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>&nbsp;</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- DIFICULDADE CIR\xDARGICA \u2013</strong> 
  <span style="font-weight: 400;">Em caso de dificuldade t\xE9cnica durante a realiza\xE7\xE3o de uma colecistectomia laparosc\xF3pica \u2013 em geral, por um intenso processo inflamat\xF3rio da ves\xEDcula detectado no ato operat\xF3rio, o cirurgi\xE3o deve converter a cirurgia para t\xE9cnica aberta ou realizar uma colecistectomia subtotal.</span>
</p><p>
  <strong>- COLECISTITE ENFISEMATOSA \u2013</strong> 
  <span style="font-weight: 400;">A colecistite enfisematosa ocorre por infec\xE7\xE3o da parede da ves\xEDcula por bact\xE9rias formadoras de g\xE1s (como</span> 
  <em>
    <span style="font-weight: 400;">Clostridium welchii</span>
  </em> 
  <span style="font-weight: 400;">), sendo uma complica\xE7\xE3o mais comumente observada em homens diab\xE9ticos. A manifesta\xE7\xE3o \xE9 similar \xE0 colecistite cl\xE1ssica, por\xE9m pode ter crepita\xE7\xE3o abdominal ao exame f\xEDsico, discreta eleva\xE7\xE3o de bilirrubina indireta (por hem\xF3lise associada \xE0 infec\xE7\xE3o pelo clostr\xEDdio) e uma dificuldade diagn\xF3stica pela ultrassonografia que pode erroneamente interpretar o ar presente na parede da ves\xEDcula como g\xE1s presente em al\xE7a intestinal atrapalhando a visualiza\xE7\xE3o. Essa forma de colecistite evolui mais frequentemente com gangrena e perfura\xE7\xE3o, sendo ainda mais importante a precocidade na indica\xE7\xE3o da cirurgia.</span>
</p><p>
  <strong>- COLEDOCOLIT\xCDASE ASSOCIADA \u2013</strong> 
  <span style="font-weight: 400;">Todo paciente com colecistite aguda deve ser avaliado quanto ao risco de apresentar coledocolit\xEDase associada. Os preditores de risco s\xE3o organizados em: (1) muito forte (coledocolit\xEDase ao USG); (2) fortes (col\xE9doco &gt; 6 mm no USG; bilirrubina total &gt; 1,8 mg/dL); (3) moderados (altera\xE7\xE3o em outro laborat\xF3rio hep\xE1tico al\xE9m da bilirrubina; idade &gt; 55 anos; pancreatite biliar). As categorias finais de risco de respectivas condutas s\xE3o:</span>
</p><p>
  <span style="font-weight: 400;">- Alto risco (presen\xE7a de preditor muito forte): colangiopancretografia retr\xF3grada endosc\xF3pica (CPRE) pr\xE9-operat\xF3ria ou colangiografia intraoperat\xF3ria</span>
</p><p>
  <span style="font-weight: 400;">- Risco Intermedi\xE1rio (presen\xE7a de outros preditores): avalia\xE7\xE3o da coledocolit\xEDase com colangiorresson\xE2ncia pr\xE9-operat\xF3ria, ultrassonografia endosc\xF3pica pr\xE9-operat\xF3ria ou colangiografia intraoperat\xF3ria.</span>
</p><p>
  <span style="font-weight: 400;">- Risco Baixo (aus\xEAncia de qualquer preditor): realiza\xE7\xE3o de colecistectomia sem avalia\xE7\xE3o adicional quanto \xE0 coledocolit\xEDase associada.</span>
</p>`,ordem:6},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<p>
  <strong>&nbsp;</strong>
</p><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Ansaloni L, Coccolini F, Peitzmann AB, et al. 2016 WSES Guidelines on Acute Calculous Cholecystitis.&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery</span>
    </em> 
    <em>
      <span style="font-weight: 400;">&nbsp;2016, 11:25.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Sartelli M, Pierluigi V, Catena F, Ansaloni L, et al. 2013 WSES guidelines for management of intra-abdominal infections.</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery 2013</span>
    </em> 
    <em>
      <span style="font-weight: 400;">,&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">8:</span>
    </em> 
    <em>
      <span style="font-weight: 400;">3.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Sartelli M, Catena F, Abu-Zidan FM, Ansaloni L, et al. Management of intra-abdominal infections: recommendations by the WSES 2016 consensus conference.</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery 2017</span>
    </em> 
    <em>
      <span style="font-weight: 400;">,&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">12:</span>
    </em> 
    <em>
      <span style="font-weight: 400;">22.&nbsp;</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Takada T, Strasberg SM, Solomkin JS, et al. TG13:</span>
    </em> 
    <em>
      <span style="font-weight: 400;">Updated Tokyo Guidelines for acute cholangitis and acute cholecystitis. J Hepatobiliary Pancreat Sci</span>
    </em> 
    <em>
      <span style="font-weight: 400;">2013, 20:1-109.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Solomkin JS, Mazuski JE, Bradley FS, et al. Diagnosis and Management of Complicated Intra-abdominal Infection in Adults and Children: Guidelines by the Surgical Infection Society and the Infectious Diseases Society of America. Clinical Infectious Diseases 2010; 50:133-64.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">European Association for the Study of the Liver. EASL Clinical Practice Guidelines on the prevention, diagnosis and treatment of gallstones. Journal of Hepatology 2016; 65:146-181.</span>
    </em>
  </li>
</ul><p>&nbsp;</p>`,ordem:7}],videos:[{id:"2b9f1216-a2f3-48a4-9313-cd5bbe54816c",titulo:"Aguda",duracao:15,thumbUrl:"https://i.vimeocdn.com/video/716648036_1920x1273.jpg?r=pad"},{id:"5499b507-60b9-4b56-8067-d146bbd9befb",titulo:"T\xEDtulo  para Colecistite Aguda",duracao:15,thumbUrl:"https://i.vimeocdn.com/video/716648036_1920x1273.jpg?r=pad"},{id:"cff83d6d-6417-42f9-b4d6-20c348cd5222",titulo:"T\xEDtulo  para Colecistite Aguda",duracao:15,thumbUrl:"https://i.vimeocdn.com/video/716647839_1920x1273.jpg?r=pad"}],fluxogramas:[{id:"86964537-2a2a-40dc-a622-ce551274557f",nome:"Fluxograma de Colecistite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/f1f2342e-ecab-415a-839d-219ce3de23bf.jpg",orientacao:"horizontal"},{id:"ae8f03a4-a3b0-4c94-9f01-2e7182f33ba8",nome:"Fluxograma de Colecistite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/2139797f-1ef7-4937-b6d5-f3572805ed2e.jpg",orientacao:"vertical"},{id:"e804ec83-2526-4737-b282-2658e5f5f6a9",nome:"Fluxograma de Colecistite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/0c28bd47-822c-4412-890a-53b4f3f8e20c.jpg",orientacao:"horizontal"},{id:"6b0e27ae-54b0-4e8a-9e9c-58ea3bfdde6f",nome:"Fluxograma de Colecistite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/8c933bc1-ae3f-44d9-ac35-c3f1e8044aed.jpg",orientacao:"vertical"}],tags:["Ves\xEDcula"]},{id:"f04603dd-c5e0-44d4-a3e4-53baa757cd19",nome:"Colite Pseudomembranosa",categoria:2,termosDeBusca:"colite pseudomembranosa, colite, pseudomembranosa, clostridioides, clostridium",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"8e1dee48-86f4-439a-abc4-a4f4b05f480d",nome:"1o epis\xF3dio (grave ou n\xE3o)",favorito:!0,ordem:1,secoes:[{item:"ANTIBI\xD3TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"475221ee-29a4-4937-8412-438ffeaf4a5b",opcoes:[{id:"a08bd6ed-8712-4498-950e-420615e0ec35",descr:`Fidaxomicina (200mg/cp) 200 mg VO/SNG 12/12h por 10 dias (MEDGRUPO)
Indispon\xEDvel no Brasil`,recomendado:!0,favorito:!0,ordem:1},{id:"29853370-b897-4115-af05-f7eeac437a4f",descr:"Vancomicina (125mg/cp) 125 mg VO/SNG 6/6h por 10 dias",recomendado:!1,favorito:!1,ordem:2},{id:"cfdebfe5-00f4-464c-bd33-805c1fda7721",descr:`Metronidazol (250mg/cp) 500 mg VO/SNG 8/8h por 10-14 dias\r
N\xE3o fazer em casos graves`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Discreta prefer\xEAncia pela fidaxomicina; metronidazol n\xE3o \xE9 op\xE7\xE3o para casos graves.",ordem:1}],conceitosPraticos:[{conceito:"Tratar apenas sintom\xE1ticos: diarreia com \u2265 3 epis\xF3dios de fezes mal-formadas em 24h.",ordem:1},{conceito:"Infec\xE7\xE3o n\xE3o-grave: leuc\xF3citos < 15 mil/mm3 e creatinina \u2264 1,5 mg/dL.",ordem:2},{conceito:"Infec\xE7\xE3o grave: leuc\xF3citos \u2265 15 mil/mm3 ou creatinina > 1,5 mg/dL.",ordem:3},{conceito:"Infec\xE7\xE3o fulminante: infec\xE7\xE3o grave + (hipotens\xE3o ou choque ou \xEDleo ou megac\xF3lon).",ordem:4}]},{id:"92d9682e-a5e0-4297-b49a-db179ffb10cf",nome:"Recorr\xEAncia",favorito:!1,ordem:2,secoes:[{item:"ANTIBI\xD3TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"bdf24c5f-03b7-46e9-9d67-5dc901a9b46d",opcoes:[{id:"aa1e134a-1683-4d07-b3e9-2b06a17697f5",descr:`Fidaxomicina (200mg/cp) 200 mg VO/SNG 12/12h por 10 dias (MEDGRUPO)
Indispon\xEDvel no Brasil`,recomendado:!0,favorito:!0,ordem:1},{id:"9fdea7de-20c5-4f24-abd2-9c23aaafafa1",descr:`Fidaxomicina (200mg/cp) 200 mg VO/SNG 12/12h por 5 dias, seguido de 1x/dia por 20 dias\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:2},{id:"8ed2c896-d33d-4868-a5fc-b0c5d1284095",descr:"Vancomicina (125mg/cp) 125 mg VO/SNG 6/6h por 10 dias",recomendado:!1,favorito:!1,ordem:3},{id:"a65e1f47-3651-400b-a082-3de64318f97b",descr:"Vancomicina (125mg/cp) 125 mg VO/SNG 6/6h por 10-14 dias, seguido de 12/12h por 7 dias, 1x/dia por 7 dias, 1x a cada 2-3 dias por 2-8 sem",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Discreta prefer\xEAncia pela fidaxomicina; metronidazol n\xE3o \xE9 op\xE7\xE3o para casos graves.",ordem:1},{item:"ANTICORPO MONOCLONAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"603adbfc-6974-4650-973c-8091c1f1d870",opcoes:[{id:"9422d21f-1e85-43a9-b924-5a55be872529",descr:"Bezlotoxumabe (25mg/mL) 10 mg/Kg IV dose \xFAnica (administrar em 60 min)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Atua contra a toxina B; pode ser considerado nos casos de recorr\xEAncia em at\xE9 6 meses.",ordem:2}],conceitosPraticos:[{conceito:"Tratar apenas sintom\xE1ticos: diarreia com \u2265 3 epis\xF3dios de fezes mal-formadas em 24h.",ordem:1},{conceito:"Infec\xE7\xE3o n\xE3o-grave: leuc\xF3citos < 15 mil/mm3 e creatinina \u2264 1,5 mg/dL.",ordem:2},{conceito:"Infec\xE7\xE3o grave: leuc\xF3citos \u2265 15 mil/mm3 ou creatinina > 1,5 mg/dL.",ordem:3},{conceito:"Infec\xE7\xE3o fulminante: infec\xE7\xE3o grave + (hipotens\xE3o ou choque ou \xEDleo ou megac\xF3lon).",ordem:4}]},{id:"9256f941-e625-4694-a8dd-6c6fb5b06a07",nome:"Forma Fulminante",favorito:!1,ordem:3,secoes:[{item:"ANTIBI\xD3TICO VO/SNG",grupos:[{grupo:"Analg\xE9sico",idGrupo:"674b2fde-fbfd-4ab2-8241-f1d979152618",opcoes:[{id:"a096a4cb-df4b-4eef-8cc3-96289af154d9",descr:`Vancomicina (125mg/cp) 500 mg VO/SNG 6/6h\r
Se houver melhor em 48-72h, reduz para 125 mg 6/6h por mais 10 dias`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Discreta prefer\xEAncia pela fidaxomicina.",ordem:1},{item:"ANTIBI\xD3TICO IV",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7507ac78-0bc5-4d0a-825a-d9991db7f163",opcoes:[{id:"be747296-e8d8-4540-94e9-f6f2bf58d488",descr:"Metronidazol (5mg/mL) 500 mg IV 8/8h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:2},{item:"ANTIBI\xD3TICO IV",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ffc8a6cb-426f-41c3-9cc0-a361a05c526f",opcoes:[{id:"0552cc66-0070-4528-8c4e-f83293864773",descr:"Metronidazol (5mg/mL) 500 mg IV 8/8h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:2},{item:"ANTIBI\xD3TICO IV",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7b7aeb23-cf04-48c3-a6f1-ea7397e27f49",opcoes:[{id:"c4a2fee4-9802-4659-ba26-75ba5be3b1b0",descr:"Metronidazol (5mg/mL) 500 mg IV 8/8h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:2},{item:"ANTIBI\xD3TICO IV",grupos:[{grupo:"Analg\xE9sico",idGrupo:"5a67093f-379d-498b-8552-d6737475a035",opcoes:[{id:"a0a784e8-4028-4b2a-a69e-098e0a1b4551",descr:"Metronidazol (5mg/mL) 500 mg IV 8/8h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:2},{item:"ANTIBI\xD3TICO RETAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ea763d48-50e3-4314-8552-46717c4bd823",opcoes:[{id:"2fff8266-ef11-43df-bc18-4ea2645dd910",descr:"Vancomicina (125mg/cp) 500 mg + SF 0,9% 100 mL - enema intrarretal 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Acrescentar em caso de \xEDleo.",ordem:3}],conceitosPraticos:[{conceito:"Tratar apenas sintom\xE1ticos: diarreia com \u2265 3 epis\xF3dios de fezes mal-formadas em 24h.",ordem:1},{conceito:"Infec\xE7\xE3o n\xE3o-grave: leuc\xF3citos < 15 mil/mm3 e creatinina \u2264 1,5 mg/dL.",ordem:2},{conceito:"Infec\xE7\xE3o grave: leuc\xF3citos \u2265 15 mil/mm3 ou creatinina > 1,5 mg/dL.",ordem:3},{conceito:"Infec\xE7\xE3o fulminante: infec\xE7\xE3o grave + (hipotens\xE3o ou choque ou \xEDleo ou megac\xF3lon).",ordem:4}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">O</span>
  <em>
    <span style="font-weight: 400;">Clostridioides difficile</span>
  </em>
  <span style="font-weight: 400;">\xE9 um anaer\xF3bio gram-positivo, cujo processo infeccioso leva \xE0 produ\xE7\xE3o de toxinas A e B que induzem inflama\xE7\xE3o col\xF4nica e diarreia. O principal fator de risco para essa infec\xE7\xE3o \xE9 o uso de antibi\xF3ticos, que modifica a flora bacteriana, facilitando a multiplica\xE7\xE3o do</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">e a libera\xE7\xE3o de suas toxinas \u2013 qualquer antibi\xF3tico carrega esse potencial, com maior risco para fluoroquinolonas, clindamicina, cefalosporinas, carbapen\xEAmicos e penicilina.</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">A principal manifesta\xE7\xE3o de infec\xE7\xE3o pelo</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">\xE9 a diarreia aquosa, embora o paciente tamb\xE9m possa manifestar dor abdominal, c\xF3lica, febre, n\xE1usea e anorexia. H\xE1 risco de um quadro fulminante de colite, em que ocorre hipotens\xE3o ou choque ou megac\xF3lon.</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">Como existe a situa\xE7\xE3o de carreador assintom\xE1tico da bact\xE9ria, a pesquisa de infec\xE7\xE3o por</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">s\xF3 deve ser feita nos casos com sintomas sugestivos: diarreia com \u2265 3 epis\xF3dios de fezes mal-formadas em 24h. A proposta diagn\xF3stica passa por 2 etapas em exames de fezes.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">Em uma 1\xAA etapa, utiliza-se um teste altamente sens\xEDvel, capaz de detectar a bact\xE9ria ou o material gen\xE9tico produtor de toxina, mas sem garantir ainda que exista infec\xE7\xE3o de fato com produ\xE7\xE3o aumentada de toxinas:&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">- PCR (teste de amplifica\xE7\xE3o de \xE1cido nucleico \u2013 NAAT), que detecta os genes respons\xE1vel pela produ\xE7\xE3o das toxinas A (tcdA) e B (tcdB); OU</span>
</p><p>
  <span style="font-weight: 400;">- Pesquisa de GDH (glutamato desidrogenase), ant\xEDgeno produzido por todas as cepas de</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">(toxig\xEAnicas e n\xE3o-toxig\xEAnicas).</span>
</p><p>
  <span style="font-weight: 400;">Se avalia\xE7\xE3o da 1\xAA etapa, foi negativa, exclui-se a infec\xE7\xE3o pelo</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">, mas, em caso de exame positivo, parte-se para a 2\xAA etapa, que utiliza um teste mais espec\xEDfico, ou seja, a pesquisa direta das toxinas A e B nas fezes por imunoensaio: a positividade confirma, enfim, a infec\xE7\xE3o pelo</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Caso a pesquisa de toxinas vier negativa, pode significar apenas uma coloniza\xE7\xE3o mesmo ou ainda um falso negativo, de modo que, se a suspeita cl\xEDnica for ainda muito forte, deve-se considerar o tratamento.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Ao diagn\xF3stico, \xE9 importante tamb\xE9m definir a gravidade do quadro infeccioso:</span>
</p><p>
  <span style="font-weight: 400;">- Infec\xE7\xE3o n\xE3o-grave: leuc\xF3citos &lt; 15 mil/mm</span>
  <span style="font-weight: 400;">3</span>
  <span style="font-weight: 400;">e creatinina \u2264 1,5 mg/dL;</span>
</p><p>
  <span style="font-weight: 400;">- Infec\xE7\xE3o grave: leuc\xF3citos \u2265 15 mil/mm</span>
  <span style="font-weight: 400;">3</span>
  <span style="font-weight: 400;">ou creatinina &gt; 1,5 mg/dL;</span>
</p><p>
  <span style="font-weight: 400;">- Infec\xE7\xE3o fulminante: infec\xE7\xE3o grave associada a hipotens\xE3o ou choque ou \xEDleo ou megac\xF3lon.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Outras caracter\xEDsticas associadas a pior progn\xF3stico: hipoalbuminemia, calprotectina fecal elevada (&gt; 2.000 mcg/g), eosinopenia, temperatura &gt; 38,5</span>
  </em>
  <em>
    <span style="font-weight: 400;">o</span>
  </em>
  <em>
    <span style="font-weight: 400;">C, infec\xE7\xE3o pela cepa NAP/027/BI (mais toxinas A e B, produz uma terceira toxina - toxina bin\xE1ria CDT - e tem alto n\xEDvel de resist\xEAncia a quinolonas), idade &gt; 65 anos.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">
      <img src="https://d55mnj1ee66xh.cloudfront.net/academico/848f12b2-e75a-487a-852b-e48678ed7f58.jpg" alt="" width="100%" height="auto">
    </span>
  </em>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">O tratamento antimicrobiano \xE9 indicado para casos sintom\xE1ticos e com comprova\xE7\xE3o diagn\xF3stica da infec\xE7\xE3o \u2013 portanto n\xE3o h\xE1 indica\xE7\xE3o de terapia para pacientes apenas com diagn\xF3stico laboratorial, uma vez que carreadores assintom\xE1ticos s\xE3o comuns.</span>
</p><p>
  <strong>Primeiro epis\xF3dio (n\xE3o-grave ou grave) \u2013</strong>
  <span style="font-weight: 400;">Para o primeiro epis\xF3dio de casos graves ou n\xE3o-graves, as principais op\xE7\xF5es terap\xEAuticas s\xE3o fidaxomicina (200 mg 12/12h) ou vancomicina (125 mg 6/6h), ambos por via oral (ou sonda) por 10 dias, com discreta prefer\xEAncia pela primeira. Em casos de risco mais baixo (casos n\xE3o-graves em pacientes jovens e com m\xEDnimas comorbidades), o metronidazol (500 mg 8/8h) por 10-14 dias \xE9 tamb\xE9m uma op\xE7\xE3o.</span>
</p><p>
  <strong>Recorr\xEAncia \u2013</strong>
  <span style="font-weight: 400;">Em caso de recorr\xEAncia, as op\xE7\xF5es continuam a ser fidaxomicina e vancomicina por via oral; com, mais uma vez, discreta prefer\xEAncia pela primeira. Os esquemas posol\xF3gicos podem ser os mesmos citados anteriormente ou utilizados em estrat\xE9gia de pulso decrescente: fidaxomicina 200 mg 12/12h por 5 dias seguido por 1x/dia por 20 dias OU vancomicina 125 mg 6/6h por 10-14 dias, 12/12h por 7 dias, 1x/dia por 7 dias e, por fim, 1x a cada 2-3 dias por 2-8 semanas.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* A l\xF3gica da estrat\xE9gia em pulso decrescente est\xE1 na possibilidade de facilitar o retorno gradual da microbiota col\xF4nica e ainda atingir amostras de C. difficile vegetetativos liberados por esporos fecais persistentes.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Em caso de recorr\xEAncia dentro de 6 meses, o bezlotoxumabe (10 mg/Kg IV ao longo de 60 minutos, em dose \xFAnica) pode ser acrescentado ao esquema antibi\xF3tico \u2013 trata-se de um anticorpo monoclonal contra a toxina B do</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">, por\xE9m deve ser usado com cautela em portadores de insufici\xEAncia card\xEDaca. H\xE1 uma corrente que defende considerar esse f\xE1rmaco no primeiro epis\xF3dio de pacientes &gt; 65 anos que tenham infec\xE7\xE3o grave ou sejam imunocomprometidos.&nbsp;</span>
</p><p>
  <strong>Epis\xF3dio fulminante \u2013</strong>
  <span style="font-weight: 400;">Para os epis\xF3dios fulminantes, como n\xE3o h\xE1 dados que suportem o uso de fidaxomicina, o esquema inclui vancomicina oral (ou por sonda) inicialmente em dose alta (500 mg 6/6h) geralmente associada ao metronidazol intravenoso (500 mg 8/8h). Se houver melhora cl\xEDnica ap\xF3s 48-72h, a dose da vancomicina pode ser reduzida para 125 mg 6/6h por mais 10 dias. Na presen\xE7a de \xEDleo, deve-se acrescentar, a todo o esquema proposto, a instila\xE7\xE3o de vancomicina retal (500 mg 6/6h).</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* A justificativa para a associa\xE7\xE3o de metronidazol IV \xE9 a poss\xEDvel lentid\xE3o na chegada da vancomicina at\xE9 o c\xF3lon aliada ao fato de que concentra\xE7\xF5es terap\xEAuticas de metronidazol nas fezes serem atingidas pela medica\xE7\xE3o intravenosa em virtude da excre\xE7\xE3o biliar e intestinal do f\xE1rmaco.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Em casos refrat\xE1rios ap\xF3s 3-5 dias de tratamento antibi\xF3tico, h\xE1 op\xE7\xE3o de transplante de microbiota fecal (instila\xE7\xE3o de fezes processadas de doador no trato gastrointestinal do paciente) ou cirurgia, est\xE1 \xFAltima \xE9 ainda mais imperativa em casos de isquemia col\xF4nica ou perfura\xE7\xE3o e tem, como op\xE7\xF5es principais, a colectomia total com ileostomia distal ou a estrat\xE9gia de ileostomia em al\xE7a com lavagem col\xF4nica.</span>
</p><p>
  <strong>Profilaxia secund\xE1ria \u2013</strong>
  <span style="font-weight: 400;">Os pacientes que apresentam \u2265 2 recorr\xEAncias podem se beneficiar de transplante de microbiota fecal via colonoscopia ou c\xE1psula (na aus\xEAncia destas, o enema \xE9 outra op\xE7\xE3o). Se ainda assim houver mais recorr\xEAncias, pode-se repetir o transplante de microbiota fecal ou fazer uma tentativa de supress\xE3o cr\xF4nica com vancomicina 125 mg VO 1x/dia por, pelo menos, 8 semanas.</span>
</p><p>
  <span style="font-weight: 400;">Nos pacientes que apresentaram um quadro recente de infec\xE7\xE3o por</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">, h\xE1 o receio de novo epis\xF3dio caso ele precisa ser submetido a uma antibioticoterapia. Assim, uma estrat\xE9gia profil\xE1tica pode ser oferecida, especialmente naqueles casos com infec\xE7\xE3o por</span>
  <em>
    <span style="font-weight: 400;">C.</span>
  </em> 
  <em>
    <span style="font-weight: 400;">difficile</span>
  </em>
  <span style="font-weight: 400;">nos \xFAltimos 3 meses que tenham maior risco de recorr\xEAncia (&gt; 65 anos ou imunocomprometido). A estrat\xE9gia recomendada \xE9 o uso de vancomicina 125 mg VO 1x/dia por 5 dias ap\xF3s o t\xE9rmino da antibioticoterapia.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Inibidor de bomba de pr\xF3ton \u2013</strong>
  <span style="font-weight: 400;">Embora haja uma associa\xE7\xE3o te\xF3rica entre estrat\xE9gias de supress\xE3o \xE1cida, como o uso de inibidor de bomba de pr\xF3ton, n\xE3o h\xE1 obriga\xE7\xE3o de suspens\xE3o deste tipo de f\xE1rmaco durante uma infec\xE7\xE3o por</span>
  <em>
    <span style="font-weight: 400;">C. difficile</span>
  </em>
  <span style="font-weight: 400;">, desde que a indica\xE7\xE3o para seu uso seja adequada.</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Johnson S, Lavergne V, Skinner AM, et al. Clinical Practice Guideline by the Infectious Diseases Society of America (IDSA) and Society for Healthcare Epidemiology of America (SHEA): 2021 Focused Update Guidelines on Management of</span>
    <em>
      <span style="font-weight: 400;">Clostridioides difficile</span>
    </em>
    <span style="font-weight: 400;">Infection in Adults.</span>
    <em>
      <span style="font-weight: 400;">Clinical Infectious Diseases</span>
    </em>
    <span style="font-weight: 400;">2021;73(5):1029\u20131044.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Kelly CR, Fischer M, Allegretti JR, et al.</span> 
    <span style="font-weight: 400;">ACG Clinical Guidelines: Prevention, Diagnosis, and Treatment of</span>
    <em>
      <span style="font-weight: 400;">Clostridioides difficile</span>
    </em>
    <span style="font-weight: 400;">Infections.</span>
    <em>
      <span style="font-weight: 400;">Am J Gastroenterol</span>
    </em>
    <span style="font-weight: 400;">2021;116:1124-1147.</span>
  </li>
</ol><p>
  <span style="font-weight: 400;">Poylin V, Hawkins AT, Bhama AR, et al. The American Society of Colon and Rectal Surgeons Clinical Practice Guidelines for the Management of</span>
  <em>
    <span style="font-weight: 400;">Clostridioides difficile</span>
  </em>
  <span style="font-weight: 400;">Infection.</span>
  <em>
    <span style="font-weight: 400;">Diseases of the Colon &amp; Rectum</span>
  </em>
  <span style="font-weight: 400;">2021;64(6):650-668.</span>
</p>`,ordem:6}],videos:[],fluxogramas:[],tags:["Colite","Pseudomembranosa","Clostridioides","Clostridium"]},{id:"ffe31ee6-71b9-4558-add5-969d019392d1",nome:"Desordens da Peristalse Esofagiana",categoria:2,termosDeBusca:"desordens da peristalse esofagiana, espasmo esofagiano difuso, espasmo esofagiano distal, esofago hipercontratil, quebra-nozes, motilidade esofagiana ineficaz, ausencia de contratilidade, batedeira",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"3d8385aa-4bfb-4071-9e12-5196ae925539",nome:"Desordem da Peristalse Es\xF4fago",favorito:!0,ordem:1,secoes:[{item:"PROCIN\xC9TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"61005582-efaf-49d5-abb3-7c5be60c2103",opcoes:[{id:"45621009-2323-4fdb-b0d6-737726344ddb",descr:"Metoclopramida (10mg/cp) 10 mg VO 2-3x/dia (antes das refei\xE7\xF5es) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"f9330a3b-ba25-417f-92ca-808d0d009c25",descr:"Metoclopramida (4mg/mL) 10 mg VO 2-3x/dia (antes das refei\xE7\xF5es)",recomendado:!1,favorito:!1,ordem:2},{id:"1f327bcf-6c72-48bc-98ca-4005565ebac2",descr:"Domperidona (10mg/cp) 10 mg VO 3x/dia (antes das refei\xE7\xF5es)",recomendado:!1,favorito:!1,ordem:3},{id:"ba045348-2cd0-4269-b524-f5b89d4cc73e",descr:"Domperidona (1mg/mL) 10 mg VO 3x/dia (antes das refei\xE7\xF5es)",recomendado:!1,favorito:!1,ordem:4},{id:"408d4464-8a21-4882-80ba-488c5780a504",descr:`Prucaloprida (1-2mg/cp) 2 mg VO 1x/dia\r
Se ClCr < 30 mL/min: 1mg VO 1x/dia`,recomendado:!1,favorito:!1,ordem:5},{id:"277c3acf-8c0e-4e3a-b152-a0c9cb81f476",descr:`Cisaprida (5-10mg/cp) 5-10 mg VO 4x/dia (antes das refei\xE7\xF5es)\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:6}],ordem:1}],academico:'Op\xE7\xE3o na "aus\xEAncia de contratilidade".',ordem:1},{item:"ERITROMICINA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"0b021b50-c5f5-462f-941b-aaf17645dc3a",opcoes:[{id:"310baeb1-737c-4f1e-9974-c91a88882f9b",descr:"Eritromicina (500mg/cp) 500 mg VO 3x/dia (antes das refei\xE7\xF5es) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"5c6436f5-552b-40b4-93e4-e341b03e3399",descr:"Eritromicina (25-50mg/mL) 250-500 mg VO 3x/dia (antes das refei\xE7\xF5es)",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:'Alternativa ao procin\xE9tico na "aus\xEAncia de contratilidade";risco de redu\xE7\xE3o da efic\xE1cia (taquifilaxia) ap\xF3s 4 semanas.',ordem:2},{item:"BLOQUEADOR DE CANAL DE C\xC1LCIO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"9f90652d-680a-4ac9-a301-896e15b1ab8d",opcoes:[{id:"18845c42-f05d-405b-987f-858a9295f705",descr:"Diltiazem (30-90mg/cp) 60-90 mg VO 3x/dia (antes das refei\xE7\xF5es)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:'Op\xE7\xE3o no "espasmo esofagiano distal" e no "es\xF4fago hipercontr\xE1til".',ordem:3}],conceitosPraticos:[{conceito:"Realizar EDA para excluir obstru\xE7\xE3o mec\xE2nica.",ordem:1},{conceito:"Padr\xE3o-ouro: esofagomanometria de alta resolu\xE7\xE3o.",ordem:2},{conceito:"Aus\xEAncia de contratilidade: IRP normal + 100% das contra\xE7\xF5es falhas.",ordem:3},{conceito:"Espasmo esofagiano distal: IRP normal + \u2265 20% das degluti\xE7\xF5es com contra\xE7\xF5es prematuras.",ordem:4},{conceito:"Es\xF4fago hipercontr\xE1til: IRP normal + \u2265 20% das degluti\xE7\xF5es com hipercontratilidade.",ordem:5},{conceito:"Motilidade esofagiana ineficaz: IRP normal + \u2265 70% das contra\xE7\xF5es ineficazes ou \u2265\xA050% das contra\xE7\xF5es falhas.",ordem:6}]}],topicos:[],videos:[],fluxogramas:[],tags:["Espasmo Esofagiano Difuso","Espasmo Esofagiano Distal","Es\xF4fago Hipercontr\xE1til","Quebra-nozes","Motilidade esofagiana ineficaz","aus\xEAncia de contratilidade","Batedeira"]},{id:"2de832f5-f37a-43fd-8f6e-0fccd8f0fdec",nome:"Diarreia Aguda",categoria:1,termosDeBusca:"diarreia aguda, disenteria, desidratacao",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"55a05196-8849-477d-b01b-f34c91754851",nome:"Plano A",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"cfd9e9b0-16e8-4b60-8355-e270ec1ae181",opcoes:[{id:"04d97286-435a-4b20-8539-4cf08a79807b",descr:"Dieta livre",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Manter alimenta\xE7\xE3o habitual.",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"aa273300-1f34-4978-9605-b3422d7976f3",opcoes:[{id:"5cb56a2e-64b9-4975-a24b-0bd4927ca3f1",descr:`L\xEDquidos caseiros (\xE1gua, ch\xE1, suco, \xE1gua de coco, sopas) ou solu\xE7\xE3o de sais de reidrata\xE7\xE3o oral (SRO) ap\xF3s cada evacua\xE7\xE3o/v\xF4mito:\r
- < 1 ano: 50-100 mL\r
- 1- 10 anos: 100-200 mL\r
- > 10 anos: quantidade que aceitar`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"N\xE3o utilizar refrigerante; n\xE3o ado\xE7ar ch\xE1 e suco.",ordem:2},{item:"ZINCO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"fb064651-1a73-466d-9dc2-6803522d6b2e",opcoes:[{id:"43b1374c-f889-4859-b1d4-35ce1a35ebdb",descr:`Sulfato de zinco (4mg/mL) 5 mL (20 mg) VO 1x/dia durante 10-14 dias (para < 5 anos) (MEDGRUPO)
* \u2264\xA06 meses: 2,5 mL (10 mg)`,recomendado:!0,favorito:!0,ordem:1},{id:"175f8c53-6061-46c8-a59f-974157b5a9ca",descr:`Gluconato de zinco (4mg/mL) 5 mL (20 mg) VO 1x/dia durante 10-14 dias (para < 5 anos)\r
* \u2264\xA06 meses: 2,5 mL (10 mg)`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Indicado para < 5 anos; alguns SRO tamb\xE9m cont\xEAm zinco.",ordem:3},{item:"ANTIEM\xC9TICO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"9734fbb9-374a-4b15-9a1b-c7336b3feb82",opcoes:[{id:"ccfecea6-8c75-49e0-816d-22246241c976",descr:`Ondansetrona (4-8mg/cp) VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO)\r
- Adulto: 4-8 mg\r
- Crian\xE7a: 0,1 mg/Kg (m\xE1x 4 mg)`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Pode proporcionar redu\xE7\xE3o na frequ\xEAncia de v\xF4mitos.",ordem:4},{item:"ANTIDIARREICO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"63d421ef-0e01-413f-8b27-36311e69b74a",opcoes:[{id:"5a0b56fa-8735-4ecf-a3ea-22ab6323eb2d",descr:"Racecadotrila (100mg/cp) 100 mg VO 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"97936424-f3ec-4634-9da4-7efc313598b9",descr:`Racecadotrila (10mg/sach\xEA) 1,5 mg/Kg VO 8/8h (dissolver em \xE1gua, misturar a alimento ou administrar diretamente)\r
- < 9 Kg (3-9 meses): 10 mg VO 8/8h\r
- 9-13 Kg (10-35 meses): 20 mg VO 8/8h`,recomendado:!1,favorito:!1,ordem:2},{id:"5f2b6a98-6bc1-438f-a4af-fc51051d7e90",descr:`Racecadotrila (30mg/sach\xEA) 1,5 mg/Kg VO 8/8h (dissolver em \xE1gua, misturar a alimento ou administrar diretamente)\r
- 14-27 Kg (3-8 anos): 30 mg VO 8/8h\r
- > 27 Kg (9-14 anos): 60 mg VO 8/8h`,recomendado:!1,favorito:!1,ordem:3},{id:"751615a0-00af-4fb1-b413-8d7734d1c87f",descr:`Loperamida (2mg/cp) 2-4 mg VO ap\xF3s evacua\xE7\xE3o (n\xE3o administrar em < 18 anos)\r
Dose m\xE1xima: 8 mg/dia; n\xE3o administrar por > 48h`,recomendado:!1,favorito:!1,ordem:4},{id:"5af079fd-3a71-4074-99c9-72c525e6eabb",descr:`Subsalicilato de bismuto (525mg/30mL) 525 mg VO a cada 30 ou 60 min (m\xE1x 8 doses)\r
3-6 anos: 87 mg (5 mL) | 6-9 anos: 175 mg (10 mL) | 9-12 anos: 262 mg (20 mL)\r
* Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Embora n\xE3o haja consenso, pode ser considerado em imunocompetente com diarreia aquosa.",ordem:5},{item:"PROBI\xD3TICO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"cc810c88-37de-475a-97d1-3b8e176b1298",opcoes:[{id:"4578f407-8523-44b1-8c98-f417605ba044",descr:"Saccharomyces boulardii (250mg/cp) 250-500 mg 1-2x/dia durante 3-7 dias (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"4bebf824-cfe2-43f0-b56a-548cd474dc2b",descr:"Saccharomyces boulardii (100-200mg/cp) 200 mg 2x/dia durante 3-7 dias",recomendado:!1,favorito:!1,ordem:2},{id:"28f5a441-3d60-46d0-af43-400f32a16bef",descr:"Saccharomyces boulardii (200-250mg/sach\xEA) 1-2 sach\xEAs 2x/dia durante 3-7 dias",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Embora n\xE3o haja consenso, pode ser considerado em imunocompetente.",ordem:6}],conceitosPraticos:[{conceito:"Plano A (sem desidrata\xE7\xE3o) \u2192  ativo, olhos sem altera\xE7\xE3o, sem sede, l\xE1grimas (+), boca \xFAmida, sinal da prega abdominal desaparece imediatamente, pulso cheio",ordem:1},{conceito:"Plano B (desidrata\xE7\xE3o) \u2192 \u2265 2 dos seguintes: irritado, olhos fundos, sedento, l\xE1grimas (-), boca seca, sinal da prega abdominal desaparece lentamente, pulso cheio",ordem:2},{conceito:"Plano C (desidrata\xE7\xE3o grave) \u2192 \u2265 2 dos seguintes, sendo \u2265 1 destacado com asterisco: let\xE1rgico*, olhos fundos, n\xE3o \xE9 capaz de beber*, l\xE1grimas (-), boca muito seca, sinal da prega abdominal desaparece em > 2 seg, pulso fraco*)",ordem:3}]},{id:"424f4f2f-3abb-48d8-aeaa-fdae1543f553",nome:"Plano B",favorito:!1,ordem:2,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"683d506c-d1ca-4816-b1d9-7caefe7acb0f",opcoes:[{id:"befe7c69-f593-4705-ba23-eed5ca24e135",descr:"Dieta zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"N\xE3o alimentar durante per\xEDodo de reidrata\xE7\xE3o (exceto crian\xE7a em aleitamento materno); passar para o Plano A quando reidratado e aceitando alimenta\xE7\xE3o.",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2dfaf66a-2cb8-4ae3-b6a9-32d87cecc1f8",opcoes:[{id:"be994547-7bdb-4f43-97b1-6f687fbc2795",descr:`Solu\xE7\xE3o de sais de reidrata\xE7\xE3o oral (SRO) 75 mL/Kg no per\xEDodo inicial de 4-6h:\r
OBS: Se v\xF4mitos persistente, optar por SNG 20 mL/Kg/h`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"O plano B visa tratar a desidrata\xE7\xE3o no estabelecimento de sa\xFAde.",ordem:2},{item:"ANTIEM\xC9TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"32253b95-1f84-4f6e-b649-db6cc418fbce",opcoes:[{id:"f5aeadf4-d97b-44b3-ae07-a4e81b9ce45b",descr:`Ondansetrona (4-8mg/cp) VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO)\r
- Adulto: 4-8 mg\r
- Crian\xE7a: 0,1 mg/Kg (m\xE1x 4 mg)`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Pode proporcionar redu\xE7\xE3o na frequ\xEAncia de v\xF4mitos.",ordem:3},{item:"ANTIBI\xD3TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7e16a3ef-0f23-4a82-95f1-1686e60178f4",opcoes:[{id:"5c238b94-b669-4e50-8825-ec234b6b74db",descr:`Azitromicina (40mg/mL) 10 mg/Kg VO dose \xFAnica no 1o dia + 5 mg/Kg VO 1x/dia por 4 dias\r
* Escolha para crian\xE7as de 3 meses a 10 anos (at\xE9 30 Kg)`,recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"b69d85c3-88a3-49ca-b7db-0e0c42d5c8f6",opcoes:[{id:"68c007d0-01ca-45da-b3b3-10fd6484435a",descr:`Ciprofloxacino (500mg/cp) 500 mg VO 12/12h por 3 dias\r
* Escolha para crian\xE7as > 10 anos (ou > 30 Kg), adolescentes e adultos`,recomendado:!0,favorito:!0,ordem:1},{id:"2f7e0197-7427-4bb7-8237-9a48acc177ae",descr:`Ceftriaxona (500-1000mg/frasco) 50-100 mg/Kg IM 1x/dia por 3-5 dias\r
* Escolha para crian\xE7as < 3 meses ou com imunodefici\xEAncia; alternativa para os demais casos`,recomendado:!1,favorito:!1,ordem:2}],ordem:2}],academico:"Indicado se disenteria associada a comprometimento do estado geral.",ordem:4}],conceitosPraticos:[{conceito:"Plano A (sem desidrata\xE7\xE3o) \u2192  ativo, olhos sem altera\xE7\xE3o, sem sede, l\xE1grimas (+), boca \xFAmida, sinal da prega abdominal desaparece imediatamente, pulso cheio",ordem:1},{conceito:"Plano B (desidrata\xE7\xE3o) \u2192 \u2265 2 dos seguintes: irritado, olhos fundos, sedento, l\xE1grimas (-), boca seca, sinal da prega abdominal desaparece lentamente, pulso cheio",ordem:2},{conceito:"Plano C (desidrata\xE7\xE3o grave) \u2192 \u2265 2 dos seguintes, sendo \u2265 1 destacado com asterisco: let\xE1rgico*, olhos fundos, n\xE3o \xE9 capaz de beber*, l\xE1grimas (-), boca muito seca, sinal da prega abdominal desaparece em > 2 seg, pulso fraco*)",ordem:3}]},{id:"f57d9b57-1043-4053-903a-8deb2df7db91",nome:"Plano C",favorito:!1,ordem:3,secoes:[{item:"HIDRATA\xC7\xC3O (EXPANS\xC3O)",grupos:[{grupo:"Analg\xE9sico",idGrupo:"66fb288a-8c90-4cfd-9734-66d7acdb08ac",opcoes:[{id:"254ae493-c739-4796-b5fa-390d54494534",descr:`SF 0,9% ou Ringer lactato IV:\r
- < 1 ano: 30 mL/Kg em 1h + 70 mL/Kg em 5h\r
- \u2265 1 ano: 30 mL/Kg em 30 min + 70 mL/Kg em 2,5h\r
* RN ou < 5 anos com cardiopatia grave: iniciar com 10 mL/Kg`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Oferecer, em paralelo, solu\xE7\xE3o de sais de reidrata\xE7\xE3o oral (SRO) quando puder beber (em geral, 2-3h ap\xF3s in\xEDcio da reidrata\xE7\xE3o IV).",ordem:1},{item:"HIDRATA\xC7\xC3O (MANUTEN\xC7\xC3O E REPOSI\xC7\xC3O)",grupos:[{grupo:"Analg\xE9sico",idGrupo:"727f7f29-dd50-48e1-ad58-761be5c16b88",opcoes:[{id:"80d946d6-4ebd-4147-bc01-7b10e8422047",descr:`MANUTEN\xC7\xC3O: SG 5% + SF 0,9% (propor\xE7\xE3o 4:1) IV em 24h:\r
- \u2264\xA010 Kg: 100 mL/Kg\r
- 10-20 Kg: 1000 mL + 50 mL/Kg que exceder 10 Kg\r
- \u2265\xA020 Kg: 1500 mL + 20 mL/Kg que exceder 20 Kg (m\xE1x 2000 mL)\r
* Acrescentar KCl 10% 2 mL para cada 100 mL de solu\xE7\xE3o`,recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"71cd3b03-7a2a-4bc5-ad4e-8129c8318666",opcoes:[{id:"27c967d3-a82d-4feb-a4d5-c08607bb1aa4",descr:"REPOSI\xC7\xC3O: SG 5% + SF 0,9% (propor\xE7\xE3o 1:1) IV 50 mL/Kg/dia",recomendado:!0,favorito:!0,ordem:1}],ordem:2}],academico:"Interromper reidratac\u0327a\u0303o IV somente quando puder ingerir SRO em quantidade suficiente para se manter hidratado.",ordem:2},{item:"ANTIEM\xC9TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"03e2d3c5-c31a-4cff-be18-5cc8681831b1",opcoes:[{id:"95271304-11e8-4265-b5c6-9b5e022ff294",descr:`Ondansetrona (4-8mg/comp) VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO)
- Adulto: 4-8 mg
- Crian\xE7a: 0,1 mg/Kg (m\xE1x 4 mg)`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Pode proporcionar redu\xE7\xE3o na frequ\xEAncia de v\xF4mitos.",ordem:3},{item:"ANTIBI\xD3TICO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"6851df09-9f48-4697-9260-a15bff09cc47",opcoes:[{id:"f07b3c36-3f1c-4193-9f23-37ac0bb289d2",descr:`Azitromicina (40mg/mL) 10 mg/Kg VO dose \xFAnica no 1o dia + 5 mg/Kg VO 1x/dia por 4 dias\r
* Escolha para crian\xE7as de 3 meses a 10 anos (at\xE9 30 Kg)`,recomendado:!0,favorito:!0,ordem:1},{id:"55aac37b-683b-4e10-bfb8-fbba707c2582",descr:`Ciprofloxacino (500mg/cp) 500 mg VO 12/12h por 3 dias\r
* Escolha para crian\xE7as > 10 anos (ou > 30 Kg), adolescentes e adultos`,recomendado:!1,favorito:!1,ordem:2},{id:"7852c0ee-5053-48ea-9183-13da6d3b65f2",descr:`Ceftriaxona (500-1000mg/frasco) 50-100 mg/Kg IM ou IV 1x/dia por 3-5 dias\r
* Escolha para crian\xE7as < 3 meses ou com imunodefici\xEAncia; alternativa para os demais casos`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Indicado se disenteria associada a comprometimento do estado geral.",ordem:4}],conceitosPraticos:[{conceito:"Plano A (sem desidrata\xE7\xE3o) \u2192  ativo, olhos sem altera\xE7\xE3o, sem sede, l\xE1grimas (+), boca \xFAmida, sinal da prega abdominal desaparece imediatamente, pulso cheio",ordem:1},{conceito:"Plano B (desidrata\xE7\xE3o) \u2192 \u2265 2 dos seguintes: irritado, olhos fundos, sedento, l\xE1grimas (-), boca seca, sinal da prega abdominal desaparece lentamente, pulso cheio",ordem:2},{conceito:"Plano C (desidrata\xE7\xE3o grave) \u2192 \u2265 2 dos seguintes, sendo \u2265 1 destacado com asterisco: let\xE1rgico*, olhos fundos, n\xE3o \xE9 capaz de beber*, l\xE1grimas (-), boca muito seca, sinal da prega abdominal desaparece em > 2 seg, pulso fraco*)",ordem:3}]}],topicos:[],videos:[],fluxogramas:[],tags:["Disenteria","desidrata\xE7\xE3o"]},{id:"e8775b7f-7d00-4e79-bf84-3040a10f872a",nome:"Dislipidemia",categoria:2,termosDeBusca:"dislipidemia, ldl, hdl, triglicerideos, hipertrigliceridemia, colesterol",favoritado:!1,ordem:0,especialidades:[{nome:"CARDIOLOGIA"}],prescricoes:[],topicos:[{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Mudan\xE7a do risco cardiovascular \u2013</strong>
  <span style="font-weight: 400;">\xC9 poss\xEDvel que, ao longo do tempo, pelo controle de diferentes fatores de risco, o risco cardiovascular do paciente sofra uma redu\xE7\xE3o. Se isso ocorrer, o correto \xE9 manter a mesma intensidade da estatina prescrita no momento inicial.</span>
</p><p>
  <strong>- Apolipoprote\xEDna B \u2013</strong>
  <span style="font-weight: 400;">Como a apolipoprote\xEDna B (ApoB) encontra-se nas lipoprote\xEDnas aterog\xEAnicas (VLDL, LDL, IDL e lipoprote\xEDna A), sua dosagem constitui uma medida indireta de todas as part\xEDculas aterog\xEAnicas na corrente sangu\xEDnea, tendo uma correspond\xEAncia de racioc\xEDnio com o colesterol n\xE3o-HDL. A diretriz brasileira n\xE3o recomenda sua avalia\xE7\xE3o rotineira, mas as diretrizes americana e europeia sugerem que a dosagem de ApoB seja feita principalmente nos pacientes com hipertrigliceridemia (em especial com TG \u2265 200 mg/dL) at\xE9 porque a eleva\xE7\xE3o dos triglicer\xEDdeos torna laboratorialmente menos confi\xE1vel a avalia\xE7\xE3o dos n\xEDveis de LDL atrav\xE9s da estimativa com a f\xF3rmula de Friedwald [LDL = Colesterol Total \u2013 HDL \u2013 (TG/5)]. Como curiosidade, uma ApoB &gt; 130 mg/dL corresponderia a um LDL \u2265 160 mg/dL. Inclusive n\xEDveis de ApoB podem ser almejados como metas secund\xE1rias do tratamento de dislipidemia.&nbsp;&nbsp;</span>
</p>`,ordem:1},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Mach F, Baigent C, Catapano Al, Koskinas KC, Casula M, Badimon L, Chapman MJ et al. 2019 ESC/EAS Guidelines for the management of dyslipidaemias: lipid modification to reduce cardiovascular risk.</span>
    <em>
      <span style="font-weight: 400;">European Heart Journal</span>
    </em>
    <span style="font-weight: 400;">2019;00:1-78</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Grundy SM, Stone NJ, Bailey AL, Beam C, Birtcher KK, Blumenthal RS, Braun LT, de Ferranti S, Faiella-Tommasino J, Forman DE, Goldberg R, Heidenreich PA, Hlatky MA, Jones DW, Lloyd-Jones D, Lopez-Pajares N, Ndumele CE, Orringer CE, Peralta CA, Saseen JJ, Smith SC Jr, Sperling L, Virani SS, Yeboah J. 2018 AHA/ACC/AACVPR/AAPA/ABC/ACPM/ADA/AGS/APhA/ASPC/NLA/PCNA guideline on the management of blood cholesterol: a report of the American College of Cardiology/American Heart Association Task Force on Clinical Practice Guidelines.</span>
    <em>
      <span style="font-weight: 400;">J Am Coll Cardiol</span>
    </em>
    <span style="font-weight: 400;">2019;73:e285\u2013350.</span>
  </li>
</ol><p>
  <span style="font-weight: 400;">Faludi AA, Izar MCO, Saraiva JFK, Chacra APM, Bianco HT, Afiune Neto A et al. Atualiza\xE7\xE3o da Diretriz Brasileira de Dislipidemias e Preven\xE7\xE3o da Aterosclerose \u2013 2017.</span>
  <em>
    <span style="font-weight: 400;">Arq Bras Cardiol</span>
  </em>
  <span style="font-weight: 400;">2017; 109(2Supl.1):1-76</span>
</p>`,ordem:2}],videos:[],fluxogramas:[],tags:["LDL","HDL","Triglicer\xEDdeos","Hipertrigliceridemia","Colesterol"]},{id:"d0e0f9de-34ab-4552-a196-556b47d2c72f",nome:"Diverticulite Aguda",categoria:1,termosDeBusca:"diverticulite aguda, diverticulo, diverticulose",favoritado:!1,ordem:0,especialidades:[{nome:"CIRURGIA"}],prescricoes:[{id:"863adaa0-93cf-4ef1-a357-106e9c713e71",nome:"Tratamento Ambulatorial",favorito:!0,ordem:1,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b8167f4d-d5fd-40fd-a41b-9646f216dd8e",opcoes:[{id:"eaf1f62f-65a8-4dd1-92df-b8c8697dba1f",descr:"Dieta oral conforme aceita\xE7\xE3o (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"e3566fb0-9de7-46cb-bc5e-411b8c5966a3",descr:"Dieta oral l\xEDquida",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Individualizar",ordem:1},{item:"Antibioticoterapia",grupos:[{grupo:"Antiemetico",idGrupo:"fdf1ed1f-bc8b-4342-b439-7d185e72004b",opcoes:[{id:"72811af6-bf82-41e9-9519-6e6f60582752",descr:"Ciprofloxacina 500 mg VO 12/12h + Metronidazol 500 mg VO 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"57c82111-968d-4ca4-86be-9c5b236fd29c",descr:"Amoxicilina/Clavulanato 875/125 mg VO 12/12h",recomendado:!1,favorito:!1,ordem:2},{id:"4ae34932-5efe-49df-871e-b1c01a497b79",descr:"Moxifloxacina 400 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Prescrita por 7-10 dias, embora diretrizes mais recentes sugiram a possibilidade de n\xE3o utilizar antibioticoterapia.",ordem:2},{item:"Anti-inflamat\xF3rio",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b7415da0-5e88-4d53-ac3d-3a6843c81e88",opcoes:[{id:"183b5dce-b2ea-4c1c-937f-bcbd4a49d842",descr:"Ibuprofeno (400-600mg/comp) 400-600 mg VO 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Redu\xE7\xE3o da inflama\xE7\xE3o associada.",ordem:3},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"3d9495f4-cebd-44b5-b603-5a8ddcb5f33b",opcoes:[{id:"2bcebf4e-d6cb-4cb3-b22a-ff70f3018385",descr:"Paracetamol (500-750mg/comp) 750-1000 mg VO em caso de dor ou febre (at\xE9 6/6h) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"2a11f718-2fb2-499b-a1f3-2653db2b320a",descr:"Dipirona (500-1000mg/comp) 500-1000 mg VO em caso de dor ou febre (at\xE9 6/6h)",recomendado:!1,favorito:!1,ordem:2}],ordem:1},{grupo:"Antiemetico",idGrupo:"66306112-07e8-47c8-8d87-6cf3add09238",opcoes:[{id:"bde81bd7-9dfc-4d3d-b299-68405d6e5c79",descr:"Metoclopramida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"d421f833-2694-4e24-8b9f-0dfac4f300f5",descr:"Bromoprida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"bc6ec8bc-d2ce-414c-a6f2-7926feea7651",descr:"Ondansetrona (4-8mg/comp) 4-8 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:4}],conceitosPraticos:[{conceito:"O tratamento ambulatorial \xE9 sugerido para casos n\xE3o-complicados (abscesso, f\xEDstula, obstru\xE7\xE3o, peritonite) e que n\xE3o apresentem sepse, imunodepress\xE3o, comorbidades significativas, incapacidade de ingest\xE3o oral ou suporte domiciliar insatisfat\xF3rio.",ordem:1},{conceito:"Colonoscopia: 4-6 semanas ap\xF3s resolu\xE7\xE3o do caso para afastar malignidade",ordem:2}]},{id:"3493c787-8a40-4cb8-807b-09b4ec118606",nome:"Tto Hospitalar - Baixo Risco",favorito:!1,ordem:2,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"247b09a9-4396-4e13-bb44-4b339f4a6cfb",opcoes:[{id:"c67c74d1-6964-4d38-877c-ed898ce65152",descr:"Dieta oral zero (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"5c9fbd15-c9a9-45e4-b1f0-1511b4da45bb",descr:"Dieta oral l\xEDquida",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Individualizar.",ordem:1},{item:"Hidrata\xE7\xE3o",grupos:[{grupo:"Analg\xE9sico",idGrupo:"97d66f99-39c7-4d81-af94-750f26704249",opcoes:[{id:"ae049446-dd78-4a37-a859-df027f29719c",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Fornecer eletr\xF3litos e glicose em caso de dieta zero.",ordem:2},{item:"Antibioticoterapia",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"44c9ab4d-0c7f-4850-b48b-e35e0b9e0f96",opcoes:[{id:"a6a7b45a-0a38-41f2-8cd6-9b1f500bcd56",descr:"Ciprofloxacina 400 mg IV 12/12h + Metronidazol 500 mg IV 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"9064c087-22a6-41b2-91cc-87fc69531f30",descr:"Levofloxacina 750 mg IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:2},{id:"78b16193-bb99-48d8-b371-4163b1263e9a",descr:"Ceftriaxone 1 g IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:3},{id:"395383a1-8b90-41ce-a6c5-69aa7eb91e49",descr:"Cefazolina 1-2 g IV 8/8h + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:4},{id:"de06411f-04ae-4647-a225-bd92dba66667",descr:"Cefuroxime 1,5 g IV 8/8h + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:5},{id:"898d8616-a2bd-457b-ae60-ffd4be9c5074",descr:"Ertapenem 1 g IV 1x/dia",recomendado:!1,favorito:!1,ordem:6},{id:"a67115d5-5715-4273-adca-0952600cb903",descr:"Piperacilina/tazobactam 3,375 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:7},{id:"3d6b4174-a195-4414-a400-7bfcb34178ab",descr:"Moxifloxacina 400 mg IV 1x/dia",recomendado:!1,favorito:!1,ordem:8}],ordem:1}],academico:"Prescrita por 10-14 dias, sendo inicialmente venosa (3-5 dias) e depois, oral (como no tratamento ambulatorial).",ordem:3},{item:"Analgesia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"fff5e73d-ddde-4c24-9861-87d97542d1ab",opcoes:[{id:"aa3e6c45-f1fa-4c65-93d2-b1c615eb1efe",descr:"Cetorolaco (30mg/mL) 30 mg IV 6/6h - administrar em bolus de 15 segundos (para idoso, fazer metade da dose)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Uso regular na fase aguda",ordem:4},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f984c592-36c5-4865-bb04-6ee57598d87d",opcoes:[{id:"f7a4651d-33d8-40d5-8454-27c335406b32",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"de3417ea-3289-47d1-baa0-ecc22e057610",descr:"Dipirona (500-1000mg/comp) 500-1000 mg VO em caso de dor ou febre (at\xE9 6/6h)",recomendado:!1,favorito:!1,ordem:2},{id:"54b950c0-84fa-4efd-8a2a-98ffd169487d",descr:"Paracetamol (500-750mg/comp) 750-1000 mg VO em caso de dor ou febre (at\xE9 6/6h)",recomendado:!1,favorito:!1,ordem:3}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"163801f8-32cd-400a-96f9-433aebae8835",opcoes:[{id:"6a37ba6f-4c6a-4c1a-bd00-cd16bb5be9fc",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"6a7bb93a-b144-4205-bc3d-851cbfbd5de1",descr:"Metoclopramida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"7b1ff1b6-ffd2-40b2-95df-518a1ffe02cc",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:3},{id:"e08a0e46-63ef-47b7-8ac5-3907d64d81f5",descr:"Bromoprida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:4},{id:"0e67b0be-3363-4f13-bc09-42e071d49c13",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:5},{id:"960c0abf-701c-4eca-944e-a9a165aae2b5",descr:"Ondansetrona (4-8mg/comp) 4-8 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:6}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:5},{item:"Cuidados Gerais",grupos:[{grupo:"Analg\xE9sico",idGrupo:"6c3f80db-17cc-4625-a9ae-48b42a1e4c32",opcoes:[{id:"fb4861e5-28a1-4a32-bf28-c3f6b3f44a18",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:6}],conceitosPraticos:[{conceito:"Devem ser internados todos os casos de diverticulite complicada e aqueles que apresentem sepse, imunodepress\xE3o, comorbidades significativas, dor abdominal grave, incapacidade de ingest\xE3o oral ou suporte domiciliar insatisfat\xF3rio.",ordem:1},{conceito:"Alto Risco: idade avan\xE7ada, imunodepress\xE3o, dist\xFArbios fisiol\xF3gicos severos (sepse), desnutri\xE7\xE3o",ordem:2},{conceito:"Abordagem espec\xEDfica de casos complicados: (1) Abscesso: drenagem por TC e cirurgia eletiva (se < 4 cm, o abscesso \xE9 tratado apenas com antibi\xF3tico); (2) F\xEDstula: cirurgia eletiva; (3) Peritonite: cirurgia de urg\xEAncia; (4) Obstru\xE7\xE3o: cirurgia de urg\xEAncia.",ordem:3},{conceito:"Imunodepress\xE3o: planejar cirurgia eletiva",ordem:4},{conceito:"Colonoscopia: 4-6 semanas ap\xF3s resolu\xE7\xE3o do caso para afastar malignidade",ordem:5}]},{id:"57382301-82c0-49a5-9c35-286c51b024af",nome:"Tto Hospitalar - Alto Risco",favorito:!1,ordem:3,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"92fcdea9-2059-4ade-b87f-a5dd3b36a3f6",opcoes:[{id:"ae954d03-9558-42c9-93c1-9b186f32b1df",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s resolu\xE7\xE3o do quadro inflamat\xF3rio.",ordem:1},{item:"Hidrata\xE7\xE3o",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e764321b-8cff-4aa9-b417-41d3dc7b70a6",opcoes:[{id:"034a5808-57cc-417d-87b8-516a0ae05dfb",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Fornecer eletr\xF3litos e glicose em caso de dieta zero.",ordem:2},{item:"Antibioticoterapia",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"dc6387be-c54b-466f-8106-47690874a234",opcoes:[{id:"81790672-3adc-4102-b9a5-f5b185105448",descr:"Ciprofloxacina 400 mg IV 12/12h + Metronidazol 500 mg IV 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"d2b13c90-df92-4601-896e-9dcecf5d77b8",descr:"Levofloxacina 750 mg IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:2},{id:"6e7b11ab-4aaa-457c-8f6b-710be039b524",descr:"Imipenem 500 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:3},{id:"2d31f26e-1eef-4a47-92b9-2dadd4a3e342",descr:"Meropenem 1 g IV 8/8h",recomendado:!1,favorito:!1,ordem:4},{id:"f14bf487-bceb-4c3f-a773-3ba7226baadf",descr:"Piperacilina/tazobactam 4,5 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Prescrita por 10-14 dias, sendo inicialmente venosa (3-5 dias) e depois, oral (como no tratamento ambulatorial).",ordem:3},{item:"Analgesia",grupos:[{grupo:"Analg\xE9sico",idGrupo:"cc94b170-1136-49e1-a505-0c10723f472f",opcoes:[{id:"e5dcedb0-f068-4812-bb79-1e6ededf72ba",descr:"Cetorolaco (30mg/mL) 30 mg IV 6/6h - administrar em bolus de 15 segundos (para idoso, fazer metade da dose)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Uso regular na fase aguda",ordem:4},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"a05ec818-bbbd-43b1-9016-5bb84ef00964",opcoes:[{id:"cd362dd2-9a3c-4f52-a19e-81aaf99cd34e",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"6cc967cf-2815-40a7-a444-9f89f5e082ad",opcoes:[{id:"072560df-7741-4246-8b2a-4764b6c5d61f",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"0603d17b-b19f-4abc-bfe4-fecaf097d209",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"3d308908-e0a3-475e-8efe-3bfd65c3fb70",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:5},{item:"Cuidados Gerais",grupos:[{grupo:"Analg\xE9sico",idGrupo:"00904ef2-3c91-4d86-b618-38614d51cc91",opcoes:[{id:"76ca1078-650d-4fc4-95b1-454bb6efcb19",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:6}],conceitosPraticos:[{conceito:"Devem ser internados todos os casos de diverticulite complicada e aqueles que apresentem sepse, imunodepress\xE3o, comorbidades significativas, dor abdominal grave, incapacidade de ingest\xE3o oral ou suporte domiciliar insatisfat\xF3rio.",ordem:1},{conceito:"Alto Risco: idade avan\xE7ada, imunodepress\xE3o, dist\xFArbios fisiol\xF3gicos severos (sepse), desnutri\xE7\xE3o",ordem:2},{conceito:"Abordagem espec\xEDfica de casos complicados: (1) Abscesso: drenagem por TC e cirurgia eletiva (se < 4 cm, o abscesso \xE9 tratado apenas com antibi\xF3tico); (2) F\xEDstula: cirurgia eletiva; (3) Peritonite: cirurgia de urg\xEAncia; (4) Obstru\xE7\xE3o: cirurgia de urg\xEAncia.",ordem:3},{conceito:"Imunodepress\xE3o: planejar cirurgia eletiva",ordem:4},{conceito:"Colonoscopia: 4-6 semanas ap\xF3s resolu\xE7\xE3o do caso para afastar malignidade",ordem:5}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">Diverticulite aguda \xE9 a inflama\xE7\xE3o macrosc\xF3pica do divert\xEDculo col\xF4nico geralmente em decorr\xEAncia de uma microperfura\xE7\xE3o, ocorrendo em aproximadamente 4% dos portadores de Doen\xE7a Diverticular Col\xF4nica. Cerca de 15% dos casos ainda complicam com abscesso, f\xEDstula, perfura\xE7\xE3o ou obstru\xE7\xE3o col\xF4nica.</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">\xC9 mais comum ocorrer em pacientes acima de 50 anos, sendo a idade m\xE9dia de apresenta\xE7\xE3o de 63 anos. A manifesta\xE7\xE3o mais importante \xE9 a dor abdominal que, com maior frequ\xEAncia, localiza-se na fossa il\xEDaca esquerda pelo fato da maioria dos casos ocorrer no sigmoide. \xC9 poss\xEDvel tamb\xE9m a ocorr\xEAncia de febre, n\xE1useas e v\xF4mitos. Muitos guardam a associa\xE7\xE3o de que a diverticulite seria uma esp\xE9cie de \u201Capendicite \xE0 esquerda em pacientes acima de 50 anos\u201D.</span>
</p><p>
  <span style="font-weight: 400;">Podem ocorrer sintomas urin\xE1rios, como urg\xEAncia e dis\xFAria em virtude da extens\xE3o do processo inflamat\xF3rio do sigmoide at\xE9 a bexiga.</span>
</p><p>
  <strong>Diverticulite Complicada \u2013</strong> 
  <span style="font-weight: 400;">Os casos complicados podem ainda manifestar quadros mais espec\xEDficos na depend\xEAncia do tipo de complica\xE7\xE3o: abscesso (massa palp\xE1vel, aus\xEAncia de melhora ap\xF3s 3 dias de antibi\xF3tico), f\xEDstula (pneumat\xFAria e fecal\xFAria na f\xEDstula colovesical, que \xE9 a mais comum), obstru\xE7\xE3o (distens\xE3o) e perfura\xE7\xE3o (peritonite).
    <br>
  </span>
</p><p>&nbsp;</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/ec4a2aa4-ce30-48e8-87f3-3ec623c35e34.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>&nbsp;</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">A avalia\xE7\xE3o laboratorial inclui a solicita\xE7\xE3o de hemograma (leucocitose corrobora a suspeita), eletr\xF3litos, prote\xEDna C-reativa, exame de sedimento urin\xE1rio (pode ocorrer pi\xFAria pelo processo inflamat\xF3rio adjacente) e, para mulheres em idade f\xE9rtil,</span> 
  <span style="font-weight: 400;">\xDF</span> 
  <span style="font-weight: 400;">-HCG. A confirma\xE7\xE3o diagn\xF3stica exige a realiza\xE7\xE3o de exame de imagem, especialmente a Tomografia Computadorizada de Abdome e Pelve e, de maneira alternativa, a Ultrassonografia Abdominal, que podem demonstrar espessamento da parede col\xF4nica (&gt; 4 mm) e at\xE9 complica\xE7\xF5es, como abscesso, ou seja, tamb\xE9m diferenciam a forma complicada da n\xE3o-complicada.</span>
</p><p>
  <span style="font-weight: 400;">A imagem permite, ao lado da avalia\xE7\xE3o cl\xEDnica, concluir sobre a gravidade do quadro, encaixando o paciente na Classifica\xE7\xE3o de Hinchey: (I) abscesso peric\xF3lico; (II) abscesso \xE0 dist\xE2ncia (p\xE9lvico, intra-abdominal retroperitoneal); (III) peritonite purulenta; (IV) peritonite fecal.</span>
</p><p>&nbsp;</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/6fda018f-b62e-4b3c-8caf-3282463b06a6.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>
  <br>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">A primeira decis\xE3o \xE9 com rela\xE7\xE3o \xE0 necessidade ou n\xE3o de interna\xE7\xE3o. Devem ser internados todos os casos de diverticulite complicada e aqueles que apresentem sepse, imunodepress\xE3o, comorbidades significativas, incapacidade de ingest\xE3o oral ou suporte domiciliar insatisfat\xF3rio.</span>
</p><p>
  <strong>Tratamento ambulatorial \u2013</strong> 
  <span style="font-weight: 400;">Deve ser feito com antibioticoterapia oral por 7-10 dias. As op\xE7\xF5es mais usadas s\xE3o: ciprofloxacina 500 mg VO 12/12h + metronidazol 500 mg VO 8/8h OU amoxicilina/clavulanato 875/125 mg VO 12/12h OU moxifloxacina 400 mg VO 1x/dia. O paciente deve ser reavaliado em at\xE9 7 dias (preferencialmente em 2-3 dias) e, depois, semanalmente at\xE9 a completa resolu\xE7\xE3o dos sintomas, sem a necessidade de repeti\xE7\xE3o da tomografia.</span>
</p><p>
  <span style="font-weight: 400;">Embora esta seja a conduta cl\xE1ssica e largamente empregada, h\xE1 uma corrente que defende a possibilidade de tratar esses casos sem o uso de antibi\xF3tico.</span>
</p><p>
  <strong>Tratamento hospitalar \u2013</strong> 
  <span style="font-weight: 400;">A antibioticoterapia \xE9 feita por 10-14 dias, sendo inicialmente venosa (3-5 dias) e depois, oral (como no tratamento ambulatorial). As op\xE7\xF5es dos esquemas venosos dependem da gravidade do quadro:</span>
</p><p>
  <span style="font-weight: 400;">- Baixo risco (caso leve/moderado): ertapenem 1 g 1x/dia OU piperacilina/tazobactam 3,375 mg 6/6h OU moxifloxacina 400 mg 1x/dia</span> 
  <span style="font-weight: 400;">OU (Cefazolina 1-2 g 8/8h ou cefuroxime 1,5 g 8/8h ou ceftriaxone 1 g 1x/dia ou cefotaxima 1-2 g 6/6h ou ciprofloxacina 400 mg 12/12h ou levofloxacina 750 mg 1x/dia) + metronidazol 500 mg 8/8h.</span>
</p><p>
  <span style="font-weight: 400;">- Alto risco (caso grave): imipenem 500 mg 6/6h OU meropenem 1 g 8/8h OU piperacilina/tazobactam 4,5 mg 6/6h OU (cefepime 2 g 8/8h ou ceftazidime 2 g 8/8h ou ciprofloxacina 400 mg 12/12h ou levofloxacina 750 mg 1x/dia) + metronidazol 500 mg 8/8h.</span>
</p><p>
  <span style="font-weight: 400;">Al\xE9m do controle da dor e da hidrata\xE7\xE3o, os pacientes internados s\xE3o deixados em dieta zero ou l\xEDquida, com progress\xE3o a partir da melhora cl\xEDnica.</span>
</p><p>
  <strong>Diverticulite complicada \u2013</strong> 
  <span style="font-weight: 400;">Al\xE9m das medidas citadas, os casos complicados recebem abordagem espec\xEDfica, que, em geral, acaba envolvendo cirurgia (sigmoidectomia):</span>
</p><p>
  <span style="font-weight: 400;">- Abscesso: drenagem guiada por TC e cirurgia eletiva (se &lt; 4 cm, o abscesso \xE9 tratado apenas com antibi\xF3tico)</span>
</p><p>
  <span style="font-weight: 400;">- F\xEDstula: cirurgia eletiva</span>
</p><p>
  <span style="font-weight: 400;">- Perfura\xE7\xE3o com Peritonite: cirurgia de urg\xEAncia (em tese, acaba sendo a sigmoidectomia a Hartmann, embora, em pacientes est\xE1veis e sem comorbidades seja poss\xEDvel a realiza\xE7\xE3o de anastomose prim\xE1ria), devendo ser desencorajada a abordagem apenas com lavagem e drenagem peritoneal.</span>
</p><p>
  <span style="font-weight: 400;">- Obstru\xE7\xE3o: cirurgia de urg\xEAncia</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Tamb\xE9m devem ser referenciados para cirurgia eletiva os pacientes imunodeprimidos que tenham tido um epis\xF3dio n\xE3o-complicado a fim de evitar que, em uma poss\xEDvel recorr\xEAncia, haja o desenvolvimento de um quadro com alguma complica\xE7\xE3o.</span>
  </em> 
  <em>
    <span style="font-weight: 400;">&nbsp;</span>
  </em>
</p><p>&nbsp;</p><p>
  <em>
    <span style="font-weight: 400;">
      <img src="https://d55mnj1ee66xh.cloudfront.net/academico/18e7f146-b3a0-4a5c-8183-18961294d4b7.jpg" alt="" width="100%" height="auto">
    </span>
  </em>
</p>`,ordem:4},{titulo:"ACOMPANHAMENTO",texto:`<p>
  <span style="font-weight: 400;">Para a preven\xE7\xE3o de outros epis\xF3dios de diverticulite, o paciente deve ser orientado a aumentar a ingesta de fibras na dieta e realizar exerc\xEDcios f\xEDsicos regularmente. N\xE3o h\xE1 qualquer restri\xE7\xE3o \xE0 ingesta de nozes ou pipoca (como j\xE1 foi defendido no passado), bem como n\xE3o se recomenda o uso de mesalazina, rifaximina ou pr\xF3bi\xF3ticos.</span>
</p><p>&nbsp;</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/8b5f0281-92c2-4d16-9441-c98f296d66fb.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>&nbsp;</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p>
  <strong>(1) Colonoscopia \u2013</strong> 
  <span style="font-weight: 400;">A colonoscopia n\xE3o deve ser realizada no quadro agudo para diagn\xF3stico de diverticulite, uma vez que pode agravar a microperfura\xE7\xE3o e ainda assim n\xE3o visualizar o processo inflamat\xF3rio, que \xE9 predominantemente peridiverticular. O exame endosc\xF3pico est\xE1 indicado 6-8 semanas ap\xF3s a resolu\xE7\xE3o da diverticulite (complicada ou n\xE3o) para afastar a possibilidade de c\xE2ncer de c\xF3lon nos pacientes que n\xE3o tenham sido submetidos a uma avalia\xE7\xE3o col\xF4nica recente.&nbsp;</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Embora essa avalia\xE7\xE3o colonosc\xF3pica seja classicamente realizada em todos os casos de diverticulite, recentemente uma corrente passou a n\xE3o indic\xE1-la para os casos n\xE3o-complicados, exceto se pertinente como screening pela faixa et\xE1ria.</span>
  </em>
</p>`,ordem:6},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Sartelli M, Catena F, Ansaloni L, et al. WSES Guidelines for the management of acute left sided colonic diverticulitis in the emergency setting.&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery</span>
    </em> 
    <em>
      <span style="font-weight: 400;">&nbsp;2016, 11:37.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Sartelli M, Pierluigi V, Catena F, Ansaloni L, et al. 2013 WSES guidelines for management of intra-abdominal infections.</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery 2013</span>
    </em> 
    <em>
      <span style="font-weight: 400;">,&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">8:</span>
    </em> 
    <em>
      <span style="font-weight: 400;">3.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Sartelli M, Catena F, Abu-Zidan FM, Ansaloni L, et al. Management of intra-abdominal infections: recommendations by the WSES 2016 consensus conference.</span>
    </em> 
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery 2017</span>
    </em> 
    <em>
      <span style="font-weight: 400;">,&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">12:</span>
    </em> 
    <em>
      <span style="font-weight: 400;">22.&nbsp;</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Stollman N, Smalley W, et al. American Gastroenterological Association Institute Guideline on the Management of Acute Diverticulitis.&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">Gastroenterology</span>
    </em> 
    <em>
      <span style="font-weight: 400;">&nbsp;2015, 149:1944-1949.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Wilkins T, Embry K, George R. Diagnosis and management of acute diverticulitis.&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">American Family Physician 2013,</span>
    </em> 
    <em>
      <span style="font-weight: 400;">87:9.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Feingold D, Steele SR, Lee S, et al. Practice parameters for the treatment of sigmoid diverticulitis.&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">Diseases of the Colon &amp; Rectum</span>
    </em> 
    <em>
      <span style="font-weight: 400;">&nbsp;2014, 57:284-294.&nbsp;</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Solomkin JS, Mazuski JE, Bradley FS, et al. Diagnosis and Management of Complicated Intra-abdominal Infection in Adults and Children: Guidelines by the Surgical Infection Society and the Infectious Diseases Society of America. Clinical Infectious Diseases 2010; 50:133-64</span>
    </em>
  </li>
</ul><p>&nbsp;</p>`,ordem:7}],videos:[{id:"4044f9b9-fcf7-47ef-b2d2-4938ebc4098b",titulo:"Diverticulite",duracao:5,thumbUrl:"https://i.vimeocdn.com/video/716648084_1920x1273.jpg?r=pad"},{id:"31d37386-9c8f-4405-a974-7e08d1f516f9",titulo:"T\xEDtulo  para Diverticulite Aguda",duracao:5,thumbUrl:"https://i.vimeocdn.com/video/716648084_1920x1273.jpg?r=pad"},{id:"ce0c76ba-49db-436d-8103-daef2af92880",titulo:"T\xEDtulo  para Diverticulite Aguda",duracao:10,thumbUrl:"https://i.vimeocdn.com/video/716647949_1920x1273.jpg?r=pad"}],fluxogramas:[{id:"2eb07831-399a-4807-847d-ed2ec8adccd4",nome:"Fluxograma de Diverticulite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/75355c36-2c95-4df2-a6f8-baa42b2b0599.jpg",orientacao:"vertical"},{id:"b2212019-f8cb-412f-8681-09d996007db9",nome:"Fluxograma de Diverticulite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/0e204d18-efd9-4895-89b3-c76d2fcefb07.jpg",orientacao:"horizontal"},{id:"7a089531-48e1-46ad-b4aa-bc721e9aa4d4",nome:"Fluxograma de Diverticulite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/0c2a9c27-047e-44e6-b036-1ade789f5641.jpg",orientacao:"horizontal"},{id:"7ec36441-7cfb-46b9-aab9-f35e4305fd13",nome:"Fluxograma de Diverticulite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/1ec79a94-02f4-429c-8e37-0a50e6076754.jpg",orientacao:"vertical"}],tags:["Divert\xEDculo","Diverticulose"]},{id:"eb7e0f17-0b14-44e6-a05e-0501605fd4a0",nome:"Doen\xE7a Cel\xEDaca",categoria:2,termosDeBusca:"doenca celiaca, celiaca, espru celiaco",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"b8c57a32-0191-4a7c-b46b-3786e9323d60",nome:"Doen\xE7a Cel\xEDaca",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ba06186c-3c27-4355-b88a-bae8754b0b13",opcoes:[{id:"31a32be0-18c7-4b3e-9982-230a8586566f",descr:"Dieta livre de gl\xFAten",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Evitar alimentos que contenham trigo, centeio ou cevada.",ordem:1},{item:"CORTICOIDE",grupos:[{grupo:"Analg\xE9sico",idGrupo:"756f34e0-9f10-489c-a9c0-f618fba8b2e3",opcoes:[{id:"a426fdf7-fee4-439e-b4d4-0b674d84a56a",descr:"Budesonida (3mg/cp) 3 mg VO 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"83a6c3a4-86bb-4310-b98b-470609c58f63",descr:"Prednisona (5-20mg/cp) 0,5-1 mg/Kg VO 1x/dia",recomendado:!1,favorito:!1,ordem:2},{id:"e8ab86dd-ef76-4be5-9175-a609862ebfa7",descr:"Prednisolona (5-40mg/cp) 15-60 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:3},{id:"3ed67aaf-98b3-4d52-9cc7-66cfa2653b3c",descr:"Hidrocortisona (100mg/2mL) 100 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Se refrat\xE1rio: corticoide + imunossupressor.",ordem:2},{item:"IMUNOSSUPRESSOR",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e0837990-e347-49b1-933f-c9e937c99146",opcoes:[{id:"ba810aaa-5175-4f1a-b2e9-8b020d37a48f",descr:"Azatioprina (50mg/cp) 2 mg/Kg VO 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"e09f9635-b091-496d-bb24-f83ec29857cc",descr:"Mercaptopurina (50mg/cp) 2 mg/Kg VO 1x/dia",recomendado:!1,favorito:!1,ordem:2},{id:"704cc58f-d3c4-4c7d-baee-d3889cdf3a13",descr:"Micofenolato de Mofetila (500mg/cp) 500-1000 mg VO 12/12h",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Se refrat\xE1rio: corticoide + imunossupressor.",ordem:3}],conceitosPraticos:[{conceito:"Investiga\xE7\xE3o diagn\xF3stica feita durante dieta com gl\xFAten.",ordem:1},{conceito:"Diagn\xF3stico: cl\xEDnica + sorologia (inicia com anti-tTG-IgA e IgA total) + bi\xF3psia duodenal.",ordem:2},{conceito:"Refrat\xE1rio: cl\xEDnica persistente associada \xE0 atrofia de vilosidades na bi\xF3psia apesar de dieta sem gl\xFAten por \u2265\xA012 meses (tratar com corticoide + imunossupressor).",ordem:3}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">A doen\xE7a cel\xEDaca, com aumento substancial de sua preval\xEAncia nos \xFAltimos 50 anos, caracteriza-se por uma rea\xE7\xE3o autoimune desencadeada pela exposi\xE7\xE3o diet\xE9tica ao gl\xFAten (principal fra\xE7\xE3o proteica presente no trigo, centeio e cevada) que afeta primariamente o intestino delgado com graus variados de disabsor\xE7\xE3o naqueles indiv\xEDduos com predisposi\xE7\xE3o gen\xE9tica (forte rela\xE7\xE3o com HLA-DQ2/DQ8).</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">O quadro cl\xEDnico \xE9 secund\xE1rio ao processo inflamat\xF3rio intestinal com preju\xEDzo \xE0 absor\xE7\xE3o, o que pode ocasionar sintomas gastrointestinais t\xEDpicos (diarreia, esteatorreia, flatul\xEAncia, distens\xE3o e dor abdominal) ou altera\xE7\xF5es fora do trato gastrointestinal (anemia ferropriva, anemia megalobl\xE1stica, doen\xE7a \xF3ssea por defici\xEAncia de vitamina D e c\xE1lcio, baixa estatura, perda de peso, hipoplasia do esmalte dent\xE1rio, altera\xE7\xF5es neurol\xF3gicas por car\xEAncia de vitaminas do complexo B).</span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/35c91d3b-2264-40d6-b8cf-d707448e45ae.jpg" alt="">
  </span>
</p><p>dasdasd 
  <br>
  <br>
  <span style="font-weight: 400;">\xC9 importante notar a associa\xE7\xE3o que a doen\xE7a cel\xEDaca tem com outras condi\xE7\xF5es, como defici\xEAncia seletiva de IgA (que pode impactar no racioc\xEDnio diagn\xF3stico), eleva\xE7\xE3o n\xE3o-espec\xEDfica de transaminases, doen\xE7as autoimunes (diabetes tipo 1, tireoidopatia como Hashimoto e dermatite at\xF3pica) e dermatite herpetiforme (m\xFAltiplas p\xE1pulas e ves\xEDculas intensamente pruriginosas que ocorrem em arranjos agrupados - "herpetiformes" \u2013 especialmente em cotovelo, antebra\xE7o, joelhos, couro cabeludo, costas e n\xE1degas).</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">A avalia\xE7\xE3o diagn\xF3stica para doen\xE7a cel\xEDaca deve ser feita em todos os pacientes com sinais, sintomas ou altera\xE7\xF5es laboratoriais compat\xEDveis com essa condi\xE7\xE3o e deve ser, pelo menos, considerada nos parentes de primeiro grau (mesmo assintom\xE1ticos) de um caso confirmado.</span>
</p><p>
  <span style="font-weight: 400;">Esse racioc\xEDnio diagn\xF3stico passa pela avalia\xE7\xE3o sorol\xF3gica e, em boa parte dos casos, pela bi\xF3psia duodenal, mas \xE9 importante lembrar que, como a circula\xE7\xE3o de anticorpos e a inflama\xE7\xE3o intestinal s\xE3o desencadeadas pela exposi\xE7\xE3o ao gl\xFAten, toda a investiga\xE7\xE3o deve ser feita sem restri\xE7\xE3o diet\xE9tica.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* A sorologia dispon\xEDvel hoje inclui autoanticorpos como antitransglutaminase tecidual e antiendom\xEDseo e anticorpos contra a part\xEDcula agressiva do gl\xFAten (gliadina), que pode ser o antigliadina convencional (obsoleto para fim diagn\xF3stico) ou o antigliadina deaminada.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">O primeiro passo \xE9 a dosagem de antitransglutaminase tecidual IgA (anti-tTG-IgA) e da pr\xF3pria IgA total, uma vez que a defici\xEAncia de IgA est\xE1 presente em 2-3% dos portadores de doen\xE7a cel\xEDaca:</span>
</p><p>
  <span style="font-weight: 400;">(1) anti-tTG-IgA (+) \u2192 a sequ\xEAncia cl\xE1ssica seria referenciar para a bi\xF3psia duodenal a fim de confirmar o diagn\xF3stico, mas, a depender da intensidade dos t\xEDtulos desse anticorpo, \xE9 poss\xEDvel talvez evitar esse grau maior de invas\xE3o:</span>
</p><p>
  <span style="font-weight: 400;">- anti-tTG-IgA \u2265 10x limite superior de normalidade \u2192 coletar nova amostra de sangue para antiendom\xEDseo IgA (anti-EMA IgA): se (+), pode-se confirmar doen\xE7a cel\xEDaca, evitando bi\xF3psia especialmente em crian\xE7as, enquanto adultos at\xE9 poderiam realizar bi\xF3psia para fins de diagn\xF3stico diferencial.</span>
</p><p>
  <span style="font-weight: 400;">- anti-tTG-IgA &lt; 10x limite superior de normalidade \u2192 bi\xF3psia duodenal</span>
</p><p>
  <span style="font-weight: 400;">(2) anti-tTG-IgA (-) / IgA total (-) \u2192 pesquisar anticorpos IgG, ou seja, antigliadina deaminada IgG (anti-DPG-IgG) e antitransglutaminase tecidual IgG (anti-tTG-IgG): se (+) para um deles, referenciar para bi\xF3psia duodenal; se todos (-) n\xE3o deve ser doen\xE7a cel\xEDaca, mas a bi\xF3psia ainda poderia ser feita em caso de alta probabilidade cl\xEDnica.</span>
</p><p>
  <span style="font-weight: 400;">(3) anti-tTG-IgA (-) / IgA total (+) \u2192 n\xE3o deve ser doen\xE7a cel\xEDaca, mas a bi\xF3psia ainda poderia ser feita em caso de alta probabilidade cl\xEDnica.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Antigamente, nas crian\xE7as &lt; 2 anos, a recomenda\xE7\xE3o era de que o rastreio inicial fosse feito com anti-tTG-IgA e com anti-DPG (IgA e IgG) pela impress\xE3o de que o anti-DPG era mais sens\xEDvel nessa faixa et\xE1ria, mas estudos subsequentes n\xE3o confirmaram essa teoria.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">A bi\xF3psia duodenal \xE9 feita por endoscopia e as altera\xE7\xF5es s\xE3o graduadas pela classifica\xE7\xE3o de Marsh (modificada por Oberhuber), na qual os padr\xF5es de Marsh 2 e 3, embora n\xE3o sejam patognom\xF4nicos, confirmam o diagn\xF3stico. J\xE1 um resultado com padr\xF5es de Marsh 0 e 1 n\xE3o tem uma conduta consensual, podendo considerar a relev\xE2ncia dos sintomas para j\xE1 iniciar um tratamento ou fazer testagem laboratorial adicional (HLA-DQ2/DQ8; anticorpos associados \xE0 doen\xE7a e ainda n\xE3o testados).</span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">O \xFAnico tratamento efetivo para a doen\xE7a cel\xEDaca \xE9 a dieta livre de gl\xFAten, n\xE3o havendo atualmente op\xE7\xE3o farmacol\xF3gica adjuvante. Assim, o mais importante \xE9 a ado\xE7\xE3o de um h\xE1bito diet\xE9tico que evite trigo, centeio e cevada \u2013 embora o gl\xFAten tamb\xE9m possa ser encontrado na aveia, alguns estudos sugerem que a aveia pura possa ser tolerada pela maioria dos pacientes. Infelizmente, evitar estritamente gl\xFAten \xE9 dif\xEDcil porque existem muitas fontes ocultas em produtos aliment\xEDcios comerciais.</span>
</p><p>
  <span style="font-weight: 400;">Cerca de 70% dos pacientes apresentam melhora cl\xEDnica significativa em at\xE9 2 semanas. O acompanhamento da resposta terap\xEAutica \xE0 dieta envolve sempre reavalia\xE7\xE3o cl\xEDnica e sorologia (tTG-IgA ou anti-DPG-IgA/IgG), sendo tamb\xE9m muito importante para as crian\xE7as a monitoriza\xE7\xE3o de seu crescimento e desenvolvimento. A periodicidade desse acompanhamento n\xE3o \xE9 algo consensual, mas \xE9 razo\xE1vel que o primeiro retorno ocorra em at\xE9 3-6 meses do in\xEDcio terap\xEAutico, com outro programado para 12 meses e, depois, anualmente. Uma sorologia ainda positiva ap\xF3s 1 ano sugere fortemente contamina\xE7\xE3o de gl\xFAten na dieta.&nbsp;
    <br>
  </span>
</p><p>
  <span style="font-weight: 400;">A repeti\xE7\xE3o da bi\xF3psia duodenal \xE9 indicada nos casos com sintomas refrat\xE1rios (mesmo que com sorologia normalizada). Tamb\xE9m parece razo\xE1vel sua repeti\xE7\xE3o ap\xF3s 1-2 anos nos pacientes que apresentam melhora cl\xEDnica e sorol\xF3gica para confirmar definitivamente a cicatriza\xE7\xE3o da mucosa (que costuma ser mais tardia que a melhora cl\xEDnica).</span>
</p><p>
  <span style="font-weight: 400;">A doen\xE7a cel\xEDaca refrat\xE1ria \xE9 definida como sinais e sintomas de m\xE1-absor\xE7\xE3o persistentes ou recorrentes com atrofia de vilosidades em intestino delgado apesar da dieta livre de gl\xFAten por mais de 12 meses e na aus\xEAncia de outros dist\xFArbios (como linfoma). A partir da bi\xF3psia, h\xE1 uma separa\xE7\xE3o entre dois tipos de refratariedade: (1) Tipo 1: infiltrado linfocit\xE1rio intraepitelial normal; (2) Tipo 2: infiltrado linfocit\xE1rio intraepitelial aberrante, com risco de progress\xE3o para linfoma e geralmente com apresenta\xE7\xE3o mais grave. O tratamento acaba sendo com alguma estrat\xE9gia de imunossupress\xE3o, que costuma iniciar com corticoide por, pelo menos, 3 meses (budesonida 3 mg 8/8h VO, prednisona 0,5-1 mg/Kg 1x/dia VO ou hidrocortisona 100 mg 6/6h IV), associado a um imunomodulador como azatioprina/6-mercaptopurina (2 mg/kg/dia) ou micofenolato mofetila (500 mg 12/12h VO/IV), que acaba permanecendo como terapia de manuten\xE7\xE3o por 2-3 anos. Casos mais graves ou refrat\xE1rios podem requerer estrat\xE9gias de absoluta exce\xE7\xE3o, como cladribina ou fludarabina (0,15 mg/kg/dia por 5 dias).</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- HLA-DQ2/DQ8 \u2013</strong> 
  <span style="font-weight: 400;">Como dito anteriormente, h\xE1 um peso gen\xE9tico importante na doen\xE7a, comprovado pela forte rela\xE7\xE3o com HLA-DQ2/DQ8, o que fez com que, durante muito tempo, a pesquisa desses HLAs fosse realizada no algoritmo diagn\xF3stico. Atualmente, n\xE3o \xE9 mais assim, de forma que a determina\xE7\xE3o do HLA-DQ2/DQ8 \xE9 \xFAtil apenas para descartar doen\xE7a cel\xEDaca em situa\xE7\xF5es como: discord\xE2ncia entre sorologia (+) e histologia (-) ou paciente que recuse endoscopia.</span>
</p><p>
  <strong>- Risco de c\xE2ncer \u2013</strong> 
  <span style="font-weight: 400;">Pacientes com doen\xE7a cel\xEDaca t\xEAm risco aumentado de linfoma e c\xE2ncer gastrointestinal, por\xE9m ainda \xE9 incerto afirmar se a ades\xE3o \xE0 dieta sem gl\xFAten influencia nas taxas de c\xE2ncer.</span>
</p><p>
  <strong>- Sensibilidade n\xE3o-cel\xEDaca ao gl\xFAten \u2013</strong> 
  <span style="font-weight: 400;">A sensibilidade n\xE3o-cel\xEDaca ao gl\xFAten descreve uma s\xEDndrome de resposta sintom\xE1tica \xE0 ingest\xE3o de gl\xFAten em pacientes sem evid\xEAncia sorol\xF3gica ou histol\xF3gica de doen\xE7a cel\xEDaca. \xC9 uma situa\xE7\xE3o que n\xE3o parece associada \xE0 m\xE1-absor\xE7\xE3o ou risco aumentado para malignidade. O tratamento acaba sendo a redu\xE7\xE3o da exposi\xE7\xE3o ao gl\xFAten.</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Husby S, Murray JA, Katzka DA. AGA Clinical Practice Update on Diagnosis and Monitoring of Celiac Disease - Changing Utility of Serology and Histologic Measures: Expert Review.</span> 
    <em>
      <span style="font-weight: 400;">Gastroenterology</span>
    </em> 
    <span style="font-weight: 400;">2018;156(4):885-889.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Husby S, Koletzko S, Korponay-Szab\xF3 I, Kurppa K, et al. European Society Paediatric Gastroenterology, Hepatology and Nutrition Guidelines for Diagnosing Coeliac Disease 2020.</span> 
    <em>
      <span style="font-weight: 400;">Journal of Pediatric Gastroenterology and Nutrition</span>
    </em> 
    <span style="font-weight: 400;">2020;70(1):141-157.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Al-Toma A, Volta U, Auricchio R, Castillejo G, et al. European Society for the Study of Coeliac Disease (ESsCD) guideline for coeliac disease and other gluten-related disorders.</span> 
    <em>
      <span style="font-weight: 400;">United European Gastroenterology Journal</span>
    </em> 
    <span style="font-weight: 400;">2019;7(5):583\u2013613.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Rubio-Tapia A, Hill ID, Kelly CP, Calderwood AH, Murray JA. ACG Clinical Guidelines: Diagnosis and Management of Celiac Disease.</span> 
    <em>
      <span style="font-weight: 400;">Am J Gastroenterol</span>
    </em> 
    <span style="font-weight: 400;">2013;108:656\u2013676.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Minist\xE9rio da Sa\xFAde (BR). Comiss\xE3o Nacional de Incorpora\xE7\xE3o de Tecnologias no SUS (CONITEC). Secretaria de Ci\xEAncia, Tecnologia e Insumos Estrat\xE9gicos. Protocolo Cl\xEDnico e Diretrizes Terap\xEAuticas da Doen\xE7a Cel\xEDaca. Minist\xE9rio da Sa\xFAde, 2015.</span>
  </li>
</ol>`,ordem:6}],videos:[],fluxogramas:[],tags:["Cel\xEDaca","Espru Cel\xEDaco"]},{id:"a5d9d79a-be19-4851-a855-be8dc73df1c0",nome:"Doen\xE7a Coronariana Est\xE1vel",categoria:2,termosDeBusca:"doenca coronariana estavel, dac, coronariopatia, angina estavel, angina",favoritado:!1,ordem:0,especialidades:[{nome:"CARDIOLOGIA"}],prescricoes:[],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">A doen\xE7a coronariana est\xE1vel \u2013 tamb\xE9m denominada de s\xEDndrome coronariana cr\xF4nica \u2013 refere-se \xE0 presen\xE7a de placa ateroscler\xF3tica em art\xE9rias coron\xE1rias com risco de determinar uma perfus\xE3o inadequada ao mioc\xE1rdio.</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">A manifesta\xE7\xE3o cl\xE1ssica \xE9 a angina est\xE1vel que, na sua forma t\xEDpica, apresenta 3 caracter\xEDsticas: (1) dor ou desconforto retroesternal (pode irradiar para mand\xEDbula, membros superiores e epig\xE1strio) de curta dura\xE7\xE3o - \u2264&nbsp;10 minutos na maioria dos casos; (2) desencadeada por exerc\xEDcio ou estresse emocional; (3) aliviada em 5 minutos com repouso ou nitrato sublingual.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* A angina at\xEDpica tem 2 dessas caracter\xEDsticas; enquanto a dor tor\xE1cica n\xE3o-anginosa tem apenas um ou nenhum desses itens.</span>
  </em>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">O diagn\xF3stico geralmente acaba sendo feito a partir de exames n\xE3o invasivos que, em sua maioria, s\xE3o funcionais (provoca-se isquemia com stress f\xEDsico ou farmacol\xF3gico), mas podem ser at\xE9 anat\xF4micos (como \xE9 o caso da angioTC de coron\xE1ria). A utiliza\xE7\xE3o de coronariografia (teste invasivo) para o diagn\xF3stico s\xF3 se justifica nos casos ainda inconclusivos com exames n\xE3o-invasivos.</span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/0898cb2f-f71d-4e2f-b2c8-191a5659c333.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>
  <span style="font-weight: 400;">Classicamente, a proposta inicial \u2013 antes mesmo de executar testes diagn\xF3sticos \u2013 \xE9 classificar o doente quanto \xE0 sua probabilidade de doen\xE7a coronariana (a chamada probabilidade pr\xE9-teste), o que \xE9 feito pela avalia\xE7\xE3o cl\xEDnica (caracteriza\xE7\xE3o da dor e exame f\xEDsico, esse \xFAltimo usualmente normal) e por exames complementares b\xE1sicos: eletrocardiograma (utilidade maior ao mostrar sinais de infarto pr\xE9vio, como onda Q patol\xF3gica, ou altera\xE7\xF5es de repolariza\xE7\xE3o ventricular associadas \xE0 isquemia subepic\xE1rdica, como ondas T negativas e sim\xE9tricas em uma parede), hemograma completo, glicemia de jejum, hemoglobina glicada, perfil lip\xEDdico, fun\xE7\xE3o renal, radiografia de t\xF3rax em casos selecionados (suspeita de insufici\xEAncia card\xEDaca ou doen\xE7a pulmonar associadas) e perfil tireoideano (na suspeita de tireoideopatia).</span>
</p><p>
  <span style="font-weight: 400;">A partir do resultado da probabilidade pr\xE9-teste (PPT) \u2013 em que as diretrizes brasileira e americana usam o mesmo modelo, que \xE9 discretamente diferente do modelo europeu mais recente \u2013 separa-se a condu\xE7\xE3o diagn\xF3stica da seguinte forma:</span>
</p><p>
  <span style="font-weight: 400;">- PPT baixa (&lt; 10-15%): assume-se que o mais prov\xE1vel \xE9 a inexist\xEAncia de doen\xE7a coronariana, n\xE3o sendo obrigat\xF3ria a realiza\xE7\xE3o de investiga\xE7\xF5es diagn\xF3sticas adicionais, mas, se estas forem feitas, pode-se optar principalmente pelo teste ergom\xE9trico se o paciente for capaz de realizar exerc\xEDcio ou ecocardiograma de stress farmacol\xF3gico e angioTC de coron\xE1ria nos casos incapazes de se exercitar. Testes adicionais podem ser feitos para pesquisa de causas n\xE3o-card\xEDacas de dor tor\xE1cica.</span>
</p><p>
  <span style="font-weight: 400;">- PPT alta (&gt; 90%): assume-se o prov\xE1vel diagn\xF3stico de doen\xE7a coronariana, sendo tamb\xE9m menos importante um exame diagn\xF3stico confirmat\xF3rio, embora possam ser feitos ecocardiograma ou cintilografia de stress (f\xEDsico ou farmacol\xF3gico).</span>
</p><p>
  <span style="font-weight: 400;">- PPT intermedi\xE1ria (10/15-90%): esse \xE9 o grupo que mais se beneficia de testes diagn\xF3sticos n\xE3o-invasivos, cuja escolha depende de alguns fatores, especialmente da capacidade do paciente realizar exerc\xEDcios:</span>
</p><p>
  <span style="font-weight: 400;">(1) Capaz de realizar exerc\xEDcio: se o ECG basal for interpret\xE1vel (sem BRE, pr\xE9-excita\xE7\xE3o tipo Wolff-Parkinson-White ou infra de ST &gt; 1 mm, opta-se pelo teste ergom\xE9trico. J\xE1, se o ECG tiver estas altera\xE7\xF5es que atrapalhem a avalia\xE7\xE3o do teste ergom\xE9trico, opta-se preferencialmente por ecocardiograma/cintilografia de stress f\xEDsico. Outras op\xE7\xF5es s\xE3o: resson\xE2ncia com stress farmacol\xF3gico ou angioTC de coron\xE1ria.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Diferente das diretrizes brasileira e norte-americana, a europeia n\xE3o d\xE1 o mesmo valor ao teste ergom\xE9trico, afirmando que ele pode ser considerado como exame inicial apenas caso n\xE3o haja disponibilidade de outros m\xE9todos.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">(2) Incapaz de realizar exerc\xEDcio: O ideal \xE9 optar por ecocardiograma/cintilografia de stress farmacol\xF3gico. Outras op\xE7\xF5es: resson\xE2ncia de stress farmacol\xF3gico ou angioTC de coron\xE1ria.</span>
</p><p>
  <strong>- Estratifica\xE7\xE3o de risco \u2013</strong>
  <span style="font-weight: 400;">Ap\xF3s o diagn\xF3stico \u2013 seja com aux\xEDlio de testes diagn\xF3sticos ou atrav\xE9s do racioc\xEDnio cl\xEDnico para pacientes de probabilidade pr\xE9-teste alta \u2013 \xE9 importante a identifica\xE7\xE3o de pacientes de alto risco (risco de morte &gt; 3%/ano), os quais poder\xE3o se beneficiar de estrat\xE9gias de revasculariza\xE7\xE3o al\xE9m do tratamento medicamentoso. Para tal estratifica\xE7\xE3o, s\xE3o usados os dados dos testes diagn\xF3sticos j\xE1 citados, al\xE9m do ecocardiograma transtor\xE1cico de repouso. Assim, s\xE3o considerados de alto risco:</span>
</p><p>
  <span style="font-weight: 400;">-&nbsp; Ecocardiograma de repouso: disfun\xE7\xE3o grave do VE (FE &lt; 35%)</span>
</p><p>
  <span style="font-weight: 400;">-&nbsp; Teste ergom\xE9trico: escore de risco elevado (escore de Duke &lt; - 11)</span>
</p><p>
  <span style="font-weight: 400;">- Cintilografia de stress (SPECT): \xE1rea de isquemia \u2265 10% do mioc\xE1rdio do VE; defeitos com dilata\xE7\xE3o do VE ou aumento na capta\xE7\xE3o pulmonar utilizando o t\xE1lio.</span>
</p><p>
  <span style="font-weight: 400;">- Ecocardiograma de stress: disfun\xE7\xE3o grave do VE (pico de FE &lt; 45% ou redu\xE7\xE3o de FE \u2265&nbsp;10%); altera\xE7\xE3o contr\xE1til de hipocinesia ou acinesia em &gt; 2 segmentos com baixa FC (&lt; 120 bpm) ou com baixa dose de dobutamina (\u2264 10 mcg/kg/min)</span>
</p><p>
  <span style="font-weight: 400;">- AngioTC de coron\xE1ria: doen\xE7a obstrutiva multiarterial (estenose \u2265 70%) ou les\xE3o significativa de tronco de coron\xE1ria esquerda (estenose \u2265 50%)</span>
</p><p>
  <span style="font-weight: 400;">- Resson\xE2ncia de stress: \u2265 2 segmentos com defeito perfusional; \u2265 3 segmentos disfuncionantes com dobutamina&nbsp;</span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">Naturalmente, a abordagem n\xE3o medicamentosa \xE9 importante e inclui interrup\xE7\xE3o do tabagismo, dieta saud\xE1vel, atividade f\xEDsica (30-60 minutos de atividade f\xEDsica moderada, como caminhada r\xE1pida, na maioria dos dias) e controle do peso (objetivar IMC &lt; 25 Kg/m</span>
  <span style="font-weight: 400;">2</span>
  <span style="font-weight: 400;">, circunfer\xEAncia abdominal &lt; 102 cm nos homens e &lt; 88 cm nas mulheres). \xC9 indicada tamb\xE9m vacina\xE7\xE3o anual contra o v\xEDrus influenza. A partir de agora, nosso foco maior ser\xE1 no tratamento medicamentoso, \xFAtil para al\xEDvio sintom\xE1tico (abordagem anti-isqu\xEAmica) e para a pr\xF3pria preven\xE7\xE3o de eventos cardiovasculares (especialmente o IAM), e tamb\xE9m nas indica\xE7\xF5es de revasculariza\xE7\xE3o.</span>
</p><p>
  <strong>- Abordagem anti-isqu\xEAmica \u2013</strong>
  <span style="font-weight: 400;">O tratamento agudo de um quadro anginoso \xE9 feito com nitrato de a\xE7\xE3o curta (nitroglicerina, dinitrato de isossorbida ou propatilnitrato) atrav\xE9s de administra\xE7\xE3o sublingual ou spray (aplicado na l\xEDngua). Durante esse tratamento da crise de angina, o paciente deve manter-se sentado, pois, em ortostase, h\xE1 risco de hipotens\xE3o/s\xEDncope e, quando deitado, aumenta o retorno venoso e o trabalho card\xEDaco.</span>
</p><p>
  <br>
</p><p>
  <span style="font-weight: 400;">O tratamento anti-isqu\xEAmico cr\xF4nico deve ser escalonado de acordo com a necessidade do paciente com reavalia\xE7\xE3o da resposta em 2-4 semanas. Nesse sentido, o</span>
  <span style="font-weight: 400;">beta-bloqueador</span>
  <span style="font-weight: 400;">\xE9 a principal estrat\xE9gia, devendo ser utilizado por todos os pacientes que n\xE3o apresentem contraindica\xE7\xE3o, objetivando uma FC entre 55-60 bpm. Na intoler\xE2ncia ou contraindica\xE7\xE3o ao beta-bloqueador, as principais op\xE7\xF5es s\xE3o</span>
  <span style="font-weight: 400;">bloqueador de canal de c\xE1lcio n\xE3o-diidropirid\xEDnico</span>
  <span style="font-weight: 400;">(verapamil ou diltiazem, que tamb\xE9m n\xE3o devem ser usados nos dist\xFArbios de ritmo) ou</span>
  <span style="font-weight: 400;">ivabradina</span>
  <span style="font-weight: 400;">(necess\xE1rio ritmo sinusal e cuidado com redu\xE7\xE3o excessiva de FC; n\xE3o associar com verapamil/diltiazem).</span>
</p><p>
  <span style="font-weight: 400;">A aus\xEAncia de resposta ao beta-bloqueador indica a adi\xE7\xE3o de</span>
  <span style="font-weight: 400;">bloqueador de canal de c\xE1lcio diidropirid\xEDnico</span>
  <span style="font-weight: 400;">de a\xE7\xE3o longa (anlodipino, nifedipino) e, se ainda houver melhora, opta-se por</span>
  <span style="font-weight: 400;">nitrato de a\xE7\xE3o longa</span>
  <span style="font-weight: 400;">(mono ou dinitrato de isossorbida), o qual precisa diariamente de um per\xEDodo de 8-14h livre do medicamento para que n\xE3o seja desenvolvida toler\xE2ncia. Se ainda n\xE3o houver boa resposta, outros f\xE1rmacos podem ser acrescentados, como</span>
  <span style="font-weight: 400;">ivabradina</span>
  <span style="font-weight: 400;">,</span>
  <span style="font-weight: 400;">nicorandil</span>
  <span style="font-weight: 400;">,</span>
  <span style="font-weight: 400;">trimetazidina</span>
  <span style="font-weight: 400;">ou</span>
  <span style="font-weight: 400;">ranolazina</span>
  <span style="font-weight: 400;">(risco de aumentar intervalo QT, usar em baixa dose se associada a verapamil/diltiazem). Atualmente, o</span>
  <span style="font-weight: 400;">alopurinol</span>
  <span style="font-weight: 400;">\xE9 considerado uma op\xE7\xE3o para os casos que permanecem sintom\xE1ticos mesmo em uso de terapia antianginosa m\xE1xima.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Como trimetazidina e ranolazina n\xE3o t\xEAm efeito na hemodin\xE2mica cardiovascular, podem ser utilizados como drogas de primeira linha em pacientes com tend\xEAncia \xE0 bradicardia e/ou hipotens\xE3o. N\xE3o se recomenda a associa\xE7\xE3o de beta-bloqueador e bloqueador de canal de c\xE1lcio n\xE3o-diidropirid\xEDnico (verapamil/diltiazem).</span>
  </em>
</p><p>
  <strong>- Preven\xE7\xE3o de evento cardiovascular \u2013</strong>
  <span style="font-weight: 400;">Para preven\xE7\xE3o de trombose coronariana e consequente IAM, \xE9 recomendado o uso de</span>
  <span style="font-weight: 400;">antiagregante plaquet\xE1rio</span>
  <span style="font-weight: 400;">, de forma que o AAS 75-100 mg (dose baixa) est\xE1 indicado para todos os pacientes. Nos casos de alergia ou hist\xF3ria de sangramento digestivo com AAS, clopidogrel 75 mg/dia \xE9 a melhor op\xE7\xE3o, de modo que os outros inibidores P2Y</span>
  <span style="font-weight: 400;">12</span>
  <span style="font-weight: 400;">, prasugrel e ticagrelor, alternativas usadas nas s\xEDndromes coronarianas agudas, ainda n\xE3o foram testados para a doen\xE7a coronariana est\xE1vel. Outra op\xE7\xE3o ao AAS, por\xE9m com muito menos evid\xEAncia de benef\xEDcio \xE9 a ticlopidina.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">Tamb\xE9m entra como estrat\xE9gia preventiva o tratamento adequado de eventuais comorbidades, como</span>
  <a href="http://../HIPERTENSA%CC%83O%20ARTERIAL%20SISTE%CC%82MICA/Hipertensa%CC%83o%20Arterial%20Siste%CC%82mica%20-%20TEXTO.docx">
    <span style="font-weight: 400;">hipertens\xE3o</span>
  </a>
  <span style="font-weight: 400;">e</span>
  <a href="http://../../4%20-%20ENDOCRINOLOGIA/Diabetes/Diabetes%20-%20TEXTO.docx">
    <span style="font-weight: 400;">diabetes</span>
  </a>
  <span style="font-weight: 400;">, e</span>
  <a href="http://../DISLIPIDEMIA/Dislipidemia%20-%20TEXTO.docx">
    <span style="font-weight: 400;">dislipidemia</span>
  </a>
  <span style="font-weight: 400;">. Lembrando que, no racioc\xEDnio da dislipidemia, a doen\xE7a arterial coronariana classifica o paciente como de risco muito alto, para o qual temos o alvo de LDL &lt; 50 mg/dL, sendo prescrita</span>
  <span style="font-weight: 400;">estatina de alta intensidade</span>
  <span style="font-weight: 400;">(se o alvo n\xE3o for atingido, pode-se associar ezetimiba ou ainda inibidor de PCSK-9). Tamb\xE9m \xE9 v\xE1lido o uso de</span>
  <span style="font-weight: 400;">inibidor da ECA</span>
  <span style="font-weight: 400;">(ou, na sua intoler\xE2ncia,</span>
  <span style="font-weight: 400;">bloqueador de receptor de angiotensina-II</span>
  <span style="font-weight: 400;">), obviamente com maior n\xEDvel de evid\xEAncia na associa\xE7\xE3o com hipertens\xE3o, insufici\xEAncia card\xEDaca com fra\xE7\xE3o de eje\xE7\xE3o reduzida, diabetes ou doen\xE7a renal cr\xF4nica.</span>
</p><p>
  <strong>- Revasculariza\xE7\xE3o \u2013</strong>
  <span style="font-weight: 400;">A revasculariza\xE7\xE3o pode ser indicada tanto para aumentar a sobrevida em paciente est\xE1veis como para al\xEDvio sintom\xE1tico nos casos refrat\xE1rios \xE0 abordagem medicamentosa. As principais indica\xE7\xF5es atuais s\xE3o:</span>
</p><p>
  <span style="font-weight: 400;">- Estenose de tronco de coron\xE1ria esquerda \u2265 50%*</span>
</p><p>
  <span style="font-weight: 400;">- Estenose proximal em descendente anterior \u2265 50%*</span>
</p><p>
  <span style="font-weight: 400;">- Estenose de 2 ou 3 vasos \u2265 50% (doen\xE7a bi ou triarterial) com disfun\xE7\xE3o de VE*</span>
</p><p>
  <span style="font-weight: 400;">- Isquemia em grande \xE1rea (&gt; 10% VE) avaliada por teste n\xE3o-invasivo (SPECT, resson\xE2ncia ou ecocardiograma de stress)</span>
</p><p>
  <span style="font-weight: 400;">- Les\xE3o uniarterial remanescente com estenose \u2265 50%*</span>
  <em>
    <span style="font-weight: 400;">(menor n\xEDvel de evid\xEAncia)</span>
  </em>
</p><p>
  <span style="font-weight: 400;">- Angina refrat\xE1ria associada a qualquer estenose hemodinamicamente significativa*</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Desde que haja: (1) isquemia documentada por exame n\xE3o-invasivo; ou (2) les\xE3o hemodinamicamente relevante, ou seja, estenose &gt; 90% ou com reserva de fluxo fracionada (FFR, em ingl\xEAs) \u2264 0,80 (avalia\xE7\xE3o intracoron\xE1ria que demonstra gravidade durante angiografia).</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Outra decis\xE3o a ser tomada \xE9 se a revasculariza\xE7\xE3o ser\xE1 cir\xFArgica (Cirurgia de Revasculariza\xE7\xE3o Mioc\xE1rdica - CRM) ou percut\xE2nea (Interven\xE7\xE3o Coron\xE1ria Percut\xE2nea \u2013 ICP). Os elementos que favorecem a escolha pela CRM s\xE3o escore SYNTAX \u2265&nbsp;23, presen\xE7a de diabetes principalmente nas les\xF5es multiarteriais e a necessidade eventual de outras interven\xE7\xF5es cir\xFArgicas concomitantes (valvares ou a\xF3rticas). J\xE1 as caracter\xEDsticas que mais favorecem a ICP s\xE3o escore SYNTAX \u2264 22 e um risco cir\xFArgico mais elevado (como escore STS \u2265 5%).</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* O escore SYNTAX baseia-se nos achados da coronariografia (localiza\xE7\xE3o, n\xFAmero e complexidade das les\xF5es) e pode ser visualizado em</span>
  </em>
  <a href="http://www.syntaxsocre.com">
    <em>
      <span style="font-weight: 400;">www.syntaxsocre.com</span>
    </em>
  </a>
  <em>
    <span style="font-weight: 400;">. O escore STS pode ser acessado em</span>
  </em>
  <a href="http://riskcalc.sts.org/stswebriskcalc/calculate">
    <em>
      <span style="font-weight: 400;">http://riskcalc.sts.org/stswebriskcalc/calculate</span>
    </em>
  </a>
  <em>
    <span style="font-weight: 400;">.&nbsp;</span>
  </em>
</p><p>
  <strong>- Casos refrat\xE1rios \u2013</strong>
  <span style="font-weight: 400;">Para casos de angina refrat\xE1ria, debilitante e n\xE3o abord\xE1vel por revasculariza\xE7\xE3o, podem ser considerados tratamentos n\xE3o usuais e que ainda carecem de evid\xEAncia, como contrapulsa\xE7\xE3o externa aumentada, estimula\xE7\xE3o espinhal e revasculariza\xE7\xE3o transmioc\xE1rdica.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Angina Vasoesp\xE1stica \u2013</strong>
  <span style="font-weight: 400;">A angina vasoesp\xE1stica (ou angina variante ou angina de Prinzmetal) \xE9 uma entidade cl\xEDnica causada por espasmo coronariano que produz um quadro transit\xF3rio de angina geralmente ao repouso, associada com altera\xE7\xF5es isqu\xEAmicas do segmento ST igualmente transit\xF3rias no eletrocardiograma. Para seu tratamento cr\xF4nico, indica-se nitrato de a\xE7\xE3o longa e bloqueador de canal de c\xE1lcio, contraindicando o uso de beta-bloqueadores. Para o tratamento agudo, s\xE3o feitos nitratos de a\xE7\xE3o curta e alguns centros (especialmente no Jap\xE3o) usam fasudil IV (inibidor de rho quinase) para casos refrat\xE1rios.</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Knuuti J, Wijns W, Saraste A, et al. 2019 ESC Guidelines for the diagnosis and management of chronic coronary syndromes.</span>
    <em>
      <span style="font-weight: 400;">European Heart Journal</span>
    </em>
    <span style="font-weight: 400;">2020; 41: 407-477.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Cesar LA, Ferreira JF, Armaganijan D, Gowdak LH, Mansur AP, Bodanese LC, et al. Diretriz de Doen\xE7a Coron\xE1ria Est\xE1vel.</span>
    <em>
      <span style="font-weight: 400;">Arq Bras Cardiol</span>
    </em>
    <span style="font-weight: 400;">2014; 103(2Supl.2): 1-59.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Fihn SD, Blankenship JC, Alexander KP, Bittl JA, Byrne JG, Fletcher BJ, Fonarow GC, Lange RA, Levine GN, Maddox TM, Naidu SS, Ohman EM, Smith PK. 2014 ACC/AHA/AATS/PCNA/SCAI/STS focused update of the guideline for the diagnosis and management of patients with stable ischemic heart disease: a report of the American College of Cardiology/American Heart Association Task Force on Practice Guidelines, and the American Association for Thoracic Surgery, Preventive Cardiovascular Nurses Association, Society for Cardiovascular Angiography and Interventions, and Society of Thoracic Surgeons.</span>
    <em>
      <span style="font-weight: 400;">J Am Coll Cardiol</span>
    </em>
    <span style="font-weight: 400;">2014; 64:1929\u20131949.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Fihn SD, Gardin JM, Abrams J, Berra K, Blankenship JC, Dallas AP, Douglas PS, Foody JM, Gerber TC, Hinderliter AL, King SB III, Kligfield PD, Krumholz HM, Kwong RYK, Lim MJ, Linderbaum JA, Mack MJ, Munger MA, Prager RL, Sabik JF, Shaw LJ, Sikkema JD, Smith CR Jr, Smith SC Jr, Spertus JA, Williams SV. 2012 ACCF/AHA/ACP/AATS/PCNA/SCAI/STS guideline for the diagnosis and management of patients with stable ischemic heart disease: a report of the American College of Cardiology Foundation/American Heart Association Task Force on Practice Guidelines, and the American College of Physicians, American Association for Thoracic Surgery, Preventive Cardiovascular Nurses Association, Society for Cardiovascular Angiography and Interventions, and Society of Thoracic Surgeons.</span>
    <em>
      <span style="font-weight: 400;">J Am Coll Cardiol</span>
    </em>
    <span style="font-weight: 400;">2012; 60:2564\u20132603.</span>
  </li>
</ol><p>
  <span style="font-weight: 400;">Neumann FJ, Sousa-Uva M, Ahlsson A, Alfonso F, et al. 2018 ESC/EACTS Guidelines on myocardial revascularization.</span>
  <em>
    <span style="font-weight: 400;">European Heart Journal</span>
  </em>
  <span style="font-weight: 400;">2019; 40: 87-165.</span>
</p>`,ordem:6}],videos:[{id:"60cb5a40-a1b1-42b6-b3f6-c3f45980bb67",titulo:"Coronariana Est\xE1vel",duracao:6,thumbUrl:"https://i.vimeocdn.com/video/716648141_1920x1273.jpg?r=pad"},{id:"dd8c62a1-db0b-46e2-8c61-08336fab7ecf",titulo:"Doen\xE7a Coronariana",duracao:15,thumbUrl:"https://i.vimeocdn.com/video/716647839_1920x1273.jpg?r=pad"}],fluxogramas:[],tags:["DAC","Coronariopatia","Angina Est\xE1vel","Angina"]},{id:"22d3c372-ce41-4270-840a-714683b5c07f",nome:"Doen\xE7a do Refluxo Gastroesof\xE1gico (DRGE)",categoria:2,termosDeBusca:"doenca do refluxo gastroesofagico (drge), refluxo, drge, barrett",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"14c8e9c5-673a-495a-968f-a4931db6749c",nome:"DRGE",favorito:!0,ordem:1,secoes:[{item:"INIBIDOR DE BOMBA DE PR\xD3TON",grupos:[{grupo:"Analg\xE9sico",idGrupo:"73e08856-3279-4eec-97b2-24aefd69f462",opcoes:[{id:"e7576ca4-34f5-4b63-a8d3-7a01eb6b0fad",descr:"Esomeprazol (20-40mg/cp) 40 mg VO 1x/dia pela manh\xE3 em jejum (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"46c82dfd-edd5-495c-9429-bbde6ae83ba6",descr:"Omeprazol (10-40mg/cp) 20 mg VO 1x/dia pela manh\xE3 em jejum",recomendado:!1,favorito:!1,ordem:2},{id:"b2e26204-106e-4a60-a6ec-6c36b6c1a59d",descr:"Lanzoprazol (15-30mg/cp) 30 mg VO 1x/dia pela manh\xE3 em jejum",recomendado:!1,favorito:!1,ordem:3},{id:"281813fe-7b18-495a-a84f-44f749651226",descr:"Pantoprazol (20-40mg/cp)40 mg VO 1x/dia pela manh\xE3 em jejum",recomendado:!1,favorito:!1,ordem:4},{id:"75c5133d-1e9a-49d9-814e-f08312226fa0",descr:"Rabeprazol (10-20mg/cp) 20 mg VO 1x/dia pela manh\xE3 em jejum",recomendado:!1,favorito:!1,ordem:5},{id:"2b653560-040a-40f4-b05e-481a76d20be7",descr:"Dexlanzoprazol (30-60mg/cp) 30 mg VO 1x/dia pela manh\xE3 em jejum",recomendado:!1,favorito:!1,ordem:6}],ordem:1}],academico:"Se refrat\xE1rio, pode dobrar a dose (2x/dia).",ordem:1},{item:"BLOQUEADOR HISTAM\xCDNICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"fe64d396-ce72-492f-95c5-10a846111691",opcoes:[{id:"4ad1f825-2ade-4349-8a24-f1b2e423f490",descr:"Cimetidina (200-400mg/cp) 400 mg VO 1x/dia \xE0 noite ou 12/12h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"941840ce-b60a-4e00-8c20-e621c2bba2b0",descr:"Ranitidina (150-300mg/cp) 150 mg VO 1x/dia \xE0 noite ou 12/12h",recomendado:!1,favorito:!1,ordem:2},{id:"a6e90cb5-2429-4fbe-bd5f-d40044aea62f",descr:"Famotidina (20-40 mg/cp) 20 mg VO 1x/dia \xE0 noite ou 12/12h",recomendado:!1,favorito:!1,ordem:3},{id:"a06c2d89-3357-4cd9-9e36-e3da7d37760d",descr:`Nizatidina (150-300mg/cp) 150 mg VO 1x/dia \xE0 noite ou 12/12h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Pode ser adicionado \xE0 noite para os casos refrat\xE1rios ao IBP ou usado isoladamente nas situa\xE7\xF5es em que o IBP n\xE3o for utilizado.",ordem:2},{item:"AGONISTA GABA-B",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b39e1d2d-c087-43da-8caf-f4f73450fd97",opcoes:[{id:"c99398ca-2d5a-4003-99f5-0e920621939e",descr:"Baclofeno (10mg/cp) 5-10 mg VO 2x/dia antes das refei\xE7\xF5es - se refrat\xE1rio, aumentar 5 mg/dose a cada 4 dias (m\xE1x 20mg 3x/dia)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Modulador do esf\xEDncter esofagiano inferior que pode ser acrescentado para casos persistentemente refrat\xE1rios.",ordem:3}],conceitosPraticos:[{conceito:"Tratamento n\xE3o-farmacol\xF3gico: \u2193peso, \u2191cabeceira, n\xE3o comer 2-3h antes de deitar, evitar alimentos deflagadores.",ordem:1},{conceito:"Tratamento farmacol\xF3gico: IBP por 8 sem",ordem:2},{conceito:"Rastreio para Barrett: homens com refluxo cr\xF4nico (> 5 anos) e/ou frequente (\u2265 1x/sem) e \u2265 2 desses: > 50 anos; branco; obesidade central; tabagismo; hist\xF3ria familiar de Barrett ou adenoCA de es\xF4fago.",ordem:3},{conceito:"Barrett: IBP 1x/dia; EDA 3-5 anos se n\xE3o houver displasia; abla\xE7\xE3o endosc\xF3pica se displasia de baixo ou alto grau.",ordem:4}]}],topicos:[],videos:[],fluxogramas:[],tags:["Refluxo","DRGE","Barrett"]},{id:"92b72701-7004-4824-8c13-89b6dc1fed3e",nome:"Doen\xE7a Inflamat\xF3ria Intestinal (DII)",categoria:2,termosDeBusca:"doenca inflamatoria intestinal (dii), dii, crohn, doenca de crohn, dc, retocolite, retocolite ulcerativa, rcu, colite ulcerativa",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"45fdf320-3ad9-4edb-85ca-5abf3bb8d45b",nome:"Colite Ulcerativa_Leve-Moderada",favorito:!0,ordem:1,secoes:[{item:"MESALAZINA RETAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"cb3774a4-7535-4a2b-bc4a-d80ed5c2c3c0",opcoes:[{id:"382f2951-a786-4134-a3db-b9ff1f5337ec",descr:"Mesalazina, enema (10mg/mL) 4 g VR 1x/dia (\xE0 noite) - reter por at\xE9 8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"34e16d2d-79aa-4756-b2ad-b379e2b9e901",descr:"Mesalazina, suposit\xF3rio (1g/sp) 1 g VR 1x/dia (\xE0 noite) - reter por, pelo menos, 1-3h",recomendado:!1,favorito:!1,ordem:2},{id:"1dfd2d6c-fc4e-402a-8026-8f1bdd3daca8",descr:`Mesalazina, espuma (1g/aplica\xE7\xE3o) 2 g VR 1x/dia (\xE0 noite) - reter por at\xE9 8h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Op\xE7\xE3o depende da extens\xE3o da doen\xE7a: enema atinge sigmoide proximal e flexura espl\xEAnica; espuma atinge sigmoide m\xE9dio; suposit\xF3rio atinge reto.",ordem:1},{item:"COMPOSTO ORAL 5-ASA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"77fce92f-6bec-4d54-a30f-1f72e4cdbce0",opcoes:[{id:"49be1c7a-e9fe-41de-94cf-5a1a1aec59be",descr:"Mesalazina (0,5-1g/cp) 2-3 g VO 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"90eb7381-864d-48fe-8c3d-d2ec8da30afe",descr:"Mesalazina (0,4-0,8g/cp) 2-3 g VO 1x/dia",recomendado:!1,favorito:!1,ordem:2},{id:"4170144a-f203-4f23-b387-f197b26f5190",descr:"Mesalazina MMX (1,2g/cp) 2,4 g VO 1x/dia",recomendado:!1,favorito:!1,ordem:3},{id:"4e64bf49-0822-41c5-b5e2-8f6aa45a2f82",descr:"Mesalazina (1-2g/sach\xEA) 2-3 g VO 1x/dia",recomendado:!1,favorito:!1,ordem:4},{id:"9136715e-d9f1-44eb-baec-a02686c01496",descr:"Sulfassalazina (500mg/cp) 1 g VO 6/6h (ou 8/8h)",recomendado:!1,favorito:!1,ordem:5},{id:"765ac1df-615b-4f2c-85f1-aeefee899693",descr:`Balsalazida (750mg/cp) 2,25 g VO 8/8h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:6},{id:"6996a68e-604f-4418-be54-3b0876240628",descr:`Olsalazina (250mg/cp) 500 mg VO 12/12h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:7}],ordem:1}],academico:"A mesalazina idealmente \xE9 feita 1x/dia na dose padr\xE3o (2-3g/dia), mas, se necess\xE1rio, optar por dose alta (>3g/dia).",ordem:2},{item:"CORTICOIDE RETAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"93bb9aab-2df1-4fba-a51f-3f2ba17d78f2",opcoes:[{id:"14b814f0-a1fd-40d8-9284-19e314b67946",descr:`Hidrocortisona, enema (100mg/60mL) 100 mg VR 1-2x/dia (MEDGRUPO)
Indispon\xEDvel no Brasil`,recomendado:!0,favorito:!0,ordem:1},{id:"c5d0095d-7475-4945-84b9-ea106bd885ad",descr:`Hidrocortisona, suposit\xF3rio (25-30mg/sp) 25-30 mg VR 1x/dia\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:2},{id:"20870cb0-2883-4251-a39f-b68af68b7a3d",descr:`Hidrocortisona, espuma (90mg/aplica\xE7\xE3o) 90 mg VR 1-2x/dia\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Op\xE7\xE3o para casos refrat\xE1rios e usados apenas na indu\xE7\xE3o da remiss\xE3o (e n\xE3o como manuten\xE7\xE3o).",ordem:3},{item:"CORTICOIDE ORAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"1d5a443b-4846-42ba-942b-11faa49349b2",opcoes:[{id:"5ceff2a1-8045-484d-9a96-91a7e1573820",descr:"Prednisona (5-20mg/cp) 40 mg VO 1x/dia (por at\xE9 4 sem) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"bf197c9a-5558-4a48-9983-0b287875c7ec",descr:"Budesonida MMX - libera\xE7\xE3o prolongada (9mg/cp) 9 mg VO 1x/dia pela manh\xE3 (por at\xE9 8 sem)",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Op\xE7\xE3o para casos refrat\xE1rios e usados apenas na indu\xE7\xE3o da remiss\xE3o (e n\xE3o como manuten\xE7\xE3o).",ordem:4}],conceitosPraticos:[{conceito:"Defini\xE7\xE3o leve-moderada: < 4-6 evacua\xE7\xF5es/dia e sem manifesta\xE7\xF5es constitucionais e sist\xEAmicas de inflama\xE7\xE3o (frequ\xEAncia card\xEDaca, temperatura, anemia, VHS).",ordem:1},{conceito:"Extens\xE3o: proctite (reto), proctosigmoidite (reto e sigmoide), colite esquerda (atinge c\xF3lon descendente; n\xE3o ultrapassa flexura espl\xEAnica), colite extensa / pancolite (proximal \xE0 flexura espl\xEAnica).",ordem:2},{conceito:"Proctite e proctosigmoidite: mesalazina retal \u2192 corticoide retal \u2192 composto oral 5-ASA \u2192 corticoide oral",ordem:3},{conceito:"Colite esquerda e extensa: mesalazina retal + composto oral 5-ASA \u2192 aumentar dose oral  \u2192 corticoide oral",ordem:4}]},{id:"52007db6-7f6e-4085-9bd2-58bf9b271925",nome:"Colite Ulcerativa_Moderad-Grave",favorito:!1,ordem:2,secoes:[{item:"DROGA BIOL\xD3GICA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ba90c559-dabe-492f-ba4a-e47895ca0920",opcoes:[{id:"d1114c11-1fc4-490f-9d3b-74d2cc26aeb9",descr:"Infliximabe (10mg/mL) 10 mL + SF 0,9% 240 mL (solu\xE7\xE3o: 0,4 mg/mL) 5 mg/kg IV em \u2265 2h nas sem 0, 2, 6; e repetido a cada 8 sem (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"06ba4f51-0f2d-4437-bbff-44932a8d3770",descr:"Adalimumabe (40mg/0,4-0,8mL) 160 mg SC em 1 ou 2 dias e 80 mg SC ap\xF3s 2 semanas; seguido de manuten\xE7\xE3o com 40 mg SC 1x/sem a partir de 29o dia",recomendado:!1,favorito:!1,ordem:2},{id:"c86a8b66-fc06-4e6a-bfaf-645504c59bac",descr:"Golimumabe (50mg/0,5mL) 200 mg SC na sem 0; 100 mg SC na sem 2, seguido de 100 mg 1x/m\xEAs",recomendado:!1,favorito:!1,ordem:3},{id:"beeb65fe-1aa9-4d63-81d7-ea61931da57a",descr:`Vedolizumabe (300mg/frasco) 300 mg IV em 30 min nas sem 0, 2 e 6; e repetido a cada 8 sem (diluir em 250 mL de SF 0,9%)\r
H\xE1 op\xE7\xE3o de manuten\xE7\xE3o com apresenta\xE7\xE3o SC (indispon\xEDvel no Brasil)`,recomendado:!1,favorito:!1,ordem:4},{id:"f3a6e4bd-8da4-4d2e-8442-765ecff32a04",descr:`Vedolizumabe - manuten\xE7\xE3o (108mg/0,68mL) 108 mg SC a cada 2 sem (op\xE7\xE3o de manuten\xE7\xE3o ap\xF3s, pelo menos, 2 doses IV)\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:5},{id:"ed424474-4eb9-42fe-81b8-39d9c909a871",descr:"Ustequinumabe - indu\xE7\xE3o (130mg/26mL) dose \xFAnica de indu\xE7\xE3o IV em \u2265 1h baseada no peso (\u2264 55 kg: 260 mg / 55-85 kg: 390 mg / > 85 kg: 520 mg)",recomendado:!1,favorito:!1,ordem:6},{id:"4b15d448-b70d-42ec-a3ed-fda2ff7ab0b9",descr:"Ustequinumabe - manuten\xE7\xE3o (90mg/mL) 90 mg SC 8/8 sem (iniciar 8 sem ap\xF3s a dose de indu\xE7\xE3o)",recomendado:!1,favorito:!1,ordem:7}],ordem:1}],academico:"Geralmente se inicia com infliximabe; preferir vedolizumabe se maior risco de infec\xE7\xE3o ou c\xE2ncer (hist\xF3ria pregressa ou idoso).",ordem:1},{item:"IMUNOMODULADOR",grupos:[{grupo:"Analg\xE9sico",idGrupo:"1e63d00f-0c02-4b1b-8a82-551083c2a153",opcoes:[{id:"4a217de3-6967-4d02-a6d9-03f0049676ae",descr:"Azatioprina (50mg/cp) 50 mg VO 1x/dia, titular at\xE9 atingir alvo de 2,5 mg/Kg (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"f8ae1eb4-1e64-4971-9f8d-dcdcf7348add",descr:"Mercaptopurina (50mg/cp) 50 mg VO 1x/dia, titular at\xE9 atingir alvo de 1,5 mg/Kg",recomendado:!1,favorito:!1,ordem:2},{id:"89e8b372-a468-4084-ae9c-3c3b522dc3fe",descr:`Metotrexato (2,5mg/cp) 12,5-15 mg VO 1x/sem\r
Aumentar 5 mg a cada 4 sem (m\xE1x 25 mg)`,recomendado:!1,favorito:!1,ordem:3},{id:"3c1f91ea-ceaa-492f-bf68-e54121f9801e",descr:`Metotrexato (25mg/mL) 12,5-15 mg SC ou IM 1x/sem\r
Aumentar 5 mg a cada 4 sem (m\xE1x 25 mg)`,recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Pode ser associado \xE0 droga biol\xF3gica.",ordem:2},{item:"MOL\xC9CULAS PEQUENAS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"4f665e41-5595-4373-af6f-6a69b9d72be0",opcoes:[{id:"8536dc32-8eae-4396-8b35-99eec9efdadf",descr:"Tofacitinibe (5mg/cp) 10 mg VO 12/12h por at\xE9 16 sem, seguido de manuten\xE7\xE3o com 5 mg VO 12/12h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"3afc4ce1-1167-4eca-adb4-dc12aae04110",descr:`Tofacitinibe XR (11mg/cp) 22 mg VO 1x/dia por at\xE9 16 sem, seguido de manuten\xE7\xE3o com 11 mg VO 1x/dia\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:2},{id:"6159d1a9-3774-42f9-bdbb-25830aac1b39",descr:`Ozanimode (0,23-0,92mg/cp) 0,23 mg VO 1x/dia D1-D4; 0,46 mg VO 1x/dia D5-D7; 0,92 mg Vo 1x/dia a partir do D8\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Alternativas \xE0s drogas biol\xF3gicas.",ordem:3},{item:"\xC1CIDO F\xD3LICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"168f731a-d221-4057-b170-6607498348be",opcoes:[{id:"0d593fcf-8f36-4a3a-806d-767f77f3dc12",descr:"\xC1cido F\xF3lico (2-5mg/cp) 2-5 mg VO 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"c17d8bdf-5eb2-4674-bb6d-638329590357",descr:"\xC1cido F\xF3lico (0,4mg/mL) 2-5 mg (5-12,5 mL) VO 1x/dia",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Sempre que utilizar metotrexato.",ordem:4}],conceitosPraticos:[{conceito:"Defini\xE7\xE3o moderada-grave: escore de Mayo 6-12 pontos com pontua\xE7\xE3o endosc\xF3pica > 2 pontos.",ordem:1},{conceito:"Extens\xE3o: proctite (reto), proctosigmoidite (reto e sigmoide), colite esquerda (atinge c\xF3lon descendente; n\xE3o ultrapassa flexura espl\xEAnica), colite extensa / pancolite (proximal \xE0 flexura espl\xEAnica).",ordem:2},{conceito:"Tratamento: droga biol\xF3gica \xB1 imunomodulador \u2192 se refrat\xE1rio, trocar droga biol\xF3gica (outras op\xE7\xF5es: mol\xE9culas pequenas).",ordem:3}]},{id:"77cda912-7df5-427d-a43f-8b3a740411b0",nome:"Colite Ulcerativa_Aguda Grave",favorito:!1,ordem:3,secoes:[{item:"CORTICOIDE PARENTERAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b6b88c54-3d41-4641-85dd-cfb6d33f17c6",opcoes:[{id:"63713d43-92ed-4ef9-8c56-eed42a403669",descr:"Metilprednisolona (40 mg/mL) 40 mg IV 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"fdc0e1db-9fe4-45a4-8783-ec33d97c1aad",descr:"Hidrocortisona (100mg/2mL) 100 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Maioria dos pacientes responde em 3-5 dias; prefer\xEAncia por metilprednisolona pela menor reten\xE7\xE3o de s\xF3dio e perda de pot\xE1ssio.",ordem:1},{item:"SEGUNDA LINHA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"3f84a422-6227-4c84-81e9-359022fa73dd",opcoes:[{id:"3ae90979-5403-46a3-ac33-c4d3ca5c9412",descr:"Infliximabe (10mg/mL) 10 mL + SF 0,9% 240 mL (solu\xE7\xE3o: 0,4 mg/mL) 5 mg/kg IV em \u2265 2h nas sem 0, 2, 6; e repetido a cada 8 sem (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"9f7440e7-b57b-4451-841d-8c7da50d425c",descr:"Ciclosporina (50mg/mL) 2 mg/Kg/dia IV lentamente (em 2-24h) durante 7 dias, seguido de Ciclosporina (25-100mg/cp) ou Ciclosporina (100mg/mL) 2,5 mg/Kg VO 12/12h",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Iniciar se n\xE3o houver melhora ap\xF3s 3-5 dias de corticoide IV.",ordem:2},{item:"CORTICOIDE ORAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7e9c5de5-0f6b-4f4e-ae36-fe2ef489f8e2",opcoes:[{id:"4ec10b13-ad36-48e3-9844-17d5591bc4b9",descr:"Prednisona (5-20mg/cp) 60 mg VO 1x/dia",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Iniciar antes da alta hospitalar em substitui\xE7\xE3o ao corticoide IV e, ap\xF3s 2 semanas, retirar gradualmente.",ordem:3}],conceitosPraticos:[{conceito:"Defini\xE7\xE3o aguda grave: \u2265 6 evacua\xE7\xF5es/dia e, pelo menos, uma caracter\xEDstica de atividade inflamat\xF3ria (frequ\xEAncia card\xEDaca, temperatura, anemia, VHS).",ordem:1},{conceito:"Tratamento: corticoide IV \u2192 infliximabe ou ciclosporina \u2192 cirurgia.",ordem:2},{conceito:"N\xE3o utilizar antibi\xF3tico de rotina; apenas em caso de peritonite, colite fulminante ou megac\xF3lon t\xF3xico \u2192 ciprofloxacino + metronidazol.",ordem:3}]},{id:"69373de2-f46f-4ea9-8ba4-e1c7fc3e0c5c",nome:"Crohn_Leve-Moderada",favorito:!1,ordem:4,secoes:[{item:"CORTICOIDE ORAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"84780b8d-e980-4f24-b51b-a168b57c94f4",opcoes:[{id:"b410f6ba-d281-47f2-8416-4f47dc5042fd",descr:"Budesonida MMX - libera\xE7\xE3o prolongada (9mg/cp) 9 mg VO 1x/dia (por at\xE9 8 sem)",recomendado:!0,favorito:!0,ordem:1},{id:"5092972b-d4bb-406f-9c5c-539362ebda76",descr:"Prednisona (5-20mg/cp) 40 mg VO 1x/dia (por at\xE9 4 sem)",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Op\xE7\xE3o para acometimento ileal; reduzir dose gradualmente por n\xE3o ser indicado para manuten\xE7\xE3o da remiss\xE3o; j\xE1 \xE9 considerada doen\xE7a moderada-grave se n\xE3o tolerar desmame.",ordem:1},{item:"COMPOSTO ORAL 5-ASA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7b9b6a28-484f-47d5-a09e-0dd94802af9c",opcoes:[{id:"1c21d0d3-03ea-4ab1-8a8d-4d0c974c0bb9",descr:"Sulfassalazina (500mg/cp) 1 g VO 6/6h (ou 8/8h) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"54f0a728-7bbf-431a-ab4d-eb78685a5322",descr:"Mesalazina (0,5-1g/cp) 1 g VO 3-4x/dia",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Sulfassalazina usada em caso de colite; mesalazina sem comprova\xE7\xE3o de efic\xE1cia.",ordem:2},{item:"IMUNOMODULADOR",grupos:[{grupo:"Analg\xE9sico",idGrupo:"6cad3dc0-6217-455a-a140-1afaf3509a88",opcoes:[{id:"b39b7e08-5f59-424b-8cfc-1aca794dded5",descr:`Metotrexato (25mg/mL) 15-25 mg SC ou IM 1x/sem (MEDGRUPO)
Se mentiver remiss\xE3o ap\xF3s 4 meses, pode reduzir para 15 mg`,recomendado:!0,favorito:!0,ordem:1},{id:"14a7a40a-7dd9-4e2f-b29d-b84db4430698",descr:"Azatioprina (50mg/cp) 50 mg VO 1x/dia, titular at\xE9 atingir alvo de 2,5 mg/Kg",recomendado:!1,favorito:!1,ordem:2},{id:"5aa03dbd-3429-4094-a644-dc74fd41234b",descr:"Mercaptopurina (50mg/cp) 0,75-1,5 mg/Kg VO 1x/dia",recomendado:!1,favorito:!1,ordem:3},{id:"2e2aa5d3-a669-40b8-9af2-9524083a114b",descr:`Metotrexato (2,5mg/cp) 12,5-15 mg VO 1x/sem\r
Aumentar 5 mg a cada 4 sem (m\xE1x 25 mg); se mantiver redu\xE7\xE3o ap\xF3s 4 meses, pode reduzir para 15 mg`,recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Op\xE7\xE3o para manuten\xE7\xE3o da remiss\xE3o e para casos que n\xE3o toleram desmame do corticoide.",ordem:3},{item:"ANTIDIARREICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f456f1f1-5c95-4bf5-9007-6fbde42050c3",opcoes:[{id:"3e1e799d-c0b5-4dba-89d8-f90e142bb55c",descr:`Loperamida (2mg/cp) 2-4 mg VO ap\xF3s evacua\xE7\xE3o (MEDGRUPO)
Dose m\xE1xima: 16 mg/dia`,recomendado:!0,favorito:!0,ordem:1},{id:"fa1d14eb-f436-428a-bf0f-3cb2f1875173",descr:`Colestiramina (4g/env) 4 g VO 1x/dia (diluir em 60-90 mL de l\xEDquido)\r
Se necess\xE1rio, aumentar para 4 g VO 8/8h`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Utilizado para controle sintom\xE1tico.",ordem:4},{item:"\xC1CIDO F\xD3LICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ed0ef258-5d05-4183-88f7-5c6e49a70257",opcoes:[{id:"63e89ded-15f1-4b75-b35b-6773b2549846",descr:"\xC1cido F\xF3lico (2-5mg/cp) 2-5 mg VO 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"0078bcea-246f-42b1-9da1-bcfaa7548ec8",descr:"\xC1cido F\xF3lico (0,4mg/mL) 2-5 mg (5-12,5 mL) VO 1x/dia",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Sempre que utilizar metotrexato.",ordem:5}],conceitosPraticos:[{conceito:"Defini\xE7\xE3o leve-moderada (\xEDndice CDAI 150-219): tolera dieta VO, \u2193peso < 10%, sem dor, obstru\xE7\xE3o ou febre alta.",ordem:1},{conceito:"Indu\xE7\xE3o da remiss\xE3o: corticoide (budesonida, se restrito a \xEDleo e c\xF3lon D) ou sulfassalazina (se colite) - outros compostos orais 5-ASA t\xEAm efic\xE1cia controversa.",ordem:2},{conceito:"Manuten\xE7\xE3o da remiss\xE3o: nada ou imunomodulador.",ordem:3}]},{id:"41ff6d0e-aa82-4e3c-a446-987339961a07",nome:"Crohn_Moderada-Grave",favorito:!1,ordem:5,secoes:[{item:"DROGA BIOL\xD3GICA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"0afa88b8-2390-45dc-b5dd-32f0c4fb9337",opcoes:[{id:"fc309dc4-85a5-4396-a3e0-01f60c1efaa2",descr:"Infliximabe (10mg/mL) 10 mL + SF 0,9% 240 mL (solu\xE7\xE3o: 0,4 mg/mL) 5 mg/kg IV em \u2265 2h nas sem 0, 2, 6; e repetido a cada 8 sem (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"a6e11618-e924-41d3-8c6f-a32d6823cd00",descr:"Adalimumabe (40mg/0,4-0,8mL) 160 mg SC em 1 ou 2 dias e 80 mg SC ap\xF3s 2 semanas; seguido de manuten\xE7\xE3o com 40 mg SC 1x/sem a partir de 29o dia",recomendado:!1,favorito:!1,ordem:2},{id:"bce97a0a-6a88-4bad-b78d-3d064ce5870e",descr:"Certolizumabe pegol (200mg/mL) 400 mg SC nas sem 0, 2 e 4; seguido de manuten\xE7\xE3o com 400 mg SC 1x/m\xEAs",recomendado:!1,favorito:!1,ordem:3},{id:"4c331f76-79e9-4b2d-aa70-9f2c0e162065",descr:"Vedolizumabe (300mg/frasco) 300 mg IV em 30 min nas sem 0, 2 e 6; e repetido a cada 8 sem (diluir em 250 mL de SF 0,9%)",recomendado:!1,favorito:!1,ordem:4},{id:"bf0d6735-d7ec-420a-9feb-0ebfd861eb5b",descr:`Vedolizumabe - manuten\xE7\xE3o (108mg/0,68mL) 108 mg SC a cada 2 sem (op\xE7\xE3o de manuten\xE7\xE3o ap\xF3s, pelo menos, 2 doses IV)\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:5},{id:"089ec52e-a2bb-4429-8d43-844388c06fad",descr:"Ustequinumabe - indu\xE7\xE3o (130mg/26mL) dose \xFAnica de indu\xE7\xE3o IV em \u2265 1h baseada no peso (\u2264 55 kg: 260 mg / 55-85 kg: 390 mg / > 85 kg: 520 mg)",recomendado:!1,favorito:!1,ordem:6},{id:"8c82a0a8-670d-40da-83b9-59140f11c1fa",descr:"Ustequinumabe - manuten\xE7\xE3o (90mg/mL) 90 mg SC 8/8 sem (iniciar 8 sem ap\xF3s a dose de indu\xE7\xE3o)",recomendado:!1,favorito:!1,ordem:7},{id:"ccc08f4f-d1ec-4f28-9dca-ba74fcbc6e1f",descr:"Natalizumabe (20mg/mL) 15 mL (300 mg) + SF 0,9% 100 mL IV ao longo de 1h 1x/m\xEAs",recomendado:!1,favorito:!1,ordem:8}],ordem:1}],academico:"Geralmente se inicia com infliximabe; preferir vedolizumabe se maior risco de infec\xE7\xE3o ou c\xE2ncer (hist\xF3ria pregressa ou idoso); natalizumabe apenas se anti-JC negativo.",ordem:1},{item:"IMUNOMODULADOR",grupos:[{grupo:"Analg\xE9sico",idGrupo:"8ff30c84-b2f4-4e83-89a6-6e22848b77f6",opcoes:[{id:"76300112-7039-486c-a803-4ff155e951ca",descr:`Metotrexato (2,5mg/cp) 12,5-15 mg VO 1x/sem
Aumentar 5 mg a cada 4 sem (m\xE1x 25 mg); se mantiver redu\xE7\xE3o ap\xF3s 4 meses, pode reduzir para 15 mg`,recomendado:!0,favorito:!0,ordem:1},{id:"1001ea06-5802-46a5-b535-18ccfe7fc96a",descr:"Azatioprina (50mg/cp) 50 mg VO 1x/dia, titular at\xE9 atingir alvo de 2,5 mg/Kg",recomendado:!1,favorito:!1,ordem:2},{id:"56b12b71-e48f-40a4-8a3e-9fcedb7f6273",descr:"Mercaptopurina (50mg/cp) 0,75-1,5 mg/Kg VO 1x/dia",recomendado:!1,favorito:!1,ordem:3},{id:"b373934d-f4e5-4c35-aff9-280c5fbe04d3",descr:`Metotrexato (2,5mg/cp) 12,5-15 mg VO 1x/sem\r
Aumentar 5 mg a cada 4 sem (m\xE1x 25 mg); se mantiver redu\xE7\xE3o ap\xF3s 4 meses, pode reduzir para 15 mg`,recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Pode ser associado \xE0 droga biol\xF3gica, especialmente nos casos de inibidor de TNF (infliximabe, adalimumabe).",ordem:2},{item:"CORTICOIDE SIST\xCAMICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f761c0fe-e6e0-4693-82f9-c1fcc4585f0e",opcoes:[{id:"b968e16d-8521-4aff-835e-5dbb1b894eef",descr:"Prednisona (5-20mg/cp) 40-60 mg VO 1x/dia por 1-2 sem (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"d68f169e-764a-4f28-a161-631dffabe1f1",descr:"Metilprednisolona (40 mg/mL) 40 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Op\xE7\xE3o para indu\xE7\xE3o da remiss\xE3o mais rapidamente em casos francamente mais sintom\xE1ticos; utilizar IV se mais grave; realizar desmame gradual e n\xE3o utilizar por mais de 2-3 meses.",ordem:3},{item:"\xC1CIDO F\xD3LICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"020d41f4-0ee2-4fe1-9fcd-9ee85bdfcbcf",opcoes:[{id:"dde18ccf-627c-458e-9af0-9cbe80e5f762",descr:"\xC1cido F\xF3lico (2-5mg/cp) 2-5 mg VO 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"5bc0eb05-c3d8-4fb1-9130-7acb14986a9a",descr:"\xC1cido F\xF3lico (0,4mg/mL) 2-5 mg (5-12,5 mL) VO 1x/dia",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Sempre que utilizar metotrexato.",ordem:4}],conceitosPraticos:[{conceito:"Defini\xE7\xE3o moderada-grave (\xEDndice CDAI 220-450): leve que n\xE3o respondeu ao tratamento ou quadro proeminente de febre, \u2193peso, dor, anemia ou v\xF4mito intermitente.",ordem:1},{conceito:"Tratamento (indu\xE7\xE3o e manuten\xE7\xE3o da remiss\xE3o): droga biol\xF3gica \xB1 imunomodulador \u2192 se refrat\xE1rio, trocar droga biol\xF3gica / Corticoide \xE9 op\xE7\xE3o apenas para indu\xE7\xE3o r\xE1pida da remiss\xE3o.				",ordem:2}]},{id:"b2678395-78c8-4946-82a5-f0c9964ac3ac",nome:"Crohn_Grave-Fulminante",favorito:!1,ordem:6,secoes:[{item:"CORTICOIDE PARENTERAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ebe5aacd-8f04-432a-a048-4c35112dd73b",opcoes:[{id:"d6133b5c-ce33-4901-9668-18b35be3462c",descr:"Metilprednisolona (40 mg/mL) 40-60 mg IV 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de escolha; pode administrar em dose \xFAnica ou fracionada (2-3x/dia).",ordem:1},{item:"INIBIDOR DE TNF-ALFA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"c0f2dabd-7387-4566-abda-a4acd3ff57ca",opcoes:[{id:"141c9561-d922-4a95-b060-a6973299f18e",descr:"Infliximabe (10mg/mL) 10 mL + SF 0,9% 240 mL (solu\xE7\xE3o: 0,4 mg/mL) 5 mg/kg IV em \u2265 2h nas sem 0, 2, 6; e repetido a cada 8 sem (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"b592fe85-c1a7-4b05-b54f-c361f83b606f",descr:"Adalimumabe (40mg/0,4-0,8mL) 160 mg SC em 1 ou 2 dias e 80 mg SC ap\xF3s 2 semanas; seguido de manuten\xE7\xE3o com 40 mg SC 1x/sem a partir de 29o dia",recomendado:!1,favorito:!1,ordem:2},{id:"26ca0ab4-3a61-4800-a77c-f2bb20cd27d4",descr:"Certolizumabe pegol (200mg/mL) 400 mg SC nas sem 0, 2 e 4; seguido de manuten\xE7\xE3o com 400 mg SC 1x/m\xEAs",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Alternativa ao corticoide, com prefer\xEAncia pelo infliximabe.",ordem:2},{item:"CORTICOIDE ORAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"eebbad84-7097-4209-8565-89e3b1ce4e84",opcoes:[{id:"3729b0a1-1ea0-438c-8895-8c7f2b57eb70",descr:"Prednisona (5-20mg/cp) 60 mg VO 1x/dia",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Iniciar antes da alta hospitalar em substitui\xE7\xE3o ao corticoide IV e, ap\xF3s 2 semanas, retirar gradualmente.",ordem:3}],conceitosPraticos:[{conceito:"Defini\xE7\xE3o grave-fulminante (\xEDndice CDAI > 450): moderado-grave que n\xE3o respondeu ao tratamento ou quadro proeminentes de febre alta, v\xF4mito persistente, sinal peritoneal ou obstru\xE7\xE3o intestinal.",ordem:1},{conceito:"Tratamento: corticoide IV ou inibidor de TNF.",ordem:2}]},{id:"8753cc39-680f-45c3-a3b8-dca2c1405fd8",nome:"Crohn_Fistulizante",favorito:!1,ordem:7,secoes:[{item:"DROGA BIOL\xD3GICA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"d13784d3-617c-4a1b-9544-34830c5c8968",opcoes:[{id:"a56aa7d1-149c-4b2d-9b88-70ddfa9c2bd6",descr:"Infliximabe (10mg/mL) 10 mL + SF 0,9% 240 mL (solu\xE7\xE3o: 0,4 mg/mL) 5 mg/kg IV em \u2265 2h nas sem 0, 2, 6; e repetido a cada 8 sem (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"3d9bc753-2fce-4cef-a8cd-b85995a0b0d8",descr:"Adalimumabe (40mg/0,4-0,8mL) 160 mg SC em 1 ou 2 dias e 80 mg SC ap\xF3s 2 semanas; seguido de manuten\xE7\xE3o com 40 mg SC 1x/sem a partir de 29o dia",recomendado:!1,favorito:!1,ordem:2},{id:"3b730b6e-df7a-4be1-ba9c-a1cd8c4e6d4c",descr:"Vedolizumabe (300mg/frasco) 300 mg IV em 30 min nas sem 0, 2 e 6; e repetido a cada 8 sem (diluir em 250 mL de SF 0,9%)",recomendado:!1,favorito:!1,ordem:3},{id:"c0e6dadd-1a14-4971-8c83-f79ce0a2cf86",descr:`Vedolizumabe - manuten\xE7\xE3o (108mg/0,68mL) 108 mg SC a cada 2 sem (op\xE7\xE3o de manuten\xE7\xE3o ap\xF3s, pelo menos, 2 doses IV)\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:4},{id:"c4bcc177-e1c7-4e14-b83e-4fc2a7667392",descr:"Ustequinumabe - indu\xE7\xE3o (130mg/26mL) dose \xFAnica de indu\xE7\xE3o IV em \u2265 1h baseada no peso (\u2264 55 kg: 260 mg / 55-85 kg: 390 mg / > 85 kg: 520 mg)",recomendado:!1,favorito:!1,ordem:5},{id:"ddde8794-cc15-4a82-b80b-5b6b97a7ccce",descr:"Ustequinumabe - manuten\xE7\xE3o (90mg/mL) 90 mg SC 8/8 sem (iniciar 8 sem ap\xF3s a dose de indu\xE7\xE3o)",recomendado:!1,favorito:!1,ordem:6}],ordem:1}],academico:"Prefer\xEAncia pelo infliximabe; esquemas realizados com posologia tradicional (indu\xE7\xE3o e manuten\xE7\xE3o da remiss\xE3o).",ordem:1},{item:"ANTIBI\xD3TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2a03c748-e866-40ff-9f6c-fce3d7f76df2",opcoes:[{id:"a96a4f64-6918-4abf-8700-15f6c087cd50",descr:"Metronidazol (250mg/cp) 500 mg VO 12/12h por 4 sem, seguido por 250 mg VO 8/8h por 4 sem (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"072cd9e2-8b06-4af2-af33-c9a588b5c9b0",descr:"Ciprofloxacino (250-500mg/cp) 500 mg VO 12/12h por 4 sem",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Pode utilizar um antibi\xF3tico isolado ou associa\xE7\xE3o dessas op\xE7\xF5es.",ordem:2}],conceitosPraticos:[{conceito:"Tratamento: droga biol\xF3gica + antibi\xF3tico				",ordem:1},{conceito:"Realizar imagem (TC/RM pelve): detec\xE7\xE3o de abscesso exige drenagem antes do in\xEDcio de droga biol\xF3gica.",ordem:2},{conceito:"F\xEDstula complexa (trajeto alto atrav\xE9s ou acima de camada muscular esfincteriana): associar cirurgia.",ordem:3}]}],topicos:[],videos:[],fluxogramas:[],tags:["DII","Crohn","Doen\xE7a de Crohn","DC","Retocolite","Retocolite Ulcerativa","RCU","Colite Ulcerativa"]},{id:"e9d29fcc-73cc-44a9-a30c-c8193ee4de15",nome:"Doen\xE7a Renal Cr\xF4nica",categoria:2,termosDeBusca:"doenca renal cronica, drc, insuficiencia renal cronica, irc, rim",favoritado:!1,ordem:0,especialidades:[{nome:"NEFROLOGIA"}],prescricoes:[],topicos:[{titulo:"Doen\xE7a Renal Cr\xF4nica",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A Doen\xE7a Renal Cr\xF4nica (DRC) \xE9 definida (1) pela redu\xE7\xE3o na fun\xE7\xE3o filtrativa OU (2) por les\xE3o renal que persista por, pelo menos, tr\xEAs meses \u2013 note que, para definir DRC, basta um desses crit\xE9rios. Neste material, revisaremos o manejo da DRC com base em diretrizes brasileiras e o novo documento do KDIGO (</span> 
  <em>
    <span style="font-weight: 400;">Kidney Disease: Improving Global Outcomes</span>
  </em> 
  <span style="font-weight: 400;">) 2023.</span>
</p>`,ordem:2},{titulo:"QUADRO CL\xCDNICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O decl\xEDnio gradual da fun\xE7\xE3o renal em pacientes com DRC \xE9 inicialmente assintom\xE1tico. No entanto, sinais e sintomas podem ser observados em casos mais avan\xE7ados: hipervolemia, hipercalemia, acidose metab\xF3lica, hiperfosfatemia, hipertens\xE3o, anemia e doen\xE7a mineral \xF3ssea. No seu est\xE1gio mais grave \u2013 doen\xE7a renal em fase terminal \u2013 surge a uremia, que inclui anorexia, n\xE1usea, v\xF4mito, pericardite, neuropatia perif\xE9rica e altera\xE7\xF5es do estado mental.</span>
</p>`,ordem:3},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O diagn\xF3stico da DRC est\xE1 alinhado com a defini\xE7\xE3o que tra\xE7amos acima. A confirma\xE7\xE3o diagn\xF3stica requer a presen\xE7a, por mais de tr\xEAs meses, (1) de redu\xE7\xE3o da taxa de filtra\xE7\xE3o glomerular estimada (TFGe) para valores &lt; 60 mL/min/1,73m</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">OU (2) de um "dano" renal. Para ficar claro: "dano" renal tem, como&nbsp; grande marcador, a albumin\xFAria, definida pela rela\xE7\xE3o albumina/creatinina a partir de 30 mg/g em amostra isolada de urina ou albumin\xFAria \u2265 30 mg/24h) \u2013 mas outras anormalidades, como altera\xE7\xE3o de sedimento urin\xE1rio, dist\xFArbio eletrol\xEDtico por doen\xE7a tubular, bi\xF3psia anormal, altera\xE7\xE3o estrutural em exame de imagem ou hist\xF3ria de transplante renal tamb\xE9m preenchem tal crit\xE9rio.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Para a estimativa da TFG, o m\xE9todo com maior acur\xE1cia \xE9 a f\xF3rmula do CKD-EPI, seguida pela equa\xE7\xE3o do MDRD, mas ainda se usa muito a de Cockcroft-Gault, pela maior facilidade de c\xE1lculo.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O estadiamento da DRC \xE9 importante como um guia de tratamento e baseado na TFGe (seis est\xE1gios \u2013 geralmente utilizados na caracteriza\xE7\xE3o do paciente) e na albumin\xFAria (tr\xEAs categorias): 
    <br>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/37b7615d-f53e-42b2-b503-07f7ec8da9e7.jpg" alt="" width="624" height="468">
  </span>
</p>`,ordem:4},{titulo:"TRATAMENTO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O tratamento do paciente com DRC envolve estrat\xE9gias para evitar a progress\xE3o da doen\xE7a renal, como o controle da press\xE3o arterial e&nbsp; redu\xE7\xE3o press\xF3rica intraglomerular, al\xE9m de restri\xE7\xE3o proteica na dieta (at\xE9 0,8 mg/kg/dia para pacientes a partir do G3). O tratamento de complica\xE7\xF5es, como altera\xE7\xE3o hidroeletrol\xEDtica, anemia e doen\xE7a \xF3ssea, tamb\xE9m est\xE1 entre os pilares terap\xEAuticos.&nbsp;</span>
</p><p style="text-align: justify;">
  <strong>Controle da press\xE3o arterial e nefroprote\xE7\xE3o \u2013</strong> 
  <span style="font-weight: 400;">Na DRC, segundo o KDIGO, o alvo press\xF3rico mais importante \xE9 a press\xE3o sist\xF3lica &lt; 120 mmHg (caso tolerado), sendo os inibidores da enzima conversora de angiotensina (IECA) ou bloqueadores dos receptores da angiotensina 2 (BRA-II) os f\xE1rmacos preferenciais. Pela diretriz brasileira, se o paciente n\xE3o for diab\xE9tico e n\xE3o houver microalbumin\xFAria, o alvo at\xE9 poderia ser &lt; 140 x 90 mmHg. Os diur\xE9ticos tiaz\xEDdicos podem ser usados nos est\xE1gios 1, 2 e 3, mas devem ser trocados por diur\xE9ticos de al\xE7a nos est\xE1gios 4 e 5 (TFGe &lt; 30 mL/min/1,73m</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Os inibidores do cotransportador 2 de s\xF3dio e glicose, iSGLT2, como a empagliflozina, est\xE3o indicados em todo doente renal cr\xF4nico que tenha diabetes, insufici\xEAncia card\xEDaca e/ou albumin\xFAria \u2265 200 mg/dia. Tais f\xE1rmacos</span> 
  <span style="font-weight: 400;">n\xE3o devem ser iniciados se TFG &lt; 20 mL/min/1,73 m\xB2, mas usu\xE1rios pr\xE9vios da medica\xE7\xE3o podem mant\xEA-la caso a TFG caia para valores inferiores a esse e o tratamento seja bem tolerado.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Vale frisar que, mesmo que n\xE3o haja hipertens\xE3o, na presen\xE7a de albumin\xFAria A2\u2013A3, deve-se utilizar iSGLT-2 + IECA ou BRA, tendo como meta manter a protein\xFAria inferior a 0,5\u20131 g/dia (ou, pelo menos, uma queda superior a 50\u201360% em rela\xE7\xE3o ao valor inicial).&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A finerenona \xE9 um antagonista seletivo dos receptores de mineralocorticoides. Sua principal indica\xE7\xE3o, segundo as diretrizes KDIGO, \xE9 em pacientes com DRC associada a diabetes tipo 2 e protein\xFAria persistente, apesar do uso de IECA ou BRA-II. A finerenona atua reduzindo a atividade fibroinflamat\xF3ria nos rins, o que contribui para diminuir a progress\xE3o da DRC. Al\xE9m dos benef\xEDcios renais, a finerenona tamb\xE9m demonstrou reduzir eventos cardiovasculares, como hospitaliza\xE7\xF5es por insufici\xEAncia card\xEDaca e mortalidade cardiovascular, em pacientes com DRC e diabetes tipo 2.</span>
</p><p style="text-align: justify;">
  <strong>Anemia \u2013</strong> 
  <span style="font-weight: 400;">A pesquisa de anemia atrav\xE9s da hemoglobina (Hb) deve ser feita: (1) uma vez ao ano no est\xE1gio 3; (2) duas vezes por ano nos est\xE1gios 4 e 5 que n\xE3o estejam em di\xE1lise; (3) a cada tr\xEAs meses no est\xE1gio 5 em di\xE1lise; (4) quando clinicamente indicada. O diagn\xF3stico \xE9 dado quando Hb &lt; 13 g/dL (homem e mulher p\xF3s-menopausa), &lt; 12 g/dL (mulher pr\xE9-menopausa ou jovens 12-15 anos), &lt; 11,5 g/dL (5-12 anos) ou &lt; 11 g/dL (menor de 5 anos). A partir do diagn\xF3stico de anemia, uma investiga\xE7\xE3o hematol\xF3gica se imp\xF5e com hemograma completo, reticul\xF3citos, ferritina, satura\xE7\xE3o de transferrina, vitamina B12 e folato a fim de avaliar a possibilidade de outros fatores participarem do quadro an\xEAmico al\xE9m da pr\xF3pria perda da fun\xE7\xE3o hormonal renal.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O in\xEDcio do tratamento com agente estimulador da eritropoiese (como alfaepoetina) s\xF3 \xE9 mesmo indicado em quadros mais severos com Hb &lt; 10 g/dL, buscando manter</span> 
  <span style="font-weight: 400;">alvo de Hb entre 10-12 g/dL</span> 
  <span style="font-weight: 400;">, embora situa\xE7\xF5es individualizadas possam se beneficiar com introdu\xE7\xF5es mais precoces.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Em rela\xE7\xE3o \xE0 cin\xE9tica de ferro, os</span> 
  <span style="font-weight: 400;">alvos s\xE3o: ferritina 200-500 ng/mL e satura\xE7\xE3o de transferrina 20-30%</span> 
  <span style="font-weight: 400;">. Desta forma, inicia-se a suplementa\xE7\xE3o de ferro quando um desses par\xE2metros estiver abaixo destas faixas e a interrompe temporariamente caso um deles ultrapasse o limite superior do alvo. Nos renais cr\xF4nicos que estejam em tratamento conservador (fora de hemodi\xE1lise), o ideal \xE9 a reposi\xE7\xE3o oral (40 mg 3x/dia), reservando o ferro parenteral para casos de intoler\xE2ncia ou falha da via oral. J\xE1 nos pacientes em di\xE1lise, a prefer\xEAncia, a princ\xEDpio, \xE9 pelo ferro parenteral.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Dosagens de hemoglobina, ferritina e satura\xE7\xE3o da transferrina devem sem repetidas mensalmente enquanto estiverem fora do alvo. Ap\xF3s, mant\xE9m-se dosagens mensais de hemoglobina e trimestrais de ferritina e satura\xE7\xE3o da transferrina. O uso de ferro parenteral deve ser suspenso 7-10 dias antes da realiza\xE7\xE3o dos exames.</span>
</p><p style="text-align: justify;">
  <strong>Dist\xFArbio do metabolismo mineral e \xF3sseo (DMO) \u2013</strong> 
  <span style="font-weight: 400;">Sem que seja feita uma discuss\xE3o fisiopatol\xF3gica longa, \xE9 v\xE1lida uma breve recorda\xE7\xE3o do desenvolvimento do DMO para que fiquem claras as estrat\xE9gias de tratamento... Com a perda da fun\xE7\xE3o de depura\xE7\xE3o renal, ocorre inicialmente eleva\xE7\xE3o do fosfato, que se combina com o c\xE1lcio, promovendo calcifica\xE7\xE3o extra\xF3ssea, al\xE9m de hipocalcemia. De modo simult\xE2neo, a hiperfosfatemia associada \xE0 perda da fun\xE7\xE3o renal reduzem a s\xEDntese de calcitriol (vitamina D ativada que promove absor\xE7\xE3o intestinal de c\xE1lcio), o que tamb\xE9m contribui para a hipocalcemia. Por fim, essa hipocalcemia estimula a libera\xE7\xE3o de horm\xF4nio da paratireoide (PTH), configurando o estado de hiperparatireoidismo secund\xE1rio t\xE3o famoso na DRC. Perceba que, do ponto de vista eletrol\xEDtico, a eleva\xE7\xE3o do PTH parece apropriada por ajudar na corre\xE7\xE3o da hiperfosfatemia e da hipocalcemia, mas o pre\xE7o que se paga \xE9 a maior atividade reabsortiva \xF3ssea, gerando uma les\xE3o denominada de oste\xEDte fibrosa c\xEDstica.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Portanto, em resumo, os dist\xFArbios do metabolismo mineral e \xF3sseo (DMO) da DRC caracterizam-se por: (1) altera\xE7\xF5es dos n\xEDveis s\xE9ricos de c\xE1lcio, f\xF3sforo, vitamina D e PTH; (2) anormalidades \xF3sseas (remodela\xE7\xE3o, mineraliza\xE7\xE3o e volume \xF3sseo); (3) calcifica\xE7\xF5es extra\xF3ssea (particularmente, vascular).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Assim, a partir do est\xE1gio 3 de DRC, \xE9 razo\xE1vel a seguinte estrat\xE9gia de monitoriza\xE7\xE3o laboratorial:</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/b3d67196-92a8-42b3-9a43-a986f9d9e6db.jpg" alt="" width="632" height="199">
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O tratamento da DMO \xE9 direcionado principalmente para a hiperfosfatemia (dieta, quelante de f\xF3sforo e, nas fases avan\xE7adas, di\xE1lise) e para o hiperparatireoidismo secund\xE1rio (controle da hiperfosfatemia, vitamina D e cinacalcete). A hipocalcemia n\xE3o \xE9 um alvo espec\xEDfico do tratamento, mas acaba sendo amenizada com essas terap\xEAuticas citadas, como quelante de f\xF3sforo e vitamina D.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Com rela\xE7\xE3o \xE0</span> 
  <strong>hiperfosfatemia</strong> 
  <span style="font-weight: 400;">persistente (&gt; 4,5 mg/dL ou, nos pacientes em di\xE1lise, &gt; 5,5 mg/dL), deve-se: 
    <br>
  </span>(1) 
  <em>Restringir f\xF3sforo na dieta</em> a 800-1000 mg/dia com aux\xEDlio de um profissional nutricionista 
  <br>(2) 
  <em>Utilizar</em> 
  <em>quelantes de f\xF3sforo</em> 
  <em>:</em> sevelamer ou quelante \xE0 base de c\xE1lcio (como carbonato de c\xE1lcio). A diretriz do KDIGO aponta uma prefer\xEAncia pelo sevelamer em virtude do risco de hipercalcemia com a outra op\xE7\xE3o, mas a recomenda\xE7\xE3o brasileira orienta iniciar mesmo carbonato de c\xE1lcio por n\xE3o haver comprova\xE7\xE3o de superioridade do sevelamer e utilizar esse \xFAltimo apenas naqueles que permanecem com hiperfosfatemia mesmo com dose alta de quelante \xE0 base de c\xE1lcio. 
  <br>(3) 
  <em>Dialisar</em> paciente em fase avan\xE7ada de doen\xE7a renal, o que ajuda na depura\xE7\xE3o do fosfato. Aqui cabe a orienta\xE7\xE3o de individualizar a concentra\xE7\xE3o de c\xE1lcio no dialisato de acordo com as necessidades de cada paciente. Por exemplo, uma concentra\xE7\xE3o &lt; 3,0 mEq/L (&lt; 1,5 mmol/L) leva a um balan\xE7o negativo de c\xE1lcio e \xE9 interessante em casos com PTH baixo ou hipercalcemia.
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">J\xE1, no que diz respeito ao</span> 
  <strong>hiperpatireoidismo secund\xE1rio</strong> 
  <span style="font-weight: 400;">, deve-se tratar os fatores que aumentam a libera\xE7\xE3o de PTH e, em casos selecionados, ativamente reduzir a secre\xE7\xE3o desse horm\xF4nio. Nos pacientes que n\xE3o estejam em di\xE1lise, n\xE3o h\xE1 consenso quanto ao alvo do PTH, enquanto nos pacientes em di\xE1lise, o objetivo \xE9 que o PTH s\xE9rico se mantenha 2-9 vezes o limite superior de normalidade do laborat\xF3rio (em geral, PTH entre 150-600 pg/mL):</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">(1)</span> 
  <em>
    <span style="font-weight: 400;">Tratar hiperfosfatemia</span>
  </em> 
  <span style="font-weight: 400;">, como relatado acima, com cuidado para o quelante \xE0 base de c\xE1lcio n\xE3o contribuir para hipercalcemia. 
    <br>
  </span>(2) 
  <em>Tratar defici\xEAncia de vitamina D</em> (com calcitriol ou an\xE1logos da vitamina, como paricalcitol) desde que n\xE3o haja mais hiperfosfatemia e tamb\xE9m n\xE3o exista hipercalcemia. N\xE3o deve ser usado rotineiramente nos pacientes que n\xE3o estejam em di\xE1lise, reservando essa op\xE7\xE3o principalmente para os casos de hiperparatireoidismo grave e progressivo. 
  <br>(3) Utilizar 
  <em>cinacalcete</em> nos pacientes submetidos \xE0 di\xE1lise e que, apesar do tratamento das condi\xE7\xF5es anteriores, continuam com PTH elevado. Como o medicamento age aumentando a sensibilidade da paratireoide ao c\xE1lcio, tamb\xE9m \xE9 necess\xE1rio que o paciente apresente hipercalcemia para prescrever o rem\xE9dio (necess\xE1rio c\xE1lcio &gt; 8,4 mgdL), pois isso iria corroborar que talvez a gl\xE2ndula esteja resistente ao eletr\xF3lito e que, portanto, poderia responder bem ao f\xE1rmaco.
</p><p style="text-align: justify;">
  <br>
  <span style="font-size: 10pt;">
    <em>* Com a progress\xE3o da DRC, pode ocorrer hiperplasia das paratireoides e at\xE9 mesmo uma transforma\xE7\xE3o adenomatosa, ou seja, as gl\xE2ndulas ganham autonomia e passam a produzir PTH de maneira independente do c\xE1lcio s\xE9rico. Configura-se o que se chama de hiperparatireoidismo terci\xE1rio, que \xE9 absolutamente refrat\xE1rio e geralmente acompanhado at\xE9 de hipercalcemia. Seu tratamento \xE9 a paratireoidectomia.</em>
  </span>
</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- Intoxica\xE7\xE3o por alum\xEDnio \u2013</strong> 
  <span style="font-weight: 400;">Atualmente, a intoxica\xE7\xE3o por alum\xEDnio \xE9 algo incomum na DRC, uma vez que se evita us\xE1-lo na hemodi\xE1lise e \xE9 cada vez mais rara a prescri\xE7\xE3o de quelantes de f\xF3sforo \xE0 base de alum\xEDnio. Sua intoxica\xE7\xE3o cr\xF4nica, al\xE9m de causar fraqueza muscular, anemia microc\xEDtica resistente a ferro e hipercalcemia, pode induzir les\xE3o \xF3ssea do tipo osteomal\xE1cia. A desferroxamina pode ser usada como diagn\xF3stico e tratamento.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Para o diagn\xF3stico, mensura-se o alum\xEDnio s\xE9rico logo antes de uma sess\xE3o de hemodi\xE1lise, administra-se 5 mg/Kg IV de desferroxamina na \xFAltima hora desta sess\xE3o e se repete a mensura\xE7\xE3o do alum\xEDnio 2 dias depois (antes da pr\xF3xima sess\xE3o): teste positivo se houver aumento \u2265 50 mcg/L.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Para o tratamento, a estrat\xE9gia depender\xE1 do resultado do teste diagn\xF3stico: 
    <br>
  </span>(1) Aumento \u2265 300 mcg/L OU efeitos colaterais com o teste: 5 mg/kg IV 1x/semana por 4 meses (administrar desferroxamina 1-5h antes da hemodi\xE1lise). 
  <br>(2) Aumento &lt; 300 mcg/mL E sem efeitos colaterais ap\xF3s o teste: 5 mg/kg IV 1x/semana por 2 meses (administrar desferroxamina durante a \xFAltima hora da hemodi\xE1lise).
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Ap\xF3s o tempo de tratamento, o rem\xE9dio \xE9 suspenso por 1 m\xEAs e o teste diagn\xF3stico, repetido.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease. Kidney Int Suppl 2013; 3:1-163.</span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">KDIGO 2012 Clinical Practice Guideline for Anemia in Chronic Kidney Disease. Kidney Int Suppl 2013; 2:279-335.</span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">KDIGO 2017 Clinical Practice Guideline Update for the Diagnosis, Evaluation, Prevention, and Treatment of Chronic Kidney Disease\u2013Mineral and Bone Disorder (CKD-MBD). Kidney Int Suppl 2017; 7:1-59.</span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">Minist\xE9rio da Sa\xFAde (BR). Comiss\xE3o Nacional de Incorpora\xE7\xE3o de Tecnologias no SUS (CONITEC). Secretaria de Ci\xEAncia, Tecnologia e Insumos Estrat\xE9gicos. Protocolo Cl\xEDnico e Diretrizes Terap\xEAuticas: Anemia na Doen\xE7a Renal Cr\xF4nica - Alfaepoetina. Minist\xE9rio da Sa\xFAde, 2017.</span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">Minist\xE9rio da Sa\xFAde (BR). Comiss\xE3o Nacional de Incorpora\xE7\xE3o de Tecnologias no SUS (CONITEC). Secretaria de Ci\xEAncia, Tecnologia e Insumos Estrat\xE9gicos. Protocolo Cl\xEDnico e Diretrizes Terap\xEAuticas: Anemia na Doen\xE7a Renal Cr\xF4nica \u2013 Reposi\xE7\xE3o de Ferro. Minist\xE9rio da Sa\xFAde, 2017.</span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">Minist\xE9rio da Sa\xFAde (BR). Comiss\xE3o Nacional de Incorpora\xE7\xE3o de Tecnologias no SUS (CONITEC). Secretaria de Ci\xEAncia, Tecnologia e Insumos Estrat\xE9gicos. Protocolo Cl\xEDnico e Diretrizes Terap\xEAuticas: Dist\xFArbio Mineral \xD3sseo. Minist\xE9rio da Sa\xFAde, 2016.</span>
  </li>
</ol>`,ordem:6}],videos:[],fluxogramas:[],tags:["DRC","Insufici\xEAncia Renal Cr\xF4nica","IRC","rim"]},{id:"0681cffc-a955-4bed-8260-728aaa10affd",nome:"Doen\xE7a Ulcerosa P\xE9ptica (DUP)",categoria:2,termosDeBusca:"doenca ulcerosa peptica (dup), dup, ulcera peptica, helicobacter, h. pylori, pylori",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"6c7214da-d0f1-4663-8cd7-4ef622c631f9",nome:"Doen\xE7a Ulcerosa P\xE9ptica",favorito:!0,ordem:1,secoes:[{item:"INIBIDOR DE BOMBA DE PR\xD3TON",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ac95fb55-f15d-400c-aad5-bc5da6a2c2b3",opcoes:[{id:"b56cfee0-a8eb-4358-a65d-4e4cafe1d904",descr:"Omeprazol (10-40mg/cp) 20 mg VO 1-2x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"85c01e6f-24d6-4017-a924-d7f8f40c7c88",descr:"Esomeprazol (20-40mg/cp) 40 mg VO 1-2x/dia",recomendado:!1,favorito:!1,ordem:2},{id:"92bf0bcf-2c4d-4482-83e7-ae91522ec184",descr:"Lanzoprazol (15-30mg/cp) 30 mg VO 1-2x/dia",recomendado:!1,favorito:!1,ordem:3},{id:"af9813fc-cc9d-4830-9952-490fbebda4ae",descr:"Pantoprazol (20-40mg/cp)40 mg VO 1-2x/dia",recomendado:!1,favorito:!1,ordem:4},{id:"e19b3db7-bf02-4076-9612-97d2a43001ca",descr:"Rabeprazol (10-20mg/cp) 20 mg VO 1-2x/dia",recomendado:!1,favorito:!1,ordem:5},{id:"aef59b71-3bc6-4b8f-b49e-d9d9142e8600",descr:"Dexlanzoprazol (30-60mg/cp) 60 mg VO 1-2x/dia",recomendado:!1,favorito:!1,ordem:6}],ordem:1}],academico:"Estrat\xE9gia de escolha para redu\xE7\xE3o \xE1cida para cicatriza\xE7\xE3o da \xFAlcera durante 4-8 semanas (se associado ao H. pylori, pode tratar por apenas 2 semanas como parte do esquema de erradica\xE7\xE3o).",ordem:1},{item:"BLOQUEADOR \xC1CIDO COMPETITIVO DE POT\xC1SSIO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"11eb071a-c900-4d14-854f-3c0d81ea1f44",opcoes:[{id:"9875063a-bf3f-47db-811b-39471006087e",descr:"Vonoprazana (10-20mg/cp) 20 mg VO 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"1afa6e50-e269-4f3d-b312-501474597887",descr:`Revaprazana (100-200mg/cp) 200 mg VO 1x/dia\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Alternativa aos IBPs como estrat\xE9gia de antissecre\xE7\xE3o \xE1cida ao bloquearem as bombas de pr\xF3ton de forma revers\xEDvel.",ordem:2},{item:"ERRADICA\xC7\xC3O DO H. PYLORI (1a linha)",grupos:[{grupo:"Analg\xE9sico",idGrupo:"d921c2e4-71bd-4b88-9e9c-0bb20373b535",opcoes:[{id:"fcee0c82-2378-4fbc-b62b-d6df5be5f170",descr:`IBP VO 12/12h + Claritromicina (500mg/cp) 500 mg VO 12/12h + Amoxicilina (500mg/cp) 1 g VO 12/12h (MEDGRUPO)
Dura\xE7\xE3o: 14 dias`,recomendado:!0,favorito:!0,ordem:1},{id:"57bbca77-0c55-40ec-81d0-ba26d28b7a56",descr:`IBP VO 12/12h + Bismuto (120mg/cp) 240 mg VO 12/12h + Tetraciclina (500mg/cp) 500 mg VO 6/6h + Metronidazol (400mg/cp) 400 mg VO 8/8h\r
Dura\xE7\xE3o: 10-14 dias`,recomendado:!1,favorito:!1,ordem:2},{id:"99102037-d489-44f1-84c9-63429e351ad4",descr:`IBP VO 12/12h + Claritromicina (500mg/cp) 500 mg VO 12/12h + Amoxicilina (500mg/cp) 1 g VO 12/12h + Metronidazol (250mg/cp) 500 mg VO 12/12h\r
Dura\xE7\xE3o: 14 dias`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"A terapia tripla com claritromicina n\xE3o deve ser a estrat\xE9gia de escolha se houver relato de resist\xEAncia > 15% ao f\xE1rmaco ou uso recente de macrol\xEDdeo.",ordem:3},{item:"ERRADICA\xC7\xC3O DO H. PYLORI (2a e 3a linha)",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e77a9787-b9be-4542-ae87-ebef90d25955",opcoes:[{id:"68792313-8417-4924-99be-90eab4405477",descr:`IBP VO 12/12h + Levofloxacino (500mg/cp) 500 mg VO 1x/dia + Amoxicilina (500mg/cp) 1 g VO 12/12h (MEDGRUPO)
Dura\xE7\xE3o: 10-14 dias`,recomendado:!0,favorito:!0,ordem:1},{id:"da3a2754-1b29-41eb-b32c-d4c19ec675fc",descr:`IBP VO 12/12h + Bismuto (120mg/cp) 240 mg VO 12/12h + Tetraciclina (500mg/cp) 500 mg VO 6/6h + Metronidazol (400mg/cp) 400 mg VO 8/8h\r
Dura\xE7\xE3o: 10-14 dias`,recomendado:!1,favorito:!1,ordem:2},{id:"34bdb6b0-fa6c-4645-a95f-60782cfbf5a6",descr:`IBP VO 12/12h + Amoxicilina (500mg/cp) 1 g VO 12/12h + Bismuto (120mg/cp) 240 mg VO 12/12h + Furazolidona (100mg/cp) 200 mg VO 12/12\r
Dura\xE7\xE3o: 10-14 dias\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:3},{id:"4408c98f-a590-41e1-830b-4f0d362138e9",descr:`IBP VO 12/12h + Bismuto (120mg/cp) 240 mg VO 12/12h  + Levofloxacino (500mg/cp) 500 mg VO 1x/dia + Amoxicilina (500mg/cp) 1 g VO 12/12h\r
Dura\xE7\xE3o: 14 dias`,recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"As op\xE7\xF5es principais para falha inicial s\xE3o: terapia tripla com levofloxacino ou terapia qu\xE1drupla com bismuto (+ IBP, tetracilina e metronidazol).",ordem:4},{item:"ERRADICA\xC7\xC3O DO H. PYLORI (alergia \xE0 penicilina)",grupos:[{grupo:"Analg\xE9sico",idGrupo:"0c9468ca-b5ea-4b21-b1ea-fd7fc488ad2a",opcoes:[{id:"535dd51d-d5d0-4179-955b-1a7500fc3474",descr:`IBP VO 12/12h + Claritromicina (500mg/cp) 500 mg VO 12/12h + Levofloxacino (500mg/cp) 500 mg VO 1x/dia (MEDGRUPO)
Dura\xE7\xE3o: 14 dias`,recomendado:!0,favorito:!0,ordem:1},{id:"a6c5aaa0-3478-4b62-b1d9-e763f1a54868",descr:`IBP VO 12/12h + Bismuto (120mg/cp) 240 mg VO 12/12h + Tetraciclina (500mg/cp) 500 mg VO 6/6h + Metronidazol (400mg/cp) 400 mg VO 8/8h\r
Dura\xE7\xE3o: 10-14 dias`,recomendado:!1,favorito:!1,ordem:2},{id:"2c120af6-7518-4f58-91d8-a4a3c598c7f9",descr:`IBP VO 12/12h + Claritromicina (500mg/cp) 500 mg VO 12/12h + Metronidazol (400mg/cp) 400 mg VO 8/8h\r
Dura\xE7\xE3o: 14 dias`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Se a hist\xF3ria al\xE9rgica for incerta, pode-se fazer teste de provoca\xE7\xE3o supervisionada (10-25% da dose e observa\xE7\xE3o por 30-60 min)",ordem:5}],conceitosPraticos:[{conceito:"Endoscopia: indicada se > 40 anos (\u2265 60 anos para alguns autores) ou sinal de alarme.",ordem:1},{conceito:"Pesquisa para H. pylori: obrigat\xF3ria e, se positiva, \xE9 necess\xE1ria erradica\xE7\xE3o da bact\xE9ria.",ordem:2},{conceito:"Controle de cura para H. pylori: deve ser feito \u2265 4 semanas ap\xF3s t\xE9rmino do tratamento.",ordem:3},{conceito:"AINE: questionar sempre o uso e, se presente, orientar suspens\xE3o quando poss\xEDvel.",ordem:4}]}],topicos:[],videos:[],fluxogramas:[],tags:["DUP","\xDAlcera p\xE9ptica","Helicobacter","H. pylori","pylori"]},{id:"61b7e00a-23e5-41eb-8cc5-b1550d478952",nome:"Esofagite Eosinof\xEDlica",categoria:2,termosDeBusca:"esofagite eosinofilica, ",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"f13b8429-c5a6-4921-b4b5-2bccef467599",nome:"Adultos",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7fb4d013-940c-483a-97cf-e7eaf4ce4b31",opcoes:[{id:"4c32a1a7-68fa-4233-8f76-cda9a34d8f37",descr:`Dieta de elimina\xE7\xE3o emp\xEDrica (MEDGRUPO)
Eliminar leite animal, ovo, soja, trigo, amendoim/nozes e/ou frutos do mar`,recomendado:!0,favorito:!0,ordem:1},{id:"bf96e325-2cc5-437b-901b-c18c9dc96cd7",descr:"Dieta de elimina\xE7\xE3o guiada por testes",recomendado:!1,favorito:!1,ordem:2},{id:"36cb9c5b-3b11-4330-a2ee-36985bdbb5dc",descr:`Dieta elementar\r
F\xF3rmulas de amino\xE1cidos livres`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Eliminar alimentos que possam servir de gatilho.",ordem:1},{item:"INIBIDOR DE BOMBA DE PR\xD3TON",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e9acf41c-759f-4092-87ef-188ae97ea456",opcoes:[{id:"f8f40a97-d1ed-4857-8426-82ece69469dc",descr:"Esomeprazol (20-40mg/cp) 20-40 mg VO 1-2x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"457ac587-9949-4f82-9230-abea004f7965",descr:"Omeprazol (10-40mg/cp) 20-40 mg VO 1-2x/dia",recomendado:!1,favorito:!1,ordem:2},{id:"43529f5c-05f1-4856-9071-9309c90682a1",descr:"Lansoprazol (15-30mg/cp) 15-30 mg VO 1-2x/dia",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Tentar manter com menor dose poss\xEDvel.",ordem:2},{item:"CORTICOIDE T\xD3PICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"c036c904-18d2-4131-9014-bc19e749f599",opcoes:[{id:"58b73d25-e679-4b00-8f8e-508be52153e3",descr:`Budesonida (0,5mg/mL) 4 mg + Sucralose 5mg (ingerir ao longo de 5-10 min) (MEDGRUPO)
Mel pode ser alternativa \xE0 sucralose para obter material viscoso`,recomendado:!0,favorito:!0,ordem:1},{id:"192b0102-cbc0-4667-9cf2-5426d423f453",descr:`Budesonida (0,5mg/mL) 4 mg + Sucralose 5mg (ingerir ao longo de 5-10 min)\r
Mel pode ser alternativa \xE0 sucralose para obter material viscoso`,recomendado:!1,favorito:!1,ordem:2},{id:"32592739-5377-4a72-a1ed-b16f4795ff65",descr:`Fluticasona (250mcg/dose) 2 puffs VO 4x/dia (aerossol)\r
N\xE3o utilizar espa\xE7ador; deglutir ao inv\xE9s de inalar`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Reduzir dose depois de atingir remiss\xE3o; enxaguar a boca ap\xF3s uso; evitar alimentos ou bebidas por, pelo menos, 30-60 min.",ordem:3}],conceitosPraticos:[{conceito:"Diagn\xF3stico: bi\xF3pisa + exclus\xE3o de outras causas de eosinofilia esofagiana.",ordem:1},{conceito:"Op\xE7\xF5es terap\xEAuticas: dieta, inibidor de bomba de pr\xF3ton ou corticoide t\xF3pico.",ordem:2},{conceito:"Se disfagia ou impacta\xE7\xE3o alimentar refrat\xE1rias: dilata\xE7\xE3o endosc\xF3pica.",ordem:3}]},{id:"33bddfd3-c297-4d77-b337-f05d57a5d28f",nome:"Crian\xE7as",favorito:!1,ordem:2,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"1be4f5e2-5c7e-4ebf-bbd4-0859dfbc3ce4",opcoes:[{id:"839b0dc9-936b-4a26-aa10-a00192b028e0",descr:`Dieta de elimina\xE7\xE3o emp\xEDrica (MEDGRUPO)
Eliminar leite animal, ovo, soja, trigo, amendoim/nozes e/ou frutos do mar`,recomendado:!0,favorito:!0,ordem:1},{id:"5e7361b8-cfc6-4b74-97b5-0d66e9a027ae",descr:"Dieta de elimina\xE7\xE3o guiada por testes",recomendado:!1,favorito:!1,ordem:2},{id:"6179ab5a-f669-4429-8c6e-dd49ed239dce",descr:`Dieta elementar\r
F\xF3rmulas de amino\xE1cidos livres`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Eliminar alimentos que possam servir de gatilho.",ordem:1},{item:"INIBIDOR DE BOMBA DE PR\xD3TON",grupos:[{grupo:"Analg\xE9sico",idGrupo:"fc95ab3d-7824-4d70-8826-41d498695293",opcoes:[{id:"e1ac4b05-1420-49ff-acb8-c62fecd7a679",descr:"Esomeprazol (20-40mg/cp) 20-40 mg VO 1-2x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"b349f9c3-2775-4dd7-a81a-58c3106b0386",descr:"Omeprazol (10-20mg/cp) 1-2 mg/Kg VO 1x/dia",recomendado:!1,favorito:!1,ordem:2},{id:"d89007db-cc02-4cab-b2be-6328e26c3097",descr:`Lansoprazol (15-30mg/cp) 15-30 mg VO 1x/dia\r
< 10 anos: 15 mg / \u2265\xA010 anos: 30 mg`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Tentar manter com menor dose poss\xEDvel.",ordem:2},{item:"CORTICOIDE T\xD3PICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"9e3f452e-71d9-4441-9363-77ab342f0ea9",opcoes:[{id:"213ef1e0-1bbe-4e94-aabb-5fb29a36f4a5",descr:`Budesonida (0,5mg/mL) 1-2 mg + Sucralose 5mg (ingerir ao longo de 5-10 min) (MEDGRUPO)
< 10 anos: 1 mg / \u2265 10 anos: 2 mg
Mel pode ser alternativa \xE0 sucralose para obter material viscoso`,recomendado:!0,favorito:!0,ordem:1},{id:"2c480cba-c3f4-40c5-b4ce-6d1bdc833666",descr:`Fluticasona (250mcg/dose) 1-2 puffs VO 4x/dia (aerossol)\r
< 10 anos: 1 puff por dose / \u2265\xA010 anos: 2 puffs por dose\r
N\xE3o utilizar espa\xE7ador; deglutir ao inv\xE9s de inalar`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Reduzir dose depois de atingir remiss\xE3o; enxaguar a boca ap\xF3s uso; evitar alimentos ou bebidas por, pelo menos, 30-60 min.",ordem:3}],conceitosPraticos:[{conceito:"Diagn\xF3stico: bi\xF3pisa + exclus\xE3o de outras causas de eosinofilia esofagiana.",ordem:1},{conceito:"Op\xE7\xF5es terap\xEAuticas: dieta, inibidor de bomba de pr\xF3ton ou corticoide t\xF3pico.",ordem:2},{conceito:"Se disfagia ou impacta\xE7\xE3o alimentar refrat\xE1rias: dilata\xE7\xE3o endosc\xF3pica.",ordem:3}]}],topicos:[],videos:[],fluxogramas:[],tags:[]},{id:"3419cabc-9c49-439e-bd4f-9bf193cf32c8",nome:"Faringites",categoria:1,termosDeBusca:"faringites, dor de garganta, amigdalite, faringoamidgalite",favoritado:!1,ordem:0,especialidades:[{nome:"OTORRINOLARINGOLOGIA"}],prescricoes:[],topicos:[{titulo:"Faringites",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A faringite \xE9 a inflama\xE7\xE3o da faringe que, na maioria dos casos, \xE9 causada por v\xEDrus respirat\xF3rios e \xE9 autolimitada. Ela tamb\xE9m pode ser causada por bact\xE9rias, como o</span> 
  <em>
    <span style="font-weight: 400;">Streptococcus</span>
  </em> 
  <span style="font-weight: 400;">do grupo A (SGA), que requer tratamento espec\xEDfico para evitar complica\xE7\xF5es. Etiologias n\xE3o infecciosas, como alergias, doen\xE7a do refluxo gastroesof\xE1gico e irritantes ambientais tamb\xE9m podem estar implicadas.</span>
</p>`,ordem:2},{titulo:"MANIFESTA\xC7\xD5ES",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Os pacientes com faringite, independentemente da etiologia, geralmente t\xEAm dor de garganta que piora ao engolir. Outros sintomas comuns incluem febre, cefaleia, fadiga, mal-estar e linfadenopatia cervical. As manifesta\xE7\xF5es podem variar dependendo da causa subjacente.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A</span> 
  <strong>faringite viral</strong> 
  <span style="font-weight: 400;">\xE9 frequentemente acompanhada de outros sinais e sintomas respirat\xF3rios gripais, como congest\xE3o nasal, tosse, coriza, conjuntivite, espirros, febre baixa e exantema.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A</span> 
  <strong>faringite bacteriana,</strong> 
  <span style="font-weight: 400;">causada pelo SGA, \xE9 caracterizada por dor de garganta, febre, exsudato tonsilar e linfadenopatia cervical anterior dolorosa. Outros sinais que sugerem o diagn\xF3stico incluem pet\xE9quias no palato, erup\xE7\xE3o escarlatiniforme e l\xEDngua em framboesa. As complica\xE7\xF5es supurativas de uma infec\xE7\xE3o por SGA incluem otite m\xE9dia, celulite ou abscesso peritonsilar, sinusite, meningite, bacteremia e fasci\xEDte necrosante. Complica\xE7\xF5es n\xE3o supurativas, mediadas pelo sistema imunol\xF3gico, incluem a febre reum\xE1tica (FR), glomerulonefrite p\xF3s-estreptoc\xF3cica e artrite reativa.</span>
</p><p style="text-align: justify;">
  <strong>Infec\xE7\xF5es Sexualmente Transmiss\xEDveis</strong> 
  <span style="font-weight: 400;">(ISTs), como HIV,</span> 
  <em>
    <span style="font-weight: 400;">Neisseria gonorrhoeae</span>
  </em> 
  <span style="font-weight: 400;">(gonorreia) e</span> 
  <em>
    <span style="font-weight: 400;">Treponema pallidum</span>
  </em> 
  <span style="font-weight: 400;">(s\xEDfilis)</span> 
  <span style="font-weight: 400;">tamb\xE9m podem causar faringite. A infec\xE7\xE3o aguda por HIV pode se manifestar com faringite, \xFAlceras mucocut\xE2neas dolorosas e erup\xE7\xE3o cut\xE2nea generalizada. A gonorreia far\xEDngea \xE9 frequentemente assintom\xE1tica, mas pode causar dor de garganta, exsudato far\xEDngeo e linfadenopatia cervical. A s\xEDfilis secund\xE1ria pode se apresentar com faringite e les\xF5es mucosas.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Infec\xE7\xF5es agudas pelo v\xEDrus Epstein-Barr (EBV), citomegalov\xEDrus (CMV) e herpes simplex v\xEDrus (HSV) tamb\xE9m podem causar faringite. A mononucleose infecciosa, causada pelo EBV, \xE9 caracterizada por faringite, febre, fadiga, linfadenopatia cervical posterior, hepatoesplenomegalia e linfocitose at\xEDpica. O CMV pode causar uma doen\xE7a semelhante \xE0 mononucleose, mas com menor probabilidade de faringite. O HSV pode causar faringite com eritema far\xEDngeo e \xFAlceras orais.</span>
</p>`,ordem:3},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A avalia\xE7\xE3o inicial deve contemplar a pesquisa de sinais de obstru\xE7\xE3o das vias a\xE9reas superiores e infec\xE7\xF5es invasivas do pesco\xE7o. Sintomas como voz abafada, estridor, disfagia grave, trismo e apar\xEAncia t\xF3xica devem alertar para essas condi\xE7\xF5es. A necessidade de testagem para SARS-CoV-2 (COVID-19) depende da preval\xEAncia local e/ou exposi\xE7\xE3o conhecida do paciente.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Para pacientes com sintomas que sugerem fortemente uma infec\xE7\xE3o viral do trato respirat\xF3rio superior, o diagn\xF3stico de faringite viral</span> 
  <strong>pode ser feito clinicamente</strong> 
  <span style="font-weight: 400;">.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A testagem para SGA ou outros pat\xF3genos n\xE3o \xE9 necess\xE1ria, a menos que haja fatores de risco para uma causa trat\xE1vel espec\xEDfica. Pacientes com quadro cl\xEDnico compat\xEDvel com faringite por SGA, sem sintomas de uma s\xEDndrome viral respirat\xF3ria, devem ser submetidos \xE0 testagem microbiol\xF3gica. A utiliza\xE7\xE3o de crit\xE9rios cl\xEDnicos, como os</span> 
  <strong>crit\xE9rios de Centor</strong> 
  <span style="font-weight: 400;">, pode ajudar a decidir sobre a necessidade de testagem (\u2265 3 pontos indica alta probabilidade de infec\xE7\xE3o estreptoc\xF3cica).&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A testagem para faringite por SGA pode ser realizada com</span> 
  <strong>testes r\xE1pidos</strong> 
  <span style="font-weight: 400;">de detec\xE7\xE3o de ant\xEDgeno (TRDA) ou testes de amplifica\xE7\xE3o de \xE1cido nucleico (NAAT). A cultura de garganta pode ser utilizada para confirmar resultados negativos de TRDA em pacientes de alto risco (ex.: resid\xEAncia em \xE1rea de alta preval\xEAncia; hist\xF3ria de FR aguda; imunossupress\xE3o; contato pr\xF3ximo com pessoa com hist\xF3ria de FR aguda ou imunossuprimida).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A avalia\xE7\xE3o para ISTs deve incluir uma hist\xF3ria sexual detalhada e a identifica\xE7\xE3o de outros riscos para infec\xE7\xE3o aguda por HIV, como uso recente de drogas injet\xE1veis ou outras exposi\xE7\xF5es sangu\xEDneas. Pacientes com fatores de risco para ISTs devem ser testados para gonorreia far\xEDngea e s\xEDfilis secund\xE1ria.</span>
</p>`,ordem:4},{titulo:"CONDUTA",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O tratamento</span> 
  <span style="font-weight: 400;">sintom\xE1tico</span> 
  <span style="font-weight: 400;">da faringite tem como objetivo principal o al\xEDvio da dor de garganta, melhorando o conforto do paciente e sua capacidade de manter-se hidratado. A abordagem inclui</span> 
  <strong>analg\xE9sicos sist\xEAmicos orais</strong> 
  <span style="font-weight: 400;">,</span> 
  <strong>terapias t\xF3picas</strong> 
  <span style="font-weight: 400;">e</span> 
  <strong>medidas ambientais</strong> 
  <span style="font-weight: 400;">. A escolha do tratamento deve considerar a gravidade dos sintomas, a presen\xE7a de comorbidades e as prefer\xEAncias do paciente.</span>
</p><p style="text-align: justify;">
  <strong>Analg\xE9sicos sist\xEAmicos orais</strong> 
  <span style="font-weight: 400;">- incluem anti-inflamat\xF3rios n\xE3o esteroidais (AINEs), paracetamol e dipirona. Esses medicamentos geralmente t\xEAm uma dura\xE7\xE3o de efic\xE1cia de v\xE1rias horas e come\xE7am a agir dentro de uma a duas horas, aliviando a dor de garganta e outros sintomas concomitantes, como febre e cefaleia. A escolha entre os analg\xE9sicos deve considerar fatores como disfun\xE7\xE3o renal ou hep\xE1tica e hist\xF3rico de irrita\xE7\xE3o g\xE1strica ou refluxo.</span>
</p><p style="text-align: justify;">
  <strong>Terapias t\xF3picas</strong> 
  <span style="font-weight: 400;">- pastilhas e sprays</span> 
  <span style="font-weight: 400;">aplicados na garganta proporcionam al\xEDvio r\xE1pido da dor, mas com dura\xE7\xE3o mais curta, necessitando de reaplica\xE7\xE3o frequente. N\xE3o h\xE1 evid\xEAncias de que uma pastilha ou spray espec\xEDfico seja superior em efic\xE1cia. A escolha depende da disponibilidade e prefer\xEAncia do paciente.</span>
</p><p style="text-align: justify;">
  <strong>Medidas ambientais -</strong> 
  <span style="font-weight: 400;">(1)</span> 
  <strong>Umidifica\xE7\xE3o</strong> 
  <span style="font-weight: 400;">- evitar ambientes secos usando umidificadores ou passando alguns minutos em um banheiro fechado com o chuveiro quente ligado pode ajudar a aliviar os sintomas; (2)</span> 
  <strong>Evitar Irritantes</strong> 
  <span style="font-weight: 400;">: Evitar a exposi\xE7\xE3o \xE0 fuma\xE7a de tabaco, tanto ativa quanto passiva, para prevenir a irrita\xE7\xE3o que pode exacerbar a dor de garganta.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">N\xE3o se recomenda o uso rotineiro de corticoides para al\xEDvio da dor associada \xE0 faringite aguda devido ao risco de efeitos colaterais graves em compara\xE7\xE3o com a ligeira redu\xE7\xE3o na dura\xE7\xE3o da dor. No entanto, podem ser apropriados em pacientes com dor de garganta grave e/ou dificuldade extrema para engolir.</span>
</p><p style="text-align: justify;">
  <strong>Tratamento da faringite estreptoc\xF3cica -</strong> 
  <span style="font-weight: 400;">Visa reduzir a gravidade e a dura\xE7\xE3o dos sintomas, prevenir complica\xE7\xF5es agudas e tardias, e impedir a transmiss\xE3o da infec\xE7\xE3o. A antibioticoterapia \xE9 recomendada para todos os pacientes com faringite sintom\xE1tica que apresentem teste microbiol\xF3gico positivo para SGA.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Um antibi\xF3tico da classe das</span> 
  <strong>aminopenicilinas</strong> 
  <span style="font-weight: 400;">\xE9 o tratamento de escolha devido \xE0 sua efic\xE1cia, seguran\xE7a, espectro estreito e baixo custo. O f\xE1rmaco mais utilizado \xE9 a amoxicilina, 500 mg via oral, duas vezes ao dia, por dez dias. Em pacientes no tratamento de FR aguda, pode-se optar entre penicilina V oral, amoxicilina oral ou uma dose \xFAnica de penicilina G benzatina intramuscular (1,2 milh\xE3o UI IM, dose \xFAnica). Para pacientes al\xE9rgicos \xE0 penicilina,</span> 
  <strong>cefalosporinas</strong> 
  <span style="font-weight: 400;">,</span> 
  <strong>clindamicina</strong> 
  <span style="font-weight: 400;">e</span> 
  <strong>macrol\xEDdeos</strong> 
  <span style="font-weight: 400;">s\xE3o op\xE7\xF5es.&nbsp;</span>
</p><p style="text-align: justify;">
  <strong>Isolamento e retorno \xE0s atividades</strong> 
  <span style="font-weight: 400;">- Pacientes com faringite por SGA devem ser orientados a evitar contato pr\xF3ximo com outras pessoas at\xE9 completar pelo menos 24 horas de antibioticoterapia, para reduzir o risco de transmiss\xE3o. A maioria dos pacientes pode retornar ao trabalho ou escola ap\xF3s completar um dia inteiro de tratamento, desde que estejam afebris e se sintam bem.&nbsp;</span>
</p><p style="text-align: justify;">
  <strong>Acompanhamento</strong> 
  <span style="font-weight: 400;">- Teste de cura n\xE3o \xE9 necess\xE1rio para a maioria dos pacientes assintom\xE1ticos ap\xF3s o tratamento. No entanto, um teste de cura (cultura ou TRDA) \xE9 recomendado para pacientes com hist\xF3rico de febre reum\xE1tica aguda, aqueles que adquiriram a infec\xE7\xE3o durante um surto de febre reum\xE1tica ou glomerulonefrite p\xF3s-estreptoc\xF3cica, ou em casos de infec\xE7\xF5es recorrentes em ambientes de contato pr\xF3ximo. Para pacientes que testam positivo nessas circunst\xE2ncias, repete-se um curso completo de 10 dias de terapia, geralmente com um antibi\xF3tico de maior estabilidade contra beta-lactamase do que o usado inicialmente.&nbsp;</span>
</p>`,ordem:5},{titulo:"ARMADILHAS&nbsp;",texto:`<p style="text-align: justify;">
  <strong>- Sobreposi\xE7\xE3o de sintomas entre causas virais e bacterianas</strong> 
  <span style="font-weight: 400;">- A similaridade dos sintomas entre faringites virais e bacterianas pode levar ao uso inadequado de antibi\xF3ticos. A utiliza\xE7\xE3o dos crit\xE9rios de Centor pode ajudar na decis\xE3o sobre a necessidade de testagem para SGA, mas a confirma\xE7\xE3o microbiol\xF3gica \xE9 essencial para evitar o uso desnecess\xE1rio de antibi\xF3ticos.</span>
</p><p style="text-align: justify;">
  <strong>- Portadores assintom\xE1ticos de SGA</strong> 
  <span style="font-weight: 400;">- A presen\xE7a de portadores assintom\xE1ticos pode dificultar o diagn\xF3stico, levando a resultados falso-positivos e ao uso desnecess\xE1rio de antibi\xF3ticos. Portadores cr\xF4nicos s\xE3o improv\xE1veis de transmitir SGA a outros e t\xEAm baixo risco de desenvolver complica\xE7\xF5es supurativas ou febre reum\xE1tica aguda.</span>
</p><p style="text-align: justify;">
  <strong>- Identifica\xE7\xE3o de complica\xE7\xF5es graves</strong> 
  <span style="font-weight: 400;">- A identifica\xE7\xE3o de complica\xE7\xF5es como obstru\xE7\xE3o das vias a\xE9reas superiores e infec\xE7\xF5es invasivas do pesco\xE7o requer aten\xE7\xE3o especial. Sintomas como voz abafada, estridor, disfagia grave, trismo e apar\xEAncia t\xF3xica devem alertar para essas condi\xE7\xF5es que necessitam de manejo urgente. A presen\xE7a de sintomas persistentes e graves, como dor de garganta grave acompanhada de febre, trismo ou voz abafada, sugere complica\xE7\xF5es locais como celulite ou abscesso peritonsilar.</span>
</p><p style="text-align: justify;">
  <strong>- Avalia\xE7\xE3o de fatores de risco para ISTs -</strong> 
  <span style="font-weight: 400;">A falha em avaliar adequadamente os fatores de risco para infec\xE7\xF5es sexualmente transmiss\xEDveis (ISTs) pode resultar em diagn\xF3sticos perdidos de faringites causadas por HIV, gonorreia e s\xEDfilis, que t\xEAm importantes implica\xE7\xF5es para a sa\xFAde p\xFAblica e necessitam de tratamento espec\xEDfico. A hist\xF3ria sexual detalhada e a identifica\xE7\xE3o de outros riscos para infec\xE7\xE3o aguda por HIV s\xE3o cruciais na avalia\xE7\xE3o.</span>
</p><p style="text-align: justify;">
  <strong>- Evitar prescri\xE7\xE3o excessiva de antibi\xF3ticos</strong> 
  <span style="font-weight: 400;">- prescrever antibi\xF3ticos quando n\xE3o indicados aumenta o risco de efeitos colaterais e a resist\xEAncia bacteriana na comunidade. A maioria dos pacientes busca al\xEDvio da dor e informa\xE7\xF5es sobre a doen\xE7a, e n\xE3o necessariamente antibi\xF3ticos. Discuss\xF5es sobre os riscos e benef\xEDcios dos antibi\xF3ticos e abordagens n\xE3o antibi\xF3ticas, juntamente com a educa\xE7\xE3o do paciente sobre o curso cl\xEDnico esperado, s\xE3o essenciais para reduzir a prescri\xE7\xE3o excessiva de antibi\xF3ticos.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">Shulman ST, Bisno AL, Clegg HW, Gerber MA, Kaplan EL et al. Clinical Practice Guideline for the Diagnosis and Management of Group A Streptococcal Pharyngitis: 2012 Update by the Infectious Diseases Society of America. Clinical Infectious Diseases 2012; 55(10):1279-1282.</span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">NICE. Rapid tests for group A streptococcal infections in people with a sore throat. Diagnostics Guidance 2019; 38:1-49.</span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">NICE guideline NG84. Sore throat (acute): antimicrobial prescribing. NICE Guideline 2018; 1:1-29.</span>
  </li>
</ol>`,ordem:6}],videos:[],fluxogramas:[],tags:["Dor de Garganta","Amigdalite","Faringoamidgalite"]},{id:"aeb6e09e-44f0-4344-9a1a-6a82423b9448",nome:"Hemorragia Digestiva Alta N\xE3o-Varicosa",categoria:1,termosDeBusca:"hemorragia digestiva alta nao-varicosa, sangramento, sangramento digestivo, hematemese, melena, enterorragia, hematoquezia",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"26d97f50-f3f1-44de-ab53-8c9f53124680",nome:"HDA N\xE3o-Varicosa",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"8d4a8269-b22a-47f0-8961-270e03e7dc8a",opcoes:[{id:"4f4539e2-ed3a-4840-8112-e5f6f03c001e",descr:"Dieta oral zero (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"881bf227-ca92-493d-a348-0e6687af7565",descr:"Dieta oral l\xEDquida clara",recomendado:!1,favorito:!1,ordem:2},{id:"e3d0c86c-109d-4a01-9b07-a4b7651273d8",descr:"Dieta livre",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Liberar dieta ap\xF3s EDA: l\xEDquidos claros por 2 dias em caso de sangramento ativo ou vaso vis\xEDvel (Forrest I e IIa); dieta livre nas primeiras 24h em caso de hematina ou \xFAlcera de base clara (Forrest IIc ou III).",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"653d5180-3d3a-4523-b326-2b60745e67c9",opcoes:[{id:"16b1498a-9ec2-4e9e-9a46-8c84b07ce52d",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"INIBIDOR DE BOMBA DE PR\xD3TON",grupos:[{grupo:"Analg\xE9sico",idGrupo:"19d8b398-a84a-4e90-a396-fed61786dd27",opcoes:[{id:"d0756089-71d7-4b6a-99dd-dc3022594741",descr:"Omeprazol (40mg/10mL) 80 mg IV em bolus, seguido de Omeprazol 20 mL + SF 0,9% 80 mL (solu\xE7\xE3o: 0,8 mg/mL) - IV em bomba infusora a 10 mL/h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"0c417a05-8590-4047-84fe-3bd651bd479e",descr:"Esomeprazol (40mg/frasco) 80 mg IV em bolus (diluir em 10 mL de SF 0,9%), seguido de Esomeprazol 80 mg + SF 0,9% 100 mL (soluc\xE3o : 0,8 mg/dL) - IV em bomba infusora a 10 mL/h",recomendado:!1,favorito:!1,ordem:2},{id:"816d010d-60fe-4edb-94e7-22e7f00396aa",descr:"Pantoprazol (40mg/10mL) 80 mg IV em bolus (2 min), seguido de Pantoprazol 20 mL + SF 0,9% 80 mL (solu\xE7\xE3o: 0,8 mg/mL) - IV em bomba infusora a 10 mL/h",recomendado:!1,favorito:!1,ordem:3},{id:"cf68f6fc-ca39-4f2e-a291-a75618846080",descr:"Esomeprazol (20-40mg/cp) 40 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:4},{id:"da488aa9-440b-46a7-9f7a-92ffe2ffe0ad",descr:"Omeprazol (10-40mg/cp) 20 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:5},{id:"a0827fb4-ab25-442d-8d7c-029ca2f73a59",descr:"Lanzoprazol (15-30mg/cp) 30 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:6},{id:"a169cee3-03be-4331-9718-3cc0be0820e6",descr:"Pantoprazol (20-40mg/cp)40 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:7},{id:"9b05205d-18a4-4548-ac16-8d412bd76009",descr:"Rabeprazol (10-20mg/cp) 20 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:8},{id:"335dcb91-b63e-4bf4-be30-748f40fec659",descr:"Dexlanzoprazol (30-60mg/cp) 30 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:9}],ordem:1}],academico:"Idealmente, aplicar bolus (80 mg) e iniciar infus\xE3o cont\xEDnua (8mg/h) at\xE9 mesmo antes da endoscopia; nos casos de alto risco (sangramento ativo ou vaso vis\xEDvel - Forrest I e IIa), manter medica\xE7\xE3o IV por 72h, trocando para VO 1x/dia inicialmente por at\xE9 8 semanas.",ordem:3},{item:"PROCIN\xC9TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ba78cc18-7b59-4d93-b318-18d748950920",opcoes:[{id:"8b26acc8-0658-4bae-9a54-fc2c88a39eae",descr:"Eritromicina (1000mg/frasco) 250 mg IV 30-120 minutos antes da endoscopia",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Considerar administra\xE7\xE3o antes da EDA com a inten\xE7\xE3o de facilitar a visualiza\xE7\xE3o endosc\xF3pica desde que n\xE3o haja contraindica\xE7\xE3o ao medicamento (como intervalo QT longo).",ordem:4},{item:"HEMOTRANSFUS\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ef1f504e-037b-473a-a1a4-911d94fd526d",opcoes:[{id:"9e8d7cef-1988-4480-9d89-6d7b0efb1eb5",descr:"Concentrado de Hem\xE1cias 1-2U IV",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Apenas se necess\xE1rio para manter Hb \u2265 8 g/dL (\u2265 9 g/dL em idosos ou coronariopatas).\xA0",ordem:5},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2df4422e-3a66-4022-b02f-b24db891911e",opcoes:[{id:"c74d3bab-a4fe-4094-8a56-be1539256444",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"73266d94-a6ab-4164-84b0-71f96fd70be1",opcoes:[{id:"3b504f3d-f855-45df-a82e-b2343090857a",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"c007a6a0-57d3-439b-8148-ab05da9d8504",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"5967cad6-6674-4200-8486-960845c80846",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:6},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"d33f887e-9f34-458a-ba93-9710edf5e10c",opcoes:[{id:"0e2fed57-9ed2-4ee8-be85-96f4ece13a7f",descr:"Glicemia capilar 6/6h ",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"f434e214-e987-45bb-9d98-b22ae0f6f4fa",opcoes:[{id:"0d33412b-5101-49a6-a582-fbe35d9eae5b",descr:"Glicose Hipert\xF4nica 50% - 50mL (5 ampolas) se glicemia capilar < 70 mg/mL",recomendado:!0,favorito:!0,ordem:1},{id:"5953ee7d-3ca1-428c-b2b6-1156277dc720",descr:"Insulina Regular SC conforme esquema: 141-200=2U / 201-250=4U / 251-300=6U / 301-350=8U / 351-400=10U / > 400=12U. Se > 400 ou < 70, avisar plantonista",recomendado:!1,favorito:!1,ordem:2},{id:"a612d5c9-f636-4478-954e-e0fd5cf9dc7c",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!1,favorito:!1,ordem:3},{id:"c87843f0-45f1-4648-8bdf-b781dba81c6e",descr:"Manter cabeceira elevada a 30o",recomendado:!1,favorito:!1,ordem:4}],ordem:2}],academico:"Cuidados inespec\xEDficos.",ordem:7}],conceitosPraticos:[{conceito:"Realizar endoscopia digestiva alta em at\xE9 24 horas iniciais.",ordem:1},{conceito:"Em caso de \xFAlcera p\xE9ptica, a pesquisa para H. pylori deve ser feita e, se positiva, \xE9 necess\xE1ria erradica\xE7\xE3o da bact\xE9ria.",ordem:2},{conceito:"A passagem de sonda nasog\xE1strica ou nasoent\xE9rica n\xE3o \xE9 obrigat\xF3ria.",ordem:3},{conceito:"Avaliar necessidade de corre\xE7\xE3o eletrol\xEDtica.",ordem:4}]}],topicos:[],videos:[],fluxogramas:[],tags:["Sangramento","Sangramento Digestivo","Hemat\xEAmese","Melena","Enterorragia","Hematoquezia"]},{id:"ec2259bd-00bd-4015-8369-dadb4c167e69",nome:"Hemorragia Digestiva Alta Varicosa",categoria:1,termosDeBusca:"hemorragia digestiva alta varicosa, sangramento, sangramento digestivo, hematemese, melena, enterorragia, hematoquezia, varizes, cirrose",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"81c35266-9f92-4466-ae57-0a918f442359",nome:"HDA Varicosa - Tratamento",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f24f0443-f30c-4ecb-a79b-a5fe4e197511",opcoes:[{id:"42bc599b-6f0b-432a-89e9-3f396492652b",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s 24h da interrup\xE7\xE3o do sangramento.",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"37989fcc-8b5d-47f0-abb9-ceeaca5121fd",opcoes:[{id:"9b9ce9a1-cac0-4089-8b47-45451865ccf4",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"ANTIBIOTICOPROFILAXIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"3500da0e-0146-4783-bb24-271820b9118c",opcoes:[{id:"d535a4bc-eddb-46f6-9b0f-99b7b79489ce",descr:"Ceftriaxone 1 g IV 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"56abfe98-f113-4ecb-95a8-32c889ac5b34",descr:"Ciprofloxacino 400 mg IV 12/12h",recomendado:!1,favorito:!1,ordem:2},{id:"8c80a6fe-85fb-4b0b-8607-5307139aa3c7",descr:"Norfloxacina 400 mg VO ou SNG 12/12h",recomendado:!1,favorito:!1,ordem:3},{id:"30744287-d618-44c8-b3e7-83cec6ad2a20",descr:"Ciprofloxacino 500 mg VO ou SNG 12/12h",recomendado:!1,favorito:!1,ordem:4},{id:"e585121a-3aa5-47d9-ab46-a14827beec36",descr:"Sulfametoxazol/Trimetoprima 800/160 mg VO ou SNG 12/12h",recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Obrigat\xF3ria para preven\xE7\xE3o de peritonite bacteriana espont\xE2nea; iniciar, se poss\xEDvel, antes da EDA. Usar por at\xE9 7 dias.",ordem:3},{item:"VASOCONSTRICTOR ESPL\xC2NCNICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e98ad385-7efe-4bf7-ac74-a243de5016dd",opcoes:[{id:"6f5d0e33-7f79-4709-b2e6-20362a97542f",descr:"Terlipressina 2 mg IV 1x/dia por 48h, seguido de 1 mg IV 4/4h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"e1e5ab70-d3de-46c8-b57f-dc23031c49b0",descr:`Somatostatina (3mg/mL) 2 mL + SF 0,9% 240 mL (solu\xE7\xE3o: 25 mcg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 10 mL (250 mcg) IV agora, seguido de 10-20 mL/h (250-500 mcg/h)`,recomendado:!1,favorito:!1,ordem:2},{id:"26244030-6163-4fff-97ba-0ceed433b669",descr:`Octreotide (500mcg/mL) 1 mL + SF 0,9% 100 mL (solu\xE7\xE3o: 5 mcg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 10 mL (50 mcg) agora, seguido de 5-10 mL/h (25-50 mcg/h)`,recomendado:!1,favorito:!1,ordem:3},{id:"e55d29f7-81c4-4c4d-a255-fabd79b6ed38",descr:`Octreotide (500mcg/mL) 0,1 mL (50 mcg) IV agora; seguido de Octreotide (500mcg/mL) 1 mL + SF 0,9% 60 mL (solu\xE7\xE3o: 8,3 mcg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 3-6 mL/h (25-50 mcg/h)`,recomendado:!1,favorito:!1,ordem:4},{id:"d95b40ed-25db-4536-9b98-9b9bcb6a5c55",descr:`Octreotide (500mcg/mL) 0,1 mL (50 mcg) IV agora; seguido de Octreotide (500mcg/mL) 1 mL + SF 0,9% 250 mL (solu\xE7\xE3o: 2 mcg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 12,5-25 mL/h (25-50 mcg/h)`,recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Obrigat\xF3rio para redu\xE7\xE3o da intensidade do sangramento; iniciar, se poss\xEDvel, antes da EDA. Usar por 2-5 dias (as 3 op\xE7\xF5es s\xE3o igualmente eficazes)",ordem:4},{item:"PROCIN\xC9TICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"81466165-1b8f-4433-b7d6-dabc724b0eb6",opcoes:[{id:"c622238f-6fb5-47e0-a9e4-9d54b8da5d38",descr:"Eritromicina (1000mg/frasco) 250 mg IV 30-120 minutos antes da endoscopia",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Considerar administra\xE7\xE3o antes da EDA com a inten\xE7\xE3o de facilitar a visualiza\xE7\xE3o endosc\xF3pica desde que n\xE3o haja contraindica\xE7\xE3o ao medicamento (como intervalo QT longo).",ordem:5},{item:"BETA-BLOQUEADOR",grupos:[{grupo:"Analg\xE9sico",idGrupo:"c34f75d2-ab35-4287-af2c-2d4cca06e85c",opcoes:[{id:"33bf8208-f1ab-486d-942f-9fa946e47975",descr:"Propranolol (10-80mg/comp) iniciar com 20-40 mg VO 12/12h, at\xE9 o m\xE1ximo de 320 mg/dia (160 mg/dia em caso de ascite) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"ddd4d35c-f631-4b2e-994f-949aab438830",descr:`Nadolol (20-80mg/cp)iniciar com 20-40 mg VO 1x/dia, at\xE9 o m\xE1ximo de 160 mg/dia (80 mg/dia em caso de ascite)\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Iniciar ap\xF3s a interrrup\xE7\xE3o do vasoconstrictor espl\xE2ncnico como medida de profilaxia secund\xE1ria contra o ressangramento e manter por tempo indeterminado. Come\xE7ar em dose baixa, ajustando a cada 2-3 dias at\xE9 atingir FC 55-60 bpm, desde que a PA sist\xF3lica n\xE3o esteja < 90 mmHg.",ordem:6},{item:"HEMOTRANSFUS\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"19f33a71-dd74-4f5a-8e7b-149ab3404f90",opcoes:[{id:"5249f63b-57c0-4b33-9181-b4b3c543f438",descr:"Concentrado de Hem\xE1cias 1-2U IV para manuten\xE7\xE3o de Hb 7-9 g/dL",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"N\xE3o h\xE1 consenso em rela\xE7\xE3o a transfus\xE3o de plasma fresco congelado e unidade de plaqueta.",ordem:7},{item:"LACTULOSE",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f59ca128-f952-4233-af92-f82c60f671d0",opcoes:[{id:"c9a0001a-7588-4df3-a4c7-155792e552c3",descr:"Lactulona (667mg/mL) 25 mL 12/12h at\xE9 produ\xE7\xE3o de 2-3 evacua\xE7\xF5es pastosas/dia",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Iniciar em caso de Encefalopatia Hep\xE1tica.",ordem:8},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"d51c78bd-5ea8-4673-9a0c-69e2433c0bdd",opcoes:[{id:"48390bda-0ab8-4f8f-a5b3-db105ad9dbc0",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"c9f43dad-1a01-4d64-b6b7-24105782d17c",opcoes:[{id:"cc0a485e-c4ea-4d09-9be2-b410b7e86d25",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"daeb6cc6-1f50-4328-b7ee-854676872aad",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"42929bdf-c4c4-4c68-a5b3-11b5755f829a",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:9},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7f0fa389-51b0-4ff0-894c-f285efa2c2cb",opcoes:[{id:"1fb26114-cbfa-4950-aea0-3941ef678124",descr:"Glicemia capilar 6/6h ",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"0a8713b1-c0bd-420d-b964-333e47e74677",opcoes:[{id:"077336e3-9f91-4d73-a613-70364800e021",descr:"Glicose Hipert\xF4nica 50% - 50mL (5 ampolas) se glicemia capilar < 70 mg/mL",recomendado:!0,favorito:!0,ordem:1},{id:"4b649ef5-6dd5-4cdb-bf27-ddb194d0a047",descr:"Insulina Regular SC conforme esquema: 141-200=2U / 201-250=4U / 251-300=6U / 301-350=8U / 351-400=10U / > 400=12U. Se > 400 ou < 70, avisar plantonista",recomendado:!1,favorito:!1,ordem:2},{id:"e09acd35-4f05-4603-95a0-2b7517d1a4db",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!1,favorito:!1,ordem:3},{id:"fcd8cda3-f7fa-441b-952d-644495992332",descr:"Manter cabeceira elevada a 30o",recomendado:!1,favorito:!1,ordem:4}],ordem:2}],academico:"Cuidados inespec\xEDficos.",ordem:10}],conceitosPraticos:[{conceito:"Suspeita em todo o paciente com Hemorragia Digestiva Alta e estigmas de Hipertens\xE3o Porta.",ordem:1},{conceito:"Realizar endoscopia digestiva alta em at\xE9 12 horas iniciais.",ordem:2},{conceito:"Avaliar necessidade de corre\xE7\xE3o eletrol\xEDtica.",ordem:3}]},{id:"3d3cba38-4447-449f-a569-8ea31928c168",nome:"HDA Varicosa - Profilaxia 1\xE1ria",favorito:!1,ordem:2,secoes:[],conceitosPraticos:[]},{id:"6e7aa49e-1df1-44eb-b8eb-7a6cc68b1946",nome:"HDA Varicosa - Profilaxia 2\xE1ria",favorito:!1,ordem:3,secoes:[],conceitosPraticos:[]}],topicos:[],videos:[],fluxogramas:[],tags:["Sangramento","Sangramento Digestivo","Hemat\xEAmese","Melena","Enterorragia","Hematoquezia","Varizes","Cirrose"]},{id:"fad26f1f-5015-4f3a-b8ee-5b867dcdeff1",nome:"Hipernatremia",categoria:1,termosDeBusca:"hipernatremia, sodio, natremia",favoritado:!1,ordem:0,especialidades:[{nome:"MEDICINA INTERNA"}],prescricoes:[],topicos:[{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A hipernatremia \xE9 definida pela concentra\xE7\xE3o de s\xF3dio s\xE9rico maior que 145 mEq/L e \xE9 causada mais frequentemente pela redu\xE7\xE3o de \xE1gua livre (seja por redu\xE7\xE3o da ingesta e por maior perda) e mais raramente pelo ganho direto de s\xF3dio.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Em termos pr\xE1ticos, pode ser classificada em</span> 
  <strong>aguda</strong> 
  <span style="font-weight: 400;">(\u2264 48h) ou</span> 
  <strong>cr\xF4nica</strong> 
  <span style="font-weight: 400;">(&gt; 48h). A aguda \xE9 mais relacionada ao ganho de s\xF3dio (tentativa de suic\xEDdio por ingest\xE3o, erro na di\xE1lise, infus\xE3o excessiva de salina hipert\xF4nica ou bicarbonato de s\xF3dio), enquanto a cr\xF4nica \xE9 atribu\xEDda \xE0 redu\xE7\xE3o do acesso \xE0 \xE1gua (idosos, portadores de doen\xE7as neurol\xF3gicas, lactentes) e/ou \xE0 perda direta de l\xEDquidos, seja pelo trato gastrointestinal (v\xF4mito, diarreia), rim (</span> 
  <em>
    <span style="font-weight: 400;">diabetes insipidus</span>
  </em> 
  <span style="font-weight: 400;">, diurese osm\xF3tica por hiperglicemia) ou pele (sudorese).</span>
</p>`,ordem:1},{titulo:"MANIFESTA\xC7\xD5ES",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Os achados cl\xEDnicos na hipernatremia s\xE3o predominantemente neurol\xF3gicos e est\xE3o relacionados \xE0 intensidade da altera\xE7\xE3o eletrol\xEDtica e principalmente \xE0 rapidez da mudan\xE7a da natremia. Desta forma, os casos agudos t\xEAm mais chances de se associarem \xE0 desidrata\xE7\xE3o cerebral, podendo cursar com altera\xE7\xE3o no n\xEDvel de consci\xEAncia, letargia, fraqueza e irritabilidade, al\xE9m do risco de progress\xE3o para convuls\xF5es, coma e morte. Os casos cr\xF4nicos, pela maior capacidade de adapta\xE7\xE3o osm\xF3tica neuronal, t\xEAm manifesta\xE7\xF5es mais inespec\xEDficas e, muitas vezes, mascaradas por condi\xE7\xF5es neurol\xF3gicas de base.</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Naturalmente, a confirma\xE7\xE3o diagn\xF3stica da hipernatremia requer a dosagem do s\xF3dio s\xE9rico. Mas \xE9 importante tamb\xE9m solicitar: 
    <br>
  </span>- Glicemia \u2192 a hiperglicemia pode causar diurese osm\xF3tica com perda de \xE1gua e consequente hipernatremia. 
  <br>- Calemia (K + ) e calcemia (Ca ++ ) \u2192 a hipocalemia e a hipercalcemia podem contribuir para a hipernatremia ao provocarem uma redu\xE7\xE3o da a\xE7\xE3o renal da vasopressina, simulando 
  <em>diabetes insipidus</em> nefrog\xEAnico e levando, portanto, \xE0 perda de \xE1gua. 
  <br>-Fun\xE7\xE3o renal. 
  <br>- Bioqu\xEDmica urin\xE1ria (s\xF3dio e osmolaridade) \u2192 podem guiar a investiga\xE7\xE3o nos casos em que a etiologia n\xE3o \xE9 evidente.
</p>`,ordem:3},{titulo:"CONDUTA",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Na maior parte das vezes, a hipernatremia ocorre em pacientes sem acesso independente \xE0 \xE1gua ou com resposta deficiente \xE0 sede, de modo que o mais adequado \xE9 que o tratamento seja feito com o paciente hospitalizado em um primeiro momento.</span>
</p><p style="text-align: justify;">
  <strong>- Hipernatremia aguda \u2013</strong> 
  <span style="font-weight: 400;">A corre\xE7\xE3o da natremia deve ser feita rapidamente \u2013 em menos de 24h \u2013 com SG 5% (reposi\xE7\xE3o de \xE1gua livre), associando hemodi\xE1lise em casos mais graves para restaurar imediatamente a normonatremia.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Neste caso, embora classicamente seja feita infus\xE3o de SG 5% \xE0 taxa de 3-6 mL/kg/h, isso n\xE3o precisa ser obrigatoriamente respeitado, uma vez que o tratamento destes casos agudos deve ser guiado por frequente monitoriza\xE7\xE3o da natremia a cada uma a duas horas e n\xE3o apenas por f\xF3rmulas matem\xE1ticas.</span>
</p><p style="text-align: justify;">
  <strong>- Hipernatremia cr\xF4nica \u2013</strong> 
  <span style="font-weight: 400;">O tratamento desses casos atrav\xE9s da reidrata\xE7\xE3o tem como objetivo a redu\xE7\xE3o da natremia em at\xE9 10 mEq/L/dia, o que equivale a uma diminui\xE7\xE3o inferior a 0,5 mEq/L/h. Esse cuidado reduz o risco de edema cerebral e convuls\xF5es, que ainda assim \xE9 muito baixo quando comparado ao risco de corre\xE7\xF5es aceleradas de casos de hiponatremia. Como fazer?</span>
</p><h1 style="text-align: justify;">
  <span style="font-size: 10pt;">
    <span style="font-weight: 400;">(1) Em primeiro lugar, deve-se calcular o</span> 
    <em>
      <span style="font-weight: 400;">deficit</span>
    </em> 
    <span style="font-weight: 400;">de \xE1gua livre (em litros) para atingir essa varia\xE7\xE3o de 10 mEq/L desejada em 24h: 
      <br>
    </span>
  </span> 
  <span style="font-size: 10pt;">
    <span style="font-weight: 400;">
      <br>
    </span>
  </span> 
  <span style="font-size: 10pt;">
    <span style="font-weight: 400;">
      <img src="https://d55mnj1ee66xh.cloudfront.net/academico/721d31ba-af15-4f18-a532-5323ea942ec7.jpg" alt="" width="622" height="430"> 
      <br>
    </span>
  </span>
</h1><p style="text-align: justify;">
  <span style="font-weight: 400;">Como a \u201C\xE1gua corporal total\u201D \xE9 uma refer\xEAncia \xE0 propor\xE7\xE3o do peso corporal que corresponde \xE0 \xE1gua e os pacientes hipernatr\xEAmicos, em geral, est\xE3o desidratados, alguns preconizam a utiliza\xE7\xE3o de valores de \u201C\xE1gua corporal total\u201D 10% mais baixos do que os descritos na imagem acima.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">(2) Adicionar, ao volume calculado, as denominadas \u201Cperdas insens\xEDveis\u201D atrav\xE9s das fezes e suor (aproximadamente 1000 mL/24h) e eventuais perdas que continuem a ocorrer atrav\xE9s da urina e do trato gastrointestinal.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">(3) Decidir o tipo de fluido a ser utilizado para reposi\xE7\xE3o. E aqui o racioc\xEDnio \xE9 interessante...&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Se a causa da hipernatremia foi a perda de \xE1gua livre (perda cut\xE2nea, diabetes insipidus), o ideal \xE9 a reposi\xE7\xE3o tamb\xE9m de \xE1gua livre, que pode ser feita com \xE1gua pot\xE1vel por via oral (ou enteral) ou SG 5% por via intravenosa.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Se a causa da hipernatremia foi a perda de fluidos hipot\xF4nicos (diarreia, poli\xFAria), o ideal seria uma estrat\xE9gia que associasse \xE1gua livre e s\xF3dio atrav\xE9s de NaCl 0,2% ou NaCl 0,45%. Para a reposi\xE7\xE3o vol\xEAmica com estas solu\xE7\xF5es, o</span> 
  <em>
    <span style="font-weight: 400;">deficit</span>
  </em> 
  <span style="font-weight: 400;">de \xE1gua calculado no item (1) deve ser multiplicado por 1,33 se a op\xE7\xE3o for por NaCl 0,2% ou por 2, se a op\xE7\xE3o for por NaCl 0,45%.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">(4) Acompanhar a natremia em 4-6h, 12h e 24h.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Vamos a um exemplo pr\xE1tico? Considere um homem de 75 anos, 70 kg e com Na 160 mEq/L. Pela f\xF3rmula exposta no item (1), o</span> 
  <em>
    <span style="font-weight: 400;">deficit</span>
  </em> 
  <span style="font-weight: 400;">de \xE1gua livre \xE9 de 2,3 L. A esse valor, o correto seria somarmos, pelo menos, as \u201Cperdas insens\xEDveis\u201D (cerca de 1 L), o que totaliza a necessidade de reposi\xE7\xE3o de 3,3 L de \xE1gua livre em 24h. A prescri\xE7\xE3o exata nessas 24h vai depender do tipo de solu\xE7\xE3o a ser utilizada: 
    <br>
  </span>- 3,3L de \xE1gua pot\xE1vel VO (ou enteral) 
  <br>- 3,3L de SG 5% IV 
  <br>- 4,4L de NaCl 0,2% IV 
  <br>- 6,6L de NaCl 0,45% IV
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Vale lembrar que, se houver sinais de instabilidade hemodin\xE2mica em um paciente hipovol\xEAmico, a prioridade ser\xE1 a corre\xE7\xE3o desta instabilidade, que deve ser feita com SF 0,9% IV at\xE9 normaliza\xE7\xE3o da press\xE3o arterial e frequ\xEAncia card\xEDaca. Ap\xF3s esta estabiliza\xE7\xE3o, trocamos a solu\xE7\xE3o de reposi\xE7\xE3o buscando priorizar agora a corre\xE7\xE3o da hipernatremia.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- Soro glicosado e hiperglicemia -</strong> 
  <span style="font-weight: 400;">O uso de SG 5%, principalmente em pacientes cr\xEDticos e/ou diab\xE9ticos, pode ocasionar hiperglicemia, com consequente risco de aumentar a perda de \xE1gua livre por diurese osm\xF3tica e, assim, limitar a queda do s\xF3dio s\xE9rico.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Nos pacientes que desenvolverem hiperglicemia, a reposi\xE7\xE3o pode ser feita agora com SG 2,5% (solu\xE7\xE3o constru\xEDda pela associa\xE7\xE3o de volume iguais de SG 5% e \xE1gua destilada) ou NaCl 0,45% ou NaCl 0,2%.</span>
</p><p style="text-align: justify;">
  <strong>- Diabetes insipidus (DI) -</strong> 
  <span style="font-weight: 400;">Em geral, paciente com DI s\xF3 desenvolve hipernatremia quando n\xE3o t\xEAm acesso \xE0 \xE1gua. O quadro cl\xEDnico desses pacientes caracteriza-se por polidipsia e poli\xFAria com urina hipot\xF4nica. Pode ser de origem central (falta de vasopressina) ou de origem renal (resist\xEAncia dos n\xE9frons \xE0 vasopressina). Al\xE9m da reposi\xE7\xE3o l\xEDquida, realizada por via oral em pacientes alertas e orientados ou parenteral em pacientes debilitados, o tratamento da DI central \xE9 feito com desmopressina e da DI nefrog\xEAnico, com diur\xE9ticos tiaz\xEDdicos.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Braun MM, Barstow CH, Pyzocha NH. Diagnosis and management of sodium disorders: hyponatremia and hypernatremia.&nbsp;</span> 
    <em>
      <span style="font-weight: 400;">Am. Fam. Physician</span>
    </em> 
    <span style="font-weight: 400;">2015;</span> 
    <span style="font-weight: 400;">&nbsp;91:299-307.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Sterns RH. Disorders of Plasma Sodium \u2013 Causes, Consequences and Correction.</span> 
    <em>
      <span style="font-weight: 400;">N Engl J Med</span>
    </em> 
    <span style="font-weight: 400;">2015; 372:55-65</span>
  </li>
</ol><h1>
  <br>
</h1>`,ordem:5}],videos:[],fluxogramas:[],tags:["S\xF3dio","natremia"]},{id:"0240e6a0-903c-4540-a6fe-e7d4f55b61b4",nome:"Hipertens\xE3o - Crise Hipertensiva",categoria:1,termosDeBusca:"hipertensao - crise hipertensiva, has, hipertensao, encefalopatia hipertensiva, disseccao aguda de aorta, aorta, urgencia hipertensiva, emergencia hipertensiva, pseudocrise hipertensiva, crise",favoritado:!1,ordem:0,especialidades:[{nome:"CARDIOLOGIA"}],prescricoes:[{id:"991e19b5-1d67-4056-83b8-dddb8b8587a7",nome:"Dissec\xE7\xE3o Aguda de Aorta",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"11bb3072-0878-4704-9113-6d46ace270b7",opcoes:[{id:"432ce476-6da9-4145-b4a0-868cad362e56",descr:"Dieta hiposs\xF3dica",recomendado:!0,favorito:!0,ordem:1},{id:"e8507046-da5e-44c0-8607-dea7c5de2e26",descr:"Dieta oral zero (MEDGRUPO)",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Progredir ap\xF3s estabiliza\xE7\xE3o press\xF3rica",ordem:1},{item:"BETA-BLOQUEADOR IV",grupos:[{grupo:"Analg\xE9sico",idGrupo:"293a66fd-90ab-463f-8fac-7547a3630696",opcoes:[{id:"c4bc17cc-2336-4cd5-97b4-14b0c45c3cab",descr:"Metoprolol (1mg/mL) 5 mg IV agora (em 2-5 min), repetir, se necess\xE1rio, 10/10 min at\xE9 o m\xE1ximo de 20 mg",recomendado:!0,favorito:!0,ordem:1},{id:"bfe13a0a-b9ab-48ea-aa32-b77864eeb4ac",descr:`Esmolol (10mg/mL) 0,5 mg/Kg IV agora (em 1 min); seguido de Esmolol (250mg/mL) 1 mL + SF 0,9% 250 mL (solu\xE7\xE3o: 10mg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico
Iniciar 0,05 mg/Kg/min com aumentos de 0,05 mg/Kg/min a cada 10-20 min, at\xE9 0,3 mg/Kg/min`,recomendado:!1,favorito:!1,ordem:2},{id:"8df54e3c-61af-4337-ba71-e032b4a8fc9d",descr:"Labetalol (5mg/mL) 10-20 mg IV agora (em 2 min), repetir, se ncess\xE1rio, 10/10 min at\xE9 o m\xE1ximo de 300 mg",recomendado:!1,favorito:!1,ordem:3},{id:"158b02f3-c198-41b0-a39c-9f583797964b",descr:`Labetalol (5mg/mL) 40 mL + SG 5% 160 mL (solu\xE7\xE3o 1mg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
In\xEDcio com 0,4-1 mg/Kg/h at\xE9 o m\xE1ximo de 3 mg/Kg/h`,recomendado:!1,favorito:!1,ordem:4},{id:"8042b5e1-9933-4c4c-8270-76e566f0d739",descr:`Labetalol (5mg/mL) 100 mL + SG 5% 150 mL (solu\xE7\xE3o 2mg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
In\xEDcio com 0,4-1 mg/Kg/h at\xE9 o m\xE1ximo de 3 mg/Kg/h`,recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Deve ser iniciado antes da terapia anti-hipertensiva para evitar que a redu\xE7\xE3o press\xF3rica desencadeie uma resposta simp\xE1tica taquicardizante.",ordem:2},{item:"ANTI-HIPERTENSIVO IV",grupos:[{grupo:"Analg\xE9sico",idGrupo:"5aa5d22f-4a17-4d68-b2fa-08d2fb8591e1",opcoes:[{id:"d4976c1c-b89b-4c2b-a016-131fbdfc340d",descr:"Nitroprussiato de S\xF3dio 2 mL + SG 5% 250 mL (solu\xE7\xE3o:200mcg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico (in\xEDcio com 0,5 mcg/kg/min, aumentando 1-2 mL/h a cada 2 min at\xE9 o m\xE1ximo de 10 mcg/Kg/min) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"5a3a3f28-5c32-47e9-af06-812785f5257d",descr:"Hidralazina (20mg/mL) 10-20 mg IV ou IM 4/6h",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Reduzir a PA em 20 minutos objetivando PA sist\xF3lica entre 100 e 120 mmHg.",ordem:3},{item:"ANALGESIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7b08e608-2a4c-4cf5-b9ad-9b29bf2146f6",opcoes:[{id:"f9dd8a19-e642-4043-b6f5-336b8ba64c40",descr:`Morfina (10 mg/mL) 1 mL + \xC1gua Destilada 9 mL (solu\xE7\xE3o: 1mg/mL) 2-4 mg IV agora\r
Repetir a cada 5/15 min at\xE9 controle da dor ou ocorr\xEAncia de efeitos colaterais`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Administrar at\xE9 al\xEDvio da dor, surgimento de efeitos sedativos ou satura\xE7\xE3o < 95%.",ordem:4},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e1de50aa-7d65-4fb7-ae21-5a89ce504472",opcoes:[{id:"d4369de2-0ccf-4ed6-8231-3418bde3e54e",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antit\xE9rmico",idGrupo:"d43ab2ff-c219-4cc7-b924-363280cb082d",opcoes:[{id:"e1f5987d-c198-4f65-a208-e70b57a4040b",descr:"Esomeprazol (40mg/frasco) 20 mg IV 1x/dia pela manh\xE3 (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"f1c0729b-fbc8-42bb-898e-3a281ea642bb",descr:"Omeprazol (40mg/10mL) 20-40 mg IV 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:2}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:5},{item:"INIBIDOR DE BOMBA DE PR\xD3TON",grupos:[],academico:"Profilaxia de les\xE3o aguda de mucosa g\xE1strica.",ordem:6},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"9c7a88cb-42be-43c3-b057-9f69454fbc45",opcoes:[{id:"aadcdb1c-cb62-4e0b-8e18-550adc86a6c8",descr:"Balan\xE7o H\xEDdrico 4/4h",recomendado:!0,favorito:!0,ordem:1},{id:"31690562-6b3d-42a6-9e69-80304cd614c9",descr:"Monitoriza\xE7\xE3o Card\xEDaca Cont\xEDnua",recomendado:!1,favorito:!1,ordem:2},{id:"2cd3205d-f179-4928-9bf0-a171f80e5d53",descr:"O2 sob m\xE1scara a crit\xE9rio m\xE9dico",recomendado:!1,favorito:!1,ordem:3},{id:"ad4fd740-6638-402f-8e73-4e257d101b52",descr:"Acesso Venoso perif\xE9rico salinizado",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:7}],conceitosPraticos:[{conceito:"Consiste na eleva\xE7\xE3o aguda da press\xE3o arterial > 180 x 120 mmHg associada com les\xE3o aguda de \xF3rg\xE3o-alvo, sendo idealmente tratada em ambiente de terapia intensiva.",ordem:1},{conceito:"A Dissec\xE7\xE3o Aguda de Aorta deve ser tratada na suspeita cl\xEDnica: dor tor\xE1cica s\xFAbita e com irradia\xE7\xE3o para o dorso, associada a sopro de insufici\xEAncia a\xF3rtica ou diferen\xE7a de PA entre membros superiores.",ordem:2},{conceito:"Alvos terap\xEAuticos em 20 minutos: FC < 60 bpm e PA sist\xF3lica \u2264 120 mmHg.",ordem:3},{conceito:"As dissec\xE7\xF5es agudas que envolvem a aorta ascendente (classificadas como Stanford A) s\xE3o, a princ\xEDpio, emerg\xEAncias cir\xFArgicas.",ordem:4}]},{id:"8f91e93f-2532-4065-bdbf-e54dfaa80eeb",nome:"Encefalopatia Hipertensiva",favorito:!1,ordem:2,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"70cd794b-e92a-47d5-b65c-e302c28d8e67",opcoes:[{id:"0b2b90ee-8f36-4797-a81c-201b9e8c909a",descr:"Dieta oral zero (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"35b6c762-76dd-4fcf-8a6f-58622edbabd2",descr:"Dieta hiposs\xF3dica",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Progredir ap\xF3s estabiliza\xE7\xE3o press\xF3rica",ordem:1},{item:"ANTI-HIPERTENSIVO IV",grupos:[{grupo:"Analg\xE9sico",idGrupo:"d12bfe2c-fd53-4768-9a3b-8f5b6072acb4",opcoes:[{id:"83299a82-28f3-465a-892a-08b701dd91e0",descr:"Nitroprussiato de S\xF3dio 2 mL + SG 5% 250 mL (solu\xE7\xE3o:200mcg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico (in\xEDcio com 0,5 mcg/kg/min, aumentando 1-2 mL/h a cada 2 min at\xE9 o m\xE1ximo de 10 mcg/Kg/min) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"ed9b26a6-687c-45c6-bfdc-bc4110dc3647",descr:`Esmolol (10mg/mL) 0,5 mg/Kg IV agora (em 1 min); seguido de Esmolol (250mg/mL) 1 mL + SF 0,9% 250 mL (solu\xE7\xE3o: 10mg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
Iniciar 0,05 mg/Kg/min com aumentos de 0,05 mg/Kg/min a cada 10-20 min, at\xE9 0,3 mg/Kg/min`,recomendado:!1,favorito:!1,ordem:2},{id:"afd51f8e-fad4-458e-98f4-9b2620b1ae0d",descr:"Metoprolol (1mg/mL) 5 mg IV agora (em 2-5 min), repetir, se necess\xE1rio, 10/10 min at\xE9 o m\xE1ximo de 20 mg",recomendado:!1,favorito:!1,ordem:3},{id:"3ed42ac5-215d-4157-8460-c51a60c3e5d4",descr:"Labetalol (5mg/mL) 10-20 mg IV agora (em 2 min), repetir, se ncess\xE1rio, 10/10 min at\xE9 o m\xE1ximo de 300 mg",recomendado:!1,favorito:!1,ordem:4},{id:"be1ea280-c79a-4e4e-b5eb-a0b779a1b100",descr:`Labetalol (5mg/mL) 40 mL + SG 5% 160 mL (solu\xE7\xE3o 1mg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
In\xEDcio com 0,4-1 mg/Kg/h at\xE9 o m\xE1ximo de 3 mg/Kg/h`,recomendado:!1,favorito:!1,ordem:5},{id:"367b1e4a-8afe-4add-8b6c-8fdd8eeb7170",descr:`Labetalol (5mg/mL) 100 mL + SG 5% 150 mL (solu\xE7\xE3o 2mg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
In\xEDcio com 0,4-1 mg/Kg/h at\xE9 o m\xE1ximo de 3 mg/Kg/h`,recomendado:!1,favorito:!1,ordem:6},{id:"c22a52da-5e93-46a4-8f9c-f1ab455cb9b3",descr:"Hidralazina (20mg/mL) 10-20 mg IV ou IM 4/6h",recomendado:!1,favorito:!1,ordem:7},{id:"ea951a46-183b-4c4e-aede-fa300183b402",descr:`Nicardipina (2,5mg/mL) 10 mL + SG 5% 240 mL (solu\xE7\xE3o 0,1mg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico \r
Iniciar 5 mg/h (50 mL/h) com aumentos de 2,5 mg/h (25 mL/h) a cada 5-15 min, at\xE9 15 mg/h (150 mL/h)`,recomendado:!1,favorito:!1,ordem:8}],ordem:1}],academico:"Reduzir a PA em at\xE9 25% na primeira hora; a 160 x 100-110 mmHg em 2-6 horas; a 135 x 85 mmHg em 24-48 horas",ordem:2},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"4a7ffd4d-546e-47d0-93a8-a369cbb44e9c",opcoes:[{id:"c24c32a7-eebc-44fb-9818-a39507c098e2",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antit\xE9rmico",idGrupo:"34713da2-5216-4a93-bc72-f9f17947c224",opcoes:[{id:"5ddd5b73-9059-4527-8ee3-f4d273f58427",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"f480c9c6-9caa-4802-9e59-ac22feedd01d",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"5c39149a-9a47-4d42-b2ff-dd12bbbe5884",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:3},{item:"INIBIDOR DE BOMBA DE PR\xD3TON",grupos:[{grupo:"Analg\xE9sico",idGrupo:"d4c73d56-8233-4e02-8049-dabc16546022",opcoes:[{id:"e4538399-510f-44be-b3ed-843febefd18a",descr:"Esomeprazol (40mg/frasco) 20 mg IV 1x/dia pela manh\xE3 (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"844f0f19-284f-4ead-b2a6-6b9564f6f828",descr:"Omeprazol (40mg/10mL) 20-40 mg IV 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Profilaxia de les\xE3o aguda de mucosa g\xE1strica.",ordem:4},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"befc9aad-51c6-4034-97cb-55ccdfb5f024",opcoes:[{id:"ccf86279-30bb-4d19-bcd1-33215cf28b49",descr:"Balan\xE7o H\xEDdrico 4/4h",recomendado:!0,favorito:!0,ordem:1},{id:"5f0d4e47-cadc-4e92-b8a1-5c57787f6568",descr:"Monitoriza\xE7\xE3o Card\xEDaca Cont\xEDnua + oximetria de pulso",recomendado:!1,favorito:!1,ordem:2},{id:"6eeca078-fcdd-4958-b39c-7886e0878762",descr:"Manter cabeceira elevada a 30-45o",recomendado:!1,favorito:!1,ordem:3},{id:"c1d92eaa-ec3b-4e97-8c12-11dfa20abfc3",descr:"Acesso Venoso perif\xE9rico salinizado",recomendado:!1,favorito:!1,ordem:4},{id:"19bea310-66de-451c-9128-39ad99a3d087",descr:"O2 sob m\xE1scara a crit\xE9rio m\xE9dico",recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:5}],conceitosPraticos:[{conceito:"Consiste na eleva\xE7\xE3o aguda da press\xE3o arterial > 180 x 120 mmHg associada com les\xE3o aguda de \xF3rg\xE3o-alvo, sendo idealmente tratada em ambiente de terapia intensiva.",ordem:1},{conceito:"A Encefalopatia Hipertensiva tem um quadro geralmente insidioso de cefaleia, n\xE1usea e v\xF4mito, seguido de confus\xE3o mental, agita\xE7\xE3o psicomotora e eventualmente at\xE9 convuls\xE3o.",ordem:2},{conceito:"Alvos press\xF3ricos: Reduzir a PA em at\xE9 25% na primeira hora; a 160 x 100-110 mmHg em 2-6 horas; a 135 x 85 mmHg em 24-48 horas.",ordem:3},{conceito:"Ap\xF3s estabiliza\xE7\xE3o press\xF3rica: (1) retornar esquema anti-hipertensivo pr\xE9vio, aumentando dose ou acrescentando novo agente; (2) em pacientessem tratamento pr\xE9vio, iniciar drogas de 1a linha (tiazidico, bloqueador de canal de c\xE1lcio, IECA, BRA-II).",ordem:4}]},{id:"a6a3bf58-a68b-4381-869c-745ce07214aa",nome:"Urg\xEAncia Hipertensiva",favorito:!1,ordem:3,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e81deda9-4b32-484e-92db-7177632f42fe",opcoes:[{id:"5fa7bbd4-95d7-40d9-8dbd-750c84cc3579",descr:"Dieta oral zero (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"1b9258fc-8477-483a-b56a-a65a627842ee",descr:"Dieta hiposs\xF3dica",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Progredir ap\xF3s estabiliza\xE7\xE3o press\xF3rica",ordem:1},{item:"ANTI-HIPERTENSIVO VO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"bc93d7de-7176-4743-9240-49d079eb3ac7",opcoes:[{id:"e51f7162-f2a2-408f-aeec-9d34cec0521b",descr:"Clonidina (0,1-0,2mg/comp) 0,2 mg VO agora (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"60854ddb-53ef-49da-b45a-f9bb6b8e63e9",descr:"Captopril (12,5-50mg/comp) 6,25-12,5 mg VO agora",recomendado:!1,favorito:!1,ordem:2},{id:"2e9b3d7e-cda4-41a7-a4a3-5b40f6ad59e0",descr:"Hidralazina  (25-50mg/comp) 25 mg VO agora",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Buscar PA \u2264 160 x 100 mmHg.",ordem:2},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b9ba9d47-89ca-403a-8bd7-639adf2db2e0",opcoes:[{id:"5b3a132a-915b-4667-adfe-1949ade1d90c",descr:"Paracetamol (500-750mg/comp) 750-1000 mg VO em caso de dor ou febre, at\xE9 6/6h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"5b26efcd-0b29-442f-b78f-2794e205d318",descr:"Dipirona (500-1000mg/comp) 500-1000 mg VO em caso de dor ou febre, at\xE9 6/6h",recomendado:!1,favorito:!1,ordem:2}],ordem:1},{grupo:"Antit\xE9rmico",idGrupo:"939e1aba-fb70-4b80-8071-29e964deaf57",opcoes:[{id:"f8f854e4-ff44-46ea-92a8-24dbecfec3f4",descr:"Metoclopramida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"e99f11d8-ea47-4a15-96b3-43703b39b379",descr:"Bromoprida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"a613f038-8f81-495d-9bb2-0c2f0ff999bd",descr:"Ondansetrona (4-8mg/comp) 4-8 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:3},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"faa49ca1-4477-4ca0-94b0-41768d2c6f78",opcoes:[{id:"99e4635c-7658-4aa8-a504-b01baa3a039f",descr:"Balan\xE7o H\xEDdrico 4/4h",recomendado:!0,favorito:!0,ordem:1},{id:"19b2fef0-89e1-4265-aed7-f3391c52691a",descr:"Monitoriza\xE7\xE3o Card\xEDaca Cont\xEDnua",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:4}],conceitosPraticos:[{conceito:"Consiste na eleva\xE7\xE3o aguda da press\xE3o arterial > 180 x 120 mmHg, mas sem les\xE3o aguda de \xF3rg\xE3o-alvo.",ordem:1},{conceito:"Pacientes de maior risco (aneurisma cerebral/a\xF3rtico, coronariopatia, DM de longa data, AVE pr\xE9vio) ficam em observa\xE7\xE3o breve para acompanhar redu\xE7\xE3o press\xF3rica.",ordem:2},{conceito:"Alvos press\xF3ricos: PA \u2264 160 x 100 mmHg, com redu\xE7\xE3o de at\xE9 25% da PA nas primeiras horas.",ordem:3},{conceito:"Nifedipina sublingual \xE9 contraindicada.",ordem:4},{conceito:"Ap\xF3s estabiliza\xE7\xE3o press\xF3rica: (1) retornar esquema anti-hipertensivo pr\xE9vio, aumentando dose ou acrescentando novo agente; (2) em pacientessem tratamento pr\xE9vio, iniciar drogas de 1a linha (tiazidico, bloqueador de canal de c\xE1lcio, IECA, BRA-II).",ordem:5}]},{id:"b61b925f-f016-435d-a3f0-5fa9011124b2",nome:"Pseudocrise Hipertensiva",favorito:!1,ordem:4,secoes:[{item:"ANALGESIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"9e1ac578-99e2-4244-a537-8f736acf0db1",opcoes:[{id:"fc83e6a2-ce30-4ef8-9651-49503ae68dd0",descr:"Paracetamol (500-750mg/comp) 750-1000 mg VO agora (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"09f7a696-6844-4fc7-9747-afb47eba7845",descr:"Dipirona (500-1000mg/comp) 500-1000 mg VO agora",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Prescrever se o fator desencadeante for uma queixa \xE1lgica.",ordem:1},{item:"ANSIOL\xCDTICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"37fe3fc3-be86-4465-b31e-39fd5ca53f87",opcoes:[{id:"a5014251-8f85-4089-9f54-a2025b1a2666",descr:"Diazepam (5mg/comp) 5-10 mg VO agora (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"9e2cc012-2c05-450a-920f-247daf2a800a",descr:"Clonazepam (0,5-2mg/comp ou 2,5mg/mL) 0,5-2 mg VO agora",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Prescrever se o fator desencadeante for ansiedade ou eventos emocionais.",ordem:2}],conceitosPraticos:[{conceito:"Consiste na eleva\xE7\xE3o transit\xF3ria da PA em pacientes cronicamente hipertensos \u2013 geralmente em tratamento irregular \u2013 desencadeada por dor, ansiedade, eventos emocionais ou mesmo suspens\xE3o da terapia medicamentosa, por\xE9m a n\xEDveis ainda inferiores a 180 x 120 mmHg.",ordem:1},{conceito:"Reconhecer fator desencadeante e instituir tratamento adequado (analg\xE9sico, ansiol\xEDtico).",ordem:2}]}],topicos:[{titulo:"Hipertens\xE3o - Crise Hipertensiva",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">Crise Hipertensiva \xE9 definida pela eleva\xE7\xE3o severa da press\xE3o arterial (PA) a n\xEDveis \u2265 180 x 120 mmHg e corresponde a 0,45-0,59% de todos os atendimentos de emerg\xEAncia hospitalar. Nesse cen\xE1rio, existem 2 espectros que precisam ser diferenciados: Emerg\xEAncia Hipertensiva e Urg\xEAncia Hipertensiva. E o que seria a Pseudocrise Hipertensiva?</span>
</p><p>
  <strong>- Emerg\xEAncia Hipertensiva \u2013</strong>
  <span style="font-weight: 400;">Ocorre quando essa eleva\xE7\xE3o press\xF3rica \xE9 acompanhada de uma les\xE3o cardiovascular aguda \u2013 chamada de \u201Cles\xE3o aguda de \xF3rg\xE3o-alvo\u201D, com consequente risco iminente de \xF3bito. S\xE3o exemplos: Encefalopatia Hipertensiva, Hipertens\xE3o Acelerada Maligna, Dissec\xE7\xE3o Aguda de Aorta, Infarto Agudo do Mioc\xE1rdio (IAM), Acidente Vascular Encef\xE1lico - AVE (Isqu\xEAmico ou Hemorr\xE1gico), Insufici\xEAncia Card\xEDaca com Edema Agudo de Pulm\xE3o e Ecl\xE2mpsia.</span>
</p><p>
  <span style="font-weight: 400;">Ou seja, s\xE3o situa\xE7\xF5es em que, caso a PA n\xE3o seja controlada imediatamente, o desfecho do paciente pode ser fatal, seja porque a hipertens\xE3o sobrecarrega mioc\xE1rdio, vasculatura pulmonar e vasos uteroplacent\xE1rios, ou promove a propaga\xE7\xE3o de uma dissec\xE7\xE3o de aorta at\xE9 sua ruptura, ou aumenta o sangramento de um AVE hemorr\xE1gico e assim por diante. Que seja... O que precisa estar claro \xE9 que a manuten\xE7\xE3o dos n\xEDveis tensionais demasiadamente elevados n\xE3o deve ser permitida, de modo que se faz necess\xE1ria uma</span>
  <strong>redu\xE7\xE3o imediata da PA, o que ser\xE1 feito com drogas parenterais</strong>
  <span style="font-weight: 400;">.</span>
</p><p>
  <strong>- Urg\xEAncia Hipertensiva \u2013</strong>
  <span style="font-weight: 400;">Nesse caso, n\xE3o h\xE1 evid\xEAncias cl\xEDnicas ou laboratoriais de les\xE3o aguda de \xF3rg\xE3o-alvo acompanhando essa eleva\xE7\xE3o press\xF3rica e, portanto, tamb\xE9m n\xE3o h\xE1 risco iminente de morte, de forma que a redu\xE7\xE3o da PA poder\xE1 ser feita em 24-48h.</span>
</p><p>
  <strong>- Pseudocrise Hipertensiva \u2013</strong>
  <span style="font-weight: 400;">\xC9 a percep\xE7\xE3o da PA elevada a n\xEDveis que n\xE3o ultrapassam 180 x 120 mmHg e ainda acompanhada de cefaleia, dor tor\xE1cica at\xEDpica, dispneia, estresse psicol\xF3gico e s\xEDndrome do p\xE2nico, mas naturalmente sem les\xE3o aguda de \xF3rg\xE3o-alvo. Ou seja, \xE9 o dia-a-dia de um Plant\xE3o M\xE9dico.</span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/4157b8ae-76e2-422f-befb-6e9c8f243e2d.jpg" alt="" width="100%" height="auto">
  </span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">Naturalmente, a confirma\xE7\xE3o de uma Crise Hipertensiva requer a mensura\xE7\xE3o press\xF3rica em um ambiente calmo e, no caso da Emerg\xEAncia Hipertensiva, a comprova\xE7\xE3o da les\xE3o aguda de \xF3rg\xE3o-alvo. Assim, podem ser necess\xE1rios alguns exames adicionais:</span>
</p><p>
  <span style="font-weight: 400;">- Encefalopatia Hipertensiva (quadro geralmente insidioso de cefaleia, n\xE1usea e v\xF4mito, seguido de confus\xE3o mental, agita\xE7\xE3o psicomotora e eventualmente at\xE9 convuls\xE3o): neuroimagem (Tomografia Computadorizada ou Resson\xE2ncia Nuclear Magn\xE9tica de Cr\xE2nio sem contraste) para exclus\xE3o de AVE e fundo de olho pela frequente concomit\xE2ncia com Hipertens\xE3o Acelerada Maligna.</span>
</p><p>
  <span style="font-weight: 400;">- Hipertens\xE3o Acelerada Maligna (definida pela retinopatia hipertensiva grau III, caracterizada por hemorragia ou exsudato retiniano, ou grau IV, que consiste no papiledema): fundo de olho e, como \xE9 comum a ocorr\xEAncia de acometimento renal concomitante, devemos solicitar tamb\xE9m avalia\xE7\xE3o da fun\xE7\xE3o renal (ureia e creatinina s\xE9ricas) e EAS (urina tipo I, sum\xE1rio de urina e parcial de urina s\xE3o sin\xF4nimos).</span>
</p><p>
  <span style="font-weight: 400;">- Dissec\xE7\xE3o Aguda de Aorta: imagem (ecocardiograma transesof\xE1gico, angiotomografia ou angiorresson\xE2ncia da aorta), mas a mesma n\xE3o pode atrasar o tratamento, que deve ser iniciado na suspeita diagn\xF3stica pela pr\xF3pria manifesta\xE7\xE3o cl\xEDnica (dor tor\xE1cica s\xFAbita e com irradia\xE7\xE3o para o dorso, associada a sopro de insufici\xEAncia a\xF3rtica ou diferen\xE7a de PA entre membros superiores).</span>
</p><p>
  <span style="font-weight: 400;">- Infarto Agudo do Mioc\xE1rdio: Eletrocardiograma e enzimas card\xEDacas.</span>
</p><p>
  <span style="font-weight: 400;">- Acidente Vascular Encef\xE1lico: neuroimagem (Tomografia Computadorizada ou Resson\xE2ncia Nuclear Magn\xE9tica de Cr\xE2nio sem contraste).</span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">A percep\xE7\xE3o de uma PA elevada em um Plant\xE3o M\xE9dico \xE9 algo corriqueiro, de modo que precisamos sistematizar a abordagem deste tipo de paciente. Alguns questionamentos devem ser respondidos, tais como: (1) Quando \xE9 necess\xE1rio internar o paciente hipertenso? (2) Havendo necessidade de interna\xE7\xE3o, como deve ser feita a redu\xE7\xE3o press\xF3rica: com que tipo de f\xE1rmaco e com que ritmo? (3) Como orientar o paciente que n\xE3o precisa ser internado?</span>
</p><p>
  <strong>- Emerg\xEAncia Hipertensiva \u2013</strong>
  <span style="font-weight: 400;">Na Emerg\xEAncia Hipertensiva, a redu\xE7\xE3o press\xF3rica \u2013 preferencialmente em ambiente de terapia intensiva \u2013 tem que ser iniciada de imediato com drogas intravenosas, por\xE9m n\xE3o pode ocorrer uma diminui\xE7\xE3o intensa da PA em um curto espa\xE7o de tempo sob o risco de reduzir bruscamente o fluxo arterial para territ\xF3rios nobres, como coron\xE1ria, vasos cerebrais e circula\xE7\xE3o renal.</span>
</p><p>
  <span style="font-weight: 400;">De qualquer forma, em pacientes com condi\xE7\xF5es dram\xE1ticas (dissec\xE7\xE3o a\xF3rtica, edema agudo de pulm\xE3o, crise de feocromocitoma), a PA sist\xF3lica deve ser reduzida a n\xEDveis &lt; 140 mmHg na 1\xAA hora e, na dissec\xE7\xE3o a\xF3rtica, busca-se at\xE9 mesmo \u2264 120 mmHg se poss\xEDvel em 20 minutos e acompanhada de uma redu\xE7\xE3o da frequ\xEAncia card\xEDaca a &lt; 60 bpm. \xC9 interessante citar que o mais adequado na dissec\xE7\xE3o \xE9 reduzir primeiro a frequ\xEAncia card\xEDaca, uma vez que isso j\xE1 pode permitir uma diminui\xE7\xE3o press\xF3rica e, se inicialmente fosse reduzida a press\xE3o arterial, tal estrat\xE9gia poderia provocar um reflexo simp\xE1tico com aumentos da for\xE7a de contra\xE7\xE3o ventricular e da frequ\xEAncia card\xEDaca, intensificando o estresse na parede a\xF3rtica.</span>
</p><p>
  <span style="font-weight: 400;">Nos adultos sem as condi\xE7\xF5es dram\xE1ticas supracitadas, o que se busca como alvo press\xF3rico, de um modo geral, \xE9:</span>
</p><p>
  <strong>(1) Redu\xE7\xE3o de at\xE9 25% da PA m\xE9dia na 1\xAA hora;&nbsp;</strong>
</p><p>
  <strong>(2) 160 x 100 mmHg nas pr\xF3ximas 2-6h</strong>
</p><p>
  <strong>(3) 135 x 85 mmHg</strong>
  <span style="font-weight: 400;">(valores normais)</span>
  <strong>em um per\xEDodo de 24-48h subsequentes</strong>
</p><p>
  <span style="font-weight: 400;">A partir da\xED, iniciam-se drogas anti-hipertensivas por via oral, permitindo uma redu\xE7\xE3o gradual da droga parenteral at\xE9 a sua suspens\xE3o</span>
</p><p>
  <span style="font-weight: 400;">Mas</span>
  <strong>aten\xE7\xE3o</strong>
  <span style="font-weight: 400;">: existem algumas situa\xE7\xF5es de Emerg\xEAncia Hipertensiva que merecem destaque com rela\xE7\xE3o a particularidades terap\xEAuticas no controle da PA, n\xE3o seguindo os alvos descritos acima...&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">\xC9 o caso, por exemplo, do Acidente Vascular Encef\xE1lico, em que, no tipo isqu\xEAmico, a press\xE3o s\xF3 ser\xE1 reduzida se ultrapassar 220 x 120 mmHg nos pacientes n\xE3o candidatos \xE0 tromb\xF3lise ou 185 x 110 mmHg naqueles que ser\xE3o submetidos \xE0 terapia trombol\xEDtica, enquanto, no tipo hemorr\xE1gico por Hemorragia Intraparenquimatosa, busca-se, em geral, uma redu\xE7\xE3o da PA sist\xF3lica, mas que n\xE3o deve ser inferior a 140 mmHg.</span>
</p><p>
  <strong>- Urg\xEAncia Hipertensiva \u2013</strong>
  <span style="font-weight: 400;">Como n\xE3o h\xE1 les\xE3o aguda de \xF3rg\xE3o, tamb\xE9m n\xE3o h\xE1 necessidade de redu\xE7\xE3o press\xF3rica imediata, de forma que o paciente deve receber anti-hipertensivos por via oral para que a diminui\xE7\xE3o da press\xE3o ocorra ao longo das pr\xF3ximas horas ou dias a valores \u2264 160 x 100 mmHg. Nos pacientes com maior risco cardiovascular (aneurisma cerebral ou a\xF3rtico, coronariopatia, diabetes de longa data, AVE pr\xE9vio), \xE9 mais prudente que a redu\xE7\xE3o da PA se d\xEA em quest\xE3o de horas atrav\xE9s do uso de drogas de a\xE7\xE3o mais r\xE1pida, como captopril, clonidina e hidralazina. Em seguida, o doente \xE9 liberado para casa para acompanhamento hipertensivo ambulatorial. Nos casos de risco mais baixo, a manuten\xE7\xE3o no hospital n\xE3o \xE9 necess\xE1ria: bastaria a restitui\xE7\xE3o ou intensifica\xE7\xE3o do tratamento anti-hipertensivo de base, liberando o paciente para revis\xE3o ambulatorial em at\xE9 7 dias (idealmente em 24-48 horas) para verificar a resposta \xE0 medica\xE7\xE3o prescrita e avaliar a necessidade de ajuste de seu tratamento cr\xF4nico.&nbsp;&nbsp;</span>
</p><p>
  <strong>- Pseudocrise Hipertensiva \u2013</strong>
  <span style="font-weight: 400;">Tamb\xE9m n\xE3o h\xE1 indica\xE7\xE3o formal de manuten\xE7\xE3o do paciente no Plant\xE3o para normaliza\xE7\xE3o da PA. Na realidade, devemos realizar o tratamento sintom\xE1tico do evento que o levou a procurar atendimento m\xE9dico, como dor (analg\xE9sico) e ansiedade (ansiol\xEDtico) \u2013 o que, por si s\xF3, j\xE1 desencadeia alguma redu\xE7\xE3o da PA \u2013 e orientar sobre a import\xE2ncia do acompanhamento com cl\xEDnico ou cardiologista e da ades\xE3o ao tratamento anti-hipertensivo.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Intoxica\xE7\xE3o por Nitroprussiato \u2013</strong>
  <span style="font-weight: 400;">O nitroprussiato \xE9 metabolizado em cianeto, havendo risco de desenvolvimento de intoxica\xE7\xE3o por esta subst\xE2ncia (ou mais raramente pelo tiocianato), que se manifesta com altera\xE7\xE3o do estado mental e acidose l\xE1ctica. Para prevenir esta complica\xE7\xE3o, a infus\xE3o deve ser feita por tempo curto (idealmente, n\xE3o ultrapassar 2-3 dias), sem utilizar doses elevadas e com frasco e equipo protegidos da luz, uma vez que o nitroprussiato \xE9 decomposto com a exposi\xE7\xE3o a um foco luminoso. O tratamento da intoxica\xE7\xE3o pode ser feito com hidroxicobalamina (5 g ou 70 mg/Kg IV), nitrito de s\xF3dio (300 mg ou 10 mg/Kg IV \u2013 dose deve ser ajustada para pacientes portadores de anemia) e tiossulfato de s\xF3dio (12,5 g - equivalentes a 50 mL de uma solu\xE7\xE3o de tiossulfato a 25%).</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Quando a infus\xE3o de nitroprussiato chega a \u2265 4 mcg/Kg/min ou se estende por &gt; 30 minutos, pode-se administrar simultaneamente tiossulfato de s\xF3dio como estrat\xE9gia de preven\xE7\xE3o de intoxica\xE7\xE3o por cianeto, geralmente com a rela\xE7\xE3o de 10 partes de nitroprussiato para 1 parte de tiossulfato.</span>
  </em>
</p><p>
  <strong>- Prescrever Nitroprussiato para toda Emerg\xEAncia Hipertensiva -</strong>
  <span style="font-weight: 400;">De fato, o nitroprussiato \xE9 o anti-hipertensivo parenteral mais usado na maioria das Emerg\xEAncias Hipertensivas, por\xE9m n\xE3o \xE9 o de escolha em todas \u2013 classicamente no IAM e na Ecl\xE2mpsia, por exemplo, a prefer\xEAncia \xE9 por nitroglicerina e hidralazina, respectivamente.</span>
</p><p>
  <strong>- Reduzir exageradamente a PA -</strong>
  <span style="font-weight: 400;">Como refor\xE7ado anteriormente, a r\xE1pida e intensa redu\xE7\xE3o da PA pode comprometer a perfus\xE3o de territ\xF3rios nobres, como cora\xE7\xE3o, c\xE9rebro e rim, o que \xE9 mais comum de ocorrer com drogas intravenosas. Nesses casos, basta reduzir a velocidade da infus\xE3o cont\xEDnua ou mesmo suspend\xEA-la por alguns instantes e aguardar o reajuste da PA.</span>
</p><p>
  <strong>- Utilizar droga sublingual na Urg\xEAncia Hipertensiva -</strong>
  <span style="font-weight: 400;">Essa \xE9 uma armadilha onde muitos caem! N\xE3o h\xE1 comprova\xE7\xE3o de que a administra\xE7\xE3o de droga anti-hipertensiva por via sublingual (SL) tenha maior benef\xEDcio do que por via oral (VO), por isso n\xE3o h\xE1 necessidade de encorajar o seu uso. Inclusive, para a nifedipina, h\xE1 at\xE9 contraindica\xE7\xE3o: o uso sublingual pode causar brusca redu\xE7\xE3o press\xF3rica, com preju\xEDzo \xE0 perfus\xE3o org\xE2nica.</span>
</p><p>
  <strong>- N\xE3o deixar o paciente em repouso -</strong>
  <span style="font-weight: 400;">Pode parecer bobagem, mas retirar o paciente do ambiente confuso de um Plant\xE3o M\xE9dico para coloc\xE1-lo em local calmo para repouso j\xE1 \xE9 suficiente para provocar uma redu\xE7\xE3o press\xF3rica de at\xE9 20 mmHg em alguns pacientes e deve fazer parte da abordagem de uma Crise Hipertensiva.</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<ol>
  <ol>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Barroso WKS, Rodrigues CIS, Bortolotto LA, Mota-Gomes MA, Brand\xE3o AA, Feitosa ADM, et al. Diretrizes Brasileiras de Hipertens\xE3o Arterial \u2013 2020.</span>
      <em>
        <span style="font-weight: 400;">Arq Bras Cardiol</span>
      </em>
      <span style="font-weight: 400;">2021; 116(3):516-658</span>
    </li>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Vilela-Martin JF, Yugar-Toledo JC, Rodrigues MC, Barroso WKS, Carvalho LCBS, Gonz\xE1lez FJT et al. Posicionamento Luso-Brasileiro de Emerg\xEAncias Hipertensivas \u2013 2020.</span>
      <em>
        <span style="font-weight: 400;">Arq Bras Cardiol</span>
      </em>
      <span style="font-weight: 400;">2020; 114(4):736-751</span>
    </li>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Unger T, Borghi C, Charchar F, Khan NA, Poulter NR, et al. 2020 International Society of Hypertension Global Hypertension Practice Guidelines.</span>
      <em>
        <span style="font-weight: 400;">Hypertension</span>
      </em>
      <span style="font-weight: 400;">2020; 75:1334-1357.</span>
    </li>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Whelton PK, Carey RM, Aronow WS, Casey DE Jr, Collins KJ, Dennison Himmelfarb C, DePalma SM, Gidding S, Jamerson KA, Jones DW, MacLaughlin EJ, Muntner P, Ovbiagele B, Smith SC Jr, Spencer CC, Stafford RS, Taler SJ, Thomas RJ, Williams KA Sr, Williamson JD, Wright JT Jr. 2017 ACC/AHA/AAPA/ABC/ACPM/AGS/APhA/ASH/ASPC/NMA/PCNA guideline for the prevention, detection, evaluation, and management of high blood pressure in adults: a report of the American College of Cardiology/American Heart Association Task Force on Clinical Practice Guidelines.</span>
      <em>
        <span style="font-weight: 400;">Hypertension</span>
      </em>
      <span style="font-weight: 400;">. 2018;71:e13\u2013e115</span>
    </li>
  </ol>
</ol><ol>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Barroso WKS, Rodrigues CIS, Bortolotto LA, Mota-Gomes MA, Brand\xE3o AA, Feitosa ADM, et al. Diretrizes Brasileiras de Hipertens\xE3o Arterial \u2013 2020.</span>
      <em>
        <span style="font-weight: 400;">Arq Bras Cardiol</span>
      </em>
      <span style="font-weight: 400;">2021; 116(3):516-658</span>
    </li>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Vilela-Martin JF, Yugar-Toledo JC, Rodrigues MC, Barroso WKS, Carvalho LCBS, Gonz\xE1lez FJT et al. Posicionamento Luso-Brasileiro de Emerg\xEAncias Hipertensivas \u2013 2020.</span>
      <em>
        <span style="font-weight: 400;">Arq Bras Cardiol</span>
      </em>
      <span style="font-weight: 400;">2020; 114(4):736-751</span>
    </li>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Unger T, Borghi C, Charchar F, Khan NA, Poulter NR, et al. 2020 International Society of Hypertension Global Hypertension Practice Guidelines.</span>
      <em>
        <span style="font-weight: 400;">Hypertension</span>
      </em>
      <span style="font-weight: 400;">2020; 75:1334-1357.</span>
    </li>
    <li style="font-weight: 400;" aria-level="1">
      <span style="font-weight: 400;">Whelton PK, Carey RM, Aronow WS, Casey DE Jr, Collins KJ, Dennison Himmelfarb C, DePalma SM, Gidding S, Jamerson KA, Jones DW, MacLaughlin EJ, Muntner P, Ovbiagele B, Smith SC Jr, Spencer CC, Stafford RS, Taler SJ, Thomas RJ, Williams KA Sr, Williamson JD, Wright JT Jr. 2017 ACC/AHA/AAPA/ABC/ACPM/AGS/APhA/ASH/ASPC/NMA/PCNA guideline for the prevention, detection, evaluation, and management of high blood pressure in adults: a report of the American College of Cardiology/American Heart Association Task Force on Clinical Practice Guidelines.</span>
      <em>
        <span style="font-weight: 400;">Hypertension</span>
      </em>
      <span style="font-weight: 400;">. 2018;71:e13\u2013e115</span>
    </li>
  </ol><ul>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Malachias MVB, Souza WKSB, Plavnik FL, Rodrigues CIS, Brand\xE3o AA, Neves MFT, et al. 7\xAA Diretriz Brasileira de Hipertens\xE3o Arterial. Arq Bras Cardiol 2016; 107(3Supl.3):1-83</span>
  </li>
</ul><ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">James PA, Oparil S, Carter BL, et al. 2014 Evidence-Based Guideline for the Management of High Blood Pressure in Adults: Report from the Panel Members Appointed to the Eighth Joint National Committee (JNC 8).&nbsp;</span>
    <span style="font-weight: 400;">Jama</span>
    <span style="font-weight: 400;">&nbsp;2014, 311(5): 507-520.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Williams B, Mancia G, Spiering W, Rosei EA, Azizi M, et al. 2018 ESC/ESH Guidelines for the management of arterial hypertension,</span>
    <em>
      <span style="font-weight: 400;">European Heart Journal</span>
    </em>
    <span style="font-weight: 400;">2018; 39:3021\u20133104</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Chobanian AV, Bakris GL, Black, HR, et al. The Seventh Report of the Joint National Committee on Prevention, Detection, Evaluation, and Treatment of High Blood Pressure: the JNC 7 Report.&nbsp;</span>
    <span style="font-weight: 400;">Jama 2003</span>
    <span style="font-weight: 400;">,&nbsp;</span>
    <span style="font-weight: 400;">289</span>
    <span style="font-weight: 400;">(19): 2560-2571.</span>
  </li>
</ol><p>
  <span style="font-weight: 400;">Erbel R, Aboyans V, Boileau C, et al.</span>
  <span style="font-weight: 400;">2014 ESC Guidelines on the diagnosis and treatment of aortic diseases:</span>
  <span style="font-weight: 400;">Document covering acute and chronic aortic diseases of the thoracic and abdominal aorta of the adult. The Task Force for the Diagnosis and Treatment of Aortic Diseases of the European Society of Cardiology (ESC).&nbsp;</span>
  <span style="font-weight: 400;">European Heart Journal 2014,</span>
  <span style="font-weight: 400;">35: 2873-2926.</span>
</p>`,ordem:6}],videos:[{id:"c6864a9c-cae3-43e1-b323-7d5769a45c22",titulo:"T\xEDtulo  para Hipertens\xE3o - Crise Hipertensiva",duracao:10,thumbUrl:"https://i.vimeocdn.com/video/716647964_1920x1273.jpg?r=pad"}],fluxogramas:[{id:"474f6556-6936-48be-8c9e-0999d214c431",nome:"Fluxograma da Hipertens\xE3o - Crise Hipertensiva",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/17e29c7d-121c-4928-ab65-2093343e8ad2.jpg",orientacao:"vertical"},{id:"51141328-5486-4e36-9109-304f54ecac7c",nome:"Fluxograma da Hipertens\xE3o - Crise Hipertensiva",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/f0756cb7-793d-4884-89a8-cd49fa8d5ec4.jpg",orientacao:"horizontal"}],tags:["HAS","Hipertens\xE3o","Encefalopatia Hipertensiva","Dissec\xE7\xE3o Aguda de Aorta","Aorta","Urg\xEAncia Hipertensiva","Emerg\xEAncia Hipertensiva","Pseudocrise Hipertensiva","Crise"]},{id:"75f495e4-eda5-4363-bda1-404befca5a41",nome:"Hipertireoidismo",categoria:2,termosDeBusca:"hipertireoidismo, tireotoxicose, tireoide",favoritado:!1,ordem:0,especialidades:[{nome:"ENDOCRINOLOGIA"}],prescricoes:[{id:"7db74b74-e56f-4198-9cda-94b5058876ea",nome:"Hipertireoidismo",favorito:!0,ordem:1,secoes:[{item:"BETA-BLOQUEADOR",grupos:[{grupo:"Beta-bloquador",idGrupo:"10643558-e7e8-4855-91b5-32d1c42039a5",opcoes:[{id:"5c8a2cc9-1440-493d-9e8f-7bb90a3d6eb7",descr:"Propranolol (10-80mg/cp) 10-40 mg VO 8/8h ou 6/6h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"b5727bde-692e-4abd-82f6-65da91dadec2",descr:"Atenolol (25-100mg/cp) 25-100 mg VO 1x/dia ou 12/12h",recomendado:!1,favorito:!1,ordem:2},{id:"b49c5a09-a941-4b00-a733-40c4390b0ead",descr:"Metoprolol, succinato (25-100mg/cp) 25-50 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:3},{id:"e276d5a8-b011-4d85-bcd2-acc05b6650f1",descr:`Nadolol (20-80mg/cp) 40-160mg VO 1x/dia\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Controle de sintomas adren\xE9rgicos, como tremor e palpita\xE7\xE3o.",ordem:1},{item:"TIONAMIDAS",grupos:[{grupo:"Tionamidas",idGrupo:"3221953e-5215-4cab-ab50-83f47043a604",opcoes:[{id:"640ad032-462f-4da6-8474-9331bdb8ed6c",descr:`Metimazol (5-10mg/cp) 10-30 mg VO 1x/dia (MEDGRUPO)\r
Pode ser necess\xE1rio aumentar a dose para controle inicial do hipertireoidismo.\r
Posteriormente, tentar reduzir para a menor dose poss\xEDvel VO 1x/dia\r
N\xE3o utilizar no 1\xBA trimestre de gesta\xE7\xE3o`,recomendado:!0,favorito:!0,ordem:1},{id:"d82e4cfc-f821-439e-99cc-bf76d77d2fd7",descr:`Propiltiouracil (100mg/cp) 50-150 mg VO 8/8h\r
Pode ser necess\xE1rio aumentar a dose para controle inicial do hipertireoidismo.\r
Posteriormente, tentar reduzir para a menor dose poss\xEDvel VO 2-3x/dia`,recomendado:!1,favorito:!1,ordem:2},{id:"a1375220-0b65-4425-9a1d-8a7eb044a873",descr:`Carbimazol (5-20mg/cp) 10-20 mg VO 12/12h ou 8/8h\r
Posteriormente, tentar titular para 5-15 mg/dia\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Usar por 12-24 meses na doen\xE7a de Graves, com prefer\xEAncia por metimazol, exceto no 1\xBA trimestre da gesta\xE7\xE3o e na crise tireot\xF3xica.",ordem:2},{item:"ANTI-INFLAMAT\xD3RIO",grupos:[{grupo:"AINE",idGrupo:"6dbe743e-c412-4a63-978d-2a566d66cf86",opcoes:[{id:"1e77a1bc-c267-4cec-a563-98bc11156296",descr:"Naproxeno (250-500mg/cp) 250-500 mg VO 12/12h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"648c1fed-736b-48eb-949c-bf0e2d049591",descr:"Naproxeno (275-550mg/cp) 550 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:2},{id:"dd5de6ea-2bb1-4901-92b0-906d4d51283c",descr:"Ibuprofeno (200-600mg/cp) 400-800 mg VO 8/8h ou 6/6h",recomendado:!1,favorito:!1,ordem:3},{id:"102a181d-d859-421c-85e1-3478b9b7d62e",descr:`AAS (500mg/cp) 500-1000 mg VO a cada 4-8h\r
N\xE3o exceder 4 g/dia (8 comprimidos)`,recomendado:!1,favorito:!1,ordem:4},{id:"ba2ff455-f23c-428f-bf4f-044cd3fbae09",descr:"Prednisona (5-20mg/comp) 40 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Apenas para os quadros dolorosos de tireoidite subaguda, reservando prednisona se n\xE3o houver resposta com 2-3 dias de AINE/AAS.",ordem:3}],conceitosPraticos:[{conceito:"Hipertireoidismo: \u2193TSH / \u2191T4-livre e T3.",ordem:1},{conceito:"Alvo: normalizar T4-livre e T3",ordem:2},{conceito:"Monitoriza\xE7\xE3o laboratorial a cada 4-6 semanas.",ordem:3},{conceito:"Causa principal: doen\xE7a de Graves, que tem 3 op\xE7\xF5es de tratamento (tionamidas, radioiodo e tireoidectomia).",ordem:4},{conceito:"Beta-bloqueador indicado para sintomas de tireotoxicose.",ordem:5}]}],topicos:[{titulo:"Hipertireoidismo",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O hipertireoidismo consiste na maior atividade da tireoide, com consequente aumento da circula\xE7\xE3o de horm\xF4nio tireoidiano, situa\xE7\xE3o denominada de tireotoxicose. As principais causas de hipertireoidismo s\xE3o doen\xE7a de Graves (etiologia mais comum e que tem natureza autoimune), b\xF3cio multinodular t\xF3xico e adenoma t\xF3xico. J\xE1 a tireotoxicose pode ocorrer tamb\xE9m por situa\xE7\xF5es n\xE3o associadas ao hipertireoidismo, como tireoidites subagudas e exposi\xE7\xE3o a fonte hormonal n\xE3o tireoidiana, seja ex\xF3gena (chamada de tireotoxicose fact\xEDcia) ou end\xF3gena (</span>
  <em>
    <span style="font-weight: 400;">struma ovarii</span>
  </em>
  <span style="font-weight: 400;">, met\xE1stase de c\xE2ncer diferenciado de tireoide).</span>
</p>`,ordem:2},{titulo:"QUADRO CL\xCDNICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">As manifesta\xE7\xF5es principais incluem intoler\xE2ncia ao calor, ansiedade, palpita\xE7\xE3o (possibilidade de fibrila\xE7\xE3o atrial), tremor, perda de peso e b\xF3cio.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>
      <span style="font-weight: 400;">* Uma manifesta\xE7\xE3o mais rara \xE9 a paralisia peri\xF3dica tireot\xF3xica, caracterizada por uma fraqueza generalizada de instala\xE7\xE3o s\xFAbita e consci\xEAncia preservada com dura\xE7\xE3o t\xEDpica de algumas horas. Seu tratamento envolve reposi\xE7\xE3o de pot\xE1ssio - mesmo oral se o paciente tolerar (30 mEq a cada 2h at\xE9 apresentar melhora, com m\xE1ximo de 90 mEq em 24h) \u2013 j\xE1 que se entende ser um tipo de paralisia peri\xF3dica hipocal\xEAmica.</span>
    </em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Por fim, no caso particular da doen\xE7a de Graves, ainda existem manifesta\xE7\xF5es n\xE3o relacionadas ao n\xEDvel hormonal, como a oftalmopatia de Graves (mais comum em fumantes), a dermopatia infiltrativa (mixedema pr\xE9-tibial que se expressa como p\xE1pulas hiperpigmentadas com aspecto em casca de laranja) e a acropatia.</span>
</p>`,ordem:3},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O diagn\xF3stico de hipertireoidismo \xE9 necessariamente laboratorial e caracterizado por aumento de T3 e/ou do T4-livre associado \xE0 redu\xE7\xE3o do TSH.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>
      <span style="font-weight: 400;">* O hipertireoidismo subcl\xEDnico \xE9 definido por T3 e T4-livre normais associados \xE0 redu\xE7\xE3o do TSH, podendo ter as mesmas manifesta\xE7\xF5es j\xE1 citadas para o hipertireoidismo \u201Cfranco\u201D, por\xE9m geralmente mais leves.</span>
    </em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Ap\xF3s o diagn\xF3stico, torna-se imperativa a determina\xE7\xE3o da etiologia. Se houver algum achado espec\xEDfico (oftalmopatia, dermopatia ou acropatia), o diagn\xF3stico da doen\xE7a de Graves j\xE1 pode ser fechado. Caso contr\xE1rio, uma excelente op\xE7\xE3o \xE9 a dosagem do TRAb, que, se positivo, aponta para doen\xE7a de Graves. Outras op\xE7\xF5es s\xE3o a capta\xE7\xE3o de iodo radioativo (RAIU -</span>
  <em>
    <span style="font-weight: 400;">radioactive iodine uptake</span>
  </em>
  <span style="font-weight: 400;">) e a cintilografia, que demonstram aumento de atividade nas situa\xE7\xF5es de hipertireoidismo (em Graves difusamente e, nas doen\xE7as nodulares, restrita aos n\xF3dulos hiperfuncionantes) e baixa (ou ausente) nas tireoidites e na tireotoxicose fact\xEDcia. Por fim, nos pacientes sem n\xF3dulo ao exame f\xEDsico, a USG com doppler pode diferenciar doen\xE7a de Graves (fluxo aumentando) de tireoidites, sendo tamb\xE9m uma op\xE7\xE3o bem interessante nos casos em que a RAIU \xE9 contraindicada (gestante e lactante).</span>
</p>`,ordem:4},{titulo:"TRATAMENTO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">De modo geral, o uso de beta-bloqueadores \xE9 indicado para os sintomas da tireotoxicose. Os bloqueadores de canais de c\xE1lcio, verapamil e diltiazem, podem ser utilizados nos casos de contraindica\xE7\xE3o aos beta-bloqueadores. As demais estrat\xE9gias dependem da etiologia envolvida.</span>
</p><p style="text-align: justify;">
  <strong>Doen\xE7a de Graves</strong>
  <span style="font-weight: 400;">\u2013 As op\xE7\xF5es de tratamento s\xE3o: (1) drogas antitireoidianas (tionamidas): metimazol, propiltiouracil e carbimazol, este \xFAltimo indispon\xEDvel no Brasil; (2) abla\xE7\xE3o com</span>
  <span style="font-weight: 400;">131</span>
  <span style="font-weight: 400;">I; (3) tireoidectomia total.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A</span>
  <span style="font-weight: 400;">op\xE7\xE3o farmacol\xF3gica</span>
  <span style="font-weight: 400;">costuma ser a mais empregada, sendo utilizada por 12-24 meses \u2013 tempo em que a remiss\xE3o da disfun\xE7\xE3o autoimune ocorre em 30-50% das pessoas (ap\xF3s esse per\xEDodo a descontinua\xE7\xE3o da droga deve considerada). O metimazol \xE9 a droga de escolha por agir mais rapidamente, ter melhor posologia e menor incid\xEAncia de efeitos adversos, embora ainda possam ocorrer (os principais s\xE3o agranulocitose, hepatotoxicidade e vasculite). Embora existam estrat\xE9gias que se baseiem no valor dos horm\xF4nios tireoidianos, a dose inicial do metimazol recomendada costuma ser de 10-30 mg/dia. O propiltiouracil, com dose inicial de 50-150 mg 3x/dia, \xE9 preferido em duas situa\xE7\xF5es: (1) no 1\xBA trimestre de gesta\xE7\xE3o pelos maiores efeitos teratog\xEAnicos do metimazol; e (2) nos casos de crise tireot\xF3xica, uma vez que possui efeito adicional de inibir a convers\xE3o perif\xE9rica de T4 em T3.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O monitoramento da fun\xE7\xE3o tireoidiana n\xE3o deve ser feito com TSH (pode permanecer suprimido por meses), mas sim com T4-livre e T3 total a cada 4-6 semanas com ajustes individuais de dose. Ap\xF3s o controle bioqu\xEDmico, a dose do medicamento deve ser reduzida gradualmente at\xE9 que se obtenha a menor dose que mantenha os pacientes eutire\xF3ideos. A partir da\xED, as avalia\xE7\xF5es passam a ser trimestrais. Com a suspens\xE3o do tratamento ap\xF3s a remiss\xE3o (12-24 meses), a fun\xE7\xE3o tireoidiana deve voltar a ser monitorada mais de perto pelo risco de recidiva: mensalmente no primeiro semestre ap\xF3s a suspens\xE3o; trimestralmente at\xE9 o final do 1\xBA ano e, depois, anualmente por tempo indeterminado.
    <br>
  </span>
  <span style="font-weight: 400; font-size: 8pt;">* O perfil de paciente mais propenso \xE0 remiss\xE3o \xE9 de mulheres com quadros leves, b\xF3cio pequeno e TRAb negativo ou em baixos t\xEDtulos. Por isso, \xE9 \xFAtil acompanhar os n\xEDveis de TRAb antes da suspens\xE3o medicamentosa a fim de prever aqueles com maior chance de remiss\xE3o.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A</span>
  <span style="font-weight: 400;">abla\xE7\xE3o com iodo radioativo</span>
  <span style="font-weight: 400;">\xE9 bem indicada nos casos de recidiva ap\xF3s tentativa farmacol\xF3gica e em casos em que se deseje o controle r\xE1pido do hipertireoidismo, como em cardiopatas, idosos e mulheres em idade f\xE9rtil que planejam gravidez no futuro pr\xF3ximo (desde que se espere, pelo menos, 6 meses ap\xF3s o tratamento para engravidar). Ap\xF3s 1-2 meses do procedimento, devem ser avaliados T4-livre, T3 e TSH e, caso o perfil bioqu\xEDmico de hipertireoidismo permane\xE7a, essa monitoriza\xE7\xE3o deve ser mantida a cada 4-6 semanas. Se, ap\xF3s 6 meses de tratamento, ainda persistir o hipertireoidismo, \xE9 definida falha terap\xEAutica (ocorre em 20% dos casos) e pode ser indicada uma segunda tentativa.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>
      <span style="font-weight: 400;">* De modo opcional, pode-se realizar um pr\xE9-tratamento com metimazol, suspendendo esse \xFAltimo 3-7 dias antes da abla\xE7\xE3o e reintroduzindo 3-7 dias depois. Essa estrat\xE9gia \xE9 utilizada principalmente em pacientes descompensados, pelo risco de piora transit\xF3ria da tireotoxicose ap\xF3s a radioiodoterapia.</span>
    </em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A</span>
  <span style="font-weight: 400;">tireoidectomia total</span>
  <span style="font-weight: 400;">\xE9 uma op\xE7\xE3o nos refrat\xE1rios \xE0 op\xE7\xE3o farmacol\xF3gica e est\xE1 formalmente indicada nos casos de b\xF3cios volumosos (\u2265 80 g) ou com sintomas compressivos, n\xF3dulos suspeitos, gestantes ou mulheres que desejem engravidar em menos de 6 meses que n\xE3o obtiveram controle farmacol\xF3gico. A reposi\xE7\xE3o de horm\xF4nio tireoidiano (levotiroxina) deve ser iniciada antes da alta hospitalar, de prefer\xEAncia no dia subsequente \xE0 cirurgia.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>
      <span style="font-weight: 400;">* Sempre que poss\xEDvel, devemos realizar um preparo pr\xE9-operat\xF3rio: o primeiro passo consiste no tratamento com uma tionamida (metimazol) at\xE9 a obten\xE7\xE3o do eutireoidismo (geralmente 4-8 semanas). Feito isso, durante os 10 dias que antecedem o procedimento, recomenda-se a administra\xE7\xE3o de solu\xE7\xE3o com iodeto de pot\xE1ssio para reduzir a vasculariza\xE7\xE3o tireoidiana e, por consequ\xEAncia, o sangramento cir\xFArgico: solu\xE7\xE3o saturada de iodeto de pot\xE1ssio - SSKI (50 mg/gota) 1 gota 3x/dia ou solu\xE7\xE3o de Lugol (6 mg/gota) 5-10 gotas 3x/dia.</span>
    </em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Nos pacientes com oftalmopatia de Graves, em tese, qualquer uma das op\xE7\xF5es terap\xEAuticas citadas pode ser adotada, com exce\xE7\xE3o da abla\xE7\xE3o nos casos moderados a graves. Se optar pela abla\xE7\xE3o para os casos leves, por\xE9m com fatores de risco para progress\xE3o (tabagista, n\xEDveis elevados de TRAb), deve-se iniciar corticoide nos primeiros 3 dias ap\xF3s o procedimento (prednisona 0,4-0,5 mg/kg/dia ou 30 mg/dia). O medicamento deve ser mantido por 30 dias, com posterior descontinua\xE7\xE3o gradual em 6-8 semanas.</span>
</p><p style="text-align: justify;">
  <strong>Adenoma T\xF3xico (AT) e B\xF3cio Multinodular T\xF3xico (BMNT)</strong>
  <span style="font-weight: 400;">\u2013 As tionamidas (drogas antitireoidianas) n\xE3o levam \xE0 remiss\xE3o, mas podem ser usadas em um primeiro momento para o paciente atingir o eutireoidismo antes do procedimento definitivo, que preferencialmente \xE9 cir\xFArgico, geralmente optando pela tireoidectomia parcial no AT e total no BMNT, de modo que a abla\xE7\xE3o \xE9 op\xE7\xE3o nos casos com contraindica\xE7\xE3o ou recusa \xE0 cirurgia. Como a abla\xE7\xE3o pode causar uma exacerba\xE7\xE3o transit\xF3ria do hipertireoidismo, pode-se reintroduzir as tionamidas 3-7 dias ap\xF3s o procedimento. Terapias alternativas como inje\xE7\xE3o de etanol e abla\xE7\xE3o percut\xE2nea com</span>
  <em>
    <span style="font-weight: 400;">laser</span>
  </em>
  <span style="font-weight: 400;">ou radiofrequ\xEAncia podem ser indicadas em casos selecionados (contraindica\xE7\xE3o ou recusa do paciente ao radioiodo e \xE0 cirurgia).&nbsp;&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Quando se opta pela cirurgia, a fun\xE7\xE3o tireoidiana \xE9 monitorada em 4-6 semanas, quando se avalia a necessidade de reposi\xE7\xE3o hormonal nos casos de tireoidectomia parcial (por AT); suplementa\xE7\xE3o esta que \xE9 sempre iniciada logo ap\xF3s a cirurgia de tireoidectomia total (por BMNT).&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">No caso da abla\xE7\xE3o, assim como na Doen\xE7a de Graves, 1-2 meses ap\xF3s o procedimento, devem ser avaliados T4-livre, T3 e TSH e, caso o perfil bioqu\xEDmico de hipertireoidismo permane\xE7a, essa monitoriza\xE7\xE3o deve ser mantida a cada 4-6 semanas. Se, ap\xF3s 6 meses de tratamento, ainda persistir o hipertireoidismo, pode ser indicada uma segunda tentativa.</span>
</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- Efeitos colaterais das tionamidas \u2013</strong>
  <span style="font-weight: 400;">Antes de iniciar o tratamento farmacol\xF3gico, \xE9 \xFAtil solicitar hemograma e bioqu\xEDmica hep\xE1tica para ter valores de base a fim de comparar com eventual agranulocitose ou hepatotoxicidade. Embora n\xE3o seja obrigat\xF3ria a monitoriza\xE7\xE3o frequente, recomenda-se obter leucometria em todo caso febril mais grave e no in\xEDcio de uma faringite, bem como laborat\xF3rio hep\xE1tico em situa\xE7\xF5es de icter\xEDcia, col\xFAria, acolia fecal, dor abdominal, n\xE1usea e fadiga. Nestas situa\xE7\xF5es, a tionamida deve ser suspensa at\xE9 que o quadro seja esclarecido. Rea\xE7\xF5es cut\xE2neas mais leves podem ser manejadas com anti-histam\xEDnicos.</span>
</p><p style="text-align: justify;">
  <strong>- Hipertireoidismo subcl\xEDnico \u2013</strong>
  <span style="font-weight: 400;">Definido pela redu\xE7\xE3o do TSH, mas ainda com horm\xF4nios tireoidianos na faixa de normalidade. A conduta, a princ\xEDpio, \xE9 tratar com as mesmas op\xE7\xF5es terap\xEAuticas delineadas para o tratamento do hipertireoidismo manifesto. O tratamento \xE9 ainda mais imperativo em casos sintom\xE1ticos, \u2265 65 anos, cardiopatas, portadores de osteoporose ou mulheres p\xF3s-menopausa sem reposi\xE7\xE3o estrog\xEAnica. Os \xFAnicos casos que poderiam ser observados s\xE3o de gestantes (sem demonstra\xE7\xE3o de benef\xEDcio para m\xE3e e feto) e aqueles sem as condi\xE7\xF5es imperativas citadas agora, sobretudo se TSH \u2265 0,1 mU/L.</span>
</p><p style="text-align: justify;">
  <strong>- Gestantes \u2013</strong>
  <span style="font-weight: 400;">O hipertireoidismo ocorre em 0,2-0,7% das gesta\xE7\xF5es, sendo a doen\xE7a de Graves respons\xE1vel por 95% dos casos. O tratamento \xE9 feito com tionamidas e, como j\xE1 citado, no 1\xBA trimestre, a prefer\xEAncia \xE9 pelo propiltiouracil (alguns orientam que essa prefer\xEAncia permane\xE7a at\xE9 a 16\xAA semana), de forma que, no restante da gesta\xE7\xE3o, deve-se considerar a troca pelo metimazol, que, embora tenha maior potencial teratog\xEAnico, tem menor risco de hepatotoxicidade. Para as portadoras de hipertireoidismo que se tornam gestantes, pode-se tentar a suspens\xE3o das drogas caso a dose em uso seja muito baixa (&lt; 5-10 mg/dia para metimazol ou &lt; 50-100 mg para propiltiouracil). Caso o tratamento seja mantido e a paciente estiver em uso de metimazol, a troca pelo propiltiouracil no 1\xBA trimestre precisa ocorrer. A troca entre estes f\xE1rmacos deve obedecer a uma propor\xE7\xE3o aproximada de 1:20 entre as doses, ou seja, 5 mg/dia de metimazol como equival\xEAncia a 100 mg/dia de propiltiouracil. O monitoramento da fun\xE7\xE3o tireoidiana deve ser feito a cada 4 semanas, objetivando um T4-livre no limite superior de normalidade.</span>
</p><p style="text-align: justify;">
  <strong>- Terapias adjuvantes</strong>
  <span style="font-weight: 400;">- Em pacientes com alergias \xE0s tionamidas ou em casos graves de hipertireoidismo, podemos considerar o uso de terapias adjuvantes. O iodo (solu\xE7\xE3o saturada de iodeto de pot\xE1ssio), al\xE9m de ser usado no pr\xE9-operat\xF3rio de pacientes com doen\xE7a de Graves, pode ser feito ap\xF3s a radioiodoterapia, com objetivo de normalizar a fun\xE7\xE3o tireoidiana mais rapidamente, ou junto com uma tionamida, permitindo uso de uma dose menor da medica\xE7\xE3o. Em doses baixas (1-2 gotas/dia), tamb\xE9m pode ser usado como terapia prim\xE1ria se o hipertireoidismo for leve. A colestiramina \xE9 outra op\xE7\xE3o de terapia adjuvante e, em associa\xE7\xE3o com uma tionamida, promove o controle mais r\xE1pido do hipertireoidismo. Embora o l\xEDtio bloqueie a libera\xE7\xE3o de horm\xF4nio tireoidiano, seu uso \xE9 limitado pelo risco de toxicidade e efeitos adversos associados.&nbsp;&nbsp;</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li>
    <span style="font-weight: 400;">Maia AL, Scheffel RS, Meyer ELS, et al. Consenso Brasileiro para o Diagno\u0301stico e Tratamento do Hipertireoidismo: Recomendac\u0327o\u0303es do Departamento de Tireoide da Sociedade Brasileira de Endocrinologia e Metabologia. Arq Bras Endocrinol Metab. 2013; 57(3): 205-232.&nbsp;</span>
  </li>
  <li>
    <span style="font-weight: 400;">Ross DS, Burch HB, Cooper DS, Greenlee MC, Laurberg P, Maia AL, et al. 2016 American Thyroid Association Guidelines for Diagnosis and Management of Hyperthyroidism and Other Causes of Thyrotoxicosis. Thyroid 2016; 26(10): 1343-1421.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Kahaly GJ, Bartalena L, Heged\xFCs L, et al. 2018 European Thyroid Association Guideline for the Management of Graves\u2019 Hyperthyroidism.</span>
    <em>
      <span style="font-weight: 400;">Eur Thyroid J</span>
    </em>
    <span style="font-weight: 400;">2018;7:167\u2013186</span>
  </li>
  <li>
    <span style="font-weight: 400;">National Institute for Health and Care Excellence (2019) Thyroid disease: assessment and management. Nice Guideline (NG145).</span>
  </li>
  <li>
    <span style="font-weight: 400;">American College of Obstetricians and Gynecologists. Thyroid Disease in Pregnancy - ACOG Practice Bulletin No. 223.</span>
    <em>
      <span style="font-weight: 400;">Obstetrics and Gynecology</span>
    </em>
    <span style="font-weight: 400;">2020;135(6):e261-e274.</span>
    <br>
  </li>
</ol>`,ordem:6}],videos:[],fluxogramas:[],tags:["Tireotoxicose","Tireoide"]},{id:"b763758d-8899-4b6f-913b-0d84af35b3af",nome:"Hiponatremia",categoria:1,termosDeBusca:"hiponatremia, sodio, natremia",favoritado:!1,ordem:0,especialidades:[{nome:"MEDICINA INTERNA"}],prescricoes:[],topicos:[{titulo:"Hiponatremia",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A hiponatremia (Na &lt; 135 mEq/L) \xE9 o dist\xFArbio eletrol\xEDtico mais comum na pr\xE1tica (15-30% dos pacientes internados), sendo justificado pelo excesso relativo de \xE1gua em rela\xE7\xE3o ao s\xF3dio. Diversas doen\xE7as, por diferentes mecanismos fisiopatol\xF3gicos, s\xE3o capazes de desencade\xE1-la, incluindo certas interven\xE7\xF5es m\xE9dicas.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Em termos pr\xE1ticos, a hiponatremia pode ser classificada pelo:
    <br>
  </span>(1) Tempo de Desenvolvimento: 
  <strong>aguda</strong> (&lt; 48h) x 
  <strong>cr\xF4nica</strong> (\u2265 48h) \u2192 na pr\xE1tica m\xE9dica, \xE9 uma distin\xE7\xE3o dif\xEDcil de ser estabelecida
  <br>(2) Valor da Natremia: 
  <strong>leve</strong> (130-135 mEq/L) x 
  <strong>moderada</strong> (120-129 mEq/L) x 
  <strong>grave</strong> (&lt; 120 mEq/L)
</p>`,ordem:2},{titulo:"MANIFESTA\xC7\xD5ES",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Os casos agudos e graves t\xEAm maiores chances de se associarem ao edema cerebral, podendo cursar com confus\xE3o mental, convuls\xE3o, coma e parada respirat\xF3ria. Os casos cr\xF4nicos, pela maior capacidade de adapta\xE7\xE3o osm\xF3tica neuronal, t\xEAm manifesta\xE7\xF5es mais inespec\xEDficas, como cefaleia, fadiga, n\xE1usea, tontura, altera\xE7\xE3o na marcha e cognitiva, por\xE9m tamb\xE9m se associam a desfechos adversos, como risco de quedas, em particular nos idosos. Assim, essa altera\xE7\xE3o eletrol\xEDtica</span> 
  <span style="font-weight: 400;">deve ser sempre corrigida quando associada a sintomas, especialmente os de maior gravidade</span> 
  <span style="font-weight: 400;">.</span>
</p>`,ordem:3},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Naturalmente, a confirma\xE7\xE3o diagn\xF3stica da hiponatremia requer dosagem do s\xF3dio s\xE9rico. Mas \xE9 importante tamb\xE9m solicitar:
    <br>
  </span>- Glicemia plasm\xE1tica \u2192 afastar a possibilidade de hiponatremia hipert\xF4nica (a maior parte dos casos de hiponatremia \xE9 hipot\xF4nica, mas podem existir casos n\xE3o-hipot\xF4nicos, como os associados \xE0s crises hiperglic\xEAmicas, nas quais a natremia acaba sendo corrigida com o pr\xF3prio tratamento dessas situa\xE7\xF5es)
  <br>- Calemia (K + ) \u2192 pode contribuir para a hiponatremia e sua corre\xE7\xE3o facilita a normaliza\xE7\xE3o do s\xF3dio s\xE9rico
  <br>- Fun\xE7\xE3o renal
  <br>- Bioqu\xEDmica urin\xE1ria (s\xF3dio e osmolaridade) \u2192 podem guiar a investiga\xE7\xE3o etiol\xF3gica da hiponatremia
  <br>- Outros \u2192 demais exames podem ser solicitados de acordo com hip\xF3teses etiol\xF3gicas para a hiponatremia (TSH; cortisol; radiografia ou tomografia computadorizada [TC] de t\xF3rax; TC de cr\xE2nio)
</p>`,ordem:4},{titulo:"CONDUTA",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Independente da etiologia, os casos sintom\xE1ticos devem receber reposi\xE7\xE3o de s\xF3dio para estabiliza\xE7\xE3o cl\xEDnica. Na maioria das vezes, esta reposi\xE7\xE3o \xE9 feita atrav\xE9s de salina hipert\xF4nica (NaCl 3%) por via intravenosa.</span>
</p><p style="text-align: justify;">
  <strong>
    <em>Como criar uma solu\xE7\xE3o de Salina Hipert\xF4nica (NaCl 3%)
      <br>
    </em>
  </strong>(1) NaCl 20% 150 mL + \xC1gua Destilada 850 mL
  <br>(2) Qualquer solu\xE7\xE3o com 1 parte de NaCl 20% e 9 partes de SF 0,9%: 
  <br>- NaCl 20% 100 mL + SF 0,9% 900 mL
  <br>- NaCl 20% 50 mL + SF 0,9% 450 mL 
  <br>- NaCl 20% 10 mL + SF 0,9% 90 mL
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Importante ressaltar que h\xE1 limites de seguran\xE7a para a corre\xE7\xE3o no valor da natremia, que n\xE3o deve ser &gt; 10 mEq/L nas primeiras 24h e nem &gt; 8 mEq/L nas 24h subsequentes (total n\xE3o deve ultrapassar 18 mEq/L em 48h) pelo risco de</span> 
  <em>
    <span style="font-weight: 400;">S\xEDndrome de Desmieliniza\xE7\xE3o Osm\xF3tica</span>
  </em> 
  <span style="font-weight: 400;">(SDO), tamb\xE9m chamada de mielin\xF3lise pontina.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Alvos de corre\xE7\xE3o ainda mais baixos (como &lt; 8 mEq/L por dia) podem ser utilizados em casos com maior risco para SDO, como alcoolismo, desnutri\xE7\xE3o, hepatopatia e hipocalemia.</em>
  </span>
</p><p style="text-align: justify;">
  <strong>- Tratamento Emergencial -</strong> 
  <span style="font-weight: 400;">Os casos que se apresentem com maior gravidade, como convuls\xE3o ou coma, demandam corre\xE7\xE3o mais r\xE1pida da natremia. Classicamente, buscava-se aumentar em 3 mEq/L o s\xF3dio s\xE9rico em 3h, mas, atualmente recomenda-se a infus\xE3o de 100 mL de salina hipert\xF4nica (NaCl 3%) em 10 minutos, que deve ser capaz de aumentar a natremia em 2-3 mEq/L. Esta estrat\xE9gia \xE9 repetida por, no m\xE1ximo, duas a tr\xEAs vezes at\xE9 que haja melhora neurol\xF3gica ou eleva\xE7\xE3o de 5 mEq/L na natremia \u2013 o que ocorrer primeiro. Ap\xF3s essa abordagem emergencial, a normaliza\xE7\xE3o do s\xF3dio s\xE9rico pode seguir uma abordagem espec\xEDfica de acordo com a etiologia da hiponatremia.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Se o quadro neurol\xF3gico n\xE3o melhorar mesmo ap\xF3s a eleva\xE7\xE3o da natremia em 5 mEq/L, deve-se buscar outra justificativa.</em>
  </span>
</p><p style="text-align: justify;">
  <strong>- Tratamento N\xE3o-Emergencial -</strong> 
  <span style="font-weight: 400;">Se os sintomas n\xE3o forem graves, n\xE3o h\xE1 obrigatoriedade da utiliza\xE7\xE3o do</span> 
  <em>
    <span style="font-weight: 400;">bolus</span>
  </em> 
  <span style="font-weight: 400;">anteriormente descrito, devendo buscar corre\xE7\xE3o netr\xEAmica mais gradual. A Diretriz Americana cita a possibilidade da infus\xE3o de NaCl 3% a 0,5-2 mL/kg/h, mas, nessa estrat\xE9gia h\xE1 risco maior de corre\xE7\xE3o excessiva da natremia. Desta maneira, \xE9 mais seguro restringir a corre\xE7\xE3o do s\xF3dio seguindo os passos abaixo:</span>
</p><p>
  <strong>(1) Calcular o</strong> 
  <strong>
    <em>deficit</em>
  </strong> 
  <strong>de s\xF3dio</strong>
</p><p>
  <span style="font-weight: 400;">A f\xF3rmula do d\xE9ficit de s\xF3dio \xE9:&nbsp;</span>
</p><p>
          <strong>
            <em>Deficit</em>
          </strong> 
          <strong>de Na (mEq/L) = \xC1gua Corporal Total x Varia\xE7\xE3o de S\xF3dio Desejada</strong>
        </p><p>
          <span style="font-size: 8pt;">
            <em>
              <span style="font-weight: 400;">* \xC1gua Corporal Total: homem = Peso (kg) x 0,6</span>
            </em>
          </span>
        </p><p>
          <span style="font-size: 8pt;">
            <em>
              <span style="font-weight: 400;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mulher = Peso (kg) x 0,5</span>
            </em>
          </span>
        </p><p style="text-align: justify;">
  <strong>(2) Calcular o volume e a velocidade de infus\xE3o de NaCl 3% em 24h</strong>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Como regra pr\xE1tica, pode-se multiplicar por 2 o valor do</span> 
  <em>
    <span style="font-weight: 400;">deficit</span>
  </em> 
  <span style="font-weight: 400;">de s\xF3dio calculado acima para encontrar o valor aproximado do volume (em mL) da solu\xE7\xE3o de NaCl 3%. Em seguida, basta dividir esse valor por 24 para definir a velocidade de infus\xE3o em mL/h em 24h.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* O c\xE1lculo matem\xE1tico exato necessitaria da convers\xE3o inicial de "mEq de s\xF3dio" em "gramas de NaCl". Como 1 g de NaCl cont\xE9m 17 mEq de s\xF3dio, basta dividir o</em> deficit 
    <em>de s\xF3dio encontrado por 17. Teremos, ent\xE3o, o valor do</em> deficit 
    <em>de s\xF3dio agora em gramas de NaCl... E n\xE3o acabou por aqui! Em seguida, utilizamos uma regra de 3 para chegarmos ao volume de NaCl a 3% a ser infundido: \u201C3 g est\xE3o para 100 mL, assim como y g (</em> deficit 
    <em>calculado) est\xE3o para x mL\u201D.</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">De modo geral, a taxa de infus\xE3o de NaCl 3% fica pr\xF3xima de 0,5 mL/kg/h. Assim, valores muito superiores devem representar um erro matem\xE1tico ou a decis\xE3o equivocada de uma corre\xE7\xE3o natr\xEAmica mais agressiva.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Vejamos um exemplo pr\xE1tico para contextualizar o racioc\xEDnio:</span> 
  <span style="font-weight: 400;">mulher de 70 Kg com Na</span> 
  <span style="font-weight: 400;">+</span> 
  <span style="font-weight: 400;">124 mEq/L.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Visando uma corre\xE7\xE3o m\xE1xima de 10 mEq/L nas primeiras 24h, temos um</span> 
  <em>
    <span style="font-weight: 400;">deficit</span>
  </em> 
  <span style="font-weight: 400;">a ser corrigido de 350 mEq (70 x 0,5 x 10) nesse per\xEDodo. O volume aproximado de NaCl 3% \xE9, pela nossa regra pr\xE1tica, de 700 mL (350 x 2), que, em 24h, devem ser infundidos a uma taxa de 29,1 mL/h (700/24). 
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Se a op\xE7\xE3o fosse pelo \u201Cc\xE1lculo matem\xE1tico exato\u201D, os 350 mEq de</em> deficit 
    <em>equivalem a 20,6 g (350/17) e, para chegar ao volume de NaCl 3%, seria necess\xE1ria aquela regra de 3 em que \u201C3 g est\xE3o para 100 mL, assim como 20,6 g (</em> deficit 
    <em>calculado) est\xE3o para x mL\u201D. Nesse c\xE1lculo, encontrar\xEDamos 687 mL (bem pr\xF3ximos dos 700 mL), que deveriam ser infundidos \xE0 taxa de 28,6 mL/h. Muito melhor usar nossa regra pr\xE1tica...</em>
  </span>
</p><p style="text-align: justify;">
  <strong>- Conduta espec\xEDfica ap\xF3s estabiliza\xE7\xE3o natr\xEAmica -</strong> 
  <span style="font-weight: 400;">Com a melhora sintom\xE1tica, o paciente passa a ser hidratado com solu\xE7\xE3o isot\xF4nica (NaCl 0,9%) e a conduta direciona-se para o tipo de hiponatremia que o paciente desenvolveu. Esta acaba sendo tamb\xE9m a abordagem dos casos assintom\xE1ticos identificados. A hiponatremia hipot\xF4nica \xE9 classicamente dividida pelo</span> 
  <em>
    <span style="font-weight: 400;">status vol\xEAmico</span>
  </em> 
  <span style="font-weight: 400;">(sinais vitais, turgor cut\xE2neo, hidrata\xE7\xE3o de mucosa, edema perif\xE9rico), sendo a bioqu\xEDmica urin\xE1ria (osmolaridade e, especialmente, s\xF3dio) tamb\xE9m \xFAtil nessa organiza\xE7\xE3o:</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">(1) HIPOVOL\xCAMICA (desidrata\xE7\xE3o): NaCl 0,9% IV
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Na urin\xE1rio &gt; 20 mEq/L: perda renal (diur\xE9tico, defici\xEAncia de mineralocorticoide)
      <br>
    </em>
    <em>* Na urin\xE1rio &lt; 20 mEq/L: perda extrarrenal (v\xF4mito, diarreia, obstru\xE7\xE3o intestinal)</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">(2) EUVOL\xCAMICA (volemia normal; Na urin\xE1rio &gt; 20 mEq/L): direcionar a terap\xEAutica
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* SIADH = restri\xE7\xE3o h\xEDdrica / Causas End\xF3crinas (Hipocortisolismo, Hipotireoidismo) = reposi\xE7\xE3o hormonal / Medica\xE7\xE3o (barbit\xFArico, carbamazepina, clorpropamida, opioide, inibidor seletivo da recepta\xE7\xE3o da serotonina) = suspender</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">(3) HIPERVOL\xCAMICA (presen\xE7a de edema ou ascite; Na urin\xE1rio &lt; 20 mEq/L): restri\xE7\xE3o h\xEDdrica (&lt; 1 L/dia), com a op\xE7\xE3o de associa\xE7\xE3o com diur\xE9tico</span>
</p><p style="text-align: justify;">
  <strong>- Complica\xE7\xE3o (S\xEDndrome de Desmieliniza\xE7\xE3o Osm\xF3tica) \u2013</strong> 
  <span style="font-weight: 400;">A&nbsp; S\xEDndrome de Desmieliniza\xE7\xE3o Osm\xF3tica (SDO) costuma se manifestar dois a seis dias depois da corre\xE7\xE3o excessivamente r\xE1pida da natremia. Seus achados incluem disartria, disfagia, paraparesia, dist\xFArbio do comportamento, letargia e confus\xE3o mental.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Para evitar essa complica\xE7\xE3o, se o n\xEDvel de s\xF3dio s\xE9rico ultrapassar o limite de seguran\xE7a, j\xE1 devemos instituir a estrat\xE9gia de resgate conhecida como</span> 
  <em>
    <span style="font-weight: 400;">Sodium Re-Lowering</span>
  </em> 
  <span style="font-weight: 400;">(reduzir novamente o s\xF3dio), que \xE9 a mesma estrat\xE9gia para os casos que acabam desenvolvendo a SDO. Ou seja, \xE9 uma estrat\xE9gia usada tanto na preven\xE7\xE3o quanto no tratamento desta complica\xE7\xE3o:</span>
</p><p style="text-align: justify;">
  <em>
    <span style="font-weight: 400;">(1) Interromper a infus\xE3o de salina hipert\xF4nica
      <br>
    </span>
  </em>
  <em>(2) Repor \xE1gua livre (3 mL/Kg/h) por via oral ou com SG 5% IV
    <br>
  </em>
  <em>(3) Desmopressina (dDAVP) 2 mcg IV ou SC de 8/8h
    <br>
  </em>
  <em>(4) Dosar a natremia de hora em hora, at\xE9 retornar para o limite de seguran\xE7a</em>
</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- N\xE3o monitorar a evolu\xE7\xE3o da natremia -</strong> 
  <span style="font-weight: 400;">Durante o manejo daa hiponatremia grave, \xE9 mandat\xF3rio repetir a dosagem de s\xF3dio s\xE9rico a intervalos regulares de duas a quatro horas. A justificativa \xE9 que a resposta da natremia n\xE3o \xE9 totalmente previs\xEDvel, em fun\xE7\xE3o de mudan\xE7as agudas na fisiologia do paciente que podem ocorrer ao longo do tratamento (como sudorese excessiva).</span>
</p><p style="text-align: justify;">
  <strong>- Aten\xE7\xE3o ao volume de reposi\xE7\xE3o -</strong> 
  <span style="font-weight: 400;">Para evitar a corre\xE7\xE3o excessiva da natremia, \xE9 \xFAtil \u2013 embora n\xE3o seja obrigat\xF3rio \u2013 que se conecte ao paciente atrav\xE9s de bomba infusora apenas o volume total a ser prescrito de salina hipert\xF4nica no tempo determinado. Isso evita que, em caso de atraso na reavalia\xE7\xE3o da infus\xE3o, uma quantidade maior continue a ser infundida.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li>
    <em>
      <span style="font-weight: 400;">Spasovski G et al. Clinical Practice Guideline on Diagnosis and Treatment of Hyponatraemia. Nephrol Dial Transplant (2014) 29 (Suppl. 2): ii1\u2013ii39.&nbsp;</span>
    </em>
  </li>
  <li>
    <em>
      <span style="font-weight: 400;">Verbalis JG et al. Diagnosis, Evaluation and Treatment of Hyponatremia: Expert Panel Recommendations. The American Journal of Medicine (2013) 126, S1-S42.</span>
    </em>
  </li>
  <li>
    <em>
      <span style="font-weight: 400;">Adrogue HJ, Madias NE. Hyponatremia.&nbsp;N Engl J Med. 2000;342(21):1581-89.</span>
    </em>
  </li>
  <li>
    <em>
      <span style="font-weight: 400;">Braun MM, Barstow CH, Pyzocha NH. Diagnosis and management of sodium disorders: hyponatremia and hypernatremia.&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">Am. Fam. Physician 2015;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">&nbsp;91: 299-307.</span>
    </em>
  </li>
  <li>
    <em>
      <span style="font-weight: 400;">Hoorn EJ, Zietse R. Diagnosis and Treatment of Hyponatremia: Compilation of the Guidelines.&nbsp;</span>
    </em> 
    <em>
      <span style="font-weight: 400;">Journal of the American Society of Nephrology 2017</span>
    </em> 
    <em>
      <span style="font-weight: 400;">, ASN-2016101139.</span>
    </em>
  </li>
</ol>`,ordem:6}],videos:[],fluxogramas:[],tags:["S\xF3dio","natremia"]},{id:"1edc643d-02e6-4fe4-a234-2e98ce5d7b33",nome:"Hipotireoidismo",categoria:2,termosDeBusca:"hipotireoidismo, ",favoritado:!1,ordem:0,especialidades:[{nome:"ENDOCRINOLOGIA"}],prescricoes:[{id:"48f0422e-f7f6-4da0-997f-9278f47102aa",nome:"Hipotireoidismo",favorito:!0,ordem:1,secoes:[{item:"LEVOTIROXINA (T4)",grupos:[{grupo:"Horm\xF4nio Tireoidiano",idGrupo:"fc28234c-0c4e-4771-aebf-619adbafda22",opcoes:[{id:"837ad5b9-62d4-410c-9ef0-4cef39a75045",descr:`Levotiroxina (12,5-200mcg/cp) 1,6 mcg/Kg VO 1x/dia\r
- Op\xE7\xE3o: iniciar com dose mais baixa como 50 mcg/dia\r
- Idoso ou cardiopata: iniciar com 12,5-25 mcg/dia`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Cuidado em idosos ou cardiopatas pelo risco de isquemia mioc\xE1rdica pelo \u2191consumo de O2.",ordem:1}],conceitosPraticos:[{conceito:"Hipotireoidismo 1\xE1rio: \u2191TSH / \u2193T4-livre (alvo \xE9 normalizar TSH)",ordem:1},{conceito:"Hipotireoidismo 2\xE1rio: \u2193TSH (ou normal) / \u2193T4-livre (alvo \xE9 T4-livre na metade superior da normalidade)",ordem:2},{conceito:"Monitoriza\xE7\xE3o laboratorial 6-8 semanas ap\xF3s in\xEDcio do tratamento e qualquer ajuste de dose.",ordem:3},{conceito:"Levotiroxina: administrar pela manh\xE3 em jejum (30-60 min antes do caf\xE9)",ordem:4}]}],topicos:[{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O hipotireoidismo consiste na redu\xE7\xE3o da atividade da tireoide, com consequente diminui\xE7\xE3o da circula\xE7\xE3o de horm\xF4nio tireoidiano. O hipotireoidismo prim\xE1rio, isto \xE9, por problema da pr\xF3pria tireoide \xE9 o tipo mais comum (95% dos casos), tendo a autoimunidade (tireoidite de Hashimoto) como principal causa no Brasil \u2013 outras poss\xEDveis etiologias s\xE3o: defici\xEAncia de iodo, induzido por droga (amiodarona, l\xEDtio, inibidor de tirosina quinase), associado \xE0 doen\xE7a infiltrativa (sarcoidose, hemocromatose, tireoidite fibrosante), iatrog\xEAnico (p\xF3s-tireoidectomia ou abla\xE7\xE3o total) e transit\xF3rio (tireoidite subaguda, tireoidite p\xF3s-parto). O hipotireoidismo secund\xE1rio (ou central) \u2013 extremamente incomum \u2013 pode ser causado por tumores, traumas, doen\xE7as infiltrativas, infec\xE7\xF5es, hipofisites, les\xF5es cong\xEAnitas ou defeitos funcionais na libera\xE7\xE3o de TSH (pode ocorrer com dopamina e glicocorticoides).
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>*O hipotireoidismo tamb\xE9m pode ser classificado como perif\xE9rico ou extratireoidiano, situa\xE7\xE3o rara decorrente de resist\xEAncia \xE0 a\xE7\xE3o perif\xE9rica dos horm\xF4nios tireoidianos ou de sua metaboliza\xE7\xE3o aumentada.&nbsp;</em>
  </span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">As manifesta\xE7\xF5es principais s\xE3o inespec\xEDficas e relacionadas \xE0 lentifica\xE7\xE3o metab\xF3lica, como intoler\xE2ncia ao frio, fadiga, fraqueza, ganho de peso, constipa\xE7\xE3o, disfun\xE7\xE3o cognitiva, hiporreflexia e bradicardia. Outros achados incluem pele seca e descamativa, rouquid\xE3o, fala lenta, macroglossia, edema (inclusive periorbital), derrames pleural e peric\xE1rdico, ascite e hipertens\xE3o diast\xF3lica. Perceba que n\xE3o h\xE1 qualquer sinal patognom\xF4nico de hipotireoidismo.</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A pesquisa para hipotireoidismo deve ser feita nas seguintes situa\xE7\xF5es:
    <br>
  </span>- Manifesta\xE7\xF5es cl\xEDnicas compat\xEDveis.
  <br>- Rastreio em pacientes com fator de risco: b\xF3cio, radia\xE7\xE3o ou cirurgia anterior da tireoide, positividade para anti-TPO, uso de drogas associadas a hipotireoidismo, hist\xF3ria de doen\xE7a autoimune (diabetes tipo 1, s\xEDndrome de Sj\xF6gren, l\xFApus, artrite reumatoide, vitiligo, anemia perniciosa, doen\xE7a cel\xEDaca), hist\xF3ria familiar de doen\xE7a tireoidiana, s\xEDndrome de Down, s\xEDndrome de Turner.
  <br>- Rastreio em pacientes com altera\xE7\xF5es laboratoriais compat\xEDveis: hiponatremia, anemia macroc\xEDtica, dislipidemia severa, eleva\xE7\xE3o de CPK.
  <br>
  <span style="font-size: 8pt;">
    <em>*O rastreio universal em gestantes \xE9 controverso e, atualmente, a tend\xEAncia \xE9 preferir uma abordagem direcionada \xE0s mulheres com &gt; 30 anos ou com fatores de risco citados acima.</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O diagn\xF3stico de hipotireoidismo \xE9 necessariamente laboratorial e caracterizado por redu\xE7\xE3o do T4-livre e eleva\xE7\xE3o do TSH no hipotireoidismo prim\xE1rio, em compara\xE7\xE3o com a redu\xE7\xE3o do T4-livre e um TSH tamb\xE9m reduzido (eventualmente pode estar normal) no hipotireoidismo secund\xE1rio (ou central). Nos casos de hipotireoidismo prim\xE1rio, alguns autores indicam a dosagem do anti-TPO para certifica\xE7\xE3o da etiologia autoimune, enquanto outros afirmam que essa medida \xE9 desnecess\xE1ria em pa\xEDses com sufici\xEAncia de iodo, uma vez que quase todos t\xEAm tireoidite de Hashimoto.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Habitualmente, o rastreio de doen\xE7a tireoidiana \xE9 feito atrav\xE9s da mensura\xE7\xE3o inicial do TSH, cujo intervalo de normalidade fica entre 0,4-4,5 mU/L, excetuando-se as gestantes, para as quais deve-se seguir os valores de refer\xEAncia locais espec\xEDficos para cada trimestre. Se estes valores de refer\xEAncia n\xE3o estiverem dispon\xEDveis, no 1\xBA trimestre, considera-se o intervalo de 0,1-4,0 mU/L com retorno gradual aos par\xE2metros de fora da gesta\xE7\xE3o ao longo do 2\xBA e 3\xBA trimestres. Como ocorre uma eleva\xE7\xE3o fisiol\xF3gica do TSH com o avan\xE7ar da idade, n\xEDveis de corte um pouco mais elevados podem ser considerados para pacientes idosos.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Como o TSH apresenta certa variabilidade pessoal e existem casos de hipotireoidismo transit\xF3rio e at\xE9 de erro laboratorial, o adequado \xE9 que a eleva\xE7\xE3o do TSH seja confirmada depois de 2-3 meses para que agora, em associa\xE7\xE3o com o T4-livre, o diagn\xF3stico de hipotireoidismo seja confirmado.&nbsp;</span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">N\xE3o h\xE1 mist\xE9rio quanto ao tratamento do hipotireoidismo, sendo necess\xE1ria a reposi\xE7\xE3o de horm\xF4nio tireoidiano, o que \xE9 feito na forma de monoterapia com levotiroxina na dose inicial de 1,6 mcg/Kg/dia (112 mcg/dia em um paciente m\xE9dio de 70 Kg), embora possa ser iniciada em dose um pouco mais baixa (exemplo: 50 mcg/dia) com incrementos graduais posteriores. A maioria dos autores concorda que o alvo do tratamento \xE9 a redu\xE7\xE3o do TSH para um valor dentro da sua faixa de normalidade (exce\xE7\xE3o fica para os casos de hipotireoidismo secund\xE1rio, em que o alvo deve ser um T4-livre dentro da metade superior da faixa de normalidade).
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>*Importante notar que, nas gestantes, a recomenda\xE7\xE3o \xE9 que o TSH fique na metade inferior da faixa de refer\xEAncia local espec\xEDfica do trimestre. Se n\xE3o estiver dispon\xEDvel, defende-se que o alvo seja &lt; 2,5 mU/L nessa popula\xE7\xE3o. Al\xE9m disso, considerando a j\xE1 citada mudan\xE7a fisiol\xF3gica relacionada \xE0 idade na dire\xE7\xE3o de valores mais altos de TSH em pacientes idosos, em pacientes com mais de 70 anos, considera-se razo\xE1vel buscar um alvo na faixa de 4-6 mU/L.&nbsp;</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Como o tratamento com levotiroxina pode aumentar o consumo de oxig\xEAnio e induzir isquemia mioc\xE1rdica, os pacientes idosos ou cardiopatas (portadores de doen\xE7a coronariana ou insufici\xEAncia card\xEDaca) devem iniciar com doses mais baixas (12,5-25 mcg/dia).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Ap\xF3s 6-8 semanas do in\xEDcio do tratamento (bem como de qualquer futura altera\xE7\xE3o da posologia), o TSH deve ser monitorado para avalia\xE7\xE3o da adequa\xE7\xE3o de dose, que poder\xE1 requerer ajustes individuais, os quais geralmente s\xE3o feitos com incrementos ou redu\xE7\xF5es de 12,5-25 mcg/dia. Ap\xF3s atingir o estado eutireoidiano, o intervalo de acompanhamento pode ser aumentado para 4-6 meses e depois, anualmente. O T4 livre pode ser monitorado nos est\xE1gios iniciais do tratamento.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Se n\xE3o ocorrer normaliza\xE7\xE3o do TSH mesmo com doses muito elevadas de levotiroxina (&gt; 2 mcg/Kg/dia), considerar m\xE1 ades\xE3o terap\xEAutica, m\xE1 absor\xE7\xE3o ou interfer\xEAncia por outras drogas. Caso haja o entendimento de que estas situa\xE7\xF5es n\xE3o se encontram presentes, \xE9 necess\xE1rio descartar associa\xE7\xE3o com insufici\xEAncia adrenal.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A administra\xE7\xE3o da levotiroxina deve ser feita idealmente pela manh\xE3 em jejum (30-60 minutos antes do caf\xE9), embora haja a alternativa da administra\xE7\xE3o noturna, respeitando, pelo menos, 2 horas de intervalo da \xFAltima refei\xE7\xE3o. A levotiroxina n\xE3o deve ser administrada junto com outros f\xE1rmacos que podem reduzir sua absor\xE7\xE3o, como sulfato ferroso, carbonato de c\xE1lcio e sevelamer \u2013 nestas situa\xE7\xF5es, o ideal \xE9 uma separa\xE7\xE3o de 4 horas entre as administra\xE7\xF5es.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- Mulher que se torna gestante \u2013</strong> 
  <span style="font-weight: 400;">Como \xE9 frequente uma maior necessidade de horm\xF4nio tireoidiano na gesta\xE7\xE3o, mulheres com hipotireoidismo que engravidam devem preventivamente aumentar a dose de levotiroxina em 25-30% ou adicionar 2 comprimidos por semana (ou seja, dobrar a dose di\xE1ria em 2 dias na semana). Novos ajustes na posologia ser\xE3o feitos a partir do acompanhamento do TSH.</span>
</p><p style="text-align: justify;">
  <strong>- Troca de marca da levotiroxina \u2013</strong> 
  <span style="font-weight: 400;">Como a utiliza\xE7\xE3o de diferentes tipos de levotiroxina dispon\xEDveis no mercado (marcas diferentes ou gen\xE9ricos) pode resultar em varia\xE7\xF5es na dose administrada, recomenda-se evitar a troca da prepara\xE7\xE3o utilizada. Em caso de mudan\xE7a, os n\xEDveis de TSH e T4-livre devem ser verificados em 6-8 semanas.</span>
</p><p style="text-align: justify;">
  <strong>- Avaliar adequa\xE7\xE3o da reposi\xE7\xE3o por manifesta\xE7\xF5es cl\xEDnicas \u2013</strong> 
  <span style="font-weight: 400;">Embora possa ser \xFAtil acompanhar as mudan\xE7as dos sinais e sintomas de pacientes tratados por hipotireoidismo, como essas manifesta\xE7\xF5es carecem de especificidade, n\xE3o se recomenda julgar a adequa\xE7\xE3o da reposi\xE7\xE3o hormonal apenas por esse par\xE2metro, sendo muito mais importante a avalia\xE7\xE3o bioqu\xEDmica. A perpetua\xE7\xE3o de sintomas apesar do equil\xEDbrio bioqu\xEDmico deve levantar a possibilidade de outros diagn\xF3sticos, como anemia, hepatopatia cr\xF4nica, insufici\xEAncia card\xEDaca, hipercalcemia, depress\xE3o, ansiedade e fibromialgia.</span>
</p><p style="text-align: justify;">
  <strong>- Outras formas de reposi\xE7\xE3o \u2013</strong> 
  <span style="font-weight: 400;">N\xE3o h\xE1 comprova\xE7\xE3o do benef\xEDcio de reposi\xE7\xE3o hormonal com T3 (triiodotironina) ou extratos de tireoide, de modo que tais estrat\xE9gias n\xE3o s\xE3o recomendadas pelas principais diretrizes vigentes.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li>
    <span style="font-weight: 400;">Brenta G, Vaisman M, Sgarbi JA, et al. Diretrizes cli\u0301nicas pra\u0301ticas para o manejo do hipotireoidismo.</span> 
    <em>
      <span style="font-weight: 400;">Arq Bras Endocrinol Metab.</span>
    </em> 
    <span style="font-weight: 400;">2013; 57 (4): 265-299.&nbsp;</span>
  </li>
  <li>
    <span style="font-weight: 400;">Jonklaas J, Bianco AC, Bauer AJ, et al. Guidelines for the Treatment of Hypothyroidism: Prepared by the American Thyroid Association Task Force on Thyroid Hormone Replacement.</span> 
    <em>
      <span style="font-weight: 400;">Thyroid</span>
    </em> 
    <span style="font-weight: 400;">2014; 24(12):1670-1751.</span>
  </li>
  <li>
    <span style="font-weight: 400;">National Institute for Health and Care Excellence (2019) Thyroid disease: assessment and management. Nice Guideline (NG145).</span>
  </li>
  <li>
    <span style="font-weight: 400;">Okosieme O, Gilbert J, Abraham P, et al. Management of primary hypothyroidism: statement by the British Thyroid Association Executive Committee.</span> 
    <em>
      <span style="font-weight: 400;">Clinical Endocrinology</span>
    </em> 
    <span style="font-weight: 400;">2016; 84(6):799\u2013808</span>
  </li>
  <li>
    <span style="font-weight: 400;">American College of Obstetricians and Gynecologists. Thyroid Disease in Pregnancy - ACOG Practice Bulletin No. 223.</span> 
    <em>
      <span style="font-weight: 400;">Obstetrics and Gynecology</span>
    </em> 
    <span style="font-weight: 400;">2020;135(6):e261-e274.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Alexander EK, et al. 2017 Guidelines of the American Thyroid Association for the Diagnosis and Management of Thyroid Disease During Pregnancy and the Postpartum. Thyroid. 2017 Mar;27(3):315-389.</span>
  </li>
</ol>`,ordem:5}],videos:[],fluxogramas:[],tags:[]},{id:"064835aa-94b4-46de-88be-fcc843053eb5",nome:"Insufici\xEAncia Card\xEDaca Aguda",categoria:1,termosDeBusca:"insuficiencia cardiaca aguda, edema agudo de pulmao, eap, icc",favoritado:!1,ordem:0,especialidades:[{nome:"CARDIOLOGIA"}],prescricoes:[{id:"013a9651-8235-40b5-a6f8-4b64231c23a6",nome:"IC Aguda",favorito:!0,ordem:1,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2216d05a-fbf0-4bda-817c-c266bad97286",opcoes:[{id:"06a304f3-dc1a-4f44-8857-671417edbc57",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s estabiliza\xE7\xE3o cl\xEDnica.",ordem:1},{item:"Hidrata\xE7\xE3o",grupos:[{grupo:"Analg\xE9sico",idGrupo:"0524881c-a794-4395-907e-51c580dea3b3",opcoes:[{id:"6b523f94-d670-4dd7-af0d-ab2e554f1a45",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:'Considerar reposi\xE7\xE3o vol\xEAmica apenas no perfil "seco", ou seja, sem congest\xE3o.',ordem:2},{item:"Diur\xE9tico de Al\xE7a",grupos:[{grupo:"Analg\xE9sico",idGrupo:"fa5f73f0-bd8d-404b-98ac-1368f7325869",opcoes:[{id:"375520e6-0a32-4e8c-933e-500cad509b20",descr:`Furosemida (20mg/2mL) 20-40 mg IV em 1-2 min 4/4h (MEDGRUPO)
Se n\xE3o houver resposta, a dose pode ser dobrada a cada 2 horas, at\xE9 200 mg`,recomendado:!0,favorito:!0,ordem:1},{id:"70e14b6c-bdc3-4ba7-92a4-981ef9c930a2",descr:`Furosemida (20mg/2mL) 40 mg IV agora em 1-2 min; seguido de Furosemida (20mg/2mL) 10 mL + SF 0,9% 90 mL (solu\xE7\xE3o: 1mg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Infundir 10-40 mL/h (repetir bolus inicial a cada aumento na infus\xE3o)`,recomendado:!1,favorito:!1,ordem:2},{id:"ec9f3891-b4cd-41a0-a34a-3facccd00ef4",descr:`Furosemida (20mg/2mL) 40 mg IV agora em 1-2 min; seguido de Furosemida (20mg/2mL) 20 mL + SF 0,9% 80 mL (solu\xE7\xE3o: 2mg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Infundir 5-20 mL/h (repetir bolus inicial a cada aumento na infus\xE3o)`,recomendado:!1,favorito:!1,ordem:3},{id:"316ae1e5-4a8b-4a89-9880-c2288f2e55a1",descr:`Furosemida (20mg/2mL) 40 mg IV agora em 1-2 min; seguido de Furosemida (20mg/2mL) 10 mL - IV em bomba infusora a crit\xE9rio m\xE9dico \r
Infundir 1-4 mL/h (repetir bolus inicial a cada aumento na infus\xE3o)`,recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Se o paciente j\xE1 fazia uso pr\xE9vio de furosemida, a dose inicial deve ser maior ou igual \xE0 dose habitual (at\xE9 o m\xE1ximo de 2,5x). ",ordem:3},{item:"Diur\xE9tico Tiaz\xEDdico",grupos:[{grupo:"Analg\xE9sico",idGrupo:"4f8dfc03-763a-4a79-b280-7ebdd72b32ad",opcoes:[{id:"7cafeae9-1d2f-4e1c-b9a7-e82b92d1a3b5",descr:"Indapamida (1,5-2,5mg/comp) 2,5 mg VO 1x/dia (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"b3048f0a-93f0-4041-a9c4-6802761c2604",descr:"Hidroclorotiazida (25-50mg/comp) 25 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:2},{id:"e254bcf3-75e4-4d2b-89dd-c47bd4c617d9",descr:"Clortalidona (12,5-50mg/comp) 12,5 mg VO 1x/dia",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Pode ser associado \xE0 furosemida apenas nos casos que n\xE3o respondem ao diur\xE9tico de al\xE7a.",ordem:4},{item:"Vasodilatador",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b37b5609-f6e3-4d2f-aa68-a86ef39b8d71",opcoes:[{id:"42aa6366-f60a-4401-954d-feec95cbb21f",descr:`Nitroprussiato de S\xF3dio (25 mg/mL) 2 mL + SG 5% 250 mL (solu\xE7\xE3o:200mcg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico (MEDGRUPO)
Iniciar 0,25 mcg/kg/min at\xE9 o m\xE1ximo de 10 mcg/Kg/min`,recomendado:!0,favorito:!0,ordem:1},{id:"29166b63-6325-4233-81bb-7c985966ce29",descr:`Nitroglicerina (5mg/mL) 5 mL + SG 5% 245 mL (solu\xE7\xE3o:100mcg/mL) IV em bomba infusora a crit\xE9rio m\xE9dico\r
Iniciar 10-20 mcg/min (6-12 mL/h) com aumentos de 5-10 mcg/min (3-6 mL/h) a cada 5-10 min se necess\xE1rio, at\xE9 200 mcg/min (120 mL/h)`,recomendado:!1,favorito:!1,ordem:2},{id:"9ee725d1-86b8-4ee5-a72f-4ed773fc6df4",descr:`Nesiritide 1,5 mg + SG 5% 250 mL (solu\xE7\xE3o:6mcg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico \r
Bolus opcional de 2 mcg/Kg, seguido de 0,01 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Prescrito para al\xEDvio sintom\xE1tico da congest\xE3o desde que PA sist\xF3lica > 90 mmHg. ",ordem:5},{item:"Inotr\xF3pico",grupos:[{grupo:"Analg\xE9sico",idGrupo:"960e2efb-6762-4cf1-bb6e-b85afa89ef68",opcoes:[{id:"f226f33d-1ddc-4336-a8d8-41dc93db3b10",descr:`Dobutamina 60 mL + SG 5% 190 mL (solu\xE7\xE3o: 3000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico (MEDGRUPO)
Iniciar 2,5 mcg/kg/min, aumentando a cada 10 min se necess\xE1rio, at\xE9 20 mcg/Kg/min`,recomendado:!0,favorito:!0,ordem:1},{id:"37863920-7dab-49c5-85c9-c03c01c2899b",descr:`Dobutamina 20 mL + SG 5% 230 mL (solu\xE7\xE3o: 1000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Iniciar 2,5 mcg/kg/min, aumentando a cada 10 min se necess\xE1rio, at\xE9 20 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:2},{id:"de19e003-3d92-4634-bfc6-e8e3532350f6",descr:`Milrinona 20 mL + SG 5% 80 mL (solu\xE7\xE3o: 200 mcg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Ataque opcional de 50 mcg/Kg IV em 10 minutos, seguido de 0,375-0,75 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:3},{id:"f18edb23-0c05-457f-ac78-191b7b1fc4cb",descr:`Levosimendan 5 mL + SG 5% 245 mL (solu\xE7\xE3o: 50mcg/mL) - IV em bomba infurosa a crit\xE9rio m\xE9dico\r
Ataque de 6-12 mcg/min em 10 minutos, seguido de 0,05-0,2 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:4},{id:"07f1768f-3d54-4655-b8e0-23dd301136a3",descr:`Dopamina 50 mL + SG 5% 200 mL (solu\xE7\xE3o: 1000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Iniciar 1 mcg/Kg/min at\xE9 o m\xE1ximo de 5 mcg/kg/min `,recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Usado em caso de hipotens\xE3o severa (PA sist\xF3lica < 90 mmHg) ou sinais de choque",ordem:6},{item:"Opioide",grupos:[{grupo:"Analg\xE9sico",idGrupo:"b9030fc2-a976-425c-8903-4155ed74ac4b",opcoes:[{id:"8eac1ea2-eef8-4496-99e0-20c1b627a529",descr:"Morfina 1 mL (10mg/mL) + \xC1gua Destilada 9 mL (solu\xE7\xE3o: 1mg/mL) \u2013 5 mL (5 mg) IV 4/4h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Considerar uso apenas em casos de desconforto respirat\xF3rio grave por edema agudo de pulm\xE3o.",ordem:7},{item:"Profilaxia Antitromb\xF3tica",grupos:[{grupo:"Analg\xE9sico",idGrupo:"9cdeabac-e787-43b9-a040-165d2708cfd6",opcoes:[{id:"7019c75d-e1f7-42de-b04e-d39d0b2d50c1",descr:"Enoxaparina (20mg/0,2mL) 40 mg SC 1x/dia \xE0s 18 horas (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"933753aa-4a85-4cc1-a51a-b46f4f32de9b",descr:"Dalteparina (12.500-25.000UI/mL) 5.000 UI SC 1x/dia \xE0s 18 horas",recomendado:!1,favorito:!1,ordem:2},{id:"6d47ba7e-0c2b-459b-b0a2-3514da2a3e3c",descr:"Heparina n\xE3o-fracionada (5.000UI/0,25mL) 5.000 UI SC 8/8h ou 12/12h",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Preven\xE7\xE3o de doen\xE7a venosa profunda.",ordem:8},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"1f30d743-9216-40ae-acc3-ce620c94a9ac",opcoes:[{id:"c6cb882a-ed82-4e3f-96de-b93d5228d993",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"antiem\xE9tico",idGrupo:"b0d16405-a112-401b-8821-a63af0533373",opcoes:[{id:"8036752c-ebd1-42b4-8049-6e0fa6b62b23",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"8fa1c33a-5277-4c5e-9ee5-c3008004e7e5",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"adfc1722-b797-40c0-b90c-ccdd20475be2",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:9},{item:"Cuidados Gerais",grupos:[{grupo:"Analg\xE9sico",idGrupo:"862d4e58-de77-452d-b6e5-c05a13114281",opcoes:[{id:"5d3bba53-139b-4e67-b469-37928996a763",descr:"Manter cabeceira elevada a 30o",recomendado:!0,favorito:!0,ordem:1},{id:"59b349b9-4148-466f-ad1a-d58807e54a5f",descr:"O2 suplementar sob m\xE1scara ou cateter nasal a 6 L/min se SatO2 < 90%",recomendado:!1,favorito:!1,ordem:2},{id:"c3a9b091-acfe-42e1-98a6-f19a40421ed3",descr:"Glicemia capilar 6/6h ",recomendado:!1,favorito:!1,ordem:3},{id:"2fd9f8ff-6a7f-4f2b-84d4-9638304c5be6",descr:"Glicose Hipert\xF4nica 50% - 50mL (5 ampolas) se glicemia capilar < 70 mg/mL",recomendado:!1,favorito:!1,ordem:4},{id:"f0becf60-bb0e-4000-8dbc-6308d399e529",descr:"Insulina Regular SC conforme esquema: 141-200=2U / 201-250=4U / 251-300=6U / 301-350=8U / 351-400=10U / > 400=12U. Se > 400 ou < 70, avisar plantonista",recomendado:!1,favorito:!1,ordem:5},{id:"16153ada-f4e8-4e26-a86a-98a441db5758",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!1,favorito:!1,ordem:6},{id:"f48b4323-aa31-4ef9-9a9c-0b27c75326d0",descr:"Pesar diariamente em jejum",recomendado:!1,favorito:!1,ordem:7}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:10}],conceitosPraticos:[{conceito:'Perfil "congesto e quente": sinais de congest\xE3o (pulmonar ou sist\xEAmica) e boa perfus\xE3o perif\xE9rica. Tratar com diur\xE9tico e vasodilatador.',ordem:1},{conceito:'Perfil "congesto e frio": sinais de congest\xE3o (pulmonar ou sist\xEAmica) e m\xE1 perfus\xE3o perif\xE9rica. Tratar com inotr\xF3pico, vasodilatador (se PA sist\xF3lica > 90 mmHg) e diur\xE9tico quando houver melhora perfusional.',ordem:2},{conceito:"As medica\xE7\xF5es de uso cr\xF4nico para insufici\xEAncia card\xEDaca devem ser mantidas, salvo contraindica\xE7\xE3o espec\xEDfica.",ordem:3}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">Corresponde ao in\xEDcio r\xE1pido ou \xE0 piora de sinais e sintomas de insufici\xEAncia card\xEDaca (IC), resultando em necessidade de terapia urgente. Esta incapacidade card\xEDaca de eje\xE7\xE3o sangu\xEDnea pode ser precipitada por uma s\xEDndrome coronariana aguda, uma arritmia de maior gravidade, uma valvopatia, uma hipertens\xE3o arterial significativa ou mesmo por um quadro pr\xE9vio de insufici\xEAncia card\xEDaca agudizado pelas mesmas raz\xF5es descritas, por infec\xE7\xF5es ou pela modifica\xE7\xE3o do tratamento farmacol\xF3gico at\xE9 ent\xE3o utilizado.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* O grau m\xE1ximo de congest\xE3o pulmonar \xE9 conhecido como Edema Agudo de Pulm\xE3o, quando h\xE1 um desconforto respirat\xF3rio severo e estertora\xE7\xE3o pulmonar bilateral.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">
      <img src="https://d55mnj1ee66xh.cloudfront.net/academico/9529ff5d-d44a-44ab-832a-c8a188c4561e.jpg" alt="" width="100%" height="auto">
    </span>
  </em>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">As principais manifesta\xE7\xF5es da insufici\xEAncia card\xEDaca agudizada s\xE3o dispneia, taquipneia, ortopneia, estertora\xE7\xE3o pulmonar, 3</span> 
  <span style="font-weight: 400;">a</span> 
  <span style="font-weight: 400;">bulha card\xEDaca, turg\xEAncia jugular e edema perif\xE9rico.</span>
</p><p>
  <span style="font-weight: 400;">Seus principais diagn\xF3sticos diferenciais s\xE3o pneumonia, crise asm\xE1tica, edema agudo de pulm\xE3o n\xE3o-cardiog\xEAnico (por aumento da permeabilidade capilar verificado na S\xEDndrome da Ang\xFAstia Respirat\xF3ria Aguda - SARA) e tamponamento card\xEDaco.</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">A percep\xE7\xE3o da agudiza\xE7\xE3o \xE9 cl\xEDnica, mas, em um primeiro momento, \xE9 mandat\xF3ria a tentativa de identificar o fator precipitante, de forma que devem ser realizados:</span>
</p><p>
  <span style="font-weight: 400;">- Eletrocardiograma: identifica\xE7\xE3o de S\xEDndrome Coronariana Aguda e Arritmia;</span>
</p><p>
  <span style="font-weight: 400;">- Ecocardiograma: avalia\xE7\xE3o das fun\xE7\xF5es contr\xE1til e valvar;</span>
</p><p>
  <span style="font-weight: 400;">- Radiografia de T\xF3rax: sinais de congest\xE3o, cardiomegalia, efus\xE3o pleural ou mesmo causas n\xE3o-card\xEDacas para as manifesta\xE7\xF5es do paciente, como pneumonia;</span>
</p><p>
  <span style="font-weight: 400;">- Pept\xEDdeos natriur\xE9ticos: n\xEDveis normais (BNP &lt; 100 pg/mL; NT-proBNP &lt; 300 pg/mL) tornam o diagn\xF3stico de IC aguda muito improv\xE1vel;</span>
</p><p>
  <span style="font-weight: 400;">- Hemograma Completo: possibilidade de infec\xE7\xE3o;</span>
</p><p>
  <span style="font-weight: 400;">- Enzimas Card\xEDacas, em especial, a troponina (possibilidade de S\xEDndrome Coronariana Aguda)</span>
</p><p>
  <span style="font-weight: 400;">- Eletr\xF3litos (Na, K, Cl), ureia e creatinina: avalia\xE7\xE3o e acompanhamento da fun\xE7\xE3o renal (repetir a cada 1-2 dias durante interna\xE7\xE3o);</span>
</p><p>
  <span style="font-weight: 400;">- Gasometria Arterial (informa\xE7\xE3o ventilat\xF3ria e do status \xE1cido-b\xE1sico)</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* A utiliza\xE7\xE3o do cateter de art\xE9ria pulmonar (Swan-Ganz) n\xE3o deve ser feita de rotina, mas pode ser implementada em casos mais graves e refrat\xE1rios.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Naturalmente, na percep\xE7\xE3o de um fator precipitante espec\xEDfico, a abordagem ser\xE1 direcionada para sua resolu\xE7\xE3o, como na</span> 
  <a href="about:blank">
    <span style="font-weight: 400;">S\xEDndrome Coronariana Aguda</span>
  </a> 
  <span style="font-weight: 400;">ou</span> 
  <a href="about:blank">
    <span style="font-weight: 400;">Arritmia</span>
  </a> 
  <span style="font-weight: 400;">.&nbsp;</span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">Como em qualquer paciente de maior gravidade, a abordagem deve come\xE7ar com: (1) Avalia\xE7\xE3o e manuten\xE7\xE3o da perviedade de via a\xE9rea, respira\xE7\xE3o e circula\xE7\xE3o; (2) MOV (</span> 
  <span style="font-weight: 400;">M</span> 
  <span style="font-weight: 400;">onitoriza\xE7\xE3o Card\xEDaca Cont\xEDnua;</span> 
  <span style="font-weight: 400;">O</span> 
  <span style="font-weight: 400;">x\xEDmetro de Pulso; Acesso</span> 
  <span style="font-weight: 400;">V</span> 
  <span style="font-weight: 400;">enoso).</span>
</p><p>
  <br>
</p><p>
  <span style="font-weight: 400;">O paciente deve ser mantido em posi\xE7\xE3o sentada e o oxig\xEAnio suplementar sob m\xE1scara s\xF3 deve ser utilizado na presen\xE7a de hipoxemia (satura\xE7\xE3o &lt; 90%), ou seja, esta n\xE3o deve ser uma estrat\xE9gia de rotina, pois pode causar vasoconstric\xE7\xE3o e redu\xE7\xE3o do d\xE9bito card\xEDaco. H\xE1 indica\xE7\xE3o de ventila\xE7\xE3o n\xE3o-invasiva (como CPAP) em caso de hipoxemia refrat\xE1ria, bem como casos mais severos de desconforto respirat\xF3rio. Nestes casos, se houver hipotens\xE3o, redu\xE7\xE3o do n\xEDvel de consci\xEAncia ou sinais de fal\xEAncia respirat\xF3ria, o mais apropriado \xE9 a intuba\xE7\xE3o orotraqueal.</span>
</p><p>
  <span style="font-weight: 400;">De qualquer forma, h\xE1 um manejo organizado nas situa\xE7\xF5es de IC aguda com objetivo maior de al\xEDvio sintom\xE1tico.</span>
</p><p>
  <strong>- Organiza\xE7\xE3o Terap\xEAutica -</strong> 
  <span style="font-weight: 400;">H\xE1 um manejo organizado nas situa\xE7\xF5es de IC aguda com objetivo maior de al\xEDvio sintom\xE1tico.</span> 
  <span style="font-weight: 400;">Em termos pr\xE1ticos, \xE9 \xFAtil organizar a abordagem nos pacientes no Plant\xE3o M\xE9dico de acordo com o seu perfil cl\xEDnico durante o quadro mais agudo para facilitar a organiza\xE7\xE3o terap\xEAutica. Assim, o paciente \xE9 classificado pela presen\xE7a de:&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">(1) Congest\xE3o (pulmonar ou sist\xEAmica): congesto x seco;&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">(2) Hipoperfus\xE3o perif\xE9rica: frio (se presente) x quente (se ausente).&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">Desta forma, temos esses 4 grupos:</span>
</p><p>
  <span style="font-weight: 400;">- Congesto e quente (perfil B - mais comum): diur\xE9tico e vasodilatador</span>
</p><p>
  <span style="font-weight: 400;">- Congesto e frio (perfil C): inotr\xF3pico, vasodilatadores se PA sist\xF3lica &gt; 90 mmHg e diur\xE9tico quando houver melhora perfusional</span>
</p><p>
  <span style="font-weight: 400;">- Seco e frio (perfil D ou L): reposi\xE7\xE3o vol\xEAmica</span>
</p><p>
  <span style="font-weight: 400;">- Seco e quente (perfil A): paciente compensado</span>
</p><p>
  <strong>- Diur\xE9ticos: Os f\xE1rmacos principais \u2013</strong> 
  <span style="font-weight: 400;">O pilar terap\xEAutico para o al\xEDvio da congest\xE3o (pulmonar ou sist\xEAmica) \xE9 o uso intravenoso de</span> 
  <strong>diur\xE9tico de al\xE7a</strong> 
  <span style="font-weight: 400;">\u2013 como a furosemida, devendo ser iniciado o mais precocemente poss\xEDvel para todos os pacientes, excetuando-se aqueles com hipotens\xE3o severa ou choque. Embora a utiliza\xE7\xE3o de</span> 
  <em>
    <span style="font-weight: 400;">bolus</span>
  </em> 
  <span style="font-weight: 400;">intermitentes seja a estrat\xE9gia mais empregada, a infus\xE3o cont\xEDnua \xE9 igualmente eficaz. Em m\xE9dia, a diurese come\xE7a ap\xF3s 30 minutos da administra\xE7\xE3o da droga, com o pico ocorrendo em 1-2 horas.</span>
</p><p>
  <span style="font-weight: 400;">Em geral, inicia-se com 20-40 mg IV de furosemida 4/4h, mas, se n\xE3o houver resposta, a dose pode ser dobrada a cada 2 horas, at\xE9 o m\xE1ximo de 200 mg. J\xE1, para infus\xE3o cont\xEDnua, faz-se um</span> 
  <em>
    <span style="font-weight: 400;">bolus</span>
  </em> 
  <span style="font-weight: 400;">inicial de 40 mg IV, seguida de infus\xE3o a 10-40 mg/h (repetir</span> 
  <em>
    <span style="font-weight: 400;">bolus</span>
  </em> 
  <span style="font-weight: 400;">inicial a cada incremento na infus\xE3o). Outra op\xE7\xE3o para os casos que n\xE3o respondem inicialmente \xE9 adicionar um tiaz\xEDdico mesmo por via oral para potencializar o efeito diur\xE9tico (hidroclorotiazida 25 mg / clortalidona 12,5 mg / indapamida 2,5 mg).&nbsp;</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Se o paciente j\xE1 fazia uso pr\xE9vio de furosemida, a dose inicial deve ser maior ou igual \xE0 dose di\xE1ria habitual (at\xE9 o m\xE1ximo de 2,5x). Por exemplo, se a dose oral di\xE1ria era de 40 mg, a primeira dose IV pode ser de 40-100 mg)</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Se estas estrat\xE9gias diur\xE9ticas n\xE3o surtirem efeito, pode ser utilizada a ultrafiltra\xE7\xE3o renal com auxilio de um nefrologista.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Algumas pessoas optam pela infus\xE3o de dopamina em dose baixa (&lt; 3 mcg/Kg/min) buscando otimizar a perfus\xE3o renal e a diurese nos casos refrat\xE1rios, mas \xE9 uma medida de efic\xE1cia, at\xE9 hoje, question\xE1vel.</span>
  </em>
</p><p>
  <strong>- Vasodilatadores: 2</strong> 
  <strong>o</strong> 
  <strong>grupo farmacol\xF3gico mais usado \u2013</strong> 
  <span style="font-weight: 400;">Ajudam na melhora da congest\xE3o pulmonar e sist\xEAmica, al\xE9m aumentar o d\xE9bito card\xEDaco e otimizar a resposta diur\xE9tica. Por estas raz\xF5es, devem ser prescritos para al\xEDvio sintom\xE1tico desde que n\xE3o haja hipotens\xE3o. Nos casos de IC aguda hipertensiva, estas drogas tornam-se absolutamente priorit\xE1rias. Em casos mais brandos de HAS, pode-se utilizar o captopril na abordagem inicial, j\xE1 que tamb\xE9m tem a\xE7\xE3o vasodilatadora com redu\xE7\xE3o da p\xF3s-carga. As op\xE7\xF5es intravenosas s\xE3o:</span>
</p><p>
  <span style="font-weight: 400;">(1) NITROPRUSSIATO DE S\xD3DIO</span>
</p><p>
  <span style="font-weight: 400;">Dilui\xE7\xE3o: 2 mL (50 mg) de Nitroprussiato de s\xF3dio + 250 mL de SG 5%</span>
</p><p>
  <span style="font-weight: 400;">Administra\xE7\xE3o: In\xEDcio com 0,25 mcg/kg/min, aumentando 1-2 mL/h a cada 5-10 min at\xE9 o m\xE1ximo de 10 mcg/Kg/min</span>
</p><p>
  <span style="font-weight: 400;">(2) NITROGLICERINA</span>
</p><p>
  <span style="font-weight: 400;">Dilui\xE7\xE3o: 5 mL (25 mg) de Nitroglicerina + 245 mL de SG 5%</span>
</p><p>
  <span style="font-weight: 400;">Administra\xE7\xE3o: In\xEDcio com 10-20 mcg/min (6-12 mL/h), aumentando 3-6 mL/h a cada 5-10 min se necess\xE1rio at\xE9 200 mcg/min (120 ml/h)</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* O nesiritide (bolus de 2mcg/Kg, seguido de infus\xE3o de 0,01 mcg/Kg/min) tem sido menos usado por sua meia-vida mais longa.</span>
  </em>
</p><p>
  <strong>- Uso de inotr\xF3picos: hipotens\xE3o severa ou choque \u2013</strong> 
  <span style="font-weight: 400;">Nos casos de press\xE3o sist\xF3lica &lt; 90 mmHg ou sinais de choque (extremidades frias, confus\xE3o mental), est\xE1 indicada a infus\xE3o de drogas que aumentem a for\xE7a de contra\xE7\xE3o card\xEDaca, como:</span>
</p><p>
  <span style="font-weight: 400;">(1) DOBUTAMINA</span>
</p><p>
  <span style="font-weight: 400;">Dilui\xE7\xE3o (exemplo): 60 mL (750 mg) de Dobutamina + 190 mL de SG 5%</span> 
  <em>
    <span style="font-weight: 400;">(solu\xE7\xE3o: 3000 mcg/mL)</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Administra\xE7\xE3o: In\xEDcio com 2,5 mcg/kg/min, aumentando a cada 10 min at\xE9 o m\xE1ximo de 20 mcg/Kg/min</span>
</p><p>
  <span style="font-weight: 400;">(2) MILRINONA</span>
</p><p>
  <span style="font-weight: 400;">Dilui\xE7\xE3o: 20 mL (20 mg) de Milrinona + 80 mL de SG 5% ou SF 0,9%</span> 
  <em>
    <span style="font-weight: 400;">(solu\xE7\xE3o: 200 mcg/mL)</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Administra\xE7\xE3o: Ataque opcional de 50 mcg/Kg em 10 minutos, seguido de 0,375-0,75 mcg/Kg/min (necessita de corre\xE7\xE3o em caso de insufici\xEAncia renal)</span>
</p><p>
  <span style="font-weight: 400;">(3) LEVOSIMENDAM</span>
</p><p>
  <span style="font-weight: 400;">Dilui\xE7\xE3o: 5 mL (12,5 mg) de Levosimendan + 245 mL de SG 5%</span> 
  <em>
    <span style="font-weight: 400;">(solu\xE7\xE3o: 50 mcg/mL)</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Administra\xE7\xE3o: Ataque 6-12 mcg/Kg em 10 minutos, seguido de 0,05-0,2 mcg/Kg/min</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Milrinona e Levosimendan devem ser evitados se PA sist\xF3lica &lt; 90 mmHg porque, como t\xEAm efeito vasodilatador, podem agravar a hipotens\xE3o. Como essas drogas n\xE3o agem via receptores beta-adren\xE9rgicos, o efeito delas n\xE3o \xE9 reduzido por beta-bloqueador (como ocorre com a dobutamina), logo seu grande uso \xE9 quando se julga que um beta-bloqueio possa ter contribui\xE7\xE3o na hipoperfus\xE3o.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">** A dopamina \xE9 usada por alguns como op\xE7\xE3o inotr\xF3pica, mas ela n\xE3o \xE9 citada pelas diretrizes Brasileira e Americana.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">A manuten\xE7\xE3o da hipotens\xE3o mesmo com a otimiza\xE7\xE3o destes agentes inotr\xF3picos \xE9 uma indica\xE7\xE3o do uso de vasopressores, como dopamina em altas doses (&gt; 5 mcg/Kg/min) ou noradrenalina. Em casos ainda mais graves, deve-se avaliar a possibilidade da instala\xE7\xE3o de um suporte mec\xE2nico, como o bal\xE3o intra-a\xF3rtico.</span>
</p><p>
  <strong>- Outras drogas \u2013</strong> 
  <span style="font-weight: 400;">Em pacientes agitados, pode ser necess\xE1ria a administra\xE7\xE3o de f\xE1rmacos ansiol\xEDticos e sedativos, sendo os benzodiazep\xEDnicos a op\xE7\xE3o mais segura.</span>
</p><p>
  <span style="font-weight: 400;">Se houver hiponatremia grave persistente, pode ser administrado um antagonista de vasopressina por curto per\xEDodo caso haja disponibilidade: tolvaptan VO, iniciando com 15 mg 1x/dia. Caso a varia\xE7\xE3o da natremia seja &lt; 5 mEq/L em 24h, considerar aumento para 30 mg/dia, podendo chegar a, no m\xE1ximo, 60 mg/dia. Se a varia\xE7\xE3o da natremia for &gt; 8 mEq/L em 8h ou &gt; 12 mEq/L em 24h, deve-se suspender a pr\xF3xima dose e/ou aumentar a infus\xE3o de solu\xE7\xE3o hipot\xF4nica.</span>
</p><p>
  <strong>- N\xE3o esquecer: Profilaxia antitromb\xF3tica \u2013</strong> 
  <span style="font-weight: 400;">Para todo paciente admitido por IC aguda, deve ser prescrita profilaxia para complica\xE7\xE3o tromb\xF3tica.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Conduta quanto \xE0 medica\xE7\xE3o de uso cr\xF4nico -</strong> 
  <span style="font-weight: 400;">Muitos pacientes com IC aguda s\xE3o, na verdade, portadores de IC cr\xF4nica agudizada. Desta forma, s\xE3o usu\xE1rios cr\xF4nicos de um tratamento farmacol\xF3gico oral direcionado para a fal\xEAncia card\xEDaca e que deve ser mantido caso n\xE3o haja contraindica\xE7\xE3o (como hipercalemia e disfun\xE7\xE3o renal para IECA) ou instabilidade hemodin\xE2mica (hipotens\xE3o sintom\xE1tica, hipoperfus\xE3o, bradicardia) \u2013 inclusive os beta-bloqueadores podem permanecer na fase aguda, exceto no caso de choque cardiog\xEAnico. Se esse tratamento for interrompido na interna\xE7\xE3o, o seu retorno deve ser feito ap\xF3s um per\xEDodo de 48h de estabiliza\xE7\xE3o cl\xEDnica.</span>
</p><p>
  <span style="font-weight: 400;">Se o paciente n\xE3o fazia uso de um tratamento cr\xF4nico, a interna\xE7\xE3o deve servir como uma oportunidade para inici\xE1-lo desde que haja estabilidade hemodin\xE2mica. O cuidado \xE9 ainda mais especial no momento de iniciar beta-bloqueador, o que s\xF3 deve ser feito ap\xF3s a descontinua\xE7\xE3o de diur\xE9tico venoso, vasodilatadores e inotr\xF3picos.</span>
</p><p>
  <strong>- Achar que morfina \xE9 medica\xE7\xE3o obrigat\xF3ria \u2013</strong> 
  <span style="font-weight: 400;">Embora possa reduzir a dispneia e a ansiedade, h\xE1 um risco importante da morfina (2-4 mg IV) induzir n\xE1usea e depress\xE3o respirat\xF3ria. Assim, seu uso s\xF3 pode ser considerado em casos de desconforto respirat\xF3rio grave por edema agudo de pulm\xE3o.</span>
</p><p>
  <strong>- Associa\xE7\xE3o de solu\xE7\xE3o salina hipert\xF4nica e furosemida \u2013</strong> 
  <span style="font-weight: 400;">Embora alguns sugiram que o uso de solu\xE7\xE3o salina hipert\xF4nica em associa\xE7\xE3o com a furosemida (NaCl 4,6% a 7,5% 100-150 mL em 20 a 30 minutos), poderia otimizar o preenchimento do compartimento intravascular, melhorando a perfus\xE3o renal e a a\xE7\xE3o diur\xE9tica, a seguran\xE7a e a efici\xEAncia desta abordagem ainda s\xE3o incertas.</span>
</p><p>
  <strong>- Desmame de agente venosos \u2013</strong> 
  <span style="font-weight: 400;">Ap\xF3s a estabilidade hemodin\xE2mica, os vasodilatadores e inotr\xF3picos venosos at\xE9 ent\xE3o utilizados devem ser retirados de forma gradual e substitu\xEDdos por agentes orais, evitando um efeito "rebote". Dessa forma, doses crescentes de nitrato devem ser introduzidas para o desmame da nitroglicerina. Para o desmame do nitroprussiato, pode ser usado IECA ou a combina\xE7\xE3o de hidralazina com nitrato. Como n\xE3o h\xE1 agentes inotr\xF3picos orais dispon\xEDveis e a utiliza\xE7\xE3o de vasodilatadores por si s\xF3 j\xE1 \xE9 capaz de incrementar o d\xE9bito card\xEDaco, o desmame dos agentes inotr\xF3picos tamb\xE9m \xE9 realizado frequentemente com o uso de vasodilatadores orais: mais uma vez com doses crescentes de IECA ou a combina\xE7\xE3o hidralazina com nitrato.</span>
</p>`,ordem:5},{titulo:`SUGEST\xD5ES 
    BIBLIOGR\xC1FICAS`,texto:`<ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Heidenreich PA, Bozkurt B, Aguilar D, Allen LA, et al. 2022 AHA/ACC/HFSA guideline for the management of heart failure: a report of the American College of Cardiology/American Heart Association Joint Committee on Clinical Practice Guidelines.</span> 
    <em>
      <span style="font-weight: 400;">Circulation</span>
    </em> 
    <span style="font-weight: 400;">2022;145:e895\u2013e1032.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">McDonagh TA, Metra M, Adamo M, Gardner RS, et al. 2021 ESC Guidelines for the diagnosis and treatment of acute and chronic heart failure: Developed by the Task Force for the diagnosis and treatment of acute and chronic heart failure of the European Society of Cardiology (ESC) With the special contribution of the Heart Failure Association (HFA) of the ESC.</span> 
    <em>
      <span style="font-weight: 400;">European Heart Journal</span>
    </em> 
    <span style="font-weight: 400;">2021; 42(36):3599\u20133726.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Comit\xEA Coordenador da Diretriz de Insufici\xEAncia Card\xEDaca. Diretriz Brasileira de Insufici\xEAncia Card\xEDaca Cr\xF4nica e Aguda. Arq Bras Cardiol. 2018; 111(3):436-539</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Montera MW, Almeida RA, Tinoco EM, Rocha RM, Moura LZ, R\xE9a-Neto A, et al. Sociedade Brasileira de Cardiologia. II Diretriz Brasileira de Insufici\xEAncia Card\xEDaca Aguda. Arq Bras Cardiol.2009;93(3 supl.3):1-65</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Ponikowski P, Voors AA, Anker SD, Bueno H, Cleland JG et al. 2016 ESC Guidelines for the diagnosis and treatment of acute and chronic heart failure: The Task Force for the diagnosis and treatment of acute and chronic heart failure of the&nbsp; European Society of Cardiology (ESC) - Developed with the special contribution of the Heart Failure Association (HFA) of the ESC.</span> 
    <em>
      <span style="font-weight: 400;">Eur Heart J</span>
    </em> 
    <span style="font-weight: 400;">. 2016;37:2129-2200.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Yancy CW, Jessup M, Bozkurt B, Butler J, Casey DE Jr, Drazner MH, Fonarow GC, Geraci SA, Horwich T, Januzzi JL, Johnson MR, Kasper EK, Levy WC, Masoudi FA, McBride PE, McMurray JJV, Mitchell JE, Peterson PN, Riegel B, Sam F, Stevenson LW, Tang WHW, Tsai EJ, Wilkoff BL. 2013 ACCF/AHA guideline for the management of heart failure: a report of the American College of Cardiology Foundation/American Heart Association Task Force on Practice Guidelines. Circulation 2013;128:e240-e327.</span>
  </li>
</ol>`,ordem:6}],videos:[{id:"3f3e4c17-cc5d-4522-8736-33002b7560d4",titulo:"Insufici\xEAncia Card\xEDaca",duracao:5,thumbUrl:"https://i.vimeocdn.com/video/716648011_1920x1273.jpg?r=pad"}],fluxogramas:[{id:"707f37a3-2825-4b08-b466-b43714ed128e",nome:"Fluxograma da Insuficiencia Cardiaca  Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/0b81c3c9-2a99-422c-92bd-f09d7062d4a3.jpg",orientacao:"horizontal"},{id:"7ddbafbc-6ea0-4aec-8fab-bb04b4a21345",nome:"Fluxograma da Insuficiencia Cardiaca  Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/cf3034e3-d13a-4dbd-8d15-5fb23eeb24e7.jpg",orientacao:"vertical"}],tags:["Edema agudo de pulm\xE3o","EAP","ICC"]},{id:"b71b16a4-6bee-4d03-8015-db52e359840d",nome:"Intoxica\xE7\xE3o por Benzodiazep\xEDnico",categoria:1,termosDeBusca:"intoxicacao por benzodiazepinico, ",favoritado:!1,ordem:0,especialidades:[{nome:"MEDICINA INTERNA"}],prescricoes:[],topicos:[{titulo:"Intoxica\xE7\xE3o por Benzodiazep\xEDnico",texto:"",ordem:1},{titulo:`CONCEITO 
  &nbsp;`,texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Os benzodiazep\xEDnicos s\xE3o drogas hipn\xF3tico-sedativas amplamente utilizadas em nosso meio para o tratamento de dist\xFArbios de ansiedade, s\xEDndromes de abstin\xEAncia e ins\xF4nia, al\xE9m de serem \xFAteis para a seda\xE7\xE3o em alguns procedimentos m\xE9dicos. O termo "intoxica\xE7\xE3o" se refere \xE0 overdose desse tipo de medica\xE7\xE3o, podendo ser acidental ou intencional. Inclusive, essa classe farmacol\xF3gica \xE9 uma das mais utilizadas em casos de tentativa de suic\xEDdio.</span>
</p>`,ordem:2},{titulo:"MANIFESTA\xC7\xD5ES",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Como os benzodiazep\xEDnicos s\xE3o drogas depressoras centrais - com a\xE7\xE3o similar ao \xE1lcool - os pacientes intoxicados apresentam-se com redu\xE7\xE3o do n\xEDvel de consci\xEAncia (principal achado; cabe ressaltar que ele n\xE3o vem acompanhado de altera\xE7\xF5es dos sinais vitais, geralmente), ataxia, fala arrastada e confus\xE3o mental. A depress\xE3o respirat\xF3ria s\xF3 costuma estar presente quando h\xE1 associa\xE7\xE3o com outra subst\xE2ncia depressora, como \xE1lcool ou opioides, ou ap\xF3s a infus\xE3o intravenosa (para seda\xE7\xE3o, por exemplo). Perceba, portanto, que a overdose oral n\xE3o costuma ser grave.</span>
</p>`,ordem:3},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Na pr\xE1tica, o diagn\xF3stico acaba sendo suspeitado pela associa\xE7\xE3o das manifesta\xE7\xF5es cl\xEDnicas com a hist\xF3ria ou suspeita de exposi\xE7\xE3o medicamentosa. Geralmente, testes espec\xEDficos para intoxica\xE7\xE3o n\xE3o s\xE3o utilizados. Al\xE9m de n\xE3o serem amplamente dispon\xEDveis, esse tipo de avalia\xE7\xE3o dificilmente muda a conduta a ser proposta. A pesquisa da droga (mais precisamente, de seus metab\xF3litos) na urina, por exemplo, n\xE3o costuma ser t\xE3o \xFAtil, pois pode "positivar" com o simples uso regular da medica\xE7\xE3o.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Durante a abordagem de uma pessoa com suspeita de intoxica\xE7\xE3o por benzodiazep\xEDnico, \xE9 importante (1) avaliar a</span> 
  <span style="text-decoration: underline;">
    <span style="font-weight: 400;">glicemia capilar</span>
  </span> 
  <span style="font-weight: 400;">, para afastar a hipoglicemia como causa da altera\xE7\xE3o do estado mental; (2) solicitar um</span> 
  <span style="text-decoration: underline;">
    <span style="font-weight: 400;">eletrocardiograma</span>
  </span> 
  <span style="font-weight: 400;">, pela possibilidade de cointoxica\xE7\xE3o com drogas que alterem o intervalo QT e o complexo QRS; (3) pesquisar o</span> 
  <span style="text-decoration: underline;">
    <span style="font-weight: 400;">n\xEDvel s\xE9rico de paracetamol (acetaminofeno), salicilato e etanol</span>
  </span> 
  <span style="font-weight: 400;">, se dispon\xEDvel, para excluir a possibilidade de cointoxica\xE7\xE3o, que \xE9 relativamente frequente; (4)</span> 
  <span style="text-decoration: underline;">
    <span style="font-weight: 400;">teste de gravidez</span>
  </span> 
  <span style="font-weight: 400;">, para mulheres em idade f\xE9rtil.</span> 
  <br>
</p>`,ordem:4},{titulo:"CONDUTA",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Aqui, h\xE1 um ponto muito interessante para ser colocado! A intoxica\xE7\xE3o por benzodiazep\xEDnicos tem um ant\xEDdoto: o</span> 
  <strong>flumazenil</strong> 
  <span style="font-weight: 400;">, um antagonista competitivo dos seus receptores! Por\xE9m, seu uso \xE9 ainda controverso nos casos de overdose oral, exatamente por serem situa\xE7\xF5es com mortalidade muito baixa, na qual os riscos do ant\xEDdoto (em especial, a precipita\xE7\xE3o de um quadro convulsivo e o surgimento de crises de abstin\xEAncia em usu\xE1rios cr\xF4nicos de benzodiazep\xEDnico) podem ser maiores que seus benef\xEDcios de abrevia\xE7\xE3o do quadro intoxicante.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A</span> 
  <span style="text-decoration: underline;">
    <span style="font-weight: 400;">indica\xE7\xE3o mais aceita</span>
  </span> 
  <span style="font-weight: 400;">\xE9 para a revers\xE3o da seda\xE7\xE3o ap\xF3s algum procedimento em indiv\xEDduos que n\xE3o fazem uso cr\xF4nico de benzodiazep\xEDnico. A presen\xE7a de depress\xE3o respirat\xF3ria ou incapacidade de prote\xE7\xE3o da via a\xE9rea (pela redu\xE7\xE3o do sens\xF3rio) s\xE3o consideradas indica\xE7\xF5es</span> 
  <span style="text-decoration: underline;">
    <span style="font-weight: 400;">controversas</span>
  </span> 
  <span style="font-weight: 400;">.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Em crian\xE7as, o flumazenil deve ser usado quando houver depress\xE3o grave do sistema nervoso central ou ataxia isolada.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">As seguintes</span> 
  <span style="text-decoration: underline;">
    <span style="font-weight: 400;">contraindica\xE7\xF5es</span>
  </span> 
  <span style="font-weight: 400;">s\xE3o citadas na literatura: (1) presen\xE7a ou suspeita de crise epil\xE9ptica; (2) ingest\xE3o concomitante de droga "pr\xF3-convlusiva" (ex.: tric\xEDclicos ou bupropiona); (3) uso de benzodiazep\xEDnico para tratar uma crise convulsiva ou</span> 
  <em>
    <span style="font-weight: 400;">status epilepticus</span>
  </em> 
  <span style="font-weight: 400;">. Alguns textos indicam que o flumazenil tamb\xE9m n\xE3o deve ser feito em pessoas que t\xEAm toler\xE2ncia/depend\xEAncia aos benzodiazep\xEDnicos.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">Se houver indica\xE7\xE3o, qual deve ser a dose do flumazenil?</span>
  </em>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">-</span> 
  <strong>Adultos</strong> 
  <span style="font-weight: 400;">: dose inicial de 0,2 mg, em infus\xE3o intravenosa lenta (ao longo de 1-2 minutos). Se n\xE3o houver resposta, que \xE9 esperada em 2-5 minutos, pode-se fazer, a cada 1-2 minutos, novas infus\xF5es de 0,2 a 0,5 mg sem ultrapassar a dose inicial acumulada de 1 mg (dose m\xE1xima acumulada de 3 mg em 1 hora). Se ainda assim n\xE3o houver melhora, o mais prov\xE1vel \xE9 que a seda\xE7\xE3o do paciente seja por outra raz\xE3o...</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">-</span> 
  <strong>Crian\xE7as</strong> 
  <span style="font-weight: 400;">: dose inicial de 0,01-0,02 mg/Kg (at\xE9 o m\xE1ximo de 0,2-0,3 mg), em infus\xE3o intravenosa lenta, que pode ser repetida, pelo menos, a cada minuto, at\xE9 a dose m\xE1xima de 1 mg ou 0,05 mg/Kg (o que for menor).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Assim como em qualquer quadro de intoxica\xE7\xE3o, \xE9 importante manter o paciente sob monitoriza\xE7\xE3o. A descontamina\xE7\xE3o com carv\xE3o ativado ou lavagem g\xE1strica n\xE3o \xE9 preconizada.</span>
</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- Infus\xE3o r\xE1pida de flumazenil: convuls\xE3o \u2013</strong> 
  <span style="font-weight: 400;">O grande efeito adverso do flumazenil \xE9 a possibilidade de induzir convuls\xF5es. Esse risco \xE9 maior na associa\xE7\xE3o com intoxica\xE7\xE3o por antidepressivos tric\xEDclicos ou bupropiona. Se houver convuls\xE3o, ela acaba sendo tratada com diazepam 20 mg IV.</span>
</p><p style="text-align: justify;">
  <strong>- Possibilidade resseda\xE7\xE3o (ou seda\xE7\xE3o residual) \u2013</strong> 
  <span style="font-weight: 400;">Essa \xE9 uma importante armadilha que deve ser lembrada em todos os casos em que se usa um ant\xEDdoto para uma intoxica\xE7\xE3o: a possibilidade da meia-vida do agente intoxicante ser superior a do ant\xEDdoto. A dura\xE7\xE3o do flumazenil \xE9 curta (45 a 80 min), podendo ser menor que a de alguns benzodiazep\xEDnicos (sobretudo, os de longa e intermedi\xE1ria dura\xE7\xE3o), havendo o risco de uma resseda\xE7\xE3o. Veja a variedade de perfil de alguns desses f\xE1rmacos:</span>
</p><ol>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">meia-vida curta: midazolam;</span>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">meia-vida intermedi\xE1ria: alprazolam, lorazepam;</span>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">meia-vida longa: diazepam, clonazepam, flurazepam, clordiazep\xF3xido. 
      <br>
      <br>
    </span> 
    <span style="font-weight: 400;">
      <img src="https://share1.cloudhq-mkt3.net/71c3eba38f0d61.png" alt="" width="635" height="335"> 
      <br>
    </span>
  </li>
</ol><p style="text-align: justify;">
  <span style="font-weight: 400;">Se houver resseda\xE7\xE3o, nova administra\xE7\xE3o de flumazenil deve ser feita, respeitando os limites que citamos acima.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">Sadock BJ, Sadock VA, Ruiz P. Kaplan &amp; Sadock Comp\xEAndio de Psiquiatria Ci\xEAncia do Comportamento e Psiquiatria Cl\xEDnica, 11a edi\xE7\xE3o. Artmed. 2017.</span> 
    <span style="font-weight: 400;">
      <br>
      <br>
    </span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">Associa\xE7\xE3o Brasileira de Psiquiatria, Associa\xE7\xE3o Brasileira de Neurologia. Abuso e Depend\xEAncia de benzodiazep\xEDnicos.</span> 
    <em>
      <span style="font-weight: 400;">Projeto Diretrizes da Associa\xE7\xE3o Me\u0301dica Brasileira e Conselho Federal de Medicina</span>
    </em> 
    <span style="font-weight: 400;">. 2013.</span> 
    <span style="font-weight: 400;">
      <br>
      <br>
    </span>
  </li>
  <li style="font-weight: 400; text-align: justify;" aria-level="1">
    <span style="font-weight: 400;">Sociedade Brasileira de Pediatria. Tratado de Pediatria - volume 1, 5a edi\xE7\xE3o. Manole. 2022.</span>
  </li>
</ol>`,ordem:6}],videos:[],fluxogramas:[],tags:[]},{id:"b0806d80-d694-4003-bdf9-414ce8bc7d69",nome:"Intoxica\xE7\xE3o por Coca\xEDna",categoria:1,termosDeBusca:"intoxicacao por cocaina, ",favoritado:!1,ordem:0,especialidades:[{nome:"MEDICINA INTERNA"}],prescricoes:[],topicos:[{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A coca\xEDna \xE9 uma potente subst\xE2ncia estimuladora que causa, principalmente, altera\xE7\xF5es cardiovasculares e neurol\xF3gicas. O termo "intoxica\xE7\xE3o" se refere \xE0 sua overdose.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Essa droga possui algumas vias de administra\xE7\xF5es conhecidas e elas interferem, diretamente, no potencial de intoxica\xE7\xE3o e na intensidade do quadro. A mais cl\xE1ssica \xE9 a intranasal; atrav\xE9s dela, a subst\xE2ncia \xE9 absorvida pela mucosa local. A intravenosa \xE9 outra forma de utiliza\xE7\xE3o e, de algumas d\xE9cadas para c\xE1, a inalat\xF3ria (fumo) passou a se tornar uma grande preocupa\xE7\xE3o - a coca\xEDna \xE9 um dos componentes do</span> 
  <strong>
    <em>crack</em>
  </strong> 
  <span style="font-weight: 400;">, droga com potencial devastador na vida dos seus usu\xE1rios. Essas tr\xEAs vias apresentam alto potencial de intoxica\xE7\xE3o! Por outro lado, a oral, muito usada em pa\xEDses andinos para combater os efeitos da altitude, por exemplo, tem uma taxa de absor\xE7\xE3o baixa e, assim, uma chance pequena de intoxica\xE7\xE3o.&nbsp;</span>
</p>`,ordem:1},{titulo:"MANIFESTA\xC7\xD5ES",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">As principais manifesta\xE7\xF5es da intoxica\xE7\xE3o por coca\xEDna s\xE3o</span> 
  <span style="font-weight: 400;">cardiovasculares</span> 
  <span style="font-weight: 400;">e</span> 
  <span style="font-weight: 400;">neurol\xF3gicas</span>
  <span style="font-weight: 400;">.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Ao inibir a recapta\xE7\xE3o de catecolaminas, a droga gera uma s\xEDndrome hiperadren\xE9rgica (simpaticomim\xE9tica), que se expressa com taquicardia, hipertens\xE3o, vasoconstri\xE7\xE3o coronariana, podendo levar \xE0 isquemia mioc\xE1rdica, e outras complica\xE7\xF5es cardiovasculares, como dissec\xE7\xE3o a\xF3rtica e acidente vascular encef\xE1lico isqu\xEAmico ou hemorr\xE1gico. A midr\xEDase e a diaforese tamb\xE9m s\xE3o efeitos esperados.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Ao aumentar a concentra\xE7\xE3o de neurotransmissores excitat\xF3rios, a intoxica\xE7\xE3o tamb\xE9m pode dar origem a agita\xE7\xE3o psicomotora (com possibilidade de hipertermia), cefaleia, euforia e crises convulsivas. Alguns indiv\xEDduos podem apresentar um quadro de</span> 
  <em>
    <span style="font-weight: 400;">delirium</span>
  </em> 
  <span style="font-weight: 400;">induzido por coca\xEDna (</span> 
  <em>
    <span style="font-weight: 400;">excited delirium</span>
  </em> 
  <span style="font-weight: 400;">), caracterizado por intensa agita\xE7\xE3o, agressividade, hipertermia e outras altera\xE7\xF5es auton\xF4micas. H\xE1 maior risco de mortalidade nestes casos.</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Em tese, seria poss\xEDvel a mensura\xE7\xE3o de metab\xF3litos da coca\xEDna no sangue e na urina, principalmente, mas, em geral, tal estrat\xE9gia n\xE3o \xE9 utilizada, pois a positividade do teste n\xE3o indica, necessariamente, intoxica\xE7\xE3o aguda pela droga, j\xE1 que seus metab\xF3litos permanecem por dias na urina.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O diagn\xF3stico \xE9 feito com base na uni\xE3o das manifesta\xE7\xF5es cl\xEDnicas t\xEDpicas com o relato de uso da subst\xE2ncia.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Durante a abordagem de uma pessoa com suspeita de intoxica\xE7\xE3o por coca\xEDna, \xE9 importante (1) avaliar a</span> 
  <span style="font-weight: 400;">glicemia capilar</span> 
  <span style="font-weight: 400;">, para afastar a hipoglicemia como causa da altera\xE7\xE3o do estado mental; (2) solicitar um</span> 
  <span style="font-weight: 400;">eletrocardiograma</span> 
  <span style="font-weight: 400;">, para avaliar eventuais altera\xE7\xF5es compat\xEDveis com isquemia mioc\xE1rdica ou arritmias e a possibilidade de cointoxica\xE7\xE3o com drogas que alterem o intervalo QT e o complexo QRS; (3) pesquisar o</span> 
  <span style="font-weight: 400;">n\xEDvel s\xE9rico de paracetamol (acetaminofeno) e salicilato</span> 
  <span style="font-weight: 400;">, se dispon\xEDvel, para excluir a possibilidade de cointoxica\xE7\xE3o por essas subst\xE2ncias; (4)</span> 
  <span style="font-weight: 400;">teste de gravidez</span> 
  <span style="font-weight: 400;">, para mulheres em idade f\xE9rtil.&nbsp;</span>
</p>`,ordem:3},{titulo:"CONDUTA",texto:`<p style="text-align: justify;">
  <strong>- Suporte -</strong> 
  <span style="font-weight: 400;">Como em qualquer intoxica\xE7\xE3o, a prioridade inicial \xE9 o suporte cl\xEDnico, com especial aten\xE7\xE3o \xE0 ventila\xE7\xE3o e ao aparelho circulat\xF3rio. Se houver necessidade de intuba\xE7\xE3o, deve-se evitar o uso de succinilcolina (por compartilhar a mesma via de metaboliza\xE7\xE3o plasm\xE1tica da coca\xEDna, sua utiliza\xE7\xE3o pode prolongar os efeitos de ambas; \xE9 como se a enzima respons\xE1vel pelo processo ficasse "mais ocupada", j\xE1 que teria que metabolizar as duas subst\xE2ncias).</span>
</p><p style="text-align: justify;">
  <strong>- Agita\xE7\xE3o psicomotora \u2013</strong> 
  <span style="font-weight: 400;">Para o manejo da agita\xE7\xE3o, devemos prescrever</span> 
  <strong>benzodiazep\xEDnicos</strong> 
  <span style="font-weight: 400;">, classe farmacol\xF3gica que tamb\xE9m \xE9 \xFAtil para controlar eventuais crises convulsivas e a pr\xF3pria estimula\xE7\xE3o simp\xE1tica, o que, muitas vezes, j\xE1 \xE9 suficiente para aliviar os sintomas cardiovasculares. Em geral, opta-se pelo diazepam intravenoso (dose inicial de 10 mg, seguida de 5-10 mg a cada 3-5 minutos, at\xE9 a estabiliza\xE7\xE3o do quadro) ou, mais raramente, por outras op\xE7\xF5es orais (clonazepam, clordiazep\xF3xido ou o pr\xF3prio diazepam), se o paciente estiver colaborativo; o midazolam intramuscular tamb\xE9m \xE9 uma possibilidade. Se n\xE3o houver melhora da agita\xE7\xE3o, pode-se utilizar antipsic\xF3ticos, como o haloperidol. Caso haja hipertermia associada, \xE9 preciso lan\xE7ar m\xE3o de estrat\xE9gias de resfriamento, visando uma temperatura &lt; 38,8</span> 
  <span style="font-weight: 400;">\xBA</span> 
  <span style="font-weight: 400;">C, pelo menos.</span>
</p><p style="text-align: justify;">
  <strong>- Descontamina\xE7\xE3o \u2013</strong> 
  <span style="font-weight: 400;">Para reduzir a absor\xE7\xE3o da droga, deve-se remover qualquer p\xF3 vis\xEDvel em narina e orofaringe atrav\xE9s de irriga\xE7\xE3o nasal com solu\xE7\xE3o salina. Como dito anteriormente, a intoxica\xE7\xE3o por via oral recreativa \xE9 improv\xE1vel, de forma que o uso de carv\xE3o ativado (1 g/Kg at\xE9 o m\xE1ximo de 50 g \u2013 4/4h) s\xF3 se justifica nos pacientes que fizeram ingest\xE3o de pacotes de coca\xEDna.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- Utiliza\xE7\xE3o de beta-bloqueador \u2013</strong> 
  <span style="font-weight: 400;">Essa \xE9 uma armadilha perigos\xEDssima! Ao aumentar os n\xEDveis de catecolaminas, a coca\xEDna provoca uma intensa a\xE7\xE3o adren\xE9rgica, tanto nos receptores alfa, quanto nos beta. Assim, o uso de um beta-bloqueador faria com que o est\xEDmulo adren\xE9rgico fosse direcionado, apenas, para os receptores alfa, cuja resposta \xE9 vasoconstritora. Desse modo, o uso dessas medica\xE7\xF5es</span> 
  <strong>deve ser evitado</strong> 
  <span style="font-weight: 400;">. Mesmo o labetalol, que possui a\xE7\xE3o mista alfa e beta-bloqueadora, n\xE3o tem seguran\xE7a garantida na intoxica\xE7\xE3o por coca\xEDna, at\xE9 porque o efeito alfa-bloqueador \xE9 menor que o beta-bloqueador (raz\xE3o 1:7).</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">Associa\xE7\xE3o Brasileira de Psiquiatria. Abuso e Depend\xEAncia do Crack.</span> 
    <em>
      <span style="font-weight: 400;">Projeto Diretrizes da Associa\xE7\xE3o Me\u0301dica Brasileira e Conselho Federal de Medicina</span>
    </em> 
    <span style="font-weight: 400;">. 2011.</span> 
    <span style="font-weight: 400;">
      <br>
    </span>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">American Psychiatric Association. American Psychiatric Association Practice Guidelines for the Treatment of Psychiatric Disorders: Compendium 2006. American Psychiatric Pub; 2006. Dispon\xEDvel em:</span> 
    <a href="http://www.psych.org/psych_pract/treatg/pg/SUD2ePG_04-28-06.pdf">
      <span style="font-weight: 400;">http://www.psych.org/psych_pract/treatg/pg/SUD2ePG_04-28-06.pdf</span>
    </a>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">Silva LR, Fernandino LS, Gomes PA, Xavier AJD. O paciente usu\xE1rio de crack \u2013 diagn\xF3stico e terap\xEAutica na urg\xEAncia.</span> 
    <em>
      <span style="font-weight: 400;">Rev Med Minas Gerais</span>
    </em> 
    <span style="font-weight: 400;">2015;25(2):244-252.</span> 
    <span style="font-weight: 400;">
      <br>
    </span>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">Conselho Federal de Medicina. Diretrizes Gerais M\xE9dicas Para Assist\xEAncia Integral ao Crack. 2011. Dispon\xEDvel em:</span> 
    <a href="https://portal.cfm.org.br/images/stories/pdf/cartilhacrack2.pdf">
      <span style="font-weight: 400;">https://portal.cfm.org.br/images/stories/pdf/cartilhacrack2.pdf</span>
    </a> 
    <br>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">Nardi AE, Da Silva AG, Quevedo J. Tratado de Psiquiatria da Associa\xE7\xE3o Brasileira de Psiquiatria. Artmed. 2022.</span> 
    <span style="font-weight: 400;">
      <br>
    </span>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">American Heart Association. 2023 American Heart Association Focused Update on the Management of Patients With Cardiac Arrest or Life-Threatening Toxicity Due to Poisoning: An Update to the American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care.</span> 
    <em>
      <span style="font-weight: 400;">Circulation</span>
    </em> 
    <span style="font-weight: 400;">. 2023.</span> 
    <br>
  </li>
</ol>`,ordem:5}],videos:[],fluxogramas:[],tags:[]},{id:"7cc4f4f1-50f1-49e3-9e19-7f658eb681d9",nome:"Intoxica\xE7\xE3o por Opioide",categoria:1,termosDeBusca:"intoxicacao por opioide, ",favoritado:!1,ordem:0,especialidades:[{nome:"MEDICINA INTERNA"}],prescricoes:[{id:"c8d3d337-5f10-416c-aed1-84f193ddca7f",nome:"Intoxica\xE7\xE3o por Opioide",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Dieta",idGrupo:"e5ded9bf-7741-48cb-9d2d-d46ed7e4c975",opcoes:[{id:"f24b526a-c73d-4e93-998d-69bcd0618c08",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir quando houver recupera\xE7\xE3o do n\xEDvel de consci\xEAncia.",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Hidrata\xE7\xE3o",idGrupo:"19627797-2e22-4a7d-bedb-500fc322e7a2",opcoes:[{id:"98f880b9-78bf-4c24-8b11-48e05ee4712a",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"N\xE3o \xE9 feita rotineiramente; se atentar para sinais de desidrata\xE7\xE3o.",ordem:2},{item:"ANT\xCDDOTO",grupos:[{grupo:"Ant\xEDdoto",idGrupo:"e6304bdc-cbe9-48cd-ae86-04b746341234",opcoes:[{id:"02eb5e41-9b10-4194-94dd-fb591a848e2b",descr:`Naloxone (0,4mg/mL) 0,04-2mg IV em infus\xE3o lenta (pelo menos, 10 segundos) agora e a crit\xE9rio m\xE9dico\r
Se necess\xE1rio, repetir a cada 2-3 minutos com doses progressivamente maiores (0,04\u21920,4\u21922\u21924\u219210\u219215) at\xE9 10-15 mg`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:`Dose inicial:
- Drive respirat\xF3rio residual: 0,04 mg (0,1 mL);
- Apneia ou parada respirat\xF3ria iminente: 0,4-1 mg (1-2,5 mL);
- Parada cardiorrespirat\xF3ria: 2 mg (5 ml)`,ordem:3},{item:"ANT\xCDDOTO / EVITAR REINTOXICA\xC7\xC3O",grupos:[{grupo:"Ant\xEDdoto",idGrupo:"dcc38f3f-d56f-49b7-a3ba-5376c08563b4",opcoes:[{id:"a07a868a-75b7-4c5b-be1a-a57111ddb75d",descr:`Naloxone (0,4mg/mL) 5 mL + SG 5% 495 mL (solu\xE7\xE3o: 0,004 mg/mL) IV em infus\xE3o cont\xEDnua a crit\xE9rio m\xE9dico (MEDGRUPO)\r
- Administrar 100 mL/h, titulando para que se mantenha uma frequ\xEAncia respirat\xF3ria > 12 irpm. `,recomendado:!0,favorito:!0,ordem:1},{id:"5dc88a77-52df-442d-adf3-83c2b5817ea2",descr:`Naloxone (0,4mg/mL) 2/3 da dose usada para recupera\xE7\xE3o respirat\xF3ria + SG 5% 100 mL - IV em 1 hora\r
- Administrar, a cada hora, 2/3 da dose necess\xE1ria para que se mantenha uma frequ\xEAncia respirat\xF3ria > 12 irpm.`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Antagonizar efeito residual do opioide, ap\xF3s a interrup\xE7\xE3o da a\xE7\xE3o inicial do naloxone.",ordem:4},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"70e34266-c7bb-455f-96b2-d589a82b79b2",opcoes:[{id:"ca295e81-2e09-4332-87cd-a6662f2056bf",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"eca630dd-accf-4356-9b95-a726d96d6ec6",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"eb7b6043-d96b-4630-9497-e964c0617267",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:5},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Cuidados gerais",idGrupo:"c361e262-7536-4609-8998-827ba839fd56",opcoes:[{id:"f86f3a35-7dbc-4d7b-a7c2-80415fad28c1",descr:"Glicemia capilar 6/6h",recomendado:!0,favorito:!0,ordem:1},{id:"036c7db9-aa9e-494e-abed-debc7d1d69bf",descr:"Glicose Hipert\xF4nica 50% - 50mL (5 ampolas) se glicemia capilar < 70 mg/mL",recomendado:!1,favorito:!1,ordem:2},{id:"310198f1-003e-4ee1-844a-ee06f0a0b3f7",descr:"Insulina Regular SC conforme esquema: 141-200=2U / 201-250=4U / 251-300=6U / 301-350=8U / 351-400=10U / > 400=12U. Se > 400 ou < 70, avisar plantonista",recomendado:!1,favorito:!1,ordem:3},{id:"448435ac-77d1-458f-8e9f-b4d2a9937f87",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:6}],conceitosPraticos:[{conceito:"Diagnostico Cl\xEDnico: FR \u2264 12 irpm + torpor + miose",ordem:1},{conceito:"Obter glicemia capilar para afastar hipoglicemia",ordem:2},{conceito:"Aten\xE7\xE3o especial deve ser dada ao suporte ventilat\xF3rio",ordem:3},{conceito:"H\xE1 risco de reintoxica\xE7\xE3o - por isso, deve-se manter infus\xE3o cont\xEDnua do ant\xEDdoto",ordem:4}]}],topicos:[{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O termo "intoxica\xE7\xE3o" \xE9 usado para se referir \xE0 overdose de opioide, que pode ser acidental ou intencional. Esse evento, assim como as mortes secund\xE1rias a ele, t\xEAm se elevado consideravelmente nos \xFAltimos anos, em especial pelo aumento da prescri\xE7\xE3o de tais f\xE1rmacos para tratamento de dor cr\xF4nica.</span>
</p>`,ordem:1},{titulo:"MANIFESTA\xC7\xD5ES",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Como os opioides agem em um grande n\xFAmero de receptores, uma s\xE9rie de manifesta\xE7\xF5es pode ocorrer. A mais importante delas \xE9 a depress\xE3o respirat\xF3ria, que se apresenta com bradi e hipopneia (redu\xE7\xE3o da frequ\xEAncia respirat\xF3ria e respira\xE7\xE3o superficial, respectivamente). Uma frequ\xEAncia respirat\xF3ria \u2264 12 irpm em um paciente que n\xE3o se encontra dormindo sugere, fortemente, intoxica\xE7\xE3o por opioide, em especial se acompanhada de miose e torpor, outros dois achados cl\xE1ssicos da intoxica\xE7\xE3o.&nbsp;</span>
</p><p>
          <strong>
            <em>PARA GUARDAR:</em>
          </strong>
        </p><p>
          <span style="font-weight: 400;">Tr\xEDade cl\xE1ssica da intoxica\xE7\xE3o por opioide: depress\xE3o respirat\xF3ria + redu\xE7\xE3o do n\xEDvel de consci\xEAncia + miose</span>
        </p><p style="text-align: justify;">
  <em>
    <span style="font-weight: 400;">* A aus\xEAncia de miose n\xE3o exclui a possibilidade de intoxica\xE7\xE3o; al\xE9m de n\xE3o ocorrer com todos os opioides (n\xE3o \xE9 comum com a meperedina, por exemplo), pode ser atenuada pela coingest\xE3o de outros agentes (anticolin\xE9rgicos e simpaticomim\xE9ticos). Da mesma forma, o rebaixamento do n\xEDvel de consci\xEAncia n\xE3o \xE9 obrigat\xF3rio - alguns indiv\xEDduos podem se apresentar com estado mental inalterado ou com euforia.</span>
  </em>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Outros sinais poss\xEDveis s\xE3o: redu\xE7\xE3o da peristalse, hipotonia, edema pulmonar, prurido, rash cut\xE2neo, hipotens\xE3o arterial e hipotermia.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Em adi\xE7\xE3o a esse quadro, \xE9 importante ressaltar o risco de rabdomi\xF3lise pela prolongada imobiliza\xE7\xE3o resultante do estado torporoso, que pode fazer com que o paciente se mantenha apoiado sobre um \xFAnico compartimento muscular longo per\xEDodo.</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O diagn\xF3stico \xE9 cl\xEDnico, feito com base na presen\xE7a das manifesta\xE7\xF5es t\xEDpicas, e corroborado pelo relato de uso da subst\xE2ncia. \xC9 tamb\xE9m importante despir por completo o paciente \xE0 procura de adesivos cut\xE2neos de medica\xE7\xE3o, que podem ser a "fonte" da intoxica\xE7\xE3o, e ind\xEDcios de uso de drogas intravenosas.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">N\xE3o h\xE1 indica\xE7\xE3o de exame de urina para quantifica\xE7\xE3o opioide, at\xE9 porque um resultado positivo indica, apenas, uso recente da subst\xE2ncia, sendo incapaz de confirmar que o paciente est\xE1 intoxicado. Por\xE9m, alguns testes devem ser solicitados diante da suspeita de intoxica\xE7\xE3o. \xC9 importante, por exemplo, avaliar a</span>glicemia capilar 
  <span style="font-weight: 400;">para excluir hipoglicemia, causa frequente de altera\xE7\xE3o do n\xEDvel de consci\xEAncia. Pela elevada incid\xEAncia de cointoxica\xE7\xE3o (especialmente nos Estados Unidos), \xE9 interessante solicitar o</span>n\xEDvel s\xE9rico de paracetamol 
  <span style="font-weight: 400;">(acetaminofeno), se dispon\xEDvel. Al\xE9m disso, a dosagem de</span>creatinofosfoquinase 
  <span style="font-weight: 400;">(CPK) deve ser realizada em indiv\xEDduos com hist\xF3ria de imobiliza\xE7\xE3o prolongada (neste contexto, tamb\xE9m \xE9 interessante que, no exame f\xEDsico, os principais grupamentos musculares sejam palpados, uma vez que um edema pode acompanhar a temida s\xEDndrome compartimental muscular). Um</span>eletrocardiograma 
  <span style="font-weight: 400;">deve ser solicitado, principalmente se houver suspeita de suic\xEDdio ou de cointoxica\xE7\xE3o com subst\xE2ncias que podem alterar a condu\xE7\xE3o card\xEDaca (ex.: coca\xEDna e tric\xEDclicos).</span>
</p>`,ordem:3},{titulo:"CONDUTA&nbsp;",texto:`<p style="text-align: justify;">
  <strong>- Suporte cl\xEDnico</strong> 
  <span style="font-weight: 400;">: como em qualquer intoxica\xE7\xE3o, a prioridade inicial \xE9 o suporte cl\xEDnico ao paciente, com especial aten\xE7\xE3o \xE0 ventila\xE7\xE3o e ao aparelho circulat\xF3rio.&nbsp;</span>
</p><p style="text-align: justify;">
  <strong>- Ant\xEDdoto \u2013</strong> 
  <span style="font-weight: 400;">O comprometimento ventilat\xF3rio \xE9 o sinal mais espec\xEDfico da ocorr\xEAncia da intoxica\xE7\xE3o por opioide e pode ser revertido com um ant\xEDdoto: a</span>naloxona 
  <span style="font-weight: 400;">, um antagonista opioide de curta dura\xE7\xE3o. A via ideal de administra\xE7\xE3o \xE9 a intravenosa, atrav\xE9s da qual o in\xEDcio da a\xE7\xE3o farmacol\xF3gica se d\xE1 com menos de 2 minutos.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Quando o paciente ainda tem drive respirat\xF3rio pr\xF3prio, a dose inicial deve ser de 0,04-0,05 mg. Se n\xE3o houver melhora do padr\xE3o respirat\xF3rio (frequ\xEAncia &gt; 12 irpm), novas doses progressivamente maiores (0,04 \u2192 0,4 \u2192 2 \u2192 4 \u2192 10 \u2192 15 mg) devem ser administradas a cada 2-3 minutos.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Diante de um paciente que se encontra em apneia ou em parada respirat\xF3ria iminente, a dose inicial deve ser de 0,2 - 1 mg. J\xE1 na parada cardiorrespirat\xF3ria, a dose inicial preconizada \xE9 ainda mais alta: 2 mg.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Caso n\xE3o se observe resposta adequada ap\xF3s uma dose acumulada de 5-15 mg, deve-se considerar outras causas para a depress\xE3o respirat\xF3ria, pois passa a ser improv\xE1vel que a sua justificativa seja a intoxica\xE7\xE3o por opioide\u2026</span>
</p><p style="text-align: justify;">
  <em>
    <span style="font-weight: 400;">* \xC9 importante que fique claro que o objetivo da abordagem com naloxona n\xE3o \xE9 a recupera\xE7\xE3o plena do n\xEDvel de consci\xEAncia,</span>
  </em>mas sim a melhora do padr\xE3o ventilat\xF3rio!
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Se houver dificuldade na obten\xE7\xE3o do acesso intravenoso, as doses iniciais podem ser administradas por via intramuscular, subcut\xE2nea, intra\xF3ssea e at\xE9 intranasal (para essa \xFAltima, geralmente se prefere formula\xE7\xE3o mais concentrada \u2013 1mg/mL \u2013 pois a capacidade de absor\xE7\xE3o de l\xEDquidos pela mucosa nasal \xE9 limitada). No entanto, quando se utiliza essas vias de administra\xE7\xE3o, a titula\xE7\xE3o da droga \xE9 mais dif\xEDcil pela absor\xE7\xE3o e elimina\xE7\xE3o mais lentas.</span>
</p><p style="text-align: justify;">
  <strong>- Descontamina\xE7\xE3o \u2013</strong> 
  <span style="font-weight: 400;">O uso de estrat\xE9gia de descontamina\xE7\xE3o gastrointestinal com carv\xE3o ativado n\xE3o \xE9 consensual e, geralmente, acaba n\xE3o sendo empregada. Isso porque contamos com um ant\xEDdoto eficaz e o emprego da subst\xE2ncia pode atrapalhar a visualiza\xE7\xE3o da anatomia da via a\xE9rea em uma eventual necessidade de intuba\xE7\xE3o. De qualquer forma, se houver a decis\xE3o pelo uso desta estrat\xE9gia, s\xF3 haveria justificativa para empreg\xE1-la na primeira hora da ingest\xE3o de opioide.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- Possibilidade de efeito residual de opioide (reintoxica\xE7\xE3o) \u2013</strong> 
  <span style="font-weight: 400;">Essa \xE9 uma armadilha muito s\xE9ria... Depois da melhora inicial, o paciente precisa ser avaliado de perto em rela\xE7\xE3o \xE0 sua frequ\xEAncia respirat\xF3ria e seu n\xEDvel de consci\xEAncia at\xE9 a recupera\xE7\xE3o completa (definida como um paciente assintom\xE1tico e com estado mental normal 2 horas ap\xF3s a \xFAltima dose do ant\xEDdoto). O efeito da naloxona dura, em m\xE9dia, 30-90 minutos, de modo que, se a intoxica\xE7\xE3o tiver ocorrido por opioides de a\xE7\xE3o mais longa (a meia-vida da morfina e da code\xEDna \xE9 de 2-3 horas, por exemplo; a da metadona \xE9 ainda maior), as manifesta\xE7\xF5es voltar\xE3o a ocorrer, com novo risco de depress\xE3o respirat\xF3ria.&nbsp;</span>
</p><p style="text-align: justify;">
  <em>
    <span style="font-weight: 400;">O que fazer, ent\xE3o?</span>
  </em> 
  <span style="font-weight: 400;">&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">H\xE1 algumas estrat\xE9gias... A mais cl\xE1ssica e simples \xE9 criar uma solu\xE7\xE3o de 0,004 mg/mL (2 mg em 500 mL de SG 5% ou SF 0,9%) e iniciar infus\xE3o cont\xEDnua a 100 mL/h, titulando para que se mantenha uma frequ\xEAncia respirat\xF3ria &gt; 12 irpm.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Outra forma um pouco mais trabalhosa, \xE9 calcular a dose total feita em</span> 
  <em>
    <span style="font-weight: 400;">bolus</span>
  </em> 
  <span style="font-weight: 400;">at\xE9 que tenha havido melhora respirat\xF3ria e administrar mais 2/3 desse total a cada hora em infus\xE3o cont\xEDnua dilu\xEDdo em 100 mL de SG 5% ou SF 0,9%. Vamos a um exemplo... Se foi necess\xE1ria uma dose total de 1,2 mg de naloxona para alcan\xE7ar uma revers\xE3o da intoxica\xE7\xE3o, o mais seguro agora \xE9 utilizar 2/3 desse total (0,8 mg) dilu\xEDdos em 100 mL de solu\xE7\xE3o para infus\xE3o ao longo de 1h.</span>
</p><p style="text-align: justify;">
  <strong>- Edema pulmonar \u2013</strong> 
  <span style="font-weight: 400;">A les\xE3o pulmonar aguda \xE9 uma complica\xE7\xE3o rara, por\xE9m temida, que pode ocorrer como parte da cl\xEDnica da intoxica\xE7\xE3o opioide (mais comum com hero\xEDna) e, segundo alguns autores, tamb\xE9m como efeito do uso da naloxona. Sua fisiopatologia \xE9 pouco compreendida, mas, como n\xE3o h\xE1 sobrecarga de volume, o uso de diur\xE9tico n\xE3o se justifica. A terap\xEAutica, em geral, \xE9 apenas de suporte, com bom progn\xF3stico e recupera\xE7\xE3o em 24-48h. Casos graves acabam necessitando de intuba\xE7\xE3o orotraqueal e ventila\xE7\xE3o com press\xE3o positiva.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">Boyer EW. Management of Opioid Analgesic Overdose. The New England Journal of Medicine 2012;367:146-155.</span> 
    <br>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">Associa\xE7\xE3o Brasileira de Psiquiatria, Sociedade Brasileira de Patologia Cl\xEDnica e Medicina Laboratorial, Sociedade Brasileira de Medicina de Fam\xEDlia e Comunidade. Abuso e Depend\xEAncia dos Opioides e Opi\xE1ceos.</span> 
    <em>
      <span style="font-weight: 400;">Projeto Diretrizes da Associa\xE7\xE3o Me\u0301dica Brasileira e Conselho Federal de Medicina</span>
    </em> 
    <span style="font-weight: 400;">. 2012.</span> 
    <br>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">World Health Organization. Community management of opioid overdose 2014.</span> 
    <em>
      <span style="font-weight: 400;">Dispon\xEDvel em</span>
    </em> 
    <a href="http://www.who.int/substance_abuse/publications/management_opioid_overdose/en/">
      <em>
        <span style="font-weight: 400;">http://www.who.int/substance_abuse/publications/management_opioid_overdose/en/</span>
      </em>
    </a> 
    <em>
      <span style="font-weight: 400;">&nbsp;</span>
    </em>
  </li>
  <li style="text-align: justify;">
    <span style="font-weight: 400;">Kampman K, Jarvis M, et al.</span> 
    <span style="font-weight: 400;">American Society of Addiction Medicine (ASAM) National Practice Guideline for the use of medications in the treatment of addiction involving opioid use.</span> 
    <em>
      <span style="font-weight: 400;">Journal of Addiction Medicine</span>
    </em> 
    <span style="font-weight: 400;">2015;9(5):358.</span> 
    <br>
  </li>
</ol>`,ordem:5}],videos:[],fluxogramas:[],tags:[]},{id:"7bee0304-e999-4c8f-9b17-d251160716f5",nome:"Isquemia Mesent\xE9rica Aguda",categoria:1,termosDeBusca:"isquemia mesenterica aguda, infarto, infarto enteromesenterico, necrose",favoritado:!1,ordem:0,especialidades:[{nome:"CIRURGIA"}],prescricoes:[{id:"108b37eb-c81b-4d7c-83bb-9dbd9eafb2d6",nome:"Isquemia Mesent\xE9rica Aguda",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"41d03c22-96c8-4e06-b6c2-8a377a4fb6d1",opcoes:[{id:"a3225984-546a-45ed-95f7-c8ce6c17a50f",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s restabelecimento da perfus\xE3o e estabiliza\xE7\xE3o cl\xEDnica.",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"3a84d63c-32f8-4aae-b98b-274dd6d7f7a2",opcoes:[{id:"0a73ef47-0234-4057-939d-d3812acd432f",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"ANTICOAGULA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"93b90405-e481-4cce-8eb5-3ade1f556671",opcoes:[{id:"4c9079b1-5329-4a11-8851-9a6ab5d9b985",descr:"Heparina n\xE3o-fracionada (25.000U/5mL) + SG 5% 245 mL (solu\xE7\xE3o: 100U/mL) - 80UI/Kg (ou 5000UI) bolus IV + 18U/Kg/h (ou 1250UI/h = 12,5mL/h) IV em bomba infusora a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Se poss\xEDvel, iniciar antes mesmo da confirma\xE7\xE3o diagn\xF3stica, com prefer\xEAncia pela heparina n\xE3o-fracionada.",ordem:3},{item:"ANTIBIOTICOTERAPIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"722a0b38-088f-4a0c-b3ad-aeca3e0d30fe",opcoes:[{id:"82b2a2f5-c9af-460b-9206-6cbd06aa5c2e",descr:"Ciprofloxacina 400 mg IV 12/12h + Metronidazol 500 mg IV 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"e14c8a6e-3984-4c00-a1a1-e62446b33832",descr:"Levofloxacina 750 mg IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:2},{id:"83ec7ef7-2c68-4651-9c29-689dab80dc55",descr:"Ceftriaxone 1 g IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:3},{id:"c668dd16-a19e-44aa-8d07-3f5fe2e259b1",descr:"Ertapenem 1 g IV 1x/dia",recomendado:!1,favorito:!1,ordem:4},{id:"eb5305ba-1eeb-4c93-a3d6-1cbb5997bcdc",descr:"Piperacilina/tazobactam 4,5 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Recomendada pelo elevado risco de transloca\xE7\xE3o bacteriana em virtude da perda da barreira mucosa pelo processo isqu\xEAmico.",ordem:4},{item:"ANALGESIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"bc085364-ff53-47df-adc4-bb3dec70f5c1",opcoes:[{id:"8712fb71-319e-4219-9d5c-3e0ac3ed0ac9",descr:"Morfina (10mg/mL) 1 mL + \xC1gua Destilada 9 mL (solu\xE7\xE3o: 1mg/mL) 5 mg IV 4/4h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"7f6a5d00-8e50-4924-abf2-828677e43fba",descr:"Meperidina (50mg/mL) 2 mL + SF 0,9% 8 mL (solu\xE7\xE3o: 10mg/mL) 25-100 mg IV 4/4h",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Prescri\xE7\xE3o para al\xEDvio da dor.",ordem:5},{item:"VASOPRESSORES",grupos:[{grupo:"Analg\xE9sico",idGrupo:"a6236573-143d-4b26-a75d-50079e476d88",opcoes:[{id:"12ba3a34-535c-4c7c-96ee-4c70f12d9ceb",descr:"Dobutamina 60 mL + SG 5% 190 mL (solu\xE7\xE3o: 3000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico (In\xEDcio com 2,5 mcg/kg/min, aumentando a cada 10 min at\xE9 o m\xE1ximo de 20 mcg/Kg/min) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"04a92188-9854-404a-aa44-8615b8a4662c",descr:`Dobutamina 60 mL + SG 5% 190 mL (solu\xE7\xE3o: 3000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico (MEDGRUPO)\r
Iniciar 2,5 mcg/kg/min, aumentando a cada 10 min se necess\xE1rio, at\xE9 20 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:2},{id:"ba32821e-22a1-4cea-8e1b-69f0f3158b3f",descr:`Dobutamina 20 mL + SG 5% 230 mL (solu\xE7\xE3o: 1000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Iniciar 2,5 mcg/kg/min, aumentando a cada 10 min se necess\xE1rio, at\xE9 20 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:3},{id:"e5379b07-f484-4b8f-8442-cb023496c17d",descr:`Dopamina 50 mL + SG 5% 200 mL (solu\xE7\xE3o: 1000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Iniciar 1 mcg/Kg/min at\xE9 o m\xE1ximo de 5 mcg/kg/min `,recomendado:!1,favorito:!1,ordem:4},{id:"e697e56a-e5c5-40b0-9b78-5eac0b1a2c2f",descr:`Milrinona 20 mL + SG 5% 80 mL (solu\xE7\xE3o: 200 mcg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Ataque opcional de 50 mcg/Kg IV em 10 minutos, seguido de 0,375-0,75 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Em tese, deveriam ser evitados pelo risco de exacerba\xE7\xE3o da isquemia mesent\xE9rica, mas, se for necess\xE1rio por uma instabilidade hemodin\xE2mica refrat\xE1ria, preferir uma dessas op\xE7\xF5es por terem menos efeito sobre a perfus\xE3o mesent\xE9rica do que outros vasopressores.",ordem:6},{item:"VASODILATADOR INTESTINAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"6e605ef7-22d3-46fa-92ce-3dbc87cd1ae4",opcoes:[{id:"7ac6b95c-303b-466e-b895-4d3847fd4552",descr:"Papaverina (30mg/mL) - 30-40 mg intra-arterial ao longo de 1-2 minutos",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Indicado apenas para etiologia n\xE3o-oclusiva (vasoconstric\xE7\xE3o).",ordem:7},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"a3c83179-c9d1-4853-b9aa-af849e7c8a7d",opcoes:[{id:"fbbe060e-eae6-45ef-8e60-a24088a2c447",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"1064b641-c735-4b3e-9198-ecea756aa368",opcoes:[{id:"9d3155fb-ff90-45b8-af08-763cd57ba162",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"45c7ee9c-81a6-41a2-afe2-00c484782bbb",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"eea96048-60ce-4729-9821-ac6e394719bb",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:8},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"8c869e67-daef-443a-a94b-dd5990652591",opcoes:[{id:"b0805efc-8fd5-40ae-820b-4bef9c06a94a",descr:"Glicemia capilar 6/6h ",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"e0a25c0c-afd1-4c3d-852c-0284c1a99cbf",opcoes:[{id:"11b54ba0-e4ef-46a9-b77a-eb7420b3e019",descr:"Glicose Hipert\xF4nica 50% - 50mL (5 ampolas) se glicemia capilar < 70 mg/mL",recomendado:!0,favorito:!0,ordem:1},{id:"c36b9b3b-0685-4255-b236-64cd882949c9",descr:"Insulina Regular SC conforme esquema: 141-200=2U / 201-250=4U / 251-300=6U / 301-350=8U / 351-400=10U / > 400=12U. Se > 400 ou < 70, avisar plantonista",recomendado:!1,favorito:!1,ordem:2},{id:"7ee643cb-f8e0-421e-8e14-66a82fd4414e",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Cuidados inespec\xEDficos.",ordem:9}],conceitosPraticos:[{conceito:"Considerar em todo o caso de dor abdominal intensa, por\xE9m desproporcional a achados do exame f\xEDsico, especialmente se houver acidose metab\xF3lica com eleva\xE7\xE3o de lactato.",ordem:1},{conceito:"Confirmar por exame de imagem, especialmente angiotomografia do abdome.",ordem:2},{conceito:"Avaliar necessidade de corre\xE7\xE3o eletrol\xEDtica.",ordem:3}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">A isquemia mesent\xE9rica aguda consiste na redu\xE7\xE3o acentuada e s\xFAbita da perfus\xE3o para um segmento do intestino delgado, levando \xE0 isquemia e necrose da al\xE7a intestinal, sendo uma patologia com elevada taxa de mortalidade.</span>
</p><p>
  <span style="font-weight: 400;">Suas causas incluem:&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">- Embolia de art\xE9ria mesent\xE9rica (50% dos casos): geralmente, observa-se uma fonte embolig\xEAnica ao diagn\xF3stico, especialmente \xE1trio esquerdo (por fibrila\xE7\xE3o atrial), ventr\xEDculo esquerdo (por disfun\xE7\xE3o contr\xE1til grave) ou valvas card\xEDacas (por endocardite).</span>
</p><p>
  <span style="font-weight: 400;">- Trombose de art\xE9ria mesent\xE9rica (25% dos casos): pode-se encontrar sinais sist\xEAmicos de aterosclerose ou hist\xF3ria de isquemia mesent\xE9rica cr\xF4nica, como dor ap\xF3s refei\xE7\xE3o (com consequente avers\xE3o \xE0 alimenta\xE7\xE3o) e emagrecimento.</span>
</p><p>
  <span style="font-weight: 400;">- Causa n\xE3o-oclusiva (20% dos casos): geralmente associada \xE0 vasoconstric\xE7\xE3o da art\xE9ria mesent\xE9rica, sendo mais comumente encontrada em casos graves de insufici\xEAncia card\xEDaca, hipovolemia, sepse e uso de vasoconstrictores.</span>
</p><p>
  <span style="font-weight: 400;">- Trombose de veia mesent\xE9rica (&lt;10% dos casos): associada a estados de hipercoagulabilidade, que podem ser prim\xE1rios (trombofilias) ou associados a outras situa\xE7\xF5es como malignidades, uso de contraceptivo oral e pancreatite.</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">A grande manifesta\xE7\xE3o cl\xEDnica \xE9 de dor abdominal excruciante de in\xEDcio agudo e, em um primeiro momento, desproporcional a achados do exame f\xEDsico, uma vez que sinais inflamat\xF3rios de irrita\xE7\xE3o peritoneal s\xF3 s\xE3o esperados nos casos em que a isquemia intestinal \xE9 irrevers\xEDvel e j\xE1 evoluiu com necrose de al\xE7a. Podem ocorrer tamb\xE9m distens\xE3o abdominal, n\xE1usea, v\xF4mito, hematoquezia e febre.</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">A avalia\xE7\xE3o laboratorial inclui a solicita\xE7\xE3o de hemograma, eletr\xF3litos, fun\xE7\xE3o renal, gasometria, lactato s\xE9rico, amilase (elevada em metade dos pacientes) e D-d\xEDmero (normalmente tamb\xE9m elevado). Classicamente, recomenda-se o racioc\xEDnio de que \u201Cqualquer paciente com dor abdominal aguda e acidose metab\xF3lica tem isquemia mesent\xE9rica at\xE9 que se prove o contr\xE1rio\u201D.</span>
</p><p>
  <span style="font-weight: 400;">De uma forma geral, por conta da s\xEDndrome \xE1lgica abdominal, a avalia\xE7\xE3o complementar por imagem acaba se iniciando com a radiografia simples atrav\xE9s da chamada \u201CRotina de Abdome Agudo\u201D. Tal avalia\xE7\xE3o dificilmente identifica o processo isqu\xEAmico, especialmente nos momentos iniciais, demonstrando, com mais facilidade, altera\xE7\xF5es em casos tardios como espessamento da parede intestinal (mais comum na trombose de veia mesent\xE9rica), pneumatose intestinal ou mesmo pneumoperit\xF4nio nas situa\xE7\xF5es que evoluem com perfura\xE7\xE3o.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">Assim, o grande exame diagn\xF3stico \xE9 a Angiotomografia Computadorizada do abdome, que, al\xE9m de demonstrar a falha de enchimento vascular, pode evidenciar altera\xE7\xF5es avan\xE7adas de isquemia, como distens\xE3o de al\xE7a, espessamento da parede intestinal, pneumatose intestinal e g\xE1s no sistema porta. Em caso de alergia ao contraste iodado, pode ser realizada Angiorresson\xE2ncia. Se o diagn\xF3stico continuar inconclusivo, indica-se a Angiografia convencional.</span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/47c859cc-e71d-4021-8b55-0d914f7aaa48.jpg" alt="" width="100%" height="auto">
  </span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">O paciente \xE9 naturalmente deixado em dieta zero, podendo ser introduzido um cateter nasog\xE1strico para atenuar a distens\xE3o abdominal. Devem ser iniciadas rapidamente a</span>
  <span style="font-weight: 400;">reposi\xE7\xE3o h\xEDdrica</span>
  <span style="font-weight: 400;">e a</span>
  <span style="font-weight: 400;">corre\xE7\xE3o eletrol\xEDtica</span>
  <span style="font-weight: 400;">j\xE1 pensando em maior estabilidade hemodin\xE2mica para uma eventual cirurgia, que ser\xE1, a princ\xEDpio, mandat\xF3ria nos casos de oclus\xE3o de art\xE9ria mesent\xE9rica (por embolia ou trombose) como estrat\xE9gia para reestabelecimento do fluxo arterial. A cirurgia \xE9 tamb\xE9m obrigat\xF3ria em qualquer situa\xE7\xE3o com sinais cl\xEDnicos de peritonite ou sinais radiol\xF3gicos de isquemia avan\xE7ada (como pneumatose intestinal), devendo ser realizada o mais precocemente poss\xEDvel e atrav\xE9s de laparotomia exploradora, que servir\xE1 para avaliar a viabilidade intestinal, ressecando segmentos com necrose. \xC9 comum a realiza\xE7\xE3o de uma segunda abordagem cir\xFArgica (estrat\xE9gia de \u201Csecond-look\u201D) em 24-48 horas para reavalia\xE7\xE3o intestinal.</span>
</p><p>
  <span style="font-weight: 400;">Ao diagn\xF3stico e, portanto, antes do ato operat\xF3rio, deve ser iniciada</span>
  <span style="font-weight: 400;">anticoagula\xE7\xE3o</span>
  <span style="font-weight: 400;">com heparina n\xE3o-fracionada para todos os pacientes que n\xE3o tenham contraindica\xE7\xE3o, assim como \xE9 indicado o in\xEDcio de</span>
  <span style="font-weight: 400;">antibioticoterapia de amplo espectro</span>
  <span style="font-weight: 400;">, uma vez que o processo isqu\xEAmico leva \xE0 perda da barreira mucosa, facilitando substancialmente a ocorr\xEAncia de transloca\xE7\xE3o bacteriana.</span>
</p><p>
  <span style="font-weight: 400;">Outras condutas importantes s\xE3o a analgesia, tipicamente realizada com opioide parenteral, uso de inibidor de bomba de pr\xF3ton e oxig\xEAnio suplementar. Caso haja necessidade do uso de vasopressores, os mais recomendados s\xE3o dobutamina, dopamina em dose baixa e milrinona.</span>
</p><p>
  <strong>Tratamento das Etiologias Espec\xEDficas \u2013</strong>
  <span style="font-weight: 400;">As interven\xE7\xF5es espec\xEDficas dependem da etiologia da isquemia:</span>
</p><p>
  <span style="font-weight: 400;">- Embolia de art\xE9ria mesent\xE9rica: cirurgia com embolectomia. Em pacientes clinicamente est\xE1veis e sem sinais de peritonite, at\xE9 pode ser tentada abordagem endovascular com tromb\xF3lise intra-arterial ou aspira\xE7\xE3o percut\xE2nea do \xEAmbolo (trombectomia mec\xE2nica).</span>
</p><p>
  <span style="font-weight: 400;">- Trombose de art\xE9ria mesent\xE9rica: como a trombectomia isolada n\xE3o garante uma pat\xEAncia vascular a longo prazo em virtude da doen\xE7a ateroscler\xF3tica subjacente, a abordagem mais recomendada \xE9 cirurgia de bypass, realizada interpondo-se um conduto (geralmente veia safena ou at\xE9 pr\xF3tese de PTFE) entre um vaso patente (geralmente, aorta ou art\xE9ria il\xEDaca) e um s\xEDtio distal \xE0 les\xE3o oclusiva. Em pacientes clinicamente est\xE1veis e sem sinais de peritonite, at\xE9 pode ser tentada angioplastia com coloca\xE7\xE3o de stent.</span>
</p><p>
  <span style="font-weight: 400;">- Causa n\xE3o-oclusiva (vasoespasmo): revers\xE3o do fator precipitante, com ressuscita\xE7\xE3o vol\xEAmica, otimiza\xE7\xE3o do d\xE9bito card\xEDaco e suspens\xE3o de vasoconstrictores. Tamb\xE9m \xE9 \xFAtil a administra\xE7\xE3o do vasodilatador intestinal papaverina dentro do leito arterial espl\xE2ncnico (tipicamente na art\xE9ria mesent\xE9rica superior) guiada por cateter \u2013 estrat\xE9gia que hoje vem sendo um pouco menos utilizada.</span>
</p><p>
  <span style="font-weight: 400;">- Trombose de veia mesent\xE9rica: a anticoagula\xE7\xE3o geralmente \xE9 o tratamento suficiente.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Angiotomografia em caso de insufici\xEAncia renal \u2013</strong>
  <span style="font-weight: 400;">A Angiotomografia Computadorizada deve ser realizada mesmo na presen\xE7a de insufici\xEAncia renal, uma vez que as consequ\xEAncias de um atraso no diagn\xF3stico e no tratamento s\xE3o muito mais prejudiciais ao rim e ao pr\xF3prio paciente do que a exposi\xE7\xE3o ao contraste iodado.</span>
</p><p>
  <strong>- Prioridade cir\xFArgica: ressec\xE7\xE3o x revasculariza\xE7\xE3o \u2013</strong>
  <span style="font-weight: 400;">O ideal \xE9 que a revasculariza\xE7\xE3o mesent\xE9rica no caso de isquemia por oclus\xE3o arterial (embolia ou trombose) seja realizada antes de uma eventual ressec\xE7\xE3o intestinal, por\xE9m \xE1reas de n\xEDtida necrose de al\xE7a em pacientes clinicamente inst\xE1veis podem ser removidas prioritariamente utilizando uma estrat\xE9gia de \u201CCirurgia para Controle do Dano\u201D. Nesta situa\xE7\xE3o, abrevia-se o tempo cir\xFArgico, ressecando apenas os segmentos claramente n\xE3o vi\xE1veis, mas sem realizar anastomose prim\xE1ria, deixando a restaura\xE7\xE3o do trato intestinal para uma segunda abordagem (estrat\xE9gia de \u201Csecond-look\u201D), geralmente realizada ap\xF3s 24-48 horas.</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<p>
  <strong>&nbsp;</strong>
</p><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Bala M, Kashuk J, Moore EE, et al.</span>
    </em>
    <em>
      <span style="font-weight: 400;">Acute mesenteric ischemia: guidelines of the World Society of Emergency Surgery.</span>
    </em>
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery</span>
    </em>
    <em>
      <span style="font-weight: 400;">&nbsp;2017, 12:38.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Tilsed JVT, Casamassima A, Kurihara H, et al. ESTES guidelines: acute mesenteric ischaemia. Eur J Trauma Emerg Surg 2016, 42:253\u2013270.</span>
    </em>
  </li>
</ul><p>&nbsp;</p>`,ordem:6}],videos:[],fluxogramas:[],tags:["Infarto","Infarto enteromesent\xE9rico","Necrose"]},{id:"ee97ac79-8048-44b7-a672-4f75a9aedfcb",nome:"Neutropenia Febril",categoria:1,termosDeBusca:"neutropenia febril, mascc, cancer, mascc",favoritado:!1,ordem:0,especialidades:[{nome:"HEMATOLOGIA"}],prescricoes:[],topicos:[{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Neutropenia febril \xE9 definida pela medida isolada de temperatura oral \u2265 38,3</span> 
  <span style="font-weight: 400;">o</span> 
  <span style="font-weight: 400;">C ou a perman\xEAncia sustentada por, pelo menos 1 hora, de uma temperatura \u2265 38,0</span> 
  <span style="font-weight: 400;">o</span> 
  <span style="font-weight: 400;">C em um paciente com contagem absoluta de neutr\xF3filos &lt; 500 c\xE9lulas/mm</span> 
  <span style="font-weight: 400;">3</span> 
  <span style="font-weight: 400;">ou com uma expectativa de queda a estes valores nas pr\xF3ximas 48h.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Como a temperatura oral e\u0301 3 a 4 de\u0301cimos maior do que axilar, alguns aceitam, como limiar de febre, uma temperatura axilar \u2265 37,8</em> 
    <em>o</em> 
    <em>C para o diagno\u0301stico.</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Essa situa\xE7\xE3o ocorre classicamente em pacientes submetidos \xE0 quimioterapia, estrat\xE9gia em que muitos agentes quimioter\xE1picos, al\xE9m de atuarem contra c\xE9lulas tumorais, acabam tamb\xE9m atuando no sistema mieloproliferativo, resultando na neutropenia. Isso \xE9 problem\xE1tico pelo fato de os neutr\xF3filos desempenharem um papel essencial na imunidade inata, atacando diretamente c\xE9lulas bacterianas ou hifas f\xFAngicas e liberando citocinas que induzem respostas inflamat\xF3rias no local de infec\xE7\xE3o. Al\xE9m disso, esses f\xE1rmacos tamb\xE9m danificam outras c\xE9lulas com grande capacidade de divis\xE3o, como aquelas que revestem a mucosa intestinal, o que facilita a ocorr\xEAncia de transloca\xE7\xE3o bacteriana.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Assim, em um paciente neutrop\xEAnico, deve-se presumir que a febre seja decorrente de um quadro infeccioso.</span>
</p>`,ordem:1},{titulo:"MANIFESTA\xC7\xD5ES",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Como s\xE3o pacientes com reduzida capacidade de promo\xE7\xE3o de resposta inflamat\xF3ria, a neutropenia febril \xE9, muitas vezes, o primeiro e at\xE9 o \xFAnico sinal ou sintoma de infec\xE7\xE3o nesta popula\xE7\xE3o de pacientes vulner\xE1veis. De qualquer forma, a busca por uma fonte infecciosa deve ser intensa, com especial aten\xE7\xE3o a pele, locais do cateter, pulm\xF5es, seios da face, boca, abd\xF4men, \xE1rea perirretal e sistema neurol\xF3gico como fontes potenciais de infec\xE7\xF5es.</span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Al\xE9m do hemograma completo com diferencial da leucometria para definir a neutropenia, devem ser solicitados fun\xE7\xE3o renal (ureia, creatinina), eletr\xF3litos, lactato, transaminases, bilirrubina total, fosfatase alcalina e testes direcionados para eventuais manifesta\xE7\xF5es, como a realiza\xE7\xE3o de radiografia de t\xF3rax (ou mesmo tomografia computadorizada) e cultura de escarro nos pacientes com manifesta\xE7\xE3o respirat\xF3ria.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Outra avalia\xE7\xE3o indispens\xE1vel \xE9 a coleta de hemocultura: pelo menos, 2 amostras de s\xEDtios diferentes. Se houver um cateter venoso profundo instalado, coletar uma amostra de cada l\xFAmen e mais uma de um acesso venoso perif\xE9rico. Culturas de outros s\xEDtios, como urina, trato respirat\xF3rio inferior, l\xEDquor, fezes ou feridas podem ser feitas conforme indica\xE7\xE3o cl\xEDnica.</span>
</p>`,ordem:3},{titulo:"CONDUTA",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">O primeiro passo da abordagem da neutropenia febril \xE9 a estratifica\xE7\xE3o de risco, que pode ser feita por julgamento cl\xEDnico, pelo escore MASCC (</span> 
  <em>
    <span style="font-weight: 400;">Multinational Association for Supportive Care in Cancer</span>
  </em> 
  <span style="font-weight: 400;">) ou pelo modelo de Talcott ou pela ferramenta CISNE (</span> 
  <em>
    <span style="font-weight: 400;">Clinical Index of Stable Febrile Neutropenia</span>
  </em> 
  <span style="font-weight: 400;">). Idealmente, a antibioticoterapia deve ser iniciada dentro da primeira hora de avalia\xE7\xE3o do paciente.</span>
</p><p style="text-align: justify;">
  <strong>Paciente de baixo risco \u2013</strong> 
  <span style="font-weight: 400;">Os pacientes de baixo risco s\xE3o aqueles com escore de MASCC \u2265 21 pontos ou pertencentes ao grupo 4 de Talcott ou CISNE \u2264&nbsp;2, que sejam portadores de tumor s\xF3lido e com expectativa de dura\xE7\xE3o da neutropenia &lt; 7 dias. Nesses casos, a primeira dose da antibioticoterapia \xE9 feita intravenosa e o paciente deve ser observado por, pelo menos, 4 horas, mas o restante do tratamento pode ser feito em regime ambulatorial com antibi\xF3tico por via oral, desde que ele tenha um acompanhante em casa e possa retornar (rapidamente se necess\xE1rio) para atendimento emergencial ou mesmo acompanhamento (o ideal \xE9 que resida a \u2264 1 hora ou \u2264 48 km da cl\xEDnica ou hospital).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O esquema de antibi\xF3tico oral depende se o paciente faz uso regular de profilaxia com fluoroquinolona. Se n\xE3o houver essa hist\xF3ria de profilaxia, o esquema ideal \xE9 ciprofloxacino (ou levofloxacino) com amoxicilina/clavulanato (ou com clindamicina em caso de alergia \xE0 penicilina). Alternativas menos recomendadas incluem monoterapia com levofloxacino ou moxifloxacino. Se o paciente fizer uso de profilaxia com fluoroquinolona, n\xE3o h\xE1 op\xE7\xE3o oral contra</span> 
  <em>
    <span style="font-weight: 400;">P. aeruginosa</span>
  </em> 
  <span style="font-weight: 400;">, de modo que o tratamento dever\xE1 ser o mesmo esquema intravenoso utilizado para pacientes de alto risco (se houver estrutura, a abordagem pode ser ainda ambulatorial).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O paciente deve ser orientado a retornar ao hospital para reavalia\xE7\xE3o caso surjam novos sinais ou sintomas, a febre permane\xE7a por mais de 2-3 dias ou a cultura identifique germes n\xE3o suscept\xEDveis ao regime inicial.</span>
</p><p style="text-align: justify;">
  <strong>Paciente de alto risco \u2013</strong> 
  <span style="font-weight: 400;">Os pacientes de alto risco s\xE3o aqueles com escore de MASCC &lt; 21 pontos ou pertencentes aos grupos 1-3 de Talcott ou CISNE &gt;&nbsp;2 ou que tenham expectativa de dura\xE7\xE3o da neutropenia &gt; 7 dias (o condicionamento para transplante de c\xE9lulas-tronco hematopoi\xE9ticas e a quimioterapia para neoplasia hematol\xF3gica podem causar neutropenia de 14 dias ou mais).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O tratamento \xE9 feito com antibi\xF3tico intravenoso com atividade antipseudomonas, sendo as op\xE7\xF5es mais empregadas: cefepima, piperacilina/tazobactam, carbapen\xEAmicos (imipenem ou meropenem) ou ceftazidima (menos usada hoje pelo aumento das taxas de resist\xEAncia entre gram-negativos).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A vancomicina deve ser acrescentada ao esquema em casos de maior risco de participa\xE7\xE3o de gram-positivos: instabilidade hemodin\xE2mica, pneumonia, mucosite, infec\xE7\xE3o de pele ou suspeita de infec\xE7\xE3o relacionada a cateter.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Cobertura antif\xFAngica deve ser acrescentada ao esquema caso a febre permane\xE7a depois de 4-7 dias do in\xEDcio da antibioticoterapia e ainda n\xE3o tenha ocorrido identifica\xE7\xE3o da origem infecciosa.</span>
</p><p style="text-align: justify;">
  <strong>Acompanhamento \u2013</strong> 
  <span style="font-weight: 400;">Se o tipo de infec\xE7\xE3o for detectado, a dura\xE7\xE3o da antibioticoterapia dever\xE1 respeitar o tempo de tratamento usual da condi\xE7\xE3o diagnosticada. A dura\xE7\xE3o do tratamento nos casos em que n\xE3o se documenta a fonte da infec\xE7\xE3o depende da ocorr\xEAncia de resposta terap\xEAutica, definida pela defervesc\xEAncia da febre (mantida por, pelo menos, 2 dias) e pela reconstitui\xE7\xE3o mieloide (contagem absoluta de neutr\xF3filos \u2265 500 c\xE9lulas/mm</span> 
  <span style="font-weight: 400;">3</span> 
  <span style="font-weight: 400;">). Caso a contagem de neutr\xF3filos ainda n\xE3o tenha se restabelecido, a suspens\xE3o do antibi\xF3tico pode ser considerada a partir da percep\xE7\xE3o de que essa recupera\xE7\xE3o \xE9 iminente e o paciente esteja clinicamente est\xE1vel (afebril por 5-7 dias).</span>
</p><p style="text-align: justify;">
  <strong>Profilaxia \u2013</strong> 
  <span style="font-weight: 400;">A profilaxia da neutropenia febril \xE9 indicada em algumas situa\xE7\xF5es espec\xEDficas:
    <br>
  </span>(1) Profilaxia antibacteriana: indicada para casos de alto risco de neutropenia profunda (expectativa de \u2264 100 neutr\xF3filos/mm 3 por &gt; 7 dias), como no tratamento de leucemia mieloide aguda, transplante de c\xE9lulas tronco hematopoi\xE9ticas (transplante de medula \xF3ssea) com terapia mieloablativa, tratamento com alentuzumabe ou doen\xE7a enxerto versus hospedeiro moderada a grave. O esquema envolve o uso di\xE1rio de fluoroquinolona (levofloxacino 500-750 mg VO 1x/dia ou ciprofloxacino 500-750 mg VO 2x/dia) a partir do mesmo dia ou do dia seguinte ao in\xEDcio da quimioterapia e mantido at\xE9 a resolu\xE7\xE3o da neutropenia.
  <br>
  <span style="font-size: 8pt;">
    <em>* A profilaxia antibacteriana n\xE3o \xE9 recomendada no tratamento de tumores s\xF3lidos.
      <br>
    </em>
  </span>(2) Profilaxia antif\xFAngica: nos casos de tratamento de leucemia linfoc\xEDtica aguda (maior risco de mucosite), recomenda-se preven\xE7\xE3o contra 
  <em>Candida</em> idealmente com fluconazol (400 mg VO 1x/dia), tendo, como alternativa, as equinocandinas (caspofungina, micafungina, anidulafungina). J\xE1, nos casos de tratamento de leucemia mieloide aguda e s\xEDndrome mielodispl\xE1sica, recomenda-se a profilaxia contra 
  <em>Candida</em> e 
  <em>Aspergillus</em> , o que \xE9 feito com posaconazol (300 mg/dia) ou voriconazol (200 mg VO 2x/dia). A preven\xE7\xE3o espec\xEDfica contra 
  <em>Pneumocystis jirovecii</em> \xE9 recomendada para situa\xE7\xF5es como tratamento da leucemia linfoc\xEDtica aguda, uso de prednisona \u2265&nbsp;20 mg por \u2265&nbsp;4 semanas, uso de alentuzumabe, uso de temozolomida com radioterapia e deve ser feita preferencialmente com sulfametoxazol/trimoteprima 800/160 mg 1x/dia (alternativas incluem dapsona 50 mg VO 2x/dia ou 100 mg VO 1x/dia; atovaquona 1500 mg VO 1x/dia).
  <br>(3) Profilaxia antiviral: Pacientes soropositivos para herpes simplex em tratamento de indu\xE7\xE3o para leucemias agudas ou processo de transplante alog\xEAnico de c\xE9lulas tronco hematopoi\xE9ticas devem ser tratados com aciclovir (400-800 mg VO 2x/dia) ou valaciclovir (500 mg VO 2x/dia). Por sua vez, pacientes soropositivos para herpes zoster em tratamento com inibidor de proteassoma (bortezomibe, carfilzomibe, ixazomibe) devem receber profilaxia contra herpes zoster preferencialmente com valaciclovir. Naturalmente, tamb\xE9m se indica vacina\xE7\xE3o anual contra gripe.
  <br>
  <span style="font-size: 8pt;">
    <em>* Fatores estimuladores de colo\u0302nia (G-CSF, GM-CSF) s\xE3o prescritos como profilaxia caso o regime quimioter\xE1pico tenha uma incid\xEAncia de neutropenia febril &gt; 20%.</em>
  </span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>- Fatores hematopoi\xE9ticos ex\xF3genos \u2013</strong> 
  <span style="font-weight: 400;">O uso de fatores estimuladores de col\xF4nia (G-CSF, GM-CSF) n\xE3o \xE9 estimulado para o tratamento da neutropenia febril por n\xE3o exercer impacto significativo em rela\xE7\xE3o a\u0300 morbimortalidade, embora, como dito anteriormente, possa ser indicado na profilaxia, como nos casos em que um regime quimioter\xE1pico apresenta uma incid\xEAncia de neutropenia febril &gt; 20%.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Zimmer AJ, Freifeld AG. Optimal Management of Neutropenic Fever in Patients With Cancer.</span> 
    <em>
      <span style="font-weight: 400;">J Oncol Pract</span>
    </em> 
    <span style="font-weight: 400;">2019;15(1):19-24.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Taplitz RA, Kennedy EB, Bow EJ, et al. Outpatient Management of Fever and Neutropenia in Adults Treated for Malignancy: American Society of Clinical Oncology and Infectious Diseases Society of America Clinical Practice Guideline Update.</span> 
    <em>
      <span style="font-weight: 400;">J Clin Oncol</span>
    </em> 
    <span style="font-weight: 400;">2018;36(14):1443-1453.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Klastersky J, De Naurois J, Rolston K, et al. Management of febrile neutropaenia: ESMO Clinical Practice Guidelines.</span> 
    <em>
      <span style="font-weight: 400;">Annals of Oncology</span>
    </em> 
    <span style="font-weight: 400;">2016; 27(5):111\u2013118.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Freifeld AG, Bow EJ, Sepkowitz KA, et al. Clinical Practice Guideline for the Use of Antimicrobial Agents in Neutropenic Patients with Cancer: 2010 Update by the Infectious Diseases Society of America.</span> 
    <em>
      <span style="font-weight: 400;">Clinical Infectious Diseases</span>
    </em> 
    <span style="font-weight: 400;">2011;52(4):56\u201393.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">National Comprehensive Cancer Network (NCCN) Clinical Practice Guideline in Oncology. Prevention and treatment of cancer-related infections. Vers\xE3o 1.2021.</span> 
    <span style="font-weight: 400;">http://www.nccn.org</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">National Comprehensive Cancer Network (NCCN) Clinical Practice Guideline in Oncology. Hematopoietic growth factors. Vers\xE3o 4.2021.</span> 
    <span style="font-weight: 400;">http://www.nccn.org</span>
  </li>
  <li>
    <span style="font-weight: 400;">Taplitz RA, Kennedy EB, Bow EJ, et al. Antimicrobial Prophylaxis for Adult Patients With Cancer-Related Immunosuppression: ASCO and IDSA Clinical Practice Guideline Update.</span> 
    <em>
      <span style="font-weight: 400;">J Clin Oncol</span>
    </em> 
    <span style="font-weight: 400;">2018;36(30):3043-3054</span> 
    <br>
  </li>
</ol>`,ordem:5}],videos:[],fluxogramas:[],tags:["MASCC","c\xE2ncer","MASCC"]},{id:"c1dff278-2073-4a51-a1e3-74b006f95e47",nome:"Obstru\xE7\xE3o Intestinal",categoria:1,termosDeBusca:"obstrucao intestinal, obstrucao, volvo, volvulo, brida, aderencia",favoritado:!1,ordem:0,especialidades:[{nome:"CIRURGIA"}],prescricoes:[{id:"add439df-5413-4cc3-8f99-ce6e0f18dfd2",nome:"Obstru\xE7\xE3o Intestinal",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"89ca409d-6c2c-42b1-8ccc-d1c30af63fbd",opcoes:[{id:"a3f73ad0-bf82-4106-92a9-22e11a0f6c50",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s retorno do tr\xE2nsito intestinal habitual.",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"12fe672a-4ced-4376-82d9-ec38cc6fb737",opcoes:[{id:"150691e5-e983-4b51-bb6e-998afe102b5a",descr:"SF 0,9% 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Repor volemia e atentar para altera\xE7\xE3o eletrol\xEDtica.",ordem:2},{item:"ANTIBIOTICOTERAPIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"777ef46e-ae39-43f6-a2c4-ed2d5a166d3c",opcoes:[{id:"74247ab4-814f-40f4-9003-19c8217b10ed",descr:"Ciprofloxacina 400 mg IV 12/12h + Metronidazol 500 mg IV 8/8h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"9f32dc1a-ebcd-4ad9-98bc-37f5d6eb52f4",descr:"Levofloxacina 750 mg IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:2},{id:"c90e0511-b061-4695-ac21-d0e829f84b4b",descr:"Ceftriaxone 1 g IV 1x/dia + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:3},{id:"b3e95808-a941-4c5e-9f26-0d236ee17bf4",descr:"Cefotaxima 1-2 g IV 6/6h + Metronidazol 500 mg IV 8/8h",recomendado:!1,favorito:!1,ordem:4},{id:"0294cfe2-40f4-40ad-abab-57620a2b7517",descr:"Ertapenem 1 g IV 1x/dia",recomendado:!1,favorito:!1,ordem:5},{id:"05ed097a-a590-47b1-a409-c8dd6dece087",descr:"Piperacilina/tazobactam 4,5 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:6}],ordem:1}],academico:"Para casos complicados com peritonite ou estrangulamento; em geral por, pelo menos, 7 dias.",ordem:3},{item:"PALIATIVO",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"2668c677-6627-470e-a1c5-15f51f5855d6",opcoes:[{id:"3911d6e0-bb99-4053-8087-32d7acc6f1ba",descr:"Dexametasona (4mg/mL) 4 mg IV 12/12h ",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Analg\xE9sico",idGrupo:"6f191764-de66-4522-a85c-8d04e39a7788",opcoes:[{id:"23106cd0-2892-461b-9e71-1c25b6977aa1",descr:"Octreotide (100-500mcg/mL)100 mcg SC 12/12h",recomendado:!0,favorito:!0,ordem:1}],ordem:2}],academico:"Prescrever em caso de obstru\xE7\xE3o por malignidade irressec\xE1vel.",ordem:4},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"25bfc900-0f28-41ca-9ee6-5b340027828a",opcoes:[{id:"77656ddc-a9e9-4664-bd0b-d2d9840c8ee7",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"048e13f0-dc6c-4b33-90c8-565f1839197a",opcoes:[{id:"38b4dad3-0085-4c36-b8ce-e7e615dc4420",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"2b2c5e92-d043-45fc-be9f-192daab770df",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"13be7132-58e0-4b8a-8908-56aa6037b354",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais. Evitar pr\xF3cin\xE9ticos em caso de obstru\xE7\xE3o completa.",ordem:5},{item:"INIBIDOR DE BOMBA DE PR\xD3TON",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"c0343f89-4d61-4667-92d0-311fda8f592a",opcoes:[{id:"eed99ed1-3f30-43bd-87f8-f614774dfa45",descr:"Esomeprazol (40mg/frasco) 20 mg IV 1x/dia pela manh\xE3 (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"3cbc523c-8be9-4898-acc6-4669efc9fc6a",descr:"Esomeprazol (20-40mg/comp) 20-40 mg VO 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:2},{id:"117a331c-9d3c-4380-807f-e954304ddd80",descr:"Omeprazol (10-40mg/comp) 20-40 mg VO 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:3},{id:"1835c913-4687-4716-af55-7a0f75c8c41c",descr:"Omeprazol (40mg/10mL) 20-40 mg IV 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:4},{id:"3ec367d8-e6a4-49d0-9a6b-d3ecc5c3318b",descr:"Lansoprazol (15-30mg/comp) 15-30 mg VO 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Profilaxia de les\xE3o aguda de mucosa g\xE1strica.",ordem:6},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Antiem\xE9tico",idGrupo:"fd9b22e1-2a02-4b68-bf92-ef49d37e9ba4",opcoes:[{id:"e5b720a8-5dfe-4bca-bf55-b9fbc262bfd5",descr:"Glicemia capilar 6/6h ",recomendado:!0,favorito:!0,ordem:1},{id:"74b380c3-4e6c-408f-ac42-e1f897df14d9",descr:"Glicose Hipert\xF4nica 50% - 50mL (5 ampolas) se glicemia capilar < 70 mg/mL",recomendado:!1,favorito:!1,ordem:2},{id:"c04074b9-32c4-4196-929c-1e9d34da45f3",descr:"Insulina Regular SC conforme esquema: 141-200=2U / 201-250=4U / 251-300=6U / 301-350=8U / 351-400=10U / > 400=12U. Se > 400 ou < 70, avisar plantonista",recomendado:!1,favorito:!1,ordem:3},{id:"a32797d9-a210-4bff-b1e6-5ce4f03ddf14",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!1,favorito:!1,ordem:4},{id:"b7955e0e-6ba5-4576-a266-dfe8125a6afb",descr:"Sonda nasog\xE1strica em sifonagem em caso de distens\xE3o significativa ou v\xF4mitos de repeti\xE7\xE3o",recomendado:!1,favorito:!1,ordem:5},{id:"1d0e6873-fd6d-482e-8125-af5618d77a11",descr:"Manter cabeceira elevada a 30o",recomendado:!1,favorito:!1,ordem:6}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:7}],conceitosPraticos:[{conceito:"Cirurgia imediata se: peritonite, estrangulamento (febre, taquicardia, leucocitose > 15000/mm3, acidose metab\xF3lica, dor cont\xEDnua), h\xE9rnia irredut\xEDvel, brida \u2264 6 semanas de p\xF3s-operat\xF3rio.",ordem:1},{conceito:"Avaliar necessidade de corre\xE7\xE3o eletrol\xEDtica.",ordem:2}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">Obstru\xE7\xE3o intestinal \xE9 a interrup\xE7\xE3o do fluxo do conte\xFAdo intraluminal, podendo ser mec\xE2nica ou funcional (por redu\xE7\xE3o da contratilidade das al\xE7as intestinais). Se a distens\xE3o do segmento proximal for excessiva, pode ocorrer a chamada \u201Cobstru\xE7\xE3o estrangulada\u201D que \xE9 a evolu\xE7\xE3o com isquemia da al\xE7a por compress\xE3o de vasos da parede intestinal, podendo caminhar para necrose e at\xE9 perfura\xE7\xE3o. Essa evolu\xE7\xE3o com estrangulamento \xE9 mais comum de ocorrer na obstru\xE7\xE3o completa e na obstru\xE7\xE3o em al\xE7a fechada (intestino obstru\xEDdo em 2 localidades, criando um segmento sem drenagem proximal ou distal) exatamente pela maior rapidez com que evoluem com distens\xE3o de al\xE7a.</span>
</p><p>
  <span style="font-weight: 400;">As causas principais de obstru\xE7\xE3o mec\xE2nica s\xE3o:</span>
</p><p>
  <span style="font-weight: 400;">- Delgado: Brida/ader\xEAncia (geralmente associada \xE0 cirurgia pr\xE9via), tumor metast\xE1tico, h\xE9rnia, \xEDleo biliar (imagem pode demonstrar pneumobilia, que \xE9 a presen\xE7a de ar no trato biliar), bezoar (material ingerido e n\xE3o digerido pelo trato gastrointestinal), intussuscep\xE7\xE3o.</span>
</p><p>
  <span style="font-weight: 400;">- C\xF3lon: tumor prim\xE1rio, volvo (rota\xE7\xE3o de um segmento intestinal ao redor de um ponto fixo, sendo mais comum em sigmoide e ceco).</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">&nbsp;As manifesta\xE7\xF5es cl\xEDnicas principais incluem dor abdominal de in\xEDcio agudo, distens\xE3o abdominal (principal achado do exame f\xEDsico), n\xE1usea, v\xF4mito e redu\xE7\xE3o (ou parada) da elimina\xE7\xE3o de gases e fezes. A frequ\xEAncia dessas manifesta\xE7\xF5es depende da localiza\xE7\xE3o da obstru\xE7\xE3o, de maneira que, quanto mais proximal for o quadro, mais frequente ser\xE1 a apresenta\xE7\xE3o com n\xE1usea e v\xF4mito, havendo maior risco de desidrata\xE7\xE3o e, quanto mais distal for a obstru\xE7\xE3o, mais intensa ser\xE1 a distens\xE3o do abdome. O aparecimento de febre sugere a evolu\xE7\xE3o com estrangulamento.</span>
</p><p>
  <span style="font-weight: 400;">Ao exame f\xEDsico, pode-se inicialmente auscultar sons com timbre met\xE1lico em decorr\xEAncia de uma peristalse de luta, mas que, com a progress\xE3o do quadro e da distens\xE3o, tornam-se progressivamente mais fracos. A inspe\xE7\xE3o abdominal \xE9 importante pela possibilidade de sugerir etiologias como brida/ader\xEAncia (em caso de cicatrizes abdominais) e h\xE9rnia, assim como o toque retal deve ser realizado para afastar a impacta\xE7\xE3o fecal ou uma massa retal como causas da obstru\xE7\xE3o.</span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/268a242f-43de-4c91-a2a4-72c05ef7859d.jpg" alt="" width="100%" height="auto">
  </span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">A avalia\xE7\xE3o laboratorial inclui a solicita\xE7\xE3o de hemograma, eletr\xF3litos e fun\xE7\xE3o renal e, em pacientes mais graves (febre, taquicardia, hipotens\xE3o, redu\xE7\xE3o do n\xEDvel de consci\xEAncia), acrescenta-se gasometria arterial, lactato s\xE9rico e hemocultura pela maior possibilidade de hipovolemia (com hipoperfus\xE3o tecidual) e isquemia intestinal (com necrose).</span>
</p><p>
  <span style="font-weight: 400;">De uma forma geral, um exame de imagem abdominal \xE9 necess\xE1rio para confirma\xE7\xE3o diagn\xF3stica. Em geral, o primeiro exame realizado, pela alta disponibilidade e baixo custo, \xE9 a chamada \u201CRotina de Abdome Agudo\u201D que consiste na realiza\xE7\xE3o de 3 imagens radiol\xF3gicas: (1) Radiografia Simples do Abdome em posi\xE7\xE3o supina (deitado); (2) Radiografia Simples do Abdome em ortostase (de p\xE9); (3) Radiografia Simples do T\xF3rax em ortostase (de p\xE9). Tal avali\xE7\xE3o permite confirmar rapidamente a obstru\xE7\xE3o (distens\xE3o proximal de al\xE7as com n\xEDvel hidroa\xE9reo), avaliar t\xF3rax para alguma evid\xEAncia de broncoaspira\xE7\xE3o e ainda, em algumas situa\xE7\xF5es, indicar interven\xE7\xF5es de urg\xEAncia (descompress\xE3o endosc\xF3pica em caso de volvo de sigmoide e cirurgia em caso de pneumoperit\xF4nio).&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">Ap\xF3s a radiografia simples, pode ser feita Tomografia Computadorizada do Abdome por sua maior capacidade em estabelecer o s\xEDtio da obstru\xE7\xE3o (ponto de transi\xE7\xE3o entre a al\xE7a proximal dilatada e a al\xE7a distal estreita), determinar a etiologia e identificar complica\xE7\xF5es locais, como isquemia, necrose e perfura\xE7\xE3o.</span>
</p><p>
  <span style="font-weight: 400;">Com rela\xE7\xE3o a outros exames de imagem, a ultrassonografia abdominal tem utilidade limitada \xE9 \xFAtil, uma vez que a visualiza\xE7\xE3o \xE9 dificultada pelo ac\xFAmulo de ar na al\xE7a distendida e a resson\xE2ncia magn\xE9tica acaba ficando restrita aos casos de contraindica\xE7\xE3o \xE0 tomografia (gestantes, al\xE9rgicos a contraste).</span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">O paciente deve ser internado, deixado em jejum, com reposi\xE7\xE3o h\xEDdrica, corre\xE7\xE3o eletrol\xEDtica e analgesia parenteral. A passagem de sonda nasog\xE1strica (SNG) para descompress\xE3o deve ter indica\xE7\xE3o individualizada, mas geralmente \xE9 empregada em casos de distens\xE3o abdominal significativa, n\xE1usea e v\xF4mito.</span>
</p><p>
  <strong>Cirurgia x Tratamento Conservador \u2013</strong> 
  <span style="font-weight: 400;">O paciente deve ser avaliado por um cirurgi\xE3o o mais precoce poss\xEDvel, de forma que a explora\xE7\xE3o cir\xFArgica est\xE1 formalmente indicada se houver sinais de estrangulamento ou peritonite (febre, taquicardia, leucocitose &gt; 15000/mm</span>
  <span style="font-weight: 400;">3</span>
  <span style="font-weight: 400;">, acidose metab\xF3lica, dor cont\xEDnua), h\xE9rnia irredut\xEDvel ou obstru\xE7\xE3o por ader\xEAncia nas primeiras 6 semanas de p\xF3s-operat\xF3rio. A cirurgia geralmente tamb\xE9m pode ser adotada na obstru\xE7\xE3o em al\xE7a fechada exatamente pelo seu maior risco de evoluir com estrangulamento.</span>
</p><p>
  <span style="font-weight: 400;">Os demais pacientes s\xE3o abordados, em um primeiro momento, de forma conservadora, mas, caso n\xE3o haja melhora em 3-5 dias (passagem de gases e fezes, al\xE9m da redu\xE7\xE3o da distens\xE3o abdominal e do d\xE9bito pelo cateter nasog\xE1strico), a abordagem cir\xFArgica tamb\xE9m est\xE1 indicada.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">Na obstru\xE7\xE3o parcial de delgado, como parte da abordagem conservadora, pode ser tentada a administra\xE7\xE3o intestinal de contraste hipert\xF4nico sol\xFAvel em \xE1gua (como gastrografina 50-150 mL por via oral ou SNG) que pode reduzir o edema da parede intestinal e estimular a peristalse, ajudando na resolu\xE7\xE3o do quadro obstrutivo, al\xE9m de ter o potencial de auxiliar no diagn\xF3stico etiol\xF3gico da obstru\xE7\xE3o. O contraste pode ser fornecido j\xE1 na admiss\xE3o ou ap\xF3s as primeiras 48 horas da abordagem conservadora que n\xE3o tenha se mostrado resolutiva. Ap\xF3s administrado, seu aparecimento em 24 horas no c\xF3lon em novo exame radiol\xF3gico prediz a resolu\xE7\xE3o da obstru\xE7\xE3o. Infelizmente, no Brasil, \xE9 improv\xE1vel ter essa op\xE7\xE3o do uso do contraste dispon\xEDvel.</span>
</p><p>
  <span style="font-weight: 400;">Alguns casos de obstru\xE7\xE3o podem ter abordagem espec\xEDfica: (1) brida: lise de ader\xEAncia; (2) \xEDleo biliar: enterotomia para retirada do c\xE1lculo seguida de sutura da al\xE7a; (3) volvo de sigmoide: descompress\xE3o com sigmoidoscopia flex\xEDvel, seguida de sigmoidectomia eletiva, uma vez que a recorr\xEAncia pode ser de at\xE9 50%.</span>
</p><p>
  <strong>Antibi\xF3tico \u2013</strong>
  <span style="font-weight: 400;">Embora muitos prescrevam antibi\xF3ticos rotineiramente pelo temor da ocorr\xEAncia de transloca\xE7\xE3o bacteriana, eles s\xF3 s\xE3o imprescind\xEDveis para os casos complicados com peritonite ou estrangulamento e tamb\xE9m como antibioticoprofilaxia na abordagem cir\xFArgica.</span>
</p><p>
  <strong>Outras condutas \u2013</strong>
  <span style="font-weight: 400;">Nos casos de obstru\xE7\xE3o por malignidade em pacientes n\xE3o-candidatos \xE0 cirurgia, pode-se realizar abordagem paliativa com corticoide (para redu\xE7\xE3o do edema perilesional) e/ou octreotide (para redu\xE7\xE3o da secre\xE7\xE3o de conte\xFAdo intraluminal).</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- PSEUDO-OBSTRU\xC7\xC3O \u2013</strong>
  <span style="font-weight: 400;">A pseudo-obstru\xE7\xE3o col\xF4nica aguda (tamb\xE9m chamada de S\xEDndrome de Ogilvie) caracteriza-se pela distens\xE3o aguda do c\xF3lon \u2013 especialmente ceco e c\xF3lon direito \u2013 na aus\xEAncia de obstru\xE7\xE3o mec\xE2nica nos exames de imagem, sendo mais frequente em homens idosos hospitalizados por condi\xE7\xF5es agudas ou em p\xF3s-operat\xF3rio. A abordagem visa promover a descompress\xE3o col\xF4nica inicialmente com abordagem conservadora, que inclui dieta zero, tratamento da doen\xE7a de base, descontinua\xE7\xE3o de f\xE1rmacos que reduzam a motilidade intestinal (como opioides e bloqueadores de canal de c\xE1lcio) e descompress\xE3o intestinal com cateter nasog\xE1strico e tubo retal. Se n\xE3o houver melhora em 24-48 horas ou o di\xE2metro cecal for &gt; 12 cm, deve ser administrada neostigmina (2 mg IV em 5 minutos). Se ainda assim n\xE3o houver melhora, \xE9 tentada descompress\xE3o colonosc\xF3pica ou at\xE9 mesmo cir\xFArgica (coloca\xE7\xE3o de tubo de cecostomia ou mesmo ressec\xE7\xE3o do segmento).</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<p>
  <strong>&nbsp;</strong>
</p><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Saverio SD, Coccolini F, Galati M, et al.</span>
    </em>
    <em>
      <span style="font-weight: 400;">Bologna guidelines for diagnosis and management of adhesive small bowel obstruction (ASBO): 2013 update of the evidence-based guidelines from the world society of emergency surgery ASBO working.</span>
    </em>
    <em>
      <span style="font-weight: 400;">World Journal of Emergency Surgery</span>
    </em>
    <em>
      <span style="font-weight: 400;">&nbsp;2013, 8:42.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Diaz Jr JJ, Bokhari F, Mowery NT, et al. EAST Practice Management Guidelines \u2013 Guideline for Management of Small Bowel Obstruction. J Trauma 2008, 64: 1651-1664.</span>
    </em>
  </li>
</ul><p>&nbsp;</p>`,ordem:6}],videos:[{id:"ba9ad6e7-c66c-44eb-a9eb-42ca0ccf2d2a",titulo:"T\xEDtulo  para Obstru\xE7\xE3o Intestinal",duracao:5,thumbUrl:"https://i.vimeocdn.com/video/716648011_1920x1273.jpg?r=pad"},{id:"277ea850-d525-45a4-81a1-f5738bd45566",titulo:"T\xEDtulo  para Obstru\xE7\xE3o Intestinal",duracao:5,thumbUrl:"https://i.vimeocdn.com/video/716648071_1920x1273.jpg?r=pad"}],fluxogramas:[],tags:["Obstru\xE7\xE3o","Volvo","V\xF3lvulo","Brida","Ader\xEAncia"]},{id:"8cc1b401-6d4a-4bad-8df1-b8db8f144369",nome:"Pancreatite Aguda",categoria:1,termosDeBusca:"pancreatite aguda, ",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"06c339d5-5fe2-4416-b663-1ff202cbc6b9",nome:"Pancreatite Aguda",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"1825dc51-5d30-4fd5-92f8-c881ac819120",opcoes:[{id:"bd845246-71d8-411b-b190-40f4d98bf0ea",descr:"Dieta oral zero (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"c4703b4d-fad9-42aa-a655-54c9bcb4f221",descr:"Dieta oral s\xF3lida com baixo teor de gordura (para pancreatite leve)",recomendado:!1,favorito:!1,ordem:2},{id:"d48de6a1-3384-4e10-8e1d-e514ec794148",descr:"Dieta por sonda nasog\xE1strica ou nasojejunal (para pancreatite moderada/grave)",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Retornar dieta assim que houver melhora dos sintomas (n\xE1usea, v\xF4mitos e dor abdominal); idealmente nas primeiras 48h. ",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e7074350-e254-4412-ad5a-3e86523068bb",opcoes:[{id:"c3358f46-7f31-45cd-bf83-c7d616907889",descr:"Ringer Lactato 250-500 mL/h IV nas primeiras 12-24h",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"bd00e53f-ea7a-49bf-89c8-f9c0b3e32827",opcoes:[{id:"40952045-a9d0-452b-b65e-d148be030e2e",descr:"Ringer Lactato 500 mL IV a crit\xE9rio m\xE9dico",recomendado:!0,favorito:!0,ordem:1}],ordem:2}],academico:"Hidrata\xE7\xE3o agressiva preferencialmente com Ringer Lactato, podendo ser necess\xE1ria reposi\xE7\xE3o mais r\xE1pida (bolus) em caso de deple\xE7\xE3o grave (manifestada com taquicardia e hipotens\xE3o). Principal objetivo: reduzir a ureia. Outros alvos: reduzir hemat\xF3crito (para 35-44%) e creatinina, FC < 120 bpm, PA m\xE9dia 65-85 mmHg, d\xE9bito urin\xE1rio 0,5-1 ml/kg/h.",ordem:2},{item:"ANALGESIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"5ab8ca1b-bba4-4f1d-9591-d1bddc57d1ba",opcoes:[{id:"61b07dea-f0c9-4fa7-9701-53f19013d4f0",descr:"Meperidina (50mg/mL) + SF 0,9% 9 mL (solu\xE7\xE3o 5mg/mL) - 25-50 mg IV 4/4h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"b7e88ccb-b7f2-4ad7-8fe5-cea8b71a2cdc",descr:"Tramadol (50mg/mL) 50-100 mg IV 6/6h",recomendado:!1,favorito:!1,ordem:2},{id:"3b633376-1514-4864-97c8-cacc74b1c0fd",descr:"Morfina (10mg/mL) 1 mL + \xC1gua Destilada 9 mL (solu\xE7\xE3o: 1mg/mL) 5 mg IV 4/4h",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Oferecer conforto ao paciente.",ordem:3},{item:"ANTIBIOTICOTERAPIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2710306a-e767-410a-a7f0-f524407526bf",opcoes:[{id:"60c0e476-ec17-41f9-97de-97cbc2938b77",descr:"Imipenem 500-1000 mg IV 6/6h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"cdf349d0-1b5a-4205-88a2-2672409886d6",descr:"Meropenem 1 g IV 8/8h",recomendado:!1,favorito:!1,ordem:2},{id:"834d6a70-f0ea-4d45-9a16-f495671cff18",descr:"Moxifloxacina 400 mg IV 1x/dia",recomendado:!1,favorito:!1,ordem:3},{id:"8658279c-9282-437f-a3ea-c834c14395e2",descr:"Ciprofloxacina 400 mg IV 12/12h + Metronidazol 500 mg IV 8/8h (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:4},{id:"73829106-7aa9-48b6-b965-b70850ddc069",descr:"Levofloxacina 750 mg IV 1x/dia + Metronidazol 500 mg IV 8/8h (boa op\xE7\xE3o em caso de alergia \xE0 penicilina)",recomendado:!1,favorito:!1,ordem:5}],ordem:1}],academico:"Indicada em casos de necrose pancre\xE1tica sem melhora em 7-10 dias, sendo opcional a aspira\xE7\xE3o por agulha fina guiada por TC para gram e cultura com o intuito de guiar a escolha anibi\xF3tica.",ordem:4},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"69334044-9844-4c8c-a915-c6c94c039b09",opcoes:[{id:"5e774724-1a5a-4a7d-99bc-e89a475fc1ca",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"9d0b4479-2b62-4d55-894f-563cac90a61a",opcoes:[{id:"b31cdcde-6dd7-48b2-a472-a47a7fc252b3",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"7f1206ca-c3bf-4139-8167-8d7a0b2d49b9",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"816124c0-a629-4850-8fb5-2343fe2b7d1e",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:5},{item:"PROFIL\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"09428075-63f8-4be8-915c-94cb5d4a660f",opcoes:[{id:"3eaa3afe-5c73-415d-b0a7-d954996a3dda",descr:"Esomeprazol (20-40mg/comp) 20-40 mg VO 1x/dia pela manh\xE3 (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"94252f07-2a34-4126-9a11-8dc48fcfe102",descr:"Esomeprazol (40mg/frasco) 20 mg IV 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:2},{id:"8d2c0112-7f3d-4175-8af0-0ed2a094ff03",descr:"Omeprazol (10-40mg/comp) 20-40 mg VO 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:3},{id:"a69a29d0-49ab-4e42-9ae3-695733478de7",descr:"Omeprazol (40mg/10mL) 20-40 mg IV 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:4},{id:"a0761d78-6235-47c2-a497-1d9f0b7d7b5c",descr:"Lansoprazol (15-30mg/comp) 15-30 mg VO 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:5}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"0b555449-ddbc-4ac3-b071-96bb1590e00d",opcoes:[{id:"f471bda5-73d8-4cd8-b691-7d6661b1426c",descr:"Enoxaparina (20mg/0,2mL) 40 mg SC 1x/dia \xE0s 18 horas (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"d220e206-3f89-4e2d-bd1b-f56a42d3aa00",descr:"Dalteparina (12.500-25.000UI/mL) 5.000 UI SC 1x/dia \xE0s 18 horas",recomendado:!1,favorito:!1,ordem:2},{id:"7b9360e9-23e4-4d28-8f06-b5bf8ad575c3",descr:"Heparina n\xE3o-fracionada (5.000UI/0,25mL) 5.000 UI SC 8/8h ou 12/12h",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Profilaxia de les\xE3o aguda de mucosa g\xE1strica e doen\xE7a venosa profunda.",ordem:6},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f3a28b90-3bfa-47d8-8c2c-296455ebdede",opcoes:[{id:"8c8589e4-e86d-4941-b134-7e386d7f68c1",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"41a9e4ae-fad9-479d-965b-6ee93ea5716d",opcoes:[{id:"6c81254f-7d32-4708-8ba9-deb6f7076b31",descr:"Glicemia capilar 6/6h ",recomendado:!0,favorito:!0,ordem:1},{id:"ef7d4fb3-995f-4c51-9cf3-114b2ac49669",descr:"Glicose Hipert\xF4nica 50% - 50mL (5 ampolas) se glicemia capilar < 70 mg/mL",recomendado:!1,favorito:!1,ordem:2},{id:"fa4a1866-f9b8-4f6d-823f-86f20243c995",descr:"Insulina Regular SC conforme esquema: 141-200=2U / 201-250=4U / 251-300=6U / 301-350=8U / 351-400=10U / > 400=12U. Se > 400 ou < 70, avisar plantonista",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Cuidados inespec\xEDficos.",ordem:7}],conceitosPraticos:[{conceito:"Diagn\xF3stico com 2 dos seguintes: cl\xEDnica (dor epig\xE1strica aguda), laborat\xF3rio (eleva\xE7\xE3o da amilase e/ou lipase > 3x o limite da normalidade) e imagem (TC, RM, USG).",ordem:1},{conceito:"Leve: sem disfun\xE7\xE3o org\xE2nica ou complica\xE7\xF5es locais / Moderadamente Grave: disfun\xE7\xE3o org\xE2nica < 48 h e/ou ou complica\xE7\xF5es locais / Grave: disfun\xE7\xE3o org\xE2nica > 48h",ordem:2},{conceito:"N\xE3o se recomenda antibioticoprofilaxia.",ordem:3},{conceito:"Na etiologia liti\xE1sica, a colecistectomia deve ser realizada antes da alta na pancreatite leve e ap\xF3s resolu\xE7\xE3o ou estabiliza\xE7\xE3o do quadro inflamat\xF3rio e das cole\xE7\xF5es fluidas nos casos que evolu\xEDram com necrose.",ordem:4}]}],topicos:[{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">A pancreatite aguda \xE9 o processo inflamat\xF3rio agudo do p\xE2ncreas que ainda pode envolver \xE1reas peripancre\xE1ticas ou \xF3rg\xE3os mais distantes. \xC9 classificada do ponto de vista morfol\xF3gico em:</span>
</p><p>
  <span style="font-weight: 400;">(1) Intersticial edematosa: caracterizada pela inflama\xE7\xE3o aguda do par\xEAnquima e tecidos peripancre\xE1ticos, por\xE9m sem necrose;</span>
</p><p>
  <span style="font-weight: 400;">(2) Necrosante (ou necrotizante): presen\xE7a de inflama\xE7\xE3o associada a necrose pancre\xE1tica e/ou do tecido peripancre\xE1tico.</span>
</p><p>
  <span style="font-weight: 400;">A pancreatite aguda pode, ainda, ser classificada de acordo com sua gravidade em:</span>
</p><p>
  <span style="font-weight: 400;">(1) Leve: aus\xEAncia de disfun\xE7\xE3o org\xE2nica e complica\xE7\xF5es locais ou sist\xEAmicas;</span>
</p><p>
  <span style="font-weight: 400;">(2) Moderadamente Grave: disfun\xE7\xE3o org\xE2nica transit\xF3ria (resolu\xE7\xE3o &lt; 48h) e/ou complica\xE7\xF5es locais (cole\xE7\xE3o peripancre\xE1tica, necrose, pseudocisto, necrose murada);</span>
</p><p>
  <span style="font-weight: 400;">(3) Grave: disfun\xE7\xE3o org\xE2nica persistente (&gt; 48h).</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Disfun\xE7\xE3o org\xE2nica: choque (PA sist\xF3lica &lt; 90 mmHg), insufici\xEAncia respirat\xF3ria (PaO</span>
  </em>
  <em>
    <span style="font-weight: 400;">2</span>
  </em>
  <em>
    <span style="font-weight: 400;">&lt; 60 mmHg), insufici\xEAncia renal (creatinina &gt; 2 mg/dL ap\xF3s hidrata\xE7\xE3o) e/ou hemorragia digestiva (&gt; 500 mL/24h).</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Dentre as causas mais comuns para pancreatite aguda destacam-se: lit\xEDase biliar (40-70%) e \xE1lcool (25-35%), seguidos de medicamentos (6-mercaptopurina, azatioprina, didanosina), hipercalcemia, hipertrigliceridemia (&gt; 1000 mg/dL), p\xF3s-CPRE (colangiopancreatografia retr\xF3grada endosc\xF3pica) e p\xF3s-trauma.</span>
</p>`,ordem:1},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">O quadro cl\xEDnico inclui dor abdominal de in\xEDcio agudo, cont\xEDnua, de forte intensidade, em andar superior do abdome, geralmente em faixa (conhecida tamb\xE9m como \u201Cdor em barra\u201D) e com possibilidade de irradiar para dorso. Associado ao quadro \xE1lgico, encontram-se n\xE1usea e v\xF4mitos e, em alguns casos, dispneia e febre. Quando a febre persiste por mais de 48 horas, est\xE1 correlacionada, mais provavelmente, \xE0 presen\xE7a de quadro infeccioso.</span>
</p><p>
  <span style="font-weight: 400;">Ao exame f\xEDsico, encontra-se um abdome doloroso \xE0 palpa\xE7\xE3o, com distens\xE3o e diminui\xE7\xE3o dos ru\xEDdos hidroa\xE9reos e, em alguns casos, com sinais de peritonite. Dependendo da gravidade, pode-se encontrar taquicardia, taquidispneia, hipotens\xE3o arterial e rebaixamento do n\xEDvel de consci\xEAncia. Os famosos sinais de Cullen (equimose periumbilical) e Grey-Turner (equimose de flancos) s\xE3o raros. Sua presen\xE7a</span> 
  <span style="font-weight: 400;">n\xE3o \xE9 espec\xEDfica para pancreatite, mas sim para sangramento retroperitoneal - que pode estar presente no contexto de pancreatite necrosante.</span>
</p><p>
  <span style="font-weight: 400;">Outras altera\xE7\xF5es mais raras incluem: n\xF3dulos subcut\xE2neos dolorosos nas extremidades (paniculite), icter\xEDcia (na lit\xEDase biliar) e xantomas (na hipertrigliceridemia).</span>
</p><p>
  <strong>DIAGN\xD3STICO -</strong>
  <span style="font-weight: 400;">O diagn\xF3stico de pancreatite aguda requer 2 dos seguintes crit\xE9rios:</span>
</p><p>
  <span style="font-weight: 400;">(1) Dor epig\xE1strica aguda, cont\xEDnua e de forte intensidade, com ou sem irradia\xE7\xE3o para dorso;</span>
</p><p>
  <span style="font-weight: 400;">(2) Aumento da amilase e/ou lipase (tr\xEAs vezes acima do limite superior da normalidade);</span>
</p><p>
  <span style="font-weight: 400;">(3) Imagem compat\xEDvel com pancreatite aguda na Tomografia Computadorizada (TC) ou Resson\xE2ncia Magn\xE9tica (RM) ou Ultrassonografia Abdominal (USG).</span>
</p><p>
  <span style="font-weight: 400;">Com rela\xE7\xE3o \xE0 imagem, ela n\xE3o \xE9 necessariamente obrigat\xF3ria no momento inicial de investiga\xE7\xE3o, j\xE1 que o diagn\xF3stico muitas vezes ser\xE1 feito pelos 2 primeiros crit\xE9rios. De qualquer forma, com a confirma\xE7\xE3o da pancreatite, a USG torna-se obrigat\xF3ria para todos os pacientes, em especial pela sua utilidade em encontrar a principal etiologia: lit\xEDase biliar, que dever\xE1 ser precocemente abordada com colecistectomia. Por sua vez, a TC e a RM n\xE3o dever\xE3o ser realizadas nos primeiros dias pelo fato da extens\xE3o da agress\xE3o pancre\xE1tica n\xE3o ser completamente aparente no in\xEDcio da agress\xE3o. Assim, s\xF3 h\xE1 indica\xE7\xE3o formal de sua realiza\xE7\xE3o nos casos de diagn\xF3stico duvidoso ou que n\xE3o melhorem com 48-72h de tratamento (dor persistente, febre, n\xE1usea, incapacidade de alimenta\xE7\xE3o oral).</span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/7f1772f2-a76d-428f-b1c5-d10b3955de40.jpg" alt="" width="100%" height="auto">
  </span>
</p><p>
  <span style="font-weight: 400;">A investiga\xE7\xE3o deve incluir solicita\xE7\xE3o de outros exames laboratoriais que podem ajudar a afastar outras etiologias de dor abdominal: hemograma, eletr\xF3litos, transaminases (ALT, AST), bilirrubina, c\xE1lcio, albumina e, para mulheres em idade f\xE9rtil, beta-HCG.</span>
</p><p>&nbsp;</p>`,ordem:2},{titulo:"TRATAMENTO",texto:`<p>
  <strong>Estratifica\xE7\xE3o de risco \u2013</strong>
  <span style="font-weight: 400;">Como muitos pacientes que desenvolve um quadro severo apresentam-se inicialmente sem aparente gravidade, a avalia\xE7\xE3o de risco \xE9 importante para auxiliar na triagem, ajudando, por exemplo, a definir interna\xE7\xE3o em terapia intensiva. Diversos escores foram criados para este fim, como o escores de Ranson, BISAP e o de Balthazar (\xEDndice de gravidade da TC), entretanto a maioria necessita de dados da admiss\xE3o e de, pelo menos, 48 horas.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">Assim, mais do que ficar dependente de sistema de escores para predizer a gravidade de um quadro de pancreatite aguda, deve-se ter conhecimento de fatores de risco individuais organizados em 4 pilares:&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">(1) Caracter\xEDsticas do paciente: &gt; 55 anos, comorbidades, altera\xE7\xE3o do estado mental, IMC &gt; 30 kg/m\xB2;</span>
</p><p>
  <span style="font-weight: 400;">(2) S\xEDndrome da Resposta Inflamat\xF3ria Sist\xEAmica (SIRS)</span>
</p><p>
  <span style="font-weight: 400;">(3) Laborat\xF3rio (com sinais de hipovolemia): Hemat\xF3crito &gt; 44% (ou evolutivamente pior), Ureia &gt; 42,8 mg/dl (BUN &gt; 20 mg/dl), eleva\xE7\xE3o de creatinina</span>
</p><p>
  <span style="font-weight: 400;">(4) Imagem: derrame pleural, infiltrado pulmonar, m\xFAltiplas e/ou extensas cole\xE7\xF5es extrapancre\xE1ticas</span>
</p><p>
  <span style="font-weight: 400;">Independente dessas caracter\xEDsticas, pacientes com disfun\xE7\xE3o org\xE2nica ou SIRS persistente (48 horas) devem ser admitidos idealmente na unidade de terapia intensiva.</span>
</p><p>
  <strong>Hidrata\xE7\xE3o venosa \u2013</strong>
  <span style="font-weight: 400;">Como os pacientes costumam estar hipovol\xEAmicos e com risco de menor perfus\xE3o pancre\xE1tica (perda para o 3\xBA espa\xE7o pelo aumento da permeabilidade vascular, v\xF4mitos, diaforese e perdas respirat\xF3rias), a ressuscita\xE7\xE3o vol\xEAmica deve ser agressiva (250-500 mL/h) nas primeiras 12-24 horas da admiss\xE3o, utilizando preferencialmente solu\xE7\xE3o de Ringer Lactato. A avalia\xE7\xE3o do estado vol\xEAmico do paciente deve ser frequente nas primeiras 6 horas e mantida at\xE9 24-48 horas \u2013 maior cuidado com idosos, cardiopatas e nefropatas pelo maior risco de hiper-hidrata\xE7\xE3o (congest\xE3o pulmonar, eleva\xE7\xE3o da press\xE3o intra-abdominal). O objetivo principal da hidrata\xE7\xE3o \xE9 reduzir a ureia, apesar de outros alvos tamb\xE9m serem utilizados, como redu\xE7\xE3o do hemat\xF3crito (para 35-44%) e da creatinina e manuten\xE7\xE3o de frequ\xEAncia card\xEDaca &lt; 120 bpm, PA m\xE9dia entre 65-85 mmHg e d\xE9bito urin\xE1rio 0,5-1 ml/kg/h.</span>
</p><p>
  <strong>Analgesia -</strong>
  <span style="font-weight: 400;">Deve ser realizada com opioides intravenosos, como fentanil, meperidina e morfina.&nbsp;</span>
</p><p>
  <strong>Nutri\xE7\xE3o precoce (&lt; 48h) -</strong>
  <span style="font-weight: 400;">Pacientes com pancreatite leve devem reiniciar a dieta oral (s\xF3lida, com baixo teor de gordura) assim que houver melhora dos sintomas (n\xE1usea, v\xF4mitos e dor abdominal) e presen\xE7a de peristalse, o que geralmente ocorre em 24-48 horas. Nos casos de pancreatite moderada/grave, em que a dieta oral n\xE3o \xE9 tolerada, \xE9 recomendado o uso da via enteral (sondas nasog\xE1strica e nasojejunal parecem ser igualmente eficazes) com intuito de prevenir complica\xE7\xF5es infecciosas. A nutri\xE7\xE3o parenteral deve ser evitada, ficando reservada para pacientes que n\xE3o toleram a dieta enteral ou quando esta n\xE3o se encontra dispon\xEDvel.</span>
</p>`,ordem:3},{titulo:"COMPLICA\xC7\xD5ES",texto:`<p>
  <span style="font-weight: 400;">As complica\xE7\xF5es locais agudas (\u2264 4 semanas) incluem a cole\xE7\xE3o peripancr\xE9tica e a necrose, que, ao cronificarem (&gt; 4 semanas), desenvolvem \u201Cparedes\u201D ao seu redor e passam a ser denominadas, respectivamente, de pseudocisto e necrose murada. Tais complica\xE7\xF5es, em geral, n\xE3o precisam de interven\xE7\xE3o cir\xFArgica, exceto em casos sintom\xE1ticos.</span>
</p><p>
  <span style="font-weight: 400;">J\xE1 a infec\xE7\xE3o da necrose pancre\xE1tica \xE9 uma grave complica\xE7\xE3o que pode ocorrer dentro dos primeiros 14 dias a partir de uma necrose at\xE9 ent\xE3o est\xE9ril e est\xE1 associada a aumento da morbimortalidade. Deve ser suspeitada quando h\xE1 deteriora\xE7\xE3o do quadro cl\xEDnico (instabilidade hemodin\xE2mica ou sepse, febre, leucocitose) ou aus\xEAncia de melhora ap\xF3s 7-10 dias de interna\xE7\xE3o. A imagem (TC) demonstrando a presen\xE7a de g\xE1s associada \xE0 necrose \xE9 sugestiva de infec\xE7\xE3o. Nesse contexto, est\xE1 indicada antibioticoterapia emp\xEDrica sem a obrigatoriedade de fazer aspira\xE7\xE3o com agulha fina e cultura da necrose.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">As principais op\xE7\xF5es incluem carbapen\xEAmicos, quinolonas, cefalosporinas e metronidazol por terem boa penetra\xE7\xE3o na \xE1rea necr\xF3tica:</span>
</p><p>
  <span style="font-weight: 400;">- Imipenem 500 - 1000 mg IV 6/6h</span>
</p><p>
  <span style="font-weight: 400;">- Meropenem 1g IV 8/8h&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">- Moxifloxacina 400 mg IV 1x/dia</span>
</p><p>
  <span style="font-weight: 400;">- (Ciprofloxacina 400mg IV 12/12h ou Levofloxacina 750 mg IV 1x/dia) + Metronidazol 500 mg IV 8/8h</span>
</p><p>
  <span style="font-weight: 400;">- Cefepime 2g IV 8/8h + Metronidazol 500 mg IV 8/8h</span>
</p><p>
  <span style="font-weight: 400;">Em tese, tamb\xE9m sempre se indica a interven\xE7\xE3o para remo\xE7\xE3o da \xE1rea necr\xF3tica infectada. Caso o paciente esteja est\xE1vel, deve-se adiar a cirurgia, preferencialmente por 4 semanas, para que haja forma\xE7\xE3o de parede ao redor do conte\xFAdo necr\xF3tico, promovendo certa \u201Corganiza\xE7\xE3o\u201D e facilitando o procedimento. Quanto \xE0 t\xE9cnica, a prefer\xEAncia atual \xE9 por modalidades minimamente invasivas, como necrosectomia por via laparosc\xF3pica, drenagem percut\xE2nea sem necrosectomia ou mesmo combina\xE7\xE3o de drenagem endosc\xF3pica seguida de necrosectomia tamb\xE9m por endoscopia.</span>
</p>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Antibi\xF3tico profil\xE1tico -</strong>
  <span style="font-weight: 400;">Durante muito tempo, houve uma recomenda\xE7\xE3o para o uso de antibioticoprofilaxia nos casos de necroses extensas. Entretanto, atualmente, seu uso rotineiro n\xE3o \xE9 recomendado. Assim, a prescri\xE7\xE3o de antibi\xF3tico s\xF3 se justifica nos casos em que uma infec\xE7\xE3o - pancre\xE1tica ou n\xE3o - for comprovada ou altamente suspeita.</span>
</p><p>
  <strong>- Momento da colecistectomia -</strong>
  <span style="font-weight: 400;">Nos casos de pancreatite aguda de origem biliar, a colecistectomia laparosc\xF3pica ser\xE1 realizada para evitar recorr\xEAncia de quadros liti\xE1sicos. Mas em que momento realiz\xE1-la? Nos pacientes com pancreatite leve, ela deve ser feita antes da alta. J\xE1, nos pacientes com pancreatite necrosante, deve ser adiada at\xE9 \u201Cesfriar\u201D o processo inflamat\xF3rio e ocorrer resolu\xE7\xE3o das cole\xE7\xF5es peripancre\xE1ticas, mas, de qualquer maneira, a colecistectomia j\xE1 \xE9 considerada segura a partir de 6 semanas, mesmo nos casos em que tais cole\xE7\xF5es tenham permanecido.</span>
</p><p>
  <strong>- Uso indiscriminado da CPRE -</strong>
  <span style="font-weight: 400;">Embora a lit\xEDase biliar seja a grande causa de pancreatite aguda, a CPRE n\xE3o deve ser feita de rotina, uma vez que a maior parte dos c\xE1lculos causadores do quadro inflamat\xF3rio passam diretamente ao duodeno, sendo eliminados atrav\xE9s das fezes. Assim, a \xFAnica recomenda\xE7\xE3o nesse sentido \xE9 para a realiza\xE7\xE3o de uma CPRE precoce (nas primeiras 24 horas de admiss\xE3o) apenas em casos associados \xE0 colangite. A investiga\xE7\xE3o de coledocolit\xEDase, quando suspeitada na fase aguda da pancreatite, \xE9 realizada preferencialmente com US endosc\xF3pico ou colangiorresson\xE2ncia.</span>
</p><p>
  <strong>- Acompanhamento de enzimas pancre\xE1ticas \u2013</strong>
  <span style="font-weight: 400;">Depois do diagn\xF3stico de pancreatite, n\xE3o h\xE1 motivo para acompanhar o n\xEDvel s\xE9rico de amilase e lipase, pois seu comportamento n\xE3o tem correla\xE7\xE3o com a gravidade e o progn\xF3stico.</span>
</p><p>
  <strong>- Pancreatite aguda idiop\xE1tica \u2013</strong>
  <span style="font-weight: 400;">Os casos de pancreatite aguda idiop\xE1tica (sem etiologia definida) devem ser investigados com USG endosc\xF3pica e colangiorresson\xE2ncia e, como muitas dessas situa\xE7\xF5es s\xE3o estatisticamente atribu\xEDdas \xE0 microlit\xEDase e lama biliar, pode-se indicar colecistectomia caso o paciente tolere a cirurgia.</span>
</p>`,ordem:5},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<p>
  <br>
</p><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Tenner S, Vege SS, Sheth SG et al. American College of Gastroenterology Guidelines: Management of Acute Pancreatitis. Am J Gastroenterol 2024; 119:419-437.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Working Group IAP/APA Acute Pancreatitis Guidelines. IAP/APA evidence-based guidelines for the management of acute pancreatitis. Pancreatology 2013; 13:e1.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Tenner S, Baillie J, DeWitt J, et al. American College of Gastroenterology guideline: management of acute pancreatitis. Am J Gastroenterol 2013; 108:1400.</span>
    </em>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <em>
      <span style="font-weight: 400;">Banks PA, Bollen TL, Dervenis C, et al. Classification of acute pancreatitis--2012: revision of the Atlanta classification and definitions by international consensus. Gut 2013; 62:102.</span>
    </em>
  </li>
</ul><p>&nbsp;</p>`,ordem:6}],videos:[],fluxogramas:[],tags:[]},{id:"e30b6d51-d103-490b-a9fe-d8dc022671b8",nome:"Pancreatite Cr\xF4nica",categoria:2,termosDeBusca:"pancreatite cronica, ",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"724e8a16-7a27-4678-9e02-c10d4bfe4f05",nome:"Pancreatite Cr\xF4nica",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"43342de1-9e65-4874-a321-cfb6661c1d04",opcoes:[{id:"394e47f0-a005-4aac-8609-c0a3d82439da",descr:"Dieta rica em frutas e legumes.",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Antioxidantes podem auxiliar no efeito analg\xE9sico.",ordem:1},{item:"ANALGESIA INICIAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e9c2e05f-8617-4bba-87d6-077d896bf543",opcoes:[{id:"0a8c9131-0df9-4787-9804-d6d8367be093",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Buscar estrat\xE9gia escalonada.",ordem:2},{item:"ANALGESIA NATURAL",grupos:[{grupo:"Analg\xE9sico",idGrupo:"cac84e49-1888-4a3e-b72c-daa337e21ada",opcoes:[{id:"00fa411a-8e8e-48ad-981b-4eb9f4f4818f",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Antioxidantes podem auxiliar no efeito analg\xE9sico.",ordem:3},{item:"ANALGESIA OPIOIDE",grupos:[{grupo:"Analg\xE9sico",idGrupo:"1e3874f4-aa27-46f6-9044-5aedd4675ea1",opcoes:[{id:"c8fabda1-7e77-468e-9009-e8e6751bb3c5",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Postergar para evitar abuso e depend\xEAncia.",ordem:4},{item:"ANALGESIA ADJUVANTE",grupos:[{grupo:"Analg\xE9sico",idGrupo:"fcf87f54-557f-4965-9a31-cc2d24020eae",opcoes:[{id:"92096539-58f2-453e-8d53-c9023a6ad451",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Associar quando iniciar opioide para reduzir a necessidade deste.",ordem:5},{item:"TERAPIA DE REPOSI\xC7\xC3O DE ENZIMA PANCRE\xC1TICA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"43e40151-10e2-4035-8670-09e0c5952617",opcoes:[{id:"d33b68d0-2140-4d0d-9db6-bb4d79aa9104",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:6},{item:"TERAPIA DE REPOSI\xC7\xC3O DE ENZIMA PANCRE\xC1TICA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f1439717-6283-4468-b0c8-34a58bcfbef6",opcoes:[{id:"89a1fab5-e29a-42fc-9de2-271e29339ac8",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:6},{item:"CALCIO VITAMINA D",grupos:[{grupo:"Analg\xE9sico",idGrupo:"26454344-06e7-4625-92a5-4797f15dcc06",opcoes:[{id:"8dfa4920-7b70-49f4-a1de-8a1e7e4f5f10",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:7},{item:"CALCIO VITAMINA D",grupos:[{grupo:"Analg\xE9sico",idGrupo:"392c4a71-63da-4d05-a824-b815c5529092",opcoes:[{id:"347c8b22-57df-4a68-bdd4-e071ad87b951",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],ordem:7}],conceitosPraticos:[{conceito:"Cl\xEDnica: dor abdominal, insufici\xEAncias ex\xF3crina (disabsor\xE7\xE3o) e end\xF3crina (diabetes).",ordem:1},{conceito:"Diagn\xF3stico: TC/RM de p\xE2ncreas \u2192 USG endosc\xF3pica \u2192 colangiopancreatografia por RM com secretina \u2192 bi\xF3psia.",ordem:2},{conceito:"Todos: interromper tabagismo e etilismo.",ordem:3}]}],topicos:[{titulo:"Pancreatite Cro\u0302nica",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">A pancreatite cr\xF4nica \xE9 uma doen\xE7a fibroinflamat\xF3ria do p\xE2ncreas causada por epis\xF3dios recorrentes de inflama\xE7\xE3o pancre\xE1tica que resultam na substitui\xE7\xE3o do seu par\xEAnquima por tecido fibroso. Tais epis\xF3dios inflamat\xF3rios podem ter diferentes etiologias (\xE1lcool, tabagismo, autoimune, recorr\xEAncia de pancreatite aguda) que muitas vezes est\xE3o sobrepostas, al\xE9m de contribui\xE7\xE3o de fatores de risco gen\xE9ticos individuais.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* O \xE1lcool \xE9 o principal fator de risco, atuando tamb\xE9m como cofator em pessoas que s\xE3o suscept\xEDveis a desenvolver a patologia por outros fatores.</span>
  </em>
</p>`,ordem:2},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">A reorganiza\xE7\xE3o fibr\xF3tica do p\xE2ncreas leva progressivamente a uma insufici\xEAncia pancre\xE1tica ex\xF3crina (s\xEDndrome disabsortiva com esteatorreia e defici\xEAncia de vitaminas A, D, E e K com manifesta\xE7\xF5es associadas, como osteoporose) e end\xF3crina (diabetes), al\xE9m de provocar dor abdominal, que \xE9 seu sintoma mais comum (pela hipertens\xE3o de ductos pancre\xE1ticos por rolhas proteicas, c\xE1lculos e a pr\xF3pria fibrose). A dor \xE9 tipicamente piora 5-10 minutos ap\xF3s alimenta\xE7\xE3o, tem localiza\xE7\xE3o mais epig\xE1strica com irradia\xE7\xE3o para dorso e apresenta algum al\xEDvio inclinando o corpo para frente ou assumindo a posi\xE7\xE3o genupeitoral.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Pelo risco de osteoporose, recomenda-se realizar densitometria \xF3ssea a cada 2 anos.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Outras complica\xE7\xF5es menos frequentes ainda podem surgir, como pseudocisto (manuten\xE7\xE3o por mais de 4 semanas ganha a denomina\xE7\xE3o de necrose organizada), ascite pancre\xE1tica, derrame pleural pancre\xE1tico, obstru\xE7\xE3o biliar e duodenal, pseudoaneurisma (les\xE3o c\xEDstica vascular de art\xE9rias espl\xEAnica, gastroduodenal, pancreaticoduodenal ou hep\xE1tica com risco sangramento), trombose de veia espl\xEAnica (que gera hipertens\xE3o porta segmentar com risco de hemorragia digestiva por ruptura de varizes g\xE1stricas isoladas) e at\xE9 c\xE2ncer de p\xE2ncreas.</span>
</p><p>
  <span style="font-weight: 400;">Portadores de pancreatite cr\xF4nica s\xE3o tamb\xE9m mais predispostos a doen\xE7a ulcerosa p\xE9ptica (defici\xEAncia de secre\xE7\xE3o alcalina pelo p\xE2ncreas), lit\xEDase biliar (retardo do esvaziamento da ves\xEDcula) e lit\xEDase renal (mais excre\xE7\xE3o urin\xE1ria de oxalato de c\xE1lcio quando j\xE1 h\xE1 esteatorreia).</span>
</p>`,ordem:3},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">Um componente cr\xEDtico para a percep\xE7\xE3o de pancreatite cr\xF4nica \xE9 a demonstra\xE7\xE3o de altera\xE7\xF5es morfol\xF3gicas (como fibrose) no tecido pancre\xE1tico, de forma que, para confirma\xE7\xE3o diagn\xF3stica, o primeiro exame deve ser TC ou RM do p\xE2ncreas. Em caso de d\xFAvida, uma op\xE7\xE3o \xE9 a USG endosc\xF3pica, que tem maior grau de invas\xE3o e menor especificidade. Se ainda assim, a d\xFAvida persistir uma alternativa passa a ser a colangiopancreatografia por RM com estimula\xE7\xE3o com secretina ou at\xE9 mesmo bi\xF3psia guiada por USG endosc\xF3pico (esta \xFAltima tamb\xE9m \xFAtil no diagn\xF3stico diferencial de massas pancre\xE1ticas). A CPRE, por sua vez, perdeu espa\xE7o como m\xE9todo diagn\xF3stico.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Testes que avaliam a fun\xE7\xE3o pancre\xE1tica ex\xF3crina n\xE3o s\xE3o imprescind\xEDveis para o diagn\xF3stico, por\xE9m podem ser realizados de modo complementar (a quantifica\xE7\xE3o da gordura fecal em 72h parece ser o padr\xE3o-ouro, mas, com frequ\xEAncia, inicia-se a interpreta\xE7\xE3o pela esteatorreia cl\xEDnica ou mensura\xE7\xE3o da elastase fecal, que \xE9 uma enzima exclusivamente pancre\xE1tica e n\xE3o degrad\xE1vel no trato digestivo, estando tipicamente reduzida na insufici\xEAncia pancre\xE1tica ex\xF3crina).</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">
      <img src="https://d55mnj1ee66xh.cloudfront.net/academico/53e29925-1232-4230-9969-9ec6cf4c6c1c.jpg" alt="" width="100%" height="auto">
    </span>
  </em>
</p><p>
  <span style="font-weight: 400;">Durante a investiga\xE7\xE3o e ap\xF3s o diagn\xF3stico, \xE9 importante a pesquisa de etiologias, como consumo de \xE1lcool ou cigarro, hipertrigliceridemia, epis\xF3dios pregressos de pancreatite aguda e altera\xE7\xF5es obstrutivas em m\xE9todos de imagem. Em casos de etiologia indeterminada, \xE9 \xFAtil a pesquisa gen\xE9tica \u2013 especialmente em pacientes jovens, analisando, pelo menos, as muta\xE7\xF5es gen\xE9ticas PRSS1, SPINK1, CTRC e CFTR (associa\xE7\xE3o com fibrose c\xEDstica) \u2013 nos casos ainda indeterminados, pode-se pesquisar etiologia autoimune (imagem com aspecto de \u201Cp\xE2ncreas em salsicha\u201D, histologia e laborat\xF3rio com dosagem de IgG4).</span>
</p>`,ordem:4},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">Todos os pacientes devem interromper o h\xE1bito de fumar e beber com a inten\xE7\xE3o de evitar a progress\xE3o da doen\xE7a. Por sua vez, n\xE3o h\xE1 recomenda\xE7\xE3o formal para rastreio de c\xE2ncer de p\xE2ncreas especialmente pela pouca probabilidade de modificar sua hist\xF3ria natural mesmo com um diagn\xF3stico precoce.</span>
</p><p>
  <strong>Dor \u2013</strong>
  <span style="font-weight: 400;">A queixa do paciente que mais impacta sua qualidade de vida \xE9 a dor abdominal que, na ess\xEAncia, tem uma origem multifatorial, envolvendo tanto a les\xE3o do p\xE2ncreas quanto altera\xE7\xF5es na sinaliza\xE7\xE3o nociceptiva visceral, o que acaba limitando a efic\xE1cia do tratamento. De qualquer forma, invariavelmente acabam sendo prescritos f\xE1rmacos de modo escalonado, iniciando com AINE e analg\xE9sicos sist\xEAmicos (dipirona e paracetamol) e postergando ao m\xE1ximo o uso de opioides pelo risco de depend\xEAncia e abuso, especialmente em uma popula\xE7\xE3o que j\xE1 pode ter hist\xF3rico de abuso de outras subst\xE2ncias, como \xE1lcool. De qualquer forma, \xE9 interessante que, em casos refrat\xE1rios que necessitem de opioide, seja feita associa\xE7\xE3o com outros agentes como antidepressivo tric\xEDclico, inibidor seletivo de recapta\xE7\xE3o de serotonina (ISRSs), inibidores de recapta\xE7\xE3o de serotonina e norepinefrina ou gabapentoides. Outra op\xE7\xE3o a ser considerada, embora com benef\xEDcio incerto, \xE9 a terapia com antioxidantes (vitaminas C e E, sel\xEAnio, metionina, beta-caroteno) e, nesse racioc\xEDnio, pode-se estimular o consumo de alimentos ricos tamb\xE9m em antioxidantes, como frutas e legumes.</span>
</p><p>
  <span style="font-weight: 400;">Na aus\xEAncia de melhora com a abordagem farmacol\xF3gica conservadora, as interven\xE7\xF5es subsequentes depender\xE3o da exist\xEAncia de dilata\xE7\xE3o de ducto pancre\xE1tico principal. Se n\xE3o houver dilata\xE7\xE3o, uma boa alternativa \xE9 o bloqueio do plexo cel\xEDaco, que geralmente precisa ser repetido a cada 3-6 meses. J\xE1, se houver dilata\xE7\xE3o, busca-se a drenagem desse ducto dilatado com prefer\xEAncia inicial por procedimentos endosc\xF3picos (como esfincterotomia pancre\xE1tica ou coloca\xE7\xE3o de</span>
  <em>
    <span style="font-weight: 400;">stent</span>
  </em>
  <span style="font-weight: 400;">por CPRE, litotripsia extracorp\xF3rea na presen\xE7a de c\xE1lculos seguida de extra\xE7\xE3o por endoscopia), que ter\xE3o mais sucesso nas obstru\xE7\xF5es mais proximais \u2013 em caso de falha, pode-se tentar procedimentos cir\xFArgicos descompressivos (Puestow, Frey, Beger). Para qualquer situa\xE7\xE3o de maior refratariedade, ainda h\xE1 op\xE7\xE3o de remo\xE7\xE3o cir\xFArgica do p\xE2ncreas, seja a remo\xE7\xE3o apenas da regi\xE3o mais afetada ou mesmo a pancreatectomia total com autotransplante de ilhotas pancre\xE1ticas (geralmente, s\xE3o reinfundidas na veia porta).</span>
</p><p>
  <strong>Insufici\xEAncia pancre\xE1tica ex\xF3crina \u2013</strong>
  <span style="font-weight: 400;">Para os casos de insufici\xEAncia pancre\xE1tica ex\xF3crina, opta-se pela terapia de reposi\xE7\xE3o de enzima pancre\xE1tica \u2013 o cl\xE1ssico \xE9 o fornecimento de, pelo menos, 40.000-50.000 unidades de lipase a cada refei\xE7\xE3o. Se n\xE3o houver melhora, deve-se preferir refei\xE7\xF5es menores e mais frequentes, aumentar a dose ou mesmo investigar etiologias alternativas, como supercrescimento bacteriano.</span>
</p><p>
  <strong>Diabetes \u2013</strong>
  <span style="font-weight: 400;">Embora os pacientes possam apresentar diabetes tipo 2, eles est\xE3o bastante propensos ao diabetes tipo 3c (pancreatog\xEAnico), que \xE9 associado \xE0 destrui\xE7\xE3o das ilhotas pancre\xE1ticas pela pancreatite cr\xF4nica e se caracteriza n\xE3o s\xF3 pela perda de insulina, mas tamb\xE9m pela perda dos horm\xF4nios contrainsul\xEDnicos (como glucagon), o que torna rara a ocorr\xEAncia de cetoacidose e mais comum a hipoglicemia. A metformina costuma ser o antidiab\xE9tico oral de escolha e a insulina muitas vezes \xE9 necess\xE1ria, por\xE9m geralmente em doses menores do que no diabetes tipo 1.</span>
</p><p>
  <strong>Outras complica\xE7\xF5es \u2013</strong>
  <span style="font-weight: 400;">Os pseudocistos sintom\xE1ticos (dor abdominal, saciedade precoce ou icter\xEDcia por obstru\xE7\xE3o gastrointestinal e biliar) precisam ser drenados \u2013 a drenagem endosc\xF3pica \xE9 a op\xE7\xE3o de primeira linha e, em casos de insucesso, considera-se a drenagem cir\xFArgica. Alguns tamb\xE9m recomendam a drenagem de pseudocistos assintom\xE1ticos &gt; 5 cm que n\xE3o se resolvem espontaneamente em 3-6 meses. O tratamento definitivo da obstru\xE7\xE3o biliar e gastrointestinal pela pr\xF3pria pancreatite tamb\xE9m \xE9 cir\xFArgico. O sangramento por pseudoaneurisma \xE9 confirmado e tratado por angiografia mesent\xE9rica (emboliza\xE7\xE3o). Por sua vez, a ascite e o derrame pleural pancre\xE1ticos geralmente surgem a partir de uma f\xEDstula ou ruptura de ductos pancre\xE1ticos ou pseudocisto, de modo que o tratamento pode ser feito com octreotide (reduz a secre\xE7\xE3o pancre\xE1tica) e, se necess\xE1rio, parte-se para abordagem endosc\xF3pica ou cir\xFArgica do ponto de ruptura ou da f\xEDstula.</span>
</p><p>
  <strong>- Pancreatite autoimune \u2013</strong>
  <span style="font-weight: 400;">Nos pacientes com pancreatite autoimune, o tratamento \xE9 recomendado para os casos sintom\xE1ticos (dor, icter\xEDcia ou outra manifesta\xE7\xE3o de doen\xE7a relacionada ao IgG4) ou alguns assintom\xE1ticos (massa pancre\xE1tica, altera\xE7\xE3o de fun\xE7\xE3o hep\xE1tica, les\xE3o subcl\xEDnica de doen\xE7a relacionada ao IgG4 com maior risco de evolu\xE7\xE3o grave, como trato biliar, rim, retroperit\xF4nio, aorta e mediastino). O tratamento tipicamente \xE9 com corticoide (prednisona 40 mg/dia ou 0,6 mg/Kg/dia) por 4-6 semanas, usualmente com boa resposta em 80-99% dos casos, reduzindo a dose de forma gradual posteriormente (diminuir dose di\xE1ria em 5-10 mg a cada 1-2 semanas at\xE9 atingir a dose de 20 mg e, em seguida, reduzir em 5 mg a cada 2 semanas). Se, durante a redu\xE7\xE3o, a doen\xE7a entrar novamente em atividade, as op\xE7\xF5es s\xE3o tratamento cont\xEDnuo com corticoide em dose baixa (prednisona 2,5-10 mg/dia), azatioprina ou rituximabe. Nos raros casos que nem chegam a melhorar com corticoterapia, pode ser \xFAtil uma avalia\xE7\xE3o cir\xFArgica para afastar malignidade e, caso definido o diagn\xF3stico de pancreatite autoimune corticorefrat\xE1ria, uma op\xE7\xE3o \xE9 o rituximabe.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Os casos com maior risco de recorr\xEAncia (dilata\xE7\xE3o pancre\xE1tica difusa, falha na remiss\xE3o radiol\xF3gica, manuten\xE7\xE3o de n\xEDvel elevados de IgG4 acima de 2x o limite superior de normalidade ap\xF3s o tratamento) podem ser deixados com tratamento de manuten\xE7\xE3o (prednisona 2,5-10 mg/dia ou azatioprina 2 mg/Kg/dia ou micofenolato mofetila 750 mg 2x/dia ou rituximabe).</span>
  </em>
</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Dieta com baixo teor de gordura \u2013</strong>
  <span style="font-weight: 400;">Apesar da manifesta\xE7\xE3o de esteatorreia nos pacientes com insufici\xEAncia pancre\xE1tica ex\xF3crina, n\xE3o se recomenda dieta hipolip\xEDdica, pois, al\xE9m de serem pouco palat\xE1veis, podem aumentar o risco de defici\xEAncia de vitaminas lipossol\xFAveis (A, D, E e K).</span>
</p>`,ordem:6},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<p>
  <br>
</p><ul>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Gardner TB, Adler DG, Forsmark CE, Sauer BR, et al. ACG Clinical Guideline: Chronic Pancreatitis.</span>
    <em>
      <span style="font-weight: 400;">Am J Gastroenterol</span>
    </em>
    <span style="font-weight: 400;">2020;115:322\u2013339.</span>
  </li>
</ul><ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Galv\xE3o-Alves J, et al. II Diretriz Brasileira em Pancreatite Cr\xF4nica e artigos comentados.</span>
    <em>
      <span style="font-weight: 400;">GED gastroenterol. endosc. dig</span>
    </em>
    <span style="font-weight: 400;">2017;36(1):1-66.</span>
  </li>
</ol><p>
  <span style="font-weight: 400;">L\xF6hr JM, Dominguez-Munhoz E, Rosendahl J, Besselink M, et al. United European Gastroenterology evidence-based guidelines for the diagnosis and therapy of chronic pancreatitis (HaPanEU).</span>
  <em>
    <span style="font-weight: 400;">United European Gastroenterol J.</span>
  </em>
  <span style="font-weight: 400;">2017;5(2):153\u2013199.</span>
</p>`,ordem:7}],videos:[],fluxogramas:[],tags:[]},{id:"1cef3574-5cfd-4efe-8c16-bae2e4c1f0d4",nome:"Parada Cardiorrespirat\xF3ria",categoria:1,termosDeBusca:"parada cardiorrespiratoria, assistolia, fibrilacao ventricular, aesp, pcr, parada, bls, acls, cuidados pos-parada",favoritado:!1,ordem:0,especialidades:[{nome:"CARDIOLOGIA"}],prescricoes:[{id:"96fe9c03-8fce-4206-8c7f-7884fdd1740c",nome:"ACLS",favorito:!0,ordem:1,secoes:[{item:"VASOPRESSOR",grupos:[{grupo:"Analg\xE9sico",idGrupo:"0718a429-b825-4d6b-8df8-a4b4f032d5f2",opcoes:[{id:"40176e91-7c89-477d-8a67-6f85e26e349f",descr:"Adrenalina (1mg/mL) 1 mg IV ou IO a cada 3-5 min",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Atualmente, a adrenalina \xE9 o \xFAnico vasopressor utilizado durante a parada.",ordem:1},{item:"ANTIARR\xCDTMICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"940dbeda-a503-4f11-976d-213cd9165f4b",opcoes:[{id:"1f45de4e-4e22-406d-9752-c0305e521b9b",descr:"Amiodarona (150mg/3mL) 1a dose 300 mg (2 ampolas) IV, 2\xAA dose 150 mg (1 ampola) IV (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"8dcf08ef-3c5b-4a34-9d03-17ace9b8e5c2",descr:"Lidoca\xEDna 1% (10mg/mL) 1-1,5 mg/kg IV ou IO, repetir 0,5-0,75 mg/kg a cada 5-10 min (dose m\xE1x 3 mg/kg)",recomendado:!1,favorito:!1,ordem:2},{id:"22f1e8cf-8535-4800-bc34-fd772fcfbfdd",descr:"Lidoca\xEDna 2% (20mg/mL) 1-1,5 mg/kg IV ou IO, repetir 0,5-0,75 mg/kg a cada 5-10 min (dose m\xE1x 3 mg/kg)",recomendado:!1,favorito:!1,ordem:3},{id:"ae611728-01e3-400d-8666-9e560c5489cd",descr:"Sulfato de Magn\xE9sio 50% 1-2g (2-4 mL) + SG 5% 10 mL \u2013 IV em 15 minutos (em caso de Torsades des Pointes)",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Apenas em caso de ritmo choc\xE1vel (FV ou TV sem pulso) refrat\xE1rio",ordem:2},{item:"BICARBONATO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"4604f17a-e4c3-424d-b577-2306eb2027ba",opcoes:[{id:"64b988a4-3901-45f4-aa0e-e39cf573c2fa",descr:"Bicarbonato de S\xF3dio 8,4% (1mEq/mL) 1 mEq/Kg IV agora",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Usado em situa\xE7\xF5es especiais, como acidose metab\xF3lica pr\xE9-existente, hipercalemia ou overdose por antidepressivo tric\xEDclico.",ordem:3}],conceitosPraticos:[{conceito:"Sempre que poss\xEDvel, as medica\xE7\xF5es do ACLS deve ser administradas IV. Caso n\xE3o haja essa possibilidade, a via intra\xF3ssea (IO) pode ser usada e na mesma dose. Se esta via tamb\xE9m n\xE3o estiver dispon\xEDvel, pode-se optar pela adminstra\xE7\xE3o endotraqueal utilizando 2-2,5x a dose IV e diluindo em 5-10 mL de SF 0,9%.",ordem:1},{conceito:"Ap\xF3s a administra\xE7\xE3o IV de cada medicamento infundir bolus de 20 a 30 ml de SF 0,9% e elevar o bra\xE7o do paciente.",ordem:2},{conceito:"Vasopressina e atropina n\xE3o s\xE3o mais drogas utilizadas durante a parada.",ordem:3}]},{id:"fb57b9b8-3430-415d-b33b-b3e8f4b6489c",nome:"P\xF3s-Parada",favorito:!1,ordem:2,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"479d37ff-3e63-4362-bf45-b166972cff35",opcoes:[{id:"ab8c0232-a123-461f-97d2-72e47a8d088b",descr:"Dieta oral zero",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Progredir ap\xF3s estabiliza\xE7\xE3o cl\xEDnica.",ordem:1},{item:"HIDRATA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7b4cad43-ae6e-41c8-b674-154f6f17639a",opcoes:[{id:"183af751-61fb-4c40-81d4-169d02247d8e",descr:"SF 0,9% 1-2L IV agora",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Manter PAM > 65 mmHg e PA sist\xF3lica > 90 mmHg.",ordem:2},{item:"VASOPRESSOR",grupos:[{grupo:"Analg\xE9sico",idGrupo:"f3d98837-7e6c-4851-bfeb-3be00e7bd513",opcoes:[{id:"3caebae7-f9d5-4e21-a1d0-a3818d0671bb",descr:`Noradrenalina 20 mL + SG 5% 80 mL (solu\xE7\xE3o: 200mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico (MEDGRUPO)
Administrar 0,1-0,5 mcg/kg/min`,recomendado:!0,favorito:!0,ordem:1},{id:"0fd3d1dd-6077-4b76-af63-07de67603d37",descr:`Noradrenalina 4 mL + SG 5% 96 mL (solu\xE7\xE3o: 40mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 0,1-0,5 mcg/kg/min`,recomendado:!1,favorito:!1,ordem:2},{id:"e3ab1746-2003-4843-83da-465dbf62c378",descr:`Noradrenalina 8 mL + SG 5% 242 mL (solu\xE7\xE3o: 32mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 0,1-0,5 mcg/kg/min`,recomendado:!1,favorito:!1,ordem:3},{id:"099f64a7-d2e6-42fe-9560-05c5f9c41a29",descr:`Dopamina 50 mL + SG 5% 200 mL (solu\xE7\xE3o: 1000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 5-10 mcg/kg/min`,recomendado:!1,favorito:!1,ordem:4},{id:"464ec99f-6544-4138-8aa7-82742ef95726",descr:`Dopamina 100 mL + SG 5% 150 mL (solu\xE7\xE3o: 2000mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 5-10 mcg/kg/min`,recomendado:!1,favorito:!1,ordem:5},{id:"1cb70ab4-c911-4dca-ab39-b3841262e78d",descr:`Adrenalina (1mg/mL)  1 mL + SG 5% 250 mL (solu\xE7\xE3o: 4mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 0,1-0,5 mcg/kg/min`,recomendado:!1,favorito:!1,ordem:6},{id:"b12bb440-ca30-4127-a8a4-57991c80ed20",descr:`Adrenalina (1mg/mL)  4 mL + SG 5% 250 mL (solu\xE7\xE3o: 16mcg/mL) \u2013 IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 0,1-0,5 mcg/kg/min`,recomendado:!1,favorito:!1,ordem:7}],ordem:1}],academico:"Manter PAM > 65 mmHg e PA sist\xF3lica > 90 mmHg.",ordem:3},{item:"HIPOTERMIA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ef688cdb-0d23-454a-bd6b-558fce601c86",opcoes:[{id:"ade7db3e-bb52-42ab-86e4-34f3a06e5045",descr:`SF 0,9% a 4oC 1-2L IV agora\r
Repetir se necess\xE1rio para manter alvo de temperatura`,recomendado:!0,favorito:!0,ordem:1},{id:"ae9b9e86-6b93-48ce-96bf-5dc4bc2cedef",descr:`Ringer Lactato a 4oC 1-2L IV agora\r
Repetir se necess\xE1rio para manter alvo de temperatura`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Apenas em pacientes comatosos. O m\xE9todo pode ser com administra\xE7\xE3o IV de solu\xE7\xF5es resfriadas, associada ou n\xE3o a m\xE9todos de resfriamento de superf\xEDcie (pacotes de gelo em axilas e virilhas, cobertores de refrigera\xE7\xE3o).",ordem:4},{item:"SEDA\xC7\xC3O",grupos:[{grupo:"Analg\xE9sico",idGrupo:"56d0bb4d-ea61-4a67-a5a7-647bdcdc2eb3",opcoes:[{id:"92c76f30-7481-4c29-807f-aa80cfc4e713",descr:`Propofol (10mg/mL) 20 mL + SG 5% 230 mL (solu\xE7\xE3o: 800 mcg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 5-80 mcg/Kg/min`,recomendado:!0,favorito:!0,ordem:1},{id:"297d3a65-176f-47fc-afa5-0fb6ec1c2375",descr:`Propofol (10mg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico (MEDGRUPO)\r
Administrar 20-50 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:2},{id:"6a0ce059-4cc4-43c9-a0e5-86b0508575c1",descr:`Propofol (10mg/mL) 20 mL + SG 5% 80 mL (solu\xE7\xE3o: 2000mcg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 20-50 mcg/Kg/min`,recomendado:!1,favorito:!1,ordem:3},{id:"f38fd7c2-715a-44ef-bde2-877a965037dd",descr:`Midazolam (5mg/mL) 30 mL + SG 5% 120 mL (solu\xE7\xE3o: 1mg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 2-10 mL/h (2-10 mg/h)`,recomendado:!1,favorito:!1,ordem:4},{id:"2c8eb397-8d00-4345-bdc7-fa28d5dccf54",descr:`Midazolam (5mg/mL) 40 mL + SG 5% 60 mL (solu\xE7\xE3o: 2mg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 1-5 mL/h (2-10 mg/h)`,recomendado:!1,favorito:!1,ordem:5}],ordem:1},{grupo:"antiem\xE9tico",idGrupo:"1da7e57d-3208-48cd-9004-bea256c5d8e3",opcoes:[{id:"1439df87-b1e0-4d03-8a8c-23ba9db8f8a9",descr:`Fentanil (50mcg/mL) + SG 5% 80 mL (solu\xE7\xE3o: 5mcg/mL) - IV em bomba infusora a crit\xE9rio m\xE9dico\r
Administrar 5-20 mL/h (25-100 mcg/h)`,recomendado:!0,favorito:!0,ordem:1},{id:"971c8910-2b0d-4269-9bbc-9feae71e1850",descr:"Sulfato de Magn\xE9sio 50% 8 mL (4g) + SG 5% 12 mL \u2013 IV em 15 minutos (casos refrat\xE1rios)",recomendado:!1,favorito:!1,ordem:2},{id:"c9a259ec-e7f0-4b9e-a062-317dd9ab6b55",descr:"Vecur\xF4nio 10 mg + SF 0,9% 10 mL (solu\xE7\xE3o: 1mg/mL) - 0,1 mgKg IV agora (casos refrat\xE1rios)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Adotada na ocorr\xEAncia de shivering (tremores) durante a hipotermia ou em pacientes intubados. O midazolam \xE9 uma alternativa ao propofol em vig\xEAncia de hipotens\xE3o. Em casos refrat\xE1rios de shivering, o sulfato de magn\xE9sio e o vecur\xF4nio s\xE3o opcionais, lembrando que este \xFAltimo pode mascarar convuls\xE3o.",ordem:5},{item:"SINTOM\xC1TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"9a92f1a0-cd14-4af0-b9a7-efd4df41226b",opcoes:[{id:"28fe84cb-d5b4-440b-983e-1f5eae52ed79",descr:"Dipirona (500mg/mL) 1g IV em caso de dor ou febre (at\xE9 6/6h)",recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"antiem\xE9tico",idGrupo:"ace5ad8b-2286-4a6c-b294-8f605a039ecc",opcoes:[{id:"2f5fe793-0eda-41b0-bd91-09f56bff7bfe",descr:"Metoclopramida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO) ",recomendado:!0,favorito:!0,ordem:1},{id:"31cf7554-3259-413b-83d6-be550cf86b33",descr:"Bromoprida (10mg/2mL) 10 mg IV em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"c9f2dce8-20e0-4d6d-a0ac-4f8b1a300042",descr:"Ondansetrona (4mg/2mL) 4-8 mg IV em 30 segundos em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:6},{item:"CUIDADOS GERAIS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"93a54d5d-5f58-42e5-a00d-0d90bd051e33",opcoes:[{id:"f3383f09-5d20-4367-bbfc-a5c65f9d5283",descr:"Manter cabeceira elevada a 30o",recomendado:!0,favorito:!0,ordem:1},{id:"3b829760-6e97-4452-8409-33ab15785562",descr:"Balan\xE7o H\xEDdrico 6/6h",recomendado:!1,favorito:!1,ordem:2},{id:"307f9c1e-a782-414d-b67a-7ae348afac06",descr:"Cateter de temperatura central e curva t\xE9rmica",recomendado:!1,favorito:!1,ordem:3},{id:"e1dfc39d-dec3-45e3-88a0-1a3b4195c300",descr:"Monitoriza\xE7\xE3o card\xEDaca cont\xEDnua e SatO2",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Cuidados inespec\xEDficos.",ordem:7}],conceitosPraticos:[{conceito:"Realizar ECG de 12 deriva\xE7\xF5es: presen\xE7a de supra de ST requer coronariografia de urg\xEAncia.",ordem:1},{conceito:"Manter PAM > 65 mmHg, sendo preferencialmente > 85 mmHg para otimizar perfus\xE3o cerebral.",ordem:2},{conceito:"Controle Direcionado da Temperatura: nos pacientes comatosos, manter uma temperatura constante entre 32-36oC por, pelo menos, 24h (o reaquecimento \xE9 feito a 0,25-0,5oC/h).",ordem:3},{conceito:"Realizar EEG nos pacientes comatosos.",ordem:4},{conceito:"Manter SatO2 \u2265 94%.",ordem:5}]}],topicos:[{titulo:"Parada Cardiorrespirat\xF3ria",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">\xC9 a respira\xE7\xE3o ag\xF4nica (\u201Cgasping\u201D) ou interrup\xE7\xE3o s\xFAbita e inesperada do movimento respirat\xF3rio (parada respirat\xF3ria) e/ou da circula\xE7\xE3o sist\xEAmica (parada card\xEDaca).</span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/da59a5ff-b86b-45ef-8f03-610ab83c2a2a.jpg" alt="" width="100%" height="auto">
  </span>
</p>`,ordem:2},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">N\xE3o \xE9 necess\xE1ria nenhuma avalia\xE7\xE3o complementar, bastando a percep\xE7\xE3o de que o paciente est\xE1 irresponsivo, sem a respira\xE7\xE3o normal e sem sinais de circula\xE7\xE3o.</span>
</p>`,ordem:3},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">Naturalmente, o retorno da circula\xE7\xE3o espont\xE2nea \xE9 o objetivo a ser atingido atrav\xE9s de uma sequ\xEAncia de procedimentos \u2013 conhecida como Corrente da Sobreviv\xEAncia \u2013 que envolve o Suporte B\xE1sico de Vida (BLS), o Suporte Avan\xE7ado de Vida em Cardiologia (ACLS) e os Cuidados P\xF3s-Parada, de modo que a qualidade das compress\xF5es tor\xE1cicas e a desfibrila\xE7\xE3o (em casos de ritmos choc\xE1veis) constituem os principais pilares terap\xEAuticos desse processo.</span>
</p><p>
  <strong>- Suporte B\xE1sico de Vida (BLS \u2013</strong>
  <strong>
    <em>Basic Life Support</em>
  </strong>
  <strong>)</strong>
</p><p>
  <span style="font-weight: 400;">Inicialmente, qualquer socorrista que chegue em um local onde haja uma suposta Parada Cardiorrespirat\xF3ria deve</span>
  <strong>certificar-se de que a cena esteja segura</strong>
  <span style="font-weight: 400;">para que o atendimento seja prestado. Em seguida, \xE9 recomendado</span>
  <strong>testar a responsividade</strong>
  <span style="font-weight: 400;">do paciente, chamando-o em voz alta e tocando seus ombros.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">Se n\xE3o houver resposta, \xE9 poss\xEDvel chamar ajuda com desfibrilador (gritando, usando telefone celular ou mesmo deixando a v\xEDtima sozinha para buscar ajuda), por\xE9m \xE9 mais pr\xE1tico que, antes que o Sistema de Emerg\xEAncia seja acionado, o profissional de sa\xFAde continue a</span>
  <strong>avaliar simultaneamente a respira\xE7\xE3o (apneia ou \u201Cgasping\u201D) e o pulso (por n\xE3o mais do que 10 segundos)</strong>
  <span style="font-weight: 400;">para que, em seguida, quando a ajuda for solicitada, j\xE1 seja passada a impress\xE3o diagn\xF3stica da situa\xE7\xE3o atendida. Nesse momento, 3 cen\xE1rios principais s\xE3o poss\xEDveis:</span>
</p><p>
  <span style="font-weight: 400;">(1) Respira\xE7\xE3o e pulso presentes: manter monitoriza\xE7\xE3o at\xE9 a chegada da equipe de emerg\xEAncia.</span>
</p><p>
  <span style="font-weight: 400;">(2) Respira\xE7\xE3o ausente ou \u201C</span>
  <em>
    <span style="font-weight: 400;">gasping</span>
  </em>
  <span style="font-weight: 400;">\u201D / Pulso presente: 1 ventilac\xE3o a cada 6 segundos (ou 10 ventila\xE7\xF5es por minuto), acionando ajuda ap\xF3s 2 minutos iniciais (caso n\xE3o tenha acionado anteriormente). Se houver suspeita de intoxica\xE7\xE3o por opioide, fornecer naloxone (0,4-2 mg intramuscular/intravenoso ou 2 mg intranasal).</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* O pulso deve ser reavaliado a cada 2 minutos.&nbsp;</span>
  </em>
</p><p>
  <span style="font-weight: 400;">(3) Respira\xE7\xE3o ausente / Pulso ausente:&nbsp; acionar ajuda (caso n\xE3o tenha acionado anteriormente) e iniciar manobras de Reanima\xE7\xE3o Cardiopulmonar (RCP), sistematizadas no chamado C-A-B-D prim\xE1rio com ciclos de 30 compress\xF5es e 2 ventila\xE7\xF5es, lan\xE7ando m\xE3o do desfibrilador assim que ele estiver dispon\xEDvel.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">C (CIRCULATION - Compress\xE3o Tor\xE1cica)</span>
  </em>
  <strong>\u2013</strong>
  <span style="font-weight: 400;">Sempre que poss\xEDvel, a v\xEDtima deve ser colocada sobre uma superf\xEDcie r\xEDgida e em posi\xE7\xE3o supina. O t\xF3rax deve estar desnudo, logo a roupa deve ser afastada ou at\xE9 mesmo cortada se houver tesoura dispon\xEDvel.</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Posi\xE7\xE3o:</span>
    <span style="font-weight: 400;">bra\xE7os estendidos, base das m\xE3os uma sobre a outra de modo que fiquem superpostas, paralelas (mesmo sentido), com dedos entrela\xE7ados e sobre a metade inferior do esterno.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Frequ\xEAncia:</span>
    <span style="font-weight: 400;">100-120 compress\xF5es por minuto.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Intensidade:</span>
    <span style="font-weight: 400;">o esterno deve ser comprimido em 5-6 cm de profundidade, permitindo o seu completo retorno ap\xF3s cada compress\xE3o e evitando se apoiar sobre o t\xF3rax entre as compress\xF5es.</span>
  </li>
</ul><p>
  <span style="font-weight: 400;">As 30 compress\xF5es tor\xE1cicas iniciais s\xE3o seguidas de 2 ventila\xE7\xF5es...</span>
</p><p>
  <em>
    <span style="font-weight: 400;">A (AIRWAY \u2013 Abertura de via a\xE9rea)</span>
  </em>
  <strong>\u2013</strong>
  <span style="font-weight: 400;">Para aplicar as 2 ventila\xE7\xF5es, a via a\xE9rea precisa estar aberta. Assim, a cavidade oral deve ser inspecionada, sendo retirado manualmente qualquer corpo estranho. Se este n\xE3o puder ser alcan\xE7ado e estiver obstruindo a laringe, adota-se a Manobra de Heimlich (s\xFAbita compress\xE3o abdominal).</span>
</p><p>
  <span style="font-weight: 400;">Outro passo fundamental antes da ventila\xE7\xE3o \xE9 o posicionamento adequado da via a\xE9rea para garantir a sua perviedade atrav\xE9s de 2 poss\xEDveis manobras:</span>
</p><ul>
  <li>
    <em>
      <span style="font-weight: 400;">Head Tilt \u2013 Chin Lift</span>
    </em>
    <span style="font-weight: 400;">: extens\xE3o da cabe\xE7a e eleva\xE7\xE3o do queixo (impede a queda da l\xEDngua).</span>
    <em>
      <span style="font-weight: 400;">Aten\xE7\xE3o: deve ser evitada no trauma pela extens\xE3o cervical, mas at\xE9 pode ser aplicada se houver falha da manobra de jaw thrust citada abaixo...</span>
    </em>
  </li>
  <li>
    <em>
      <span style="font-weight: 400;">Jaw Thrust</span>
    </em>
    <span style="font-weight: 400;">: tra\xE7\xE3o anterior da mand\xEDbula (eleva\xE7\xE3o do \xE2ngulo da mand\xEDbula).</span>
    <em>
      <span style="font-weight: 400;">\xC9 a manobra de escolha no trauma!</span>
    </em>
  </li>
</ul><p>
  <em>
    <span style="font-weight: 400;">B (Breathe \u2013 Ventila\xE7\xE3o) \u2013</span>
  </em> 
  <span style="font-weight: 400;">Com a via a\xE9rea p\xE9rvia, o socorrista pode realizar as 2 ventila\xE7\xF5es que devem ser feitas de forma devagar ao longo de aproximadamente 1 segundo, fornecendo a quantidade de ar suficiente para produzir expans\xE3o tor\xE1cica vis\xEDvel. Existem diferentes maneiras de ventilar a v\xEDtima, mas as ideais nos pacientes sem via a\xE9rea avan\xE7ada s\xE3o: boca-a-boca (com possibilidade de barreiras de prote\xE7\xE3o como len\xE7o facial e m\xE1scara de bolso) e bolsa-m\xE1scara. A ventila\xE7\xE3o boca-nariz \xE9 uma op\xE7\xE3o caso a ventila\xE7\xE3o pela boca da v\xEDtima n\xE3o seja fact\xEDvel (trauma, posicionamento ou dificuldade de oclus\xE3o). Pode-se utilizar c\xE2nula nasofar\xEDngea ou orofar\xEDngea para facilitar a manuten\xE7\xE3o da perviedade da via a\xE9rea, sendo a orofar\xEDngea a de prefer\xEAncia em casos de suspeita de fratura de base de cr\xE2nio ou coagulopatia grave.</span>
</p><p>
  <span style="font-weight: 400;">A realiza\xE7\xE3o de 30 compress\xF5es e 2 ventila\xE7\xF5es define o que chamamos de 1 ciclo de Reanima\xE7\xE3o Cardiopulmonar (RCP). O ideal \xE9 que se alterne os profissionais que aplicam as compress\xF5es a cada 2 minutos (ou 5 ciclos de RCP) para evitar um cansa\xE7o que poderia reduzir a qualidade do processo.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">D (Defibrillation \u2013 Desfibrila\xE7\xE3o) \u2013</span>
  </em> 
  <span style="font-weight: 400;">Assim que o desfibrilador estiver dispon\xEDvel, ele deve ser utilizado para verifica\xE7\xE3o do ritmo de parada e, se for um ritmo choc\xE1vel (Fibrila\xE7\xE3o Ventricular ou Taquicardia Ventricular Sem Pulso), 1 choque \xFAnico \xE9 aplicado. Ou seja, n\xE3o h\xE1 qualquer benef\xEDcio em se manter ciclos determinados de RCP antes do choque. O adequado \xE9 naturalmente manter a RCP enquanto as p\xE1s do desfibrilador s\xE3o aplicadas e at\xE9 que o dispositivo esteja pronto para analisar o ritmo. Ap\xF3s o choque, a RCP deve ser retomada imediatamente por mais 2 minutos e, ap\xF3s esse per\xEDodo, o ritmo \xE9 reavaliado. Se permanecer em um ritmo de parada choc\xE1vel, um novo choque \xE9 desferido e todo o processo \xE9 repetido at\xE9 que possa ser iniciado o Suporte Avan\xE7ado de Vida (ACLS) \u2013 que depende da disponibilidade de infus\xE3o de drogas intravenosas, como veremos adiante.</span>
</p><p>
  <span style="font-weight: 400;">Se o ritmo de parada n\xE3o for choc\xE1vel (Assistolia ou Atividade El\xE9trica sem Pulso \u2013 AESP), a RCP \xE9 mantida por mais 2 minutos para que o ritmo seja reavaliado e toda a sequ\xEAncia \xE9 mantida at\xE9 que se inicie o ACLS.</span>
</p><p>
  <strong>- Desfibrila\xE7\xE3o</strong>
</p><p>
  <em>
    <span style="font-weight: 400;">(1) Posi\xE7\xE3o das p\xE1s&nbsp;</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Existem 4 posi\xE7\xF5es que parecem igualmente eficazes: anterolateral, anteroposterior, infraescapular anteroesquerda e infraescapular anterodireita, mas h\xE1 uma prefer\xEAncia pela anterolateral ou anteroposterior. A mais usada continua sendo a posi\xE7\xE3o anterolateral, na qual o eixo longitudinal card\xEDaco fica situado exatamente entre as p\xE1s. Deve-se dar prefer\xEAncia a p\xE1s de di\xE2metro maior (8-12 cm), que acabam reduzindo a imped\xE2ncia tor\xE1cica.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Se o paciente for portador de marca-passo, as p\xE1s devem ficar a, pelo menos, 8 cm do gerador.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">** Com socorristas experientes, h\xE1 uma discreta prefer\xEAncia pelo desfibrilador manual em compara\xE7\xE3o com o desfibrilador externo autom\xE1tico (DEA), uma vez que o uso deste \xFAltimo pode requerer pausas maiores para an\xE1lise do ritmo.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">(2) Carga (depende do tipo de aparelho: se \xE9 monof\xE1sico ou bif\xE1sico)</span>
  </em>
</p><ul>
  <li>
    <span style="font-weight: 400;">Choque monof\xE1sico: 360J</span>
  </li>
  <li>
    <span style="font-weight: 400;">Choque bif\xE1sico: o recomendado para o choque inicial \xE9 seguir a especifica\xE7\xE3o do fabricante do aparelho (geralmente na faixa de 120 \u2013 200J). De qualquer forma, se o socorrista n\xE3o souber a especifica\xE7\xE3o, pode optar pela carga m\xE1xima dispon\xEDvel no aparelho. Choques subsequentes devem ser com energia equivalente, embora cargas maiores possam ser consideradas se assim for especificado pelo fabricante.</span>
  </li>
</ul><p>
  <em>
    <span style="font-weight: 400;">(3) Ac\xFAmulo da carga</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Com o desfibrilador manual, h\xE1 2 op\xE7\xF5es de acumular a carga:&nbsp;</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Antes de checar o ritmo: se for choc\xE1vel, descarrega a energia e, se n\xE3o for choc\xE1vel, anula a carga acumulada e retorna a RCP.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Ap\xF3s checar o ritmo: se for choc\xE1vel, deve-se retornar as compress\xF5es enquanto o desfibrilador carrega</span>
  </li>
</ul><p>
  <strong>- Suporte Avan\xE7ado de Vida em Cardiologia</strong>
  <strong>
    <em>(ACLS)</em>
  </strong>
</p><p>
  <span style="font-weight: 400;">No ACLS, h\xE1 equipamento adicional ao usado no suporte b\xE1sico, especialmente um acesso venoso perif\xE9rico para administra\xE7\xE3o de f\xE1rmacos e a possibilidade da obten\xE7\xE3o de uma via a\xE9rea avan\xE7ada (como intuba\xE7\xE3o orotraqueal). Mas aten\xE7\xE3o: como o melhor m\xE9todo de ventila\xE7\xE3o deve se basear na experi\xEAncia do socorrista, a intuba\xE7\xE3o n\xE3o \xE9 atualmente obrigat\xF3ria, sendo absolutamente aceit\xE1vel a utiliza\xE7\xE3o de outros m\xE9todos como dispositivo supragl\xF3ticos (m\xE1scara lar\xEDngea, combitube) e at\xE9 mesmo bolsa-m\xE1scara.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Na impossibilidade de acesso venoso, a 2\xAA via de escolha \xE9 o acesso intra\xF3sseo transtibial e uma 3\xAA possibiidade \xE9 o acesso venoso central (jugular interna ou subcl\xE1via).</span>
  </em>
</p><p>
  <span style="font-weight: 400;">De qualquer forma, se houver uma via a\xE9rea avan\xE7ada (dispositivo supragl\xF3tico ou tubo orotraqueal), a compress\xE3o tor\xE1cica passa a ocorrer de modo cont\xEDnuo e independente da ventila\xE7\xE3o durante a RCP. As mesmas caracter\xEDsticas da compress\xE3o devem ser mantidas (frequ\xEAncia de 100-120 por minuto; profundidade de 5-6 cm, alternar o socorrista que aplica a compress\xE3o a cada 2 minutos), mas a ventila\xE7\xE3o agora \xE9 feita com a frequ\xEAncia de 10 por minuto (equivalente a 1 ventila\xE7\xE3o a cada 6 segundos).</span>
</p><p>
  <span style="font-weight: 400;">*</span>
  <em>
    <span style="font-weight: 400;">Naturalmente, o socorrista deve se certificar do adequado posicionamento do tubo orotraqueal, o que \xE9 feito pela avalia\xE7\xE3o cl\xEDnica (visualiza\xE7\xE3o da expans\xE3o tor\xE1cica e da condensa\xE7\xE3o do tubo e ausculta tor\xE1cica em epig\xE1strio, bases e \xE1pices pulmonares) e pela quantifica\xE7\xE3o do CO</span>
  </em>
  <em>
    <span style="font-weight: 400;">2</span>
  </em>
  <em>
    <span style="font-weight: 400;">exalado (ETCO</span>
  </em>
  <em>
    <span style="font-weight: 400;">2</span>
  </em>
  <em>
    <span style="font-weight: 400;">) atrav\xE9s da capnografia com onda cont\xEDnua quantitativa. Esta \xFAltima, al\xE9m de conseguir confirmar a posi\xE7\xE3o correta do tubo, tamb\xE9m monitora a qualidade da RCP (ETCO</span>
  </em>
  <em>
    <span style="font-weight: 400;">2</span>
  </em>
  <em>
    <span style="font-weight: 400;">&lt; 10 mmHg indica necessidade de otimizar a compress\xE3o tor\xE1cica, assim como PA diast\xF3lica &lt; 20 mmHg) e pode indicar o retorno da circula\xE7\xE3o espont\xE2nea (RCE) do paciente (varia\xE7\xE3o superior a 10 mmHg aponta para essa possibilidade \u2013 ainda n\xE3o se identificou nenhum valor espec\xEDfico capaz de apontar a ocorr\xEAncia de RCE). Da mesma forma, um aumento s\xFAbito da PA diast\xF3lica ou a presen\xE7a de onda de pulso arterial durante a percep\xE7\xE3o de um ritmo organizado tamb\xE9m sugerem RCE.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">O que se faz a partir daqui difere um pouco na depend\xEAncia do ritmo de parada. Lembre-se que s\xE3o 4 ritmos poss\xEDveis:</span>
</p><ul>
  <ul>
    <li style="font-weight: 400;" aria-level="1">
      <strong>Fibrila\xE7\xE3o Ventricular (FV)</strong>
      <span style="font-weight: 400;">\u2013 o mais comum, especialmente em ambiente extra-hospitalar</span>
    </li>
  </ul>
</ul><ul>
    <li style="font-weight: 400;" aria-level="1">
      <strong>Fibrila\xE7\xE3o Ventricular (FV)</strong>
      <span style="font-weight: 400;">\u2013 o mais comum, especialmente em ambiente extra-hospitalar</span>
    </li>
  </ul><ul>
  <li aria-level="1">
    <strong>Taquicardia Ventricular sem pulso (TV sem pulso)</strong>
  </li>
</ul><ul>
  <li style="font-weight: 400;" aria-level="1">
    <strong>Atividade El\xE9trica Sem Pulso (AESP)</strong>
    <span style="font-weight: 400;">\u2013 ou PEA, da sigla em ingl\xEAs</span>
    <em>
      <span style="font-weight: 400;">Pulseless Electrical Activity</span>
    </em>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <strong>Assistolia</strong>
    <span style="font-weight: 400;">\u2013 o de pior progn\xF3stico</span>
  </li>
</ul><p>
  <em>
    <span style="font-weight: 400;">Protocolo de FV/TV sem pulso</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Lembre-se da ideia fixa de manter a RCP (compress\xE3o + ventila\xE7\xE3o, agora independentes) de forma ininterrupta. Na realidade, ela s\xF3 \xE9 interrompida para checar o ritmo e chocar. Durante a RCP, s\xE3o administrados f\xE1rmacos para tentar aumentar a taxa de sucesso da desfibrila\xE7\xE3o. S\xE3o usadas drogas vasopressoras e antiarr\xEDtmicas de modo alternado: em um per\xEDodo de 2 min de RCP se faz uma dose de vasopressor (idealmente adrenalina) e, no per\xEDodo seguinte de RCP, opta-se por um antiarr\xEDtmico (amiodarona ou lidocaina).</span>
  <em>
    <span style="font-weight: 400;">&nbsp;</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">* O vasopressor (adrenalina) provoca vasoconstric\xE7\xE3o perif\xE9rica, mantendo, desta maneira, o fluxo sangu\xEDneo direcionado para regi\xF5es mais centrais (circula\xE7\xE3o coronariana e cerebral). J\xE1 os antiarr\xEDtmicos isoladamente n\xE3o s\xE3o capazes de reverterem a arritmia, mas podem facilitar, em conjunto com a desfibrila\xE7\xE3o, a restaura\xE7\xE3o e a manuten\xE7\xE3o de um ritmo espont\xE2neo. Por esta raz\xE3o, o estabelecimento de um acesso venoso \xE9, de certa forma, algo secund\xE1rio, e n\xE3o pode adiar o choque e nem comprometer a qualidade das manobras de RCP, procedimentos que comprovadamente aumentam a taxa de sobrevida.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">** Como estrat\xE9gia vasopressora, pode-se optar pela utiliza\xE7\xE3o de vasopressina isolada ou em combina\xE7\xE3o com a adrenalina, mas estas estrat\xE9gias n\xE3o conferem nenhuma vantagem \xE0 administra\xE7\xE3o isolada de adrenalina.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Assim, h\xE1 uma sequ\xEAncia l\xF3gica que podemos guardar:</span>
</p><p>
  <span style="font-weight: 400;">RCP (2 min) + Adrenalina</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">Checa Ritmo</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">Choque</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">RCP (2 min) + Antiarr\xEDtmico</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">Checa Ritmo</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">Choque</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">RCP (2 min) + Adrenalina</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">(...)</span>
</p><p>
  <span style="font-weight: 400;">Repare, mais uma vez, que, ap\xF3s o choque se reinicia imediatamente a RCP, sem checar ritmo e nem pulso!</span>
</p><p>
  <span style="font-weight: 400;">Detalhes das drogas...</span>
</p><p>
  <span style="font-weight: 400;">Vasopressor (adrenalina)</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Adrenalina (1 mg = 1 ampola): deve ser feita a cada 3-5 minutos durante todo o ACLS.</span>
  </li>
</ul><p>
  <em>
    <span style="font-weight: 400;">* Desde 2015, a administra\xE7\xE3o isolada de vasopressina n\xE3o \xE9 estimulada pelos Protocolos de Parada Card\xEDaca! Entretanto, as diretrizes consideram o uso de corticoide + adrenalina + vasopressina nas paradas intra-hospitalares com o seguinte protocolo: administra\xE7\xE3o conjunta inicial de metilprednisolona 40 mg + adrenalina 1 mg + vasopressina 20 UI, seguido da associa\xE7\xE3o de adrenalina 1 mg + vasopressina 20 UI a cada 3 minutos at\xE9 o m\xE1ximo de 5 vezes e, havendo sucesso na reanima\xE7\xE3o, hidrocortisona 300 mg/dia por 7 dias. Por\xE9m, ainda n\xE3o \xE9 uma estrat\xE9gia recomendada de rotina!</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Antiarr\xEDtmicos (amiodarona, lidoca\xEDna ou sulfato de magn\xE9sio)</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Amiodarona: pode ser feita 2 vezes \u2013 a 1\xAA dose \xE9 de 300 mg (2 ampolas) e a 2\xAA dose, 150 mg (1 ampola).</span>
  </li>
  <li>
    <span style="font-weight: 400;">Lidoca\xEDna: usada como alternativa \xE0 amiodarona, sua dose inicial \xE9 de 1-1,5 mg/kg podendo ser administradas doses adicionais de 0,5-0,75 mg/kg a cada 5-10 minutos at\xE9 a dose cumulativa de 3 mg/kg.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Sulfato de Magn\xE9sio (1-2 g dilu\xEDdos em 10 mL de SG 5%): indicado em casos de</span>
    <em>
      <span style="font-weight: 400;">Torsades des Pointes</span>
    </em>
    <span style="font-weight: 400;">(TV polim\xF3rfica associada a intervalo QT Longo).</span>
  </li>
</ul><p>
  <span style="font-weight: 400;">Na impossibilidade de acesso venoso e intra\xF3sseo, pode-se usar a via endotraqueal, ou seja, administrar as drogas pelo tubo endotraqueal. As drogas compat\xEDveis com essa via s\xE3o memorizadas com a sigla</span>
  <strong>VANEL</strong>
  <span style="font-weight: 400;">:</span>
  <strong>V</strong>
  <span style="font-weight: 400;">asopressina,</span>
  <strong>A</strong>
  <span style="font-weight: 400;">tropina,</span>
  <strong>N</strong>
  <span style="font-weight: 400;">aloxone,</span>
  <strong>E</strong>
  <span style="font-weight: 400;">pinefrina (que \xE9 a adrenalina) e</span>
  <strong>L</strong>
  <span style="font-weight: 400;">idoca\xEDna.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Pela via endotraqueal, s\xE3o usadas doses 2,5 vezes superiores \xE0s doses venosas e dilu\xEDdas em 5-10 ml de \xE1gua est\xE9ril ou solu\xE7\xE3o salina para serem injetadas diretamente pelo tubo.</span>
  </em>
</p><p>
  <em>
    <span style="font-weight: 400;">Protocolo de Assistolia/AESP</span>
  </em>
</p><p>
  <span style="font-weight: 400;">Inicialmente, vale a pena fazer algumas considera\xE7\xF5es com rela\xE7\xE3o aos tra\xE7ados observados nesses 2 ritmos de parada:</span>
</p><p>
  <span style="font-weight: 400;">(1) Ao observamos uma aparente assistolia, podemos estar diante, na realidade, de uma FV de onda finas! Por isso, \xE9 obrigat\xF3rio adotarmos o chamado \u201CProtocolo da linha reta\u201D que inclui verificar se os cabos de monitoriza\xE7\xE3o est\xE3o conectados, aumentar o ganho do aparelho e mudar a observa\xE7\xE3o da atividade el\xE9trica do cora\xE7\xE3o, seja trocando a deriva\xE7\xE3o do monitor card\xEDaco ou a orienta\xE7\xE3o das p\xE1s do desfibrilador. Todo esse protocolo deve ser feito em menos de 10 segundos, pois \xE9 um per\xEDodo em que as manobras de RCP foram suspensas!</span>
</p><p>
  <span style="font-weight: 400;">(2) O ritmo observado durante uma AESP pode ser virtualmente qualquer um, de modo que sua defini\xE7\xE3o \xE9 a presen\xE7a de um ritmo organizado, mas sem produ\xE7\xE3o de um pulso palp\xE1vel ou press\xE3o arterial mensur\xE1vel.</span>
</p><p>
  <span style="font-weight: 400;">Sua abordagem sequencial \xE9 ainda mais simples que no Protocolo de FV/TV sem Pulso! Lembre-se da ideia fixa de se manter a RCP do modo mais ininterrupto poss\xEDvel: a interrup\xE7\xE3o s\xF3 existe para checar o ritmo... Mas, como agora os ritmos n\xE3o s\xE3o choc\xE1veis, retorna-se para a RCP, durante a qual s\xE3o administrados f\xE1rmacos, com a facilidade de que aqui s\xF3 se utiliza terapia vasopressora, atualmente restrita \xE0 adrenalina, que deve ser administrada o mais rapidamente poss\xEDvel.</span>
</p><p>
  <span style="font-weight: 400;">A sequ\xEAncia organizada fica assim:</span>
</p><p>
  <span style="font-weight: 400;">RCP (2 min) + Adrenalina</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">Checa Ritmo</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">RCP (2 min) + Adrenalina</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">Checa Ritmo</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">RCP (2 min) + Adrenalina</span>
  <strong>\u2192</strong>
  <span style="font-weight: 400;">(...)</span>
</p><p>
  <span style="font-weight: 400;">Detalhes da droga...</span>
</p><p>
  <span style="font-weight: 400;">Vasopressor (adrenalina)</span>
</p><p>
  <span style="font-weight: 400;">Nas mesmas doses usadas para FV/TV sem pulso, ou seja, 1 mg a cada 3-5 minutos.</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* ATEN\xC7\xC3O: Desde 2010, a Atropina e o marca-passo n\xE3o est\xE3o mais indicados para a abordagem de assistolia/AESP e, desde 2015, a vasopressina n\xE3o \xE9 estimulada Protocolos de Parada Card\xEDaca para administra\xE7\xE3o isolada.</span>
  </em>
</p><p>
  <strong>- Causas Revers\xEDveis: 5Hs e 5Ts</strong>
  <span style="font-weight: 400;">&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">A cada per\xEDodo de 2 minutos de RCP em qualquer ritmo, o socorrista deve pensar em poss\xEDveis causas revers\xEDveis de parada, situa\xE7\xF5es que s\xE3o ainda mais frequentes na AESP. Elas s\xE3o memorizadas atrav\xE9s da regra dos 5Hs e 5Ts:</span>
</p><p>
          <span style="font-weight: 400;">Os 5 H\u2019s</span>
        </p><p>
          <span style="font-weight: 400;">Os 5 T\u2019s</span>
        </p><p>
          <em>
            <span style="font-weight: 400;">Hipovolemia</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Toxicidade (intoxica\xE7\xE3o)</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Hip\xF3xia</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Tamponamento Card\xEDaco</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Hidrog\xEAnio (acidose)</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Tenso Pneumot\xF3rax (pneumot\xF3rax hipertensivo)</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Hipo/Hipercalemia</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Tromboembolismo Pulmonar (TEP)</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Hipotermia</span>
          </em>
        </p><p>
          <em>
            <span style="font-weight: 400;">Trombose Coronariana</span>
          </em>
        </p><p>
  <br>
</p><p>
  <strong>- Ressuscita\xE7\xE3o Cardiopulmonar Extracorp\xF3rea (ECPR)</strong>
</p><p>
  <span style="font-weight: 400;">A ressuscita\xE7\xE3o cardiopulmonar extracorp\xF3rea (ECPR) consiste na instala\xE7\xE3o de um bypass cardiopulmonar atrav\xE9s da ECMO (Oxigena\xE7\xE3o por Membrana Extracorp\xF3rea) durante a abordagem de um paciente em parada card\xEDaca. Atualmente, esta estrat\xE9gia pode ser considerada nos casos refrat\xE1rios de uma parada cuja etiologia suspeita seja potencialmente revers\xEDvel, havendo uma chance maior de sucesso nos pacientes mais jovens e com poucas comorbidades.</span>
</p><p>
  <strong>- Cuidados P\xF3s-Parada</strong>
</p><p>
  <span style="font-weight: 400;">Ap\xF3s o retorno da circula\xE7\xE3o espont\xE2nea deve-se:</span>
</p><p>
  <span style="font-weight: 400;">(1) Realizar ECG de 12 Deriva\xE7\xF5es</span>
</p><p>
  <span style="font-weight: 400;">Se houver supra de ST: indicar coronariografia de urg\xEAncia, a qual tamb\xE9m \xE9 razo\xE1vel para pacientes comatosos e com instabilidade el\xE9trica ou hemodin\xE2mica mesmo sem supra de ST.</span>
  <strong>&nbsp;</strong>
</p><p>
  <span style="font-weight: 400;">&nbsp;(2) Tratar Hipotens\xE3o (alvos: PA sist\xF3lica \u2265 90 mmHg, PAM \u2265 65 mmHg)</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Soro Fisiol\xF3gico 0,9% ou Ringer Lactato: 1-2 litros em bolus.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Vasopressores se necess\xE1rio (dopamina 5-10 mcg/kg/min, adrenalina 0,1-0,5 mcg/kg/min, noradrenalina 0,1-0,5 mcg/kg/min).</span>
  </li>
  <li>
    <span style="font-weight: 400;">Considerar causas revers\xEDveis (5Hs e 5Ts).</span>
  </li>
</ul><p>
  <span style="font-weight: 400;">(3) Realizar o Controle Direcionado da Temperatura&nbsp;</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Indica\xE7\xE3o: Pacientes que permanecem comatosos (ou seja, sem resposta sensata a comandos verbais) ap\xF3s a PCR \u2013 independente do ritmo de parada.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Protocolo: Manter por, pelo menos, 24h uma temperatura-alvo entre 32</span>
    <span style="font-weight: 400;">o</span>
    <span style="font-weight: 400;">C e 36</span>
    <span style="font-weight: 400;">o</span>
    <span style="font-weight: 400;">C \u2013 a temperatura escolhida pode ser determinada com base na prefer\xEAncia do m\xE9dico ou em fatores cl\xEDnicos (por exemplo, um alvo mais elevado \u2013 pr\xF3ximo de 36</span>
    <span style="font-weight: 400;">o</span>
    <span style="font-weight: 400;">C \u2013 pode ser melhor para pacientes com sangramento, enquanto um alvo mais baixo \u2013 mais pr\xF3ximo de 32</span>
    <span style="font-weight: 400;">o</span>
    <span style="font-weight: 400;">C \u2013 pode ser mais ben\xE9fico em caso de convuls\xE3o ou edema cerebral). Se necess\xE1ria, a redu\xE7\xE3o da temperatura pode ser conseguida pela coloca\xE7\xE3o de compressas geladas adjacentes a vasos mais calibrosos, isto \xE9, em axilas, virilhas e pesco\xE7o (reduz a temperatura em 0,5 a 1</span>
    <span style="font-weight: 400;">o</span>
    <span style="font-weight: 400;">C por hora) e/ou pela infus\xE3o de salina intravenosa resfriada (a infus\xE3o r\xE1pida de 30 mL/Kg de salina a 4</span>
    <span style="font-weight: 400;">o</span>
    <span style="font-weight: 400;">C reduz a temperatura em cerca de 2</span>
    <span style="font-weight: 400;">o</span>
    <span style="font-weight: 400;">C).</span>
  </li>
</ul><p>
  <em>
    <span style="font-weight: 400;">* Ap\xF3s essas 24h de Controle Direcionado da Temperatura, esfor\xE7os devem ser feitos para evitar a hipertermia, a qual pode agravar danos neurol\xF3gicos.</span>
  </em>
</p><p>
  <span style="font-weight: 400;">(4) Otimizar ventila\xE7\xE3o e oxigena\xE7\xE3o</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Manter satura\xE7\xE3o de oxig\xEAnio entre 92-98% com a menor FiO</span>
    <span style="font-weight: 400;">2</span>
    <span style="font-weight: 400;">poss\xEDvel e evitar hiperventila\xE7\xE3o (iniciar com FR 10 irpm, titulando para uma PaCO</span>
    <span style="font-weight: 400;">2</span>
    <span style="font-weight: 400;">em um intervalo fisiol\xF3gico entre 35-45 mmHg).</span>
  </li>
</ul><p>
  <span style="font-weight: 400;">(5) Administrar Antiarr\xEDtmico?</span>
</p><p>
  <span style="font-weight: 400;">Atualmente, n\xE3o h\xE1 nenhuma evid\xEAncia que recomende ou refute o uso de drogas antiarr\xEDtmicas (como beta-bloqueador IV ou VO, lidoca\xEDna e amiodarona), de modo que, embora n\xE3o haja respaldo, podem ser administradas na p\xF3s-parada por FV ou TV sem pulso.</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Lidoca\xEDna: 1-4 mg/min</span>
  </li>
  <li>
    <span style="font-weight: 400;">Amiodarona: 1 mg/min por 6h, seguido de 0,5 mg/min por 18h</span>
  </li>
</ul><p>
  <span style="font-weight: 400;">(6) Neuroprogn\xF3stico</span>
</p><p>
  <span style="font-weight: 400;">Nos pacientes que permanecem comatosos sugere-se que, pelo menos, depois de 72 horas de normotermia (tipicamente em, pelo menos, 5 dias do retorno da circula\xE7\xE3o espont\xE2nea nos casos abordados com controle direcionado da temperatura), seja realizada uma avalia\xE7\xE3o neuroprogn\xF3stica multimodal, composta por:</span>
</p><ul>
  <li>
    <span style="font-weight: 400;">Exame cl\xEDnico: a aus\xEAncia dos reflexos fotomotor e corneopalpebral, assim como a ocorr\xEAncia de status miocl\xF4nico (espasmos irregulares, repetitivos e espont\xE2neos \u2013 ou sens\xEDveis a sons \u2013 em face e em membros) associam-se a pior progn\xF3stico neurol\xF3gico.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Biomarcadores: a eleva\xE7\xE3o do n\xEDvel s\xE9rico da enolase neur\xF4nio-espec\xEDfica (NSE) associa-se a pior progn\xF3stico neurol\xF3gico.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Avalia\xE7\xE3o eletrofisiol\xF3gica: a presen\xE7a de</span>
    <em>
      <span style="font-weight: 400;">status epilepticus</span>
    </em>
    <span style="font-weight: 400;">ou de padr\xE3o de surto-supress\xE3o (na aus\xEAncia de drogas sedativas) no eletroencefalograma associam-se a pior progn\xF3stico neurol\xF3gico, assim como a aus\xEAncia bilateral da onda N20 no exame de potencial evocado somatossensitivo (SSEP).</span>
  </li>
  <li>
    <span style="font-weight: 400;">Neuroimagem: na TC de cr\xE2nio, a redu\xE7\xE3o da rela\xE7\xE3o das densidades das subst\xE2ncias branca e cinzenta (GWR \u2013 cujo valor normal \xE9 de cerca de 1,3) tem rela\xE7\xE3o com edema cerebral e, assim, associa-se a pior progn\xF3stico neurol\xF3gico. Na RM de cr\xE2nio, \xE1reas extensas de redu\xE7\xE3o de difus\xE3o percebidas pela t\xE9cnica de imagem ponderada por difus\xE3o (DWI) e quantificadas pelo coeficiente de difus\xE3o aparente (ADC) associam-se a pior progn\xF3stico neurol\xF3gico.</span>
  </li>
</ul>`,ordem:4},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Interrup\xE7\xE3o inadequada das compress\xF5es tor\xE1cicas -</strong>
  <span style="font-weight: 400;">O foco absoluto do BLS e do ACLS \xE9 a compress\xE3o tor\xE1cica, que deve ser otimizada ao m\xE1ximo e interrompida o m\xEDnimo poss\xEDvel. Assim, a intuba\xE7\xE3o e o acesso perif\xE9rico devem ser tentados enquanto \xE9 mantida a compress\xE3o: existe uma simultaneidade de procedimentos! Se houver necessidade de interrup\xE7\xE3o, a mesma n\xE3o deve ultrapassar 10 segundos.</span>
</p><p>
  <strong>- Avalia\xE7\xE3o do pulso -</strong>
  <span style="font-weight: 400;">A palpa\xE7\xE3o do pulso arterial (como o pulso carot\xEDdeo) para saber se houve retorno da circula\xE7\xE3o espont\xE2nea s\xF3 deve ser feita se, no momento da avalia\xE7\xE3o do ritmo card\xEDaco, for notado um ritmo el\xE9trico organizado, at\xE9 porque existem outros par\xE2metros que demonstram com maior acur\xE1cia o restabelecimento da circula\xE7\xE3o espont\xE2nea (como a capnografia citada anteriormente).</span>
</p><p>
  <strong>- Administra\xE7\xE3o de drogas intravenosas -</strong>
  <span style="font-weight: 400;">Durante o processo de reanima\xE7\xE3o, a administra\xE7\xE3o de drogas IV deve ser feita rapidamente em</span>
  <em>
    <span style="font-weight: 400;">bolus</span>
  </em>
  <span style="font-weight: 400;">e seguida de infus\xE3o de 20 mL de solu\xE7\xE3o salina pela mesma via tamb\xE9m em</span>
  <em>
    <span style="font-weight: 400;">bolus</span>
  </em>
  <span style="font-weight: 400;">, elevando posteriormente o membro por 10-20 segundos.</span>
</p><p>
  <strong>- Quando parar de reanimar? -</strong>
  <span style="font-weight: 400;">N\xE3o h\xE1 um consenso em rela\xE7\xE3o a isso, mas os principais par\xE2metros que influenciam na decis\xE3o de interromper os esfor\xE7os da RCP s\xE3o: dura\xE7\xE3o &gt; 30 minutos sem surgimento de ritmo adequado; assistolia como ritmo de parada; grande intervalo entre momento da parada e o in\xEDcio da reanima\xE7\xE3o; idade e comorbidades do paciente. As \xFAltimas diretrizes propuseram dados mais objetivos, de modo que, em pacientes intubados, uma ETCO</span>
  <span style="font-weight: 400;">2</span>
  <span style="font-weight: 400;">&lt; 10 mmHg ap\xF3s 20 minutos de RCP est\xE1 associada a uma baixa probabilidade de sucesso na reanima\xE7\xE3o.</span>
</p><p>
  <span style="font-weight: 400;">Nas paradas extra-hospitalares, existem crit\xE9rios para interrup\xE7\xE3o do BLS conhecidos como regra TOR (</span>
  <em>
    <span style="font-weight: 400;">Termination of Resuscitation</span>
  </em>
  <span style="font-weight: 400;">), em que se poderia considerar interromper o BLS caso, ap\xF3s, pelo menos, 4 intervalos de dois minutos de RCP, esses 3 crit\xE9rios estiverem presentes: parada n\xE3o foi testemunhada por um m\xE9dico do servi\xE7o de emerg\xEAncia, n\xE3o houve retorno da circula\xE7\xE3o espont\xE2nea (RCE), n\xE3o foi realizada desfibrila\xE7\xE3o (por exemplo, o ritmo n\xE3o era choc\xE1vel). Isso evitaria o transporte de pacientes sem chance de sobreviv\xEAncia...</span>
</p><p>
  <strong>- Soco precordial \u2013</strong>
  <span style="font-weight: 400;">O soco precordial \u2013 golpe \xFAnico no meio do esterno com o lado ulnar da m\xE3o cerrada \u2013 pode ser tentado nas paradas testemunhadas em ritmo ventricular caso o desfibrilador n\xE3o esteja imediatamente dispon\xEDvel.</span>
</p><p>
  <strong>SUGEST\xD5ES BIBLIOGR\xC1FICAS</strong>
</p><ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Panchal AR, Bartos JA, Caba\xF1as JG, Donnino MW, Drenna IA, Hirsch KG, et al. Part 3: Adult Basic and Advanced Life Support: 2020 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care.</span>
    <em>
      <span style="font-weight: 400;">Circulation</span>
    </em>
    <span style="font-weight: 400;">. 2020;142(suppl 2):S366\u2013S468.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Kleinman ME, Brennan EE, Goldberger ZD, Swor RA, Terry M, Bobrow BJ, Gazmuri RJ, Travers AH, Rea T. Part 5: adult basic life support and cardiopulmonary resuscitation quality: 2015 American Heart Association Guidelines Update for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation. 2015;132(suppl 2):S414\u2013S435</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Link MS, Berkow LC, Kudenchuk PJ, Halperin HR, Hess EP, Moitra VK, Neumar RW, O\u2019Neil BJ, Paxton JH, Silvers SM, White RD, Yannopoulos D, Donnino MW. Part 7: adult advanced cardiovascular life support: 2015 American Heart Association Guidelines Update for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation. 2015; 132(suppl 2):S444\u2013S464.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Callaway CW, Donnino MW, Fink EL, Geocadin RG, Golan E, Kern KB, Leary M, Meurer WJ, Peberdy MA, Thompson TM, Zimmerman JL. Part 8: post\u2013cardiac arrest care: 2015 American Heart Association Guidelines Update for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation. 2015;132(suppl 2):S465\u2013S482.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Berg RA, Hemphill R, Abella BS, Aufderheide TP, Cave DM, Hazinski MF, Lerner EB, Rea TD, Sayre MR, Swor RA. Part 5: Adult basic life support: 2010 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care.</span>
    <em>
      <span style="font-weight: 400;">Circulation</span>
    </em>
    <span style="font-weight: 400;">. 2010;122(suppl 3):S685\u2013S705</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Gonzalez MM, Timerman S, Gianotto-Oliveira R, Polastri TF, Canesin MF, Lage SG, et al. Sociedade Brasileira de Cardiologia. I Diretriz de Ressuscita\xE7\xE3o Cardiopulmonar e Cuidados Cardiovasculares de Emerg\xEAncia da Sociedade Brasileira de Cardiologia. Arq Bras Cardiol. 2013; 101(2Supl.3): 1-221</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Neumar RW, Otto CW, Link MS, Kronick SL, Shuster M, Callaway CW, Kudenchuk PJ, Ornato JP, McNally B, Silvers SM, Passman RS, White RD, Hess EP, Tang W, Davis D, Sinz E, Morrison LJ. Part 8: adult advanced cardiovascular life support: 2010 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care.</span>
    <em>
      <span style="font-weight: 400;">Circulation.</span>
    </em>
    <span style="font-weight: 400;">2010;122(suppl 3):S729 \u2013S767</span>
  </li>
</ol><p>
  <span style="font-weight: 400;">Peberdy MA, Callaway CW, Neumar RW, Geocadin RG, Zimmerman JL, Donnino M, Gabrielli A, Silvers SM, Zaritsky AL, Merchant R, Vanden Hoek TL, Kronick SL. Part 9: post\u2013 cardiac arrest care: 2010 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care.</span>
  <em>
    <span style="font-weight: 400;">Circulation</span>
  </em>
  <span style="font-weight: 400;">. 2010;122(suppl 3):S768 \u2013S786</span>
</p>`,ordem:5}],videos:[],fluxogramas:[{id:"5545342c-dc88-4b09-b774-e6cbc1ded0de",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/658330cc-83e4-40c2-bf1a-5c97e554b34c.jpg",orientacao:"vertical"},{id:"2969e5c3-4b5c-433e-93fd-bb245ce15be1",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/009f1256-d273-439e-b8e8-4c971806a385.jpg",orientacao:"horizontal"},{id:"a2dc1e6b-646b-4e7f-a0dd-7ce5a2c05c52",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/25dd21cf-169a-4a64-9511-50d3118500c1.jpg",orientacao:"horizontal"},{id:"36694a36-018b-47b4-9bf9-c0bad75b6012",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/db4f9e9e-d1e8-4e12-8c8e-4224c9bc5107.jpg",orientacao:"vertical"},{id:"197f429d-83bc-486d-ab41-26e2af1bc5af",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/05380df0-9cb6-4457-b63c-78fdab215452.jpg",orientacao:"horizontal"},{id:"daf8347c-2e41-4a1c-a01a-47b1e87b9b97",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/3be65fc7-a301-4af6-8196-c6d9a563e34e.jpg",orientacao:"horizontal"},{id:"d651bf5a-863f-486d-8fb1-8939dbc1655b",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/add77fa4-c84a-4e44-9786-bd1c14ca29bf.jpg",orientacao:"horizontal"},{id:"6bda2776-27f5-4224-a8db-a63147961189",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/b0962b1f-0d0a-43d3-b7cd-14e8e57f6b8a.jpg",orientacao:"horizontal"},{id:"e9f6ce07-a9d2-4232-a54f-d85aa0345db3",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/30bc7fcc-ff78-4d38-84d2-a2d09dcdf0d5.jpg",orientacao:"vertical"},{id:"a8eee4f5-6240-4fbd-806d-9377937e055a",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/0873f2ff-9491-4ad4-99be-f8e15dcff396.jpg",orientacao:"horizontal"},{id:"71665d55-f255-4cdb-89b3-e042b0bda6a2",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/57494d8e-f3c7-4d2e-8bde-d27ff6394295.jpg",orientacao:"vertical"},{id:"317b8e15-127e-4158-89cc-1d6fd730dc34",nome:"Fluxograma da Parada Cardiorrespirat\xF3ria",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/ad3e63d3-24f1-4f19-aecf-4af6124595a1.jpg",orientacao:"horizontal"}],tags:["Assistolia","Fibrila\xE7\xE3o Ventricular","AESP","PCR","Parada","BLS","ACLS","Cuidados P\xF3s-Parada"]},{id:"79c7009b-a942-4c21-a458-a5e4cf7392fa",nome:"Pericardite Aguda",categoria:1,termosDeBusca:"pericardite aguda, supra",favoritado:!1,ordem:0,especialidades:[{nome:"CARDIOLOGIA"}],prescricoes:[{id:"de87170a-d4d1-4bd4-ad44-e7921441496a",nome:"Pericardite Aguda",favorito:!0,ordem:1,secoes:[{item:"Dieta",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ae266510-096a-4e26-8a36-9a59a897789b",opcoes:[{id:"078a91d4-ab81-4e8c-a8e5-300cecc1f44b",descr:"Dieta oral livre",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Sem restri\xE7\xE3o diet\xE9tica espec\xEDfica.",ordem:1},{item:"Anti-inflamat\xF3rio",grupos:[{grupo:"Analg\xE9sico",idGrupo:"fc1376f7-4e28-47c9-b24a-8860a982e926",opcoes:[{id:"2288d170-861f-401d-a393-f1e1364136a1",descr:"AAS (500mg/comp) 500-1000 mg VO 6/6h ou 8/8h (1,5-4g/dia) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"6febcda1-3e5f-4b46-928f-a7e35a04bafa",descr:"Ibuprofeno (200-600mg/comp) 400-800 mg VO 8/8h",recomendado:!1,favorito:!1,ordem:2},{id:"005bb856-bd75-4abf-93d1-287a05193487",descr:"Indometacina (25-50mg/comp) 25-50 mg VO 8/8h",recomendado:!1,favorito:!1,ordem:3},{id:"50f2ff95-7ee3-4d97-8043-25add9c2e1cf",descr:"Naproxeno (250-500mg/comp) 250-500 mg VO 12/12h",recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Dura\xE7\xE3o de 1-2 semanas no primeiro epis\xF3dio n\xE3o-complicado. Casos recorrentes dever\xE3o ser tratados por, pelo menos, 2-4 semanas e necessitar\xE3o de redu\xE7\xE3o gradual da dose a cada 1-2 semanas.",ordem:2},{item:"Adjuvante",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7d81bc2a-9260-4de6-88ec-71cce90089ac",opcoes:[{id:"a3917de9-24c9-4c49-a184-1b6e6ff025e3",descr:"Colchicina (0,5-1mg/comp) 0,5 mg VO 12/12h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"0e6d48da-f6a1-4a7f-adf4-fab2971aa2ae",descr:"Colchicina (0,5-1mg/comp) 0,5 mg VO 1x/dia (se paciente < 70 Kg)",recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Importante para reduzir recorr\xEAncia. Reduzir dose: (1) > 70 anos: reduzir 50%; (2) ClCr 35-49 mL/min: 0,5 mg 1x/dia; (3) ClCr 10-34 mL/min: 0,5 mg a cada 2/3 dias. Dura\xE7\xE3o de 3 meses no primeiro epis\xF3dio n\xE3o-complicado, enquanto casos recorrentes dever\xE3o ser tratados por, pelo menos, 6 meses. A retirada gradual n\xE3o \xE9 mandat\xF3ria, mas pode ser considerada (\xFAltimas semanas: 0,5 mg 1x/dia se \u2265 70 Kg e 0,5 mg em dias alternados se < 70 Kg).",ordem:3},{item:"Corticoide",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7b1b9679-fb7d-41c4-b780-892bbf2d577f",opcoes:[{id:"5e61d610-c38f-40b2-a3f1-e2f955d0dd20",descr:"Prednisona (5-20mg/comp) 0,2-0,5 mg/Kg VO 1x/dia",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Considerado seu uso em dose baixa quando houver contraindica\xE7\xE3o \xE0 terapia anti-inflamat\xF3ria ou resposta incompleta \xE0 associa\xE7\xE3o AINE/AAS com colchicina, sendo que, neste \xFAltimo caso, deve-se considerar adicionar a corticoterapia ao inv\xE9s de substituir a terapia anti-inflamat\xF3ria.",ordem:4},{item:"Inibidor de Bomba de Pr\xF3ton",grupos:[{grupo:"Analg\xE9sico",idGrupo:"2daad270-a3be-49af-94f8-ed4f9c98c086",opcoes:[{id:"f607d4e0-31f7-4406-8d9c-39f7076d7431",descr:"Esomeprazol (20-40mg/comp) 20-40 mg VO 1x/dia pela manh\xE3 (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"4bb174a7-a3f2-4152-bbae-d6c005cbba59",descr:"Omeprazol (10-40mg/comp) 20-40 mg VO 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:2},{id:"2b699b66-8d75-4a1e-a735-f09fa5d15f1d",descr:"Lansoprazol (15-30mg/comp) 15-30 mg VO 1x/dia pela manh\xE3",recomendado:!1,favorito:!1,ordem:3}],ordem:1}],academico:"Prote\xE7\xE3o de mucosa g\xE1strica em virtude da terapia anti-inflamat\xF3ria.",ordem:5},{item:"Sintom\xE1ticos",grupos:[{grupo:"Analg\xE9sico",idGrupo:"4f0568be-9e86-40ca-b2c1-b790801adf37",opcoes:[{id:"7b1d1930-4ef0-4a60-9078-c51eb786a331",descr:"Paracetamol (500-750mg/comp) 750-1000 mg VO em caso de dor ou febre, at\xE9 6/6h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"7d6d8507-d73d-45e5-8147-75a2847a3160",descr:"Dipirona (500-1000mg/comp) 500-1000 mg VO em caso de dor ou febre, at\xE9 6/6h",recomendado:!1,favorito:!1,ordem:2}],ordem:1},{grupo:"antiem\xE9tico",idGrupo:"47dcbe65-4523-470a-8a96-5d85c3bada51",opcoes:[{id:"ebd88b6e-7a48-4250-b5f9-b9de9d164afc",descr:"Metoclopramida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h) (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"434607a4-5405-49c6-a179-2c7477fe37e3",descr:"Bromoprida (10mg/comp) 10 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h)",recomendado:!1,favorito:!1,ordem:2},{id:"3964ff88-41ff-4f4e-b8a7-99581a06fc26",descr:"Ondansetrona (4-8mg/comp) 4-8 mg VO em caso de n\xE1usea ou v\xF4mito (at\xE9 8/8h ou 12/12h)",recomendado:!1,favorito:!1,ordem:3}],ordem:2}],academico:"Condutas espec\xEDficas para manifesta\xE7\xF5es gerais.",ordem:6}],conceitosPraticos:[{conceito:"Diagn\xF3stico com 2 de 4 crit\xE9rios: dor tor\xE1cica, atrito peric\xE1rdico, ECG, derrame peric\xE1rdico.",ordem:1},{conceito:"N\xE3o usar AINE (ibuprofeno, indometacina, naproxeno) para os casos p\xF3s-infarto, optando assim pelo AAS como estrat\xE9gia anti-inflamat\xF3ria.",ordem:2},{conceito:"AAS contraindicado como estrat\xE9gia anti-inflamat\xF3ria em crian\xE7as pelo risco de S\xEDndrome de Reye e hepatotoxicidade.",ordem:3},{conceito:"Acompanhar resposta terap\xEAutica pela cl\xEDnica e PCR.",ordem:4},{conceito:"Restringir atividade f\xEDsica at\xE9 resolu\xE7\xE3o dos sintomas e normaliza\xE7\xE3o da PCR, ECG e ecocardiograma (m\xEDnimo de 3 meses para atletas).",ordem:5}]}],topicos:[{titulo:"Pericardite Aguda",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p>
  <span style="font-weight: 400;">A pericardite aguda consiste em uma s\xEDndrome de inflama\xE7\xE3o peric\xE1rdica, que pode ou n\xE3o cursar com derrame peric\xE1rdico e \xE9 respons\xE1vel por cerca de 5% dos quadros de dor tor\xE1cica na Emerg\xEAncia. As causas s\xE3o divididas em infecciosas (com destaque para v\xEDrus e bact\xE9rias, havendo redu\xE7\xE3o da etiologia tuberculosa pelo maior controle efetivo da doen\xE7a pulmonar) e n\xE3o-infecciosas (doen\xE7as autoimunes, insufici\xEAncia renal, neoplasias).
    <br>
    <br>
  </span>
</p><p>
  <span style="font-weight: 400;">
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/e859cd03-454b-4225-b47b-927686224b61.jpg" alt="" width="100%" height="auto">
  </span>
</p>`,ordem:2},{titulo:"QUADRO CL\xCDNICO",texto:`<p>
  <span style="font-weight: 400;">As manifesta\xE7\xF5es principais incluem dor tor\xE1cica (&gt;85-90% dos casos: em geral, pleur\xEDtica e com melhora na posi\xE7\xE3o de prece maometana, isto \xE9, sentado e com tronco inclinado para frente, reduzindo a press\xE3o no peric\xE1rdio parietal), atrito peric\xE1rdico (\u2264 33% dos casos); altera\xE7\xF5es eletrocardiogr\xE1ficas (at\xE9 60% dos casos: supra de ST e/ou infra de PR difusos) e derrame peric\xE1rdico (at\xE9 60% dos casos e tipicamente leve).</span>
</p><p>
  <em>
    <span style="font-weight: 400;">* Outras manifesta\xE7\xF5es associadas a etiologias espec\xEDficas podem estar presentes.</span>
  </em>
</p>`,ordem:3},{titulo:"DIAGN\xD3STICO",texto:`<p>
  <span style="font-weight: 400;">O diagn\xF3stico de pericardite aguda \xE9 dado pela presen\xE7a de, pelo menos, 2 dos seguintes crit\xE9rios descritos anteriormente: (1) dor tor\xE1cica; (2) atrito peric\xE1rdico; (3) ECG com supra de ST ou infra de PR disseminados; (4) derrame peric\xE1rdico (novo ou em piora).</span>
</p><p>
  <span style="font-weight: 400;">Por conta desses crit\xE9rios, existe recomenda\xE7\xE3o de solicita\xE7\xE3o de ECG e ecocardiograma para todos os casos suspeitos de pericardite, assim como de radiografia de t\xF3rax, que geralmente \xE9 normal. Outros exames de imagem, como resson\xE2ncia magn\xE9tica e tomografia computadorizada \u2013 que demonstram espessamento peric\xE1rdico, derrame e inj\xFAria inflamat\xF3ria \u2013 podem ser tamb\xE9m solicitados, sendo especialmente importantes nos casos em que o ecocardiograma n\xE3o \xE9 diagn\xF3stico e na suspeita de pericardite constrictiva.</span>
</p><p>
  <span style="font-weight: 400;">Em rela\xE7\xE3o \xE0 avalia\xE7\xE3o laboratorial, a eleva\xE7\xE3o de prote\xEDna C-reativa (PCR) e VHS, assim como leucocitose corroboram o diagn\xF3stico, enquanto o aumento de marcadores de necrose mioc\xE1rdica \u2013 em especial, a troponina I \u2013 sugerem miocardite concomitante.</span>
</p><p>
  <span style="font-weight: 400;">Na depend\xEAncia de uma suspeita etiol\xF3gica espec\xEDfica, podem ser solicitados exames adicionais, como provas reumatol\xF3gicas (FAN em mulher jovem com hist\xF3ria sugestiva de desordem reumatol\xF3gica), fun\xE7\xE3o renal, hemocultura (na suspeita de infec\xE7\xE3o bacteriana, como febre &gt; 38</span>
  <span style="font-weight: 400;">o</span>
  <span style="font-weight: 400;">C e sinais de sepse), sorologia para HIV e PPD.</span>
</p><p>
  <span style="font-weight: 400;">A pericardiocentese \xE9 indicada em casos de tamponamento card\xEDaco com inten\xE7\xE3o terap\xEAutica e, nos derrames peric\xE1rdicos significativos (&gt; 20 mm ao ecocardiograma na di\xE1stole) com inten\xE7\xE3o diagn\xF3stica, situa\xE7\xE3o em que a avalia\xE7\xE3o do l\xEDquido \xE9 feita de acordo com a suspeita etiol\xF3gica: citologia, pesquisa de c\xE9lulas neopl\xE1sicas, cultura, pesquisa viral por PCR, dosagem de adenosina deaminase. A bi\xF3psia peric\xE1rdica tem indica\xE7\xE3o nos casos refrat\xE1rios ao tratamento cl\xEDnico e sem diagn\xF3stico definitivo estabelecido.</span>
</p>`,ordem:4},{titulo:"TRATAMENTO",texto:`<p>
  <span style="font-weight: 400;">Os pacientes considerados de alto risco, isto \xE9, que necessitam de interna\xE7\xE3o e investiga\xE7\xE3o etiol\xF3gica, s\xE3o aqueles que apresentam manifesta\xE7\xF5es sugestivas de etiologia espec\xEDfica n\xE3o-viral ou um preditor de mau progn\xF3stico (febre &gt; 38</span>
  <span style="font-weight: 400;">o</span>
  <span style="font-weight: 400;">C, leucocitose, derrame peric\xE1rdico volumoso, tamponamento card\xEDaco, curso subagudo, associa\xE7\xE3o com miocardite, imunodepress\xE3o, trauma, uso de anticoagulante).</span>
</p><p>
  <span style="font-weight: 400;">Pacientes sem essas considera\xE7\xF5es s\xE3o tratados ambulatorialmente com reavalia\xE7\xE3o dentro de 1 semana, sendo tamb\xE9m indicada interna\xE7\xE3o para os casos que n\xE3o responderem ao tratamento anti-inflamat\xF3rio descrito abaixo. A aus\xEAncia de resposta terap\xEAutica nesse per\xEDodo \u2013 definida como persist\xEAncia de febre, dor tor\xE1cica pleur\xEDtica, novo derrame peric\xE1rdico ou piora do estado geral \u2013 sugere uma etiologia espec\xEDfica diferente da idiop\xE1tica ou viral.</span>
</p><p>
  <strong>- Tratamento Medicamentoso \u2013</strong>
  <span style="font-weight: 400;">O pilar terap\xEAutico \xE9 anti-inflamat\xF3rio, podendo envolver AAS ou anti-inflamat\xF3rio n\xE3o-esteroidal (AINE, com prefer\xEAncia pelo ibuprofeno). O acompanhamento com PCR \xE9 \xFAtil para avaliar a resposta terap\xEAutica e guiar a dura\xE7\xE3o do tratamento, que \xE9, em geral, de 1-2 semanas para casos n\xE3o-complicados.</span>
</p><p>
  <span style="font-weight: 400;">A colchicina \xE9 recomendada em dose baixa (0,5 mg 1x/dia para &lt; 70 Kg ou 0,5 mg 12/12h para \u2265 70 Kg) para otimizar a resposta \xE0 estrat\xE9gia anti-inflamat\xF3ria e prevenir recorr\xEAncia, sendo usada por 3 meses.&nbsp;</span>
</p><p>
  <span style="font-weight: 400;">A corticoterapia em dose baixa (prednisona 0,2-0,5 mg/Kg/dia) pode ser utilizada como op\xE7\xE3o de segunda linha nos casos que n\xE3o respondem ao tratamento com AAS/AINE (ou que tenham contraindica\xE7\xE3o ao mesmo) ou como tratamento padr\xE3o na etiologia reumatol\xF3gica ou ur\xEAmica. Essa dose inicial \xE9 mantida at\xE9 a resolu\xE7\xE3o dos sintomas e normaliza\xE7\xE3o da PCR, sendo realizada retirada gradual a seguir.</span>
</p><p>
  <strong>- Tratamento N\xE3o-Medicamentoso \u2013</strong>
  <span style="font-weight: 400;">A restri\xE7\xE3o \xE0 atividade f\xEDsica deve ser mantida at\xE9 a resolu\xE7\xE3o dos sintomas e normaliza\xE7\xE3o da PCR, ECG e ecocardiograma, sendo que, nos atletas, ela ainda deve ser de, no m\xEDnimo, 3 meses (ou 6 meses se houver miopericardite).</span>
</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p>
  <strong>- Pericardite p\xF3s-infarto \u2013</strong>
  <span style="font-weight: 400;">Na pericardite aguda p\xF3s-infarto (S\xEDndrome de Dressler), a combina\xE7\xE3o terap\xEAutica deve ser AAS + colchicina e n\xE3o AINE + colchicina, uma vez que o AINE prejudica a forma\xE7\xE3o da cicatriz p\xF3s-infarto.</span>
</p><p>
  <strong>- Pericardite Recorrente \u2013</strong>
  <span style="font-weight: 400;">A recorr\xEAncia \xE9 definida quando ocorre retorno das manifesta\xE7\xF5es de pericardite ap\xF3s um intervalo de 4-6 semanas livre de sintomas. O tratamento inicial deve ser o mesmo para o quadro agudo original, mas agora com uma dura\xE7\xE3o de, pelo menos, 2-4 semanas de terapia anti-inflamat\xF3ria, seguida de redu\xE7\xE3o gradual da dose a cada 1-2 semanas. Em casos refrat\xE1rios em que n\xE3o houver resposta nem mesmo \xE0 corticoterapia, pode-se optar por imunossupressores e drogas biol\xF3gicas, como:</span>
</p><p>
  <span style="font-weight: 400;">(1) Azatioprina: 1 mg/Kg/dia VO 1x/dia ou 12/12h, gradualmente aumentada para 2-3 mg/Kg/dia.</span>
</p><p>
  <span style="font-weight: 400;">(2) Imunoglobulina Intravenosa: 400-500 mg/Kg/dia por 5 dias, com possibilidade de repeti\xE7\xE3o em 4/4 semanas.</span>
</p><p>
  <span style="font-weight: 400;">(3) Inibidor de IL-1: Anakinra 1-2 mg/Kg/dia at\xE9 o m\xE1ximo de 100 mg SC 1x/dia ou rilonacept (1\xAA dose de 320 mg, seguida de dose semanal de 160 mg).</span>
</p><p>
  <strong>- Gestante \u2013</strong>
  <span style="font-weight: 400;">Existem algumas particularidades terap\xEAuticas importantes no tratamento da pericardite aguda durante a gesta\xE7\xE3o e a lacta\xE7\xE3o... A terapia anti-inflamat\xF3ria \xE9 permitida com a idade gestacional &lt; 20 semanas, sendo o AAS a droga de 1</span>
  <span style="font-weight: 400;">a</span>
  <span style="font-weight: 400;">escolha nesse per\xEDodo. Entretanto, com \u2265 20 semanas de gesta\xE7\xE3o, o AAS e os demais AINEs s\xE3o contraindicados pelo risco de fechamento precoce do ducto arterioso, de forma que a prednisona acaba sendo a op\xE7\xE3o ideal (a metaboliza\xE7\xE3o do corticoide pela placenta faz com que apenas 10% da droga ativa chegue ao feto). Durante a lacta\xE7\xE3o, o AAS deve ser evitado pelo risco te\xF3rico de S\xEDndrome de Reye na crian\xE7a, sendo permitidos os demais AINEs. J\xE1 a colchicina \xE9 contraindicada na gravidez e na lacta\xE7\xE3o!</span>
</p>`,ordem:6},{titulo:"SUGEST\xD5ES BIBLIOGR\xC1FICAS",texto:`<ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Chiabrando JG, Bonaventura A, Vecchi\xE9 A, et al. Management of Acute and Recurrent Pericarditis. Journal of the American College of Cardiology 2020, 75(1):79-92.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Adler Y, Charron P, Imazio M, et al. 2015 ESC Guidelines for the diagnosis and management of pericardial diseases: the Task Force for the Diagnosis and Management of Pericardial Diseases of the European Society of Cardiology (ESC) Endorsed by: The European Association for Cardio-Thoracic Surgery (EACTS).&nbsp;</span>
    <span style="font-weight: 400;">European Heart Journal 2015</span>
    <span style="font-weight: 400;">, 36(42):2921-2964.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Montera MW, Mesquita ET, Colafranceschi AS, Oliveira Junior AM, Rabischoffsky A, Ianni BM, et al. Sociedade Brasileira de Cardiologia. I Diretriz Brasileira de Miocardites e Pericardites. Arq Bras Cardiol 2013; 100(4 supl. 1):1-36</span>
  </li>
</ol><p>
  <span style="font-weight: 400;">Snyder MJ, Bepko J, White M. Acute pericarditis: diagnosis and management.&nbsp;</span>
  <span style="font-weight: 400;">Am Fam Physician 2014,</span>
  <span style="font-weight: 400;">89(7):553-560.</span>
</p>`,ordem:7}],videos:[],fluxogramas:[{id:"3f15825c-8925-40f9-b2a3-bed184bd4d20",nome:"Fluxograma da Pericardite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/b8b31c27-a347-409e-a8bc-10dfa79db8ed.jpg",orientacao:"vertical"},{id:"c131d570-dc7c-434e-abf5-e4ea9dedd1ea",nome:"Fluxograma da Pericardite Aguda",imagem:"https://d55mnj1ee66xh.cloudfront.net/fluxogramas/1c877b80-bb89-44e9-ab37-5636a7bb428a.jpg",orientacao:"horizontal"}],tags:["Supra"]},{id:"66122b06-edb4-4352-9875-2e67a72c5087",nome:"Sepse",categoria:1,termosDeBusca:"sepse, choque septico",favoritado:!1,ordem:0,especialidades:[{nome:"INFECTOLOGIA"}],prescricoes:[],topicos:[{titulo:"Sepse",texto:"",ordem:1},{titulo:"CONCEITO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Sepse \xE9 a disfun\xE7\xE3o org\xE2nica potencialmente fatal causada por uma resposta desregulada do hospedeiro a alguma infec\xE7\xE3o. O choque s\xE9ptico, por sua vez, \xE9 a sepse com profundas anormalidades circulat\xF3rias e do metabolismo celular.</span>
</p>`,ordem:2},{titulo:"QUADRO CL\xCDNICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">Os sinais e sintomas de sepse s\xE3o inespec\xEDficos, mas podem incluir manifesta\xE7\xF5es de uma fonte infecciosa (tosse e dispneia em uma pneumonia, por exemplo), hipotens\xE3o, taquicardia, febre, taquipneia, leucocitose e, com o agravamento do quadro, surgem sinais de choque (pele fria e cianose), al\xE9m de disfun\xE7\xE3o org\xE2nica (olig\xFAria, altera\xE7\xE3o do estado mental).</span>
</p>`,ordem:3},{titulo:"DIAGN\xD3STICO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A sepse \xE9 atualmente diagnosticada atrav\xE9s do aumento agudo de \u2265 2 pontos no escore SOFA (</span> 
  <em>
    <span style="font-weight: 400;">Sequential Organ Failure Assessment</span>
  </em> 
  <span style="font-weight: 400;">) em um paciente com infec\xE7\xE3o documentada ou suspeita, o que inclusive j\xE1 reflete uma mortalidade hospitalar de aproximadamente 10%. Os itens avaliados nesse escore buscam, na ess\xEAncia, encontrar ind\xEDcios de disfun\xE7\xE3o nos principais sistemas org\xE2nicos: neurol\xF3gico (Glasgow), respirat\xF3rio (rela\xE7\xE3o PaO</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">/FiO</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">baixa), cardiovascular (hipotens\xE3o), hepatobiliar (hiperbilirrubinemia), renal (olig\xFAria ou eleva\xE7\xE3o de creatinina) e hematol\xF3gico (plaquetopenia)
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Como o diagn\xF3stico se baseia na modifica\xE7\xE3o aguda do escore, o SOFA basal do paciente deve ser considerado 0, a n\xE3o ser que seja sabidamente portador de uma disfun\xE7\xE3o org\xE2nica (aguda ou cr\xF4nica) pr\xE9-existente antes do in\xEDcio do quadro infeccioso.</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Uma limita\xE7\xE3o do SOFA \xE9 a espera pelo resultado laboratorial da maior parte de suas vari\xE1veis. Por isso, atualmente, outros escores t\xEAm sido utilizados para um rastreio inicial, como o qSOFA (</span> 
  <em>
    <span style="font-weight: 400;">quick SOFA</span>
  </em> 
  <span style="font-weight: 400;">), a SIRS (S\xEDndrome da Resposta Inflamat\xF3ria Sist\xEAmica), NEWS 2 (</span> 
  <em>
    <span style="font-weight: 400;">National Early Warning Score</span>
  </em> 
  <span style="font-weight: 400;">) e MEWS (</span> 
  <em>
    <span style="font-weight: 400;">Modified Early Warning Score</span>
  </em> 
  <span style="font-weight: 400;">). Desses, um dos mais badalados nos \xFAltimos anos \xE9 o qSOFA, um escore mais enxuto, que avalia apenas tr\xEAs crit\xE9rios, todos com possibilidade de aferi\xE7\xE3o \xE0 beira do leito e sem necessidade de coleta de sangue: (1) Frequ\xEAncia Respirat\xF3ria \u2265 22 irpm; (2) Altera\xE7\xE3o do Estado Mental (Glasgow &lt; 15); (3) Press\xE3o Arterial Sist\xF3lica \u2264 100 mmHg. A ideia b\xE1sica \xE9 que o qSOFA seja utilizado como uma esp\xE9cie de rastreio para pacientes com risco de desenvolverem sepse, de modo que, naqueles com \u2265 2 pontos no qSOFA, devemos realizar avalia\xE7\xF5es laboratoriais contempladas pelo SOFA a fim de identificar bioquimicamente uma disfun\xE7\xE3o org\xE2nica e dar o diagn\xF3stico de sepse precocemente, al\xE9m de intensificar a frequ\xEAncia da monitoriza\xE7\xE3o do paciente e considerar a transfer\xEAncia para o CTI (Centro de Terapia Intensiva). Ou seja, o qSOFA at\xE9 consegue predizer mortalidade, mas n\xE3o \xE9 utilizado para o diagn\xF3stico de sepse. De qualquer forma, nenhum desses escores de rastreio deve ser utilizado como ferramenta isolada de</span> 
  <em>
    <span style="font-weight: 400;">screening</span>
  </em> 
  <span style="font-weight: 400;">para sepse ou choque s\xE9ptico, sendo sempre mais importante a contextualiza\xE7\xE3o do paciente a partir da sua interpreta\xE7\xE3o \xE0 beira do leito.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">J\xE1 o diagn\xF3stico de choque s\xE9ptico exige dois par\xE2metros: (1) hipotens\xE3o com necessidade de vasopressores para manuten\xE7\xE3o de uma press\xE3o arterial m\xE9dia (PAM) \u2265 65 mmHg e (2) n\xEDvel s\xE9rico de lactato elevado (&gt; 18 mg/dL ou 2 mmol/L) apesar de adequada reposi\xE7\xE3o vol\xEAmica.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Assim, na suspeita de sepse ou choque s\xE9ptico, devem ser avaliados precocemente os crit\xE9rios para disfun\xE7\xE3o org\xE2nica com verifica\xE7\xE3o da press\xE3o arterial (hipotens\xE3o \xE9 o mais comum sinal de hipoperfus\xE3o), contagem plaquet\xE1ria (hemograma), creatinina e bilirrubina s\xE9rica \u2013 todos esses \xFAteis para o SOFA, al\xE9m do lactato \u2013 hiperlactatemia pode sinalizar m\xE1 perfus\xE3o mesmo na aus\xEAncia de hipotens\xE3o.</span>
</p>`,ordem:4},{titulo:"TRATAMENTO",texto:`<p style="text-align: justify;">
  <span style="font-weight: 400;">A prioridade inicial para qualquer paciente em sepse ou choque s\xE9ptico \u2013 inclusive aqueles ainda suspeitos \u2013 \xE9 a estabiliza\xE7\xE3o da via a\xE9rea e da ventila\xE7\xE3o, como em qualquer outro paciente grave, al\xE9m de idealmente ser admitido em leito de terapia intensiva em at\xE9 seis horas. Deste modo, oxig\xEAnio suplementar deve ser disponibilizado para todos os casos e a oxigena\xE7\xE3o deve ser monitorizada continuamente por oximetria de pulso.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Tamb\xE9m precocemente, mesmo ainda na suspeita, deve ser obtido acesso venoso, que pode ser perif\xE9rico inicialmente, mas muito v\xE3o requerer um acesso venoso central, que ser\xE1 \xFAtil para administra\xE7\xE3o de volume, drogas (como vasopressores, caso necess\xE1rio) e transfus\xF5es sangu\xEDneas (caso necess\xE1rio tamb\xE9m), al\xE9m de servir para mensura\xE7\xE3o de press\xE3o venosa central (PVC) e satura\xE7\xE3o venosa central de oxig\xEAnio (SvcO</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">), vari\xE1veis que v\xEAm sendo menos usadas na sepse.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Como o cateter de art\xE9ria pulmonar (Swan-Ganz) n\xE3o \xE9 utilizado rotineiramente, atualmente quase n\xE3o se usa mais a satura\xE7\xE3o venosa mista de oxig\xEAnio (SvO</em> 
    <em>2</em> 
    <em>).</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Vamos organizar a abordagem...</span>
</p><p>
  <strong>Estabiliza\xE7\xE3o Hemodin\xE2mica</strong>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A abordagem mais importante na recupera\xE7\xE3o perfusional \xE9 a expans\xE3o vol\xEAmica, idealmente com solu\xE7\xE3o cristaloide, com prefer\xEAncia hoje pela utiliza\xE7\xE3o de solu\xE7\xF5es balanceadas, como Ringer, em compara\xE7\xE3o com SF 0,9%, mas o volume necess\xE1rio n\xE3o \xE9 previs\xEDvel. A sugest\xE3o \xE9 que sejam infundidos, pelo menos, 30 mL/kg (cerca de 2L para um adulto m\xE9dio) em at\xE9 tr\xEAs horas iniciais, principalmente nos casos de sepse com sinais de hipoperfus\xE3o ou choque s\xE9ptico.&nbsp;</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Caso o paciente permane\xE7a hipotenso com PAM &lt; 65 mmHg apesar do in\xEDcio da expans\xE3o vol\xEAmica, deve ser adicionado um</span> 
  <strong>vasopressor</strong> 
  <span style="font-weight: 400;">, com prefer\xEAncia pela noradrenalina. Se ainda n\xE3o se atingir a PAM de 65 mmHg mesmo com dose baixa a moderada de noradrenalina (0,25-0,5 mcg/kg/min), deve ser acrescentada vasopressina na dose fixa de 0,03 U/min e, caso ainda seja necess\xE1rio, o pr\xF3ximo agente deve ser a adrenalina. Na aus\xEAncia de noradrenalina, os f\xE1rmacos iniciais devem ser adrenalina ou dopamina, com especial aten\xE7\xE3o ao risco de arritmias (drogas com muita a\xE7\xE3o em receptor \u03B21-adren\xE9rgico). Outras op\xE7\xF5es de vasopressores s\xE3o: selepressina e angiotensina II (a terlipressina n\xE3o deve ser usada no choque s\xE9ptico). Havendo recursos, o ideal seria que, com o uso de vasopressor, fosse colocado um cateter arterial para aferi\xE7\xE3o mais adequada dos n\xEDveis press\xF3ricos e um cateter central para sua administra\xE7\xE3o (o f\xE1rmaco pode ser iniciado em veia perif\xE9rica enquanto \xE9 providenciado o acesso central, idealmente em s\xEDtios na fossa cubital ou ainda mais proximais e pelo menor tempo poss\xEDvel).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Para avaliar a necessidade de mais al\xEDquotas de volume al\xE9m dos 30 mL/kg iniciais, a prefer\xEAncia \xE9 por par\xE2metros din\xE2micos como a avalia\xE7\xE3o da resposta \xE0 eleva\xE7\xE3o passiva de membros inferiores ou a provas de volume, a partir de ecocardiograma, varia\xE7\xE3o de volume sist\xF3lico ou varia\xE7\xE3o da press\xE3o de pulso. Outros par\xE2metros importantes para guiarem a ressuscita\xE7\xE3o vol\xEAmica s\xE3o o d\xE9bito urin\xE1rio (\u2265 0,5 mL/kg) e a redu\xE7\xE3o do lactato s\xE9rico nos pacientes com hiperlactatemia inicial \u2013 n\xE3o h\xE1 consenso quanto \xE0 periodicidade do acompanhamento da lactatemia, sendo geralmente feito a cada quatro a seis horas. Alternativas para avaliar a perfus\xE3o tecidual e, assim, ajudar na decis\xE3o quanto a maiores aportes vol\xEAmicos, incluem achados do exame f\xEDsico, como tempo de enchimento capilar, temperatura da extremidade corporal e moteamento da pele.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Outras vari\xE1veis, como frequ\xEAncia card\xEDaca, PA sist\xF3lica, PVC (meta tradicional de 8-12 mmHg) e SvcO2 (meta tradicional \u2265 70%) n\xE3o s\xE3o,</em> 
    <strong>
      <em>isoladamente</em>
    </strong> 
    <em>, bons par\xE2metros para interpreta\xE7\xE3o de estado vol\xEAmico.</em>
  </span>
</p><p>
  <strong>Inotr\xF3picos</strong>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Se houver disfun\xE7\xE3o mioc\xE1rdica associada \xE0 hipoperfus\xE3o apesar da ressuscita\xE7\xE3o vol\xEAmica e PAM adequadas, deve ser acrescentado um inotr\xF3pico. Uma op\xE7\xE3o \xE9 a associa\xE7\xE3o de</span> 
  <strong>dobutamina</strong> 
  <span style="font-weight: 400;">(2,5-20 mcg/Kg/min) \xE0 noradrenalina ou o uso isolado de adrenalina. A disfun\xE7\xE3o mioc\xE1rdica \xE9 sugerida (1) por baixo d\xE9bito card\xEDaco, prov\xE1vel ou confirmado pelo ecocardiograma \xE0 beira do leito e/ou (2) press\xF5es elevadas de enchimento card\xEDaco, avaliadas atrav\xE9s da PVC. A m\xE1 perfus\xE3o \xE9 sinalizada pela perman\xEAncia de hiperlactatemia, enchimento capilar lentificado, livedo e SvcO</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">reduzida.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* A milrinona e o levosimendam seriam outras op\xE7\xF5es inotr\xF3picas, mas, em geral, n\xE3o s\xE3o utilizadas pelo seu maior custo e baixa disponibilidade.</em>
  </span>
</p><p>
  <strong>Corticoide</strong>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Caso, para manter a PAM \u2265&nbsp;65 mmHg, o paciente fa\xE7a uso por, pelo menos, quatro horas de noradrenalina ou adrenalina em dose \u2265 0,25 mcg/Kg/min, deve ser iniciada hidrocortisona IV 200 mg/dia por cinco a sete dias, seja em infus\xE3o cont\xEDnua ou 50 mg a cada 6h.</span>
</p><p>
  <strong>Controle do Foco de Infec\xE7\xE3o</strong>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O ideal \xE9 que sejam obtidas</span> 
  <strong>culturas antes do in\xEDcio da antibioticoterapia</strong> 
  <span style="font-weight: 400;">, desde que isso n\xE3o atrase o in\xEDcio de antimicrobianos em mais de 45 minutos. Em rela\xE7\xE3o \xE0 hemocultura (para aer\xF3bios e anaer\xF3bios), devem ser coletadas, no m\xEDnimo,duas2 amostras de s\xEDtios diferentes (distribuindo cada uma para frascos de aer\xF3bio e anaer\xF3bio), sem intervalo de tempo entre as pun\xE7\xF5es, que podem ser arteriais ou venosas. Se houver acesso vascular inserido h\xE1 &gt; 48h, este pode ser o foco da infec\xE7\xE3o e culturas devem ser coletadas por cada dispositivo inserido \u2013 se a cultura do acesso positivar duas horas antes da cultura perif\xE9rica, o cateter \xE9 provavelmente o foco infeccioso. Urina deve ser rotineiramente analisada com Gram e cultura; secre\xE7\xE3o respirat\xF3ria deve ser examinada em caso de tosse produtiva; cole\xE7\xE3o intra-abdominal p\xF3s-operat\xF3ria deve ser puncionada guiada por um m\xE9todo de imagem.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Se houver suspeita de infec\xE7\xE3o f\xFAngica, pode ser feita pesquisa de biomarcadores como 1,3 beta\u2013D-glucana, galactomanana e anticorpo antimanana, se houver disponibilidade.</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A meta deve ser a administra\xE7\xE3o de</span> 
  <strong>antibioticoterapia dentro da primeira hora</strong> 
  <span style="font-weight: 400;">para os casos de sepse prov\xE1vel, confirmada ou naqueles associados \xE0 hipotens\xE3o. Nas situa\xE7\xF5es da sepse ser \u201Capenas\u201D um diagn\xF3stico poss\xEDvel, a terap\xEAutica antimicrobiana pode ser postergada para permitir uma diferencia\xE7\xE3o mais clara com causas n\xE3o infecciosas, sendo indicado ainda o seu in\xEDcio em at\xE9 tr\xEAs horas caso a possibilidade do quadro infeccioso permane\xE7a nesse tempo. A escolha do esquema leva em considera\xE7\xE3o algumas vari\xE1veis, como o s\xEDtio da infec\xE7\xE3o, hist\xF3ria do paciente (evitar antibi\xF3ticos usados nos \xFAltimos tr\xEAs meses), comorbidades, resultado do Gram e perfil de resist\xEAncia bacteriana local (especialmente nos casos em que a infec\xE7\xE3o foi adquirida no hospital).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">De qualquer forma, em um primeiro momento, opta-se por um esquema de amplo espectro, que deve ser trocado assim que sa\xEDrem os primeiros resultados da cultura e do antibiograma \u2013 \xE9 o chamado descalonamento da antibioticoterapia.
    <br>
  </span>
  <span style="font-size: 8pt;">
    <em>* Recomenda-se a associa\xE7\xE3o de dois antibi\xF3ticos com a\xE7\xE3o contra gram-negativo em situa\xE7\xF5es de alto risco de micro-organismos multirresistentes.</em>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Algumas op\xE7\xF5es podem ser: 
    <br>
    <br>
    <img src="https://d55mnj1ee66xh.cloudfront.net/academico/528dac48-0656-4d16-bbaf-9224a8e0b343.jpg" alt="" width="648" height="561"> 
    <br>
  </span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A dura\xE7\xE3o ideal do tratamento antibi\xF3tico deve ser a menor poss\xEDvel desde que a condi\xE7\xE3o cl\xEDnica do paciente permita, variando classicamente a depender da origem (sete a oito dias para pneumonia; cinco a sete dias para bacteremia; cinco a oito dias para foco intra-abdominal; cinco dias para foco urin\xE1rio), embora s\xE9ries mais longas sejam feitas em casos de resposta cl\xEDnica lenta, focos de infec\xE7\xE3o n\xE3o controlados, bacteremia por</span> 
  <em>
    <span style="font-weight: 400;">S. aureus</span>
  </em> 
  <span style="font-weight: 400;">e comprometimento imunol\xF3gico, inclusive neutropenia. O ideal \xE9 que a decis\xE3o pela descontinua\xE7\xE3o do antibi\xF3tico seja baseada na melhora cl\xEDnica (resolu\xE7\xE3o de choque, diminui\xE7\xE3o no requisito de vasopressores) e laboratorial (redu\xE7\xE3o da procalcitonina), par\xE2metros tamb\xE9m \xFAteis quando o foco \xE9 desconhecido e nenhum pat\xF3geno foi identificado.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Al\xE9m da antibioticoterapia, o controle anat\xF4mico do foco infeccioso detectado (drenagem de abscesso, remo\xE7\xE3o de dispositivo potencialmente infectado) \xE9 essencial e deve ser feito idealmente em 6-12 horas ap\xF3s o diagn\xF3stico.</span>
</p><p>
  <strong>Outras Estrat\xE9gias Relevantes</strong>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">A transfus\xE3o de hem\xE1cias \xE9 recomendada apenas quando a hemoglobina atingir valores &lt; 7,0 g/dL, visando mant\xEA-la entre 7,0-9,0 g/dL.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Como h\xE1 risco aumentado de tromboembolismo venoso na sepse, a profilaxia antitromb\xF3tica farmacol\xF3gica n\xE3o pode ser negligenciada, com prefer\xEAncia pela heparina de baixo peso molecular. Estrat\xE9gias mec\xE2nicas (como compressor pneum\xE1tico intermitente e meia el\xE1stica) n\xE3o devem ser associadas, mas podem ser utilizadas na contraindica\xE7\xE3o \xE0 heparina. Tamb\xE9m \xE9 importante a profilaxia de \xFAlcera p\xE9ptica de estresse, especialmente em pacientes de alto risco, como nos casos de choque e portadores de coagulopatia ou hepatopatia cr\xF4nica.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O alvo glic\xEAmico do paciente \xE9 140-180 mg/dL \u2013 dois resultados de glicemia superiores a esse intervalo s\xE3o suficientes para indicar o in\xEDcio de insulina. Classicamente, a insulinoterapia \xE9 realizada com a estrat\xE9gia de administra\xE7\xE3o intermitente de insulina regular. Uma estrat\xE9gia para evitar hiperglicemia, embora n\xE3o obrigat\xF3ria, \xE9 evitar o uso de solu\xE7\xF5es que contenham glicose (por exemplo, trocar SG 5% por SF 0,9% na administra\xE7\xE3o de aminas). Com o in\xEDcio da terapia insul\xEDnica, a glicemia deve ser reavaliada a cada uma a duas horas e, ap\xF3s a sua estabiliza\xE7\xE3o, a cada quatro horas.</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">O uso de bicarbonato de s\xF3dio pode ser feito em pacientes com acidose metab\xF3lica grave (pH \u2264 7,2) e inj\xFAria renal aguda (AKIN 2 ou 3).</span>
</p><p style="text-align: justify;">
  <span style="font-weight: 400;">Nos pacientes com S\xEDndrome do Desconforto Respirat\xF3rio Agudo (SDRA) induzida por sepse, recomenda-se, como estrat\xE9gia de ventila\xE7\xE3o mec\xE2nica, um volume corrente baixo (6 mL/kg de peso predito), com press\xE3o de plat\xF4 m\xE1xima de 30 cmH</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">O, manobras de recrutamento alveolar e, em casos de rela\xE7\xE3o PaO</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">/FiO</span> 
  <span style="font-weight: 400;">2</span> 
  <span style="font-weight: 400;">\u2264 200 (SDRA moderada a grave), h\xE1 a op\xE7\xE3o de ventila\xE7\xE3o em posi\xE7\xE3o pronada (barriga para baixo) por per\xEDodo &gt; 12 h/dia e administra\xE7\xE3o intermitente de bloqueador neuromuscular \u2013 com especial aten\xE7\xE3o \xE0 analgesia e \xE0 seda\xE7\xE3o do paciente. Casos graves com hipoxemia refrat\xE1ria podem ser submetidos \xE0 oxigena\xE7\xE3o por membrana extracorp\xF3rea venovenosa (ECMO-VV).</span>
</p>`,ordem:5},{titulo:"ARMADILHAS",texto:`<p style="text-align: justify;">
  <strong>Enxergar antibi\xF3tico como droga n\xE3o-urgente \u2013</strong> 
  <span style="font-weight: 400;">Cada atraso de uma hora na administra\xE7\xE3o de antibioticoterapia, aumenta a mortalidade em 6-7%, de modo que o antibi\xF3tico deve ser visto, na sepse, como uma droga de urg\xEAncia.</span>
</p><h1>
  <span style="font-weight: 400;">SUGEST\xD5ES BIBLIOGR\xC1FICAS</span>
</h1><ol>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Evans L, Rhodes A,</span> 
    <span style="font-weight: 400;">Alhazzani W, et al. Surviving sepsis campaign: international guidelines for management of sepsis and septic shock 2021.</span> 
    <em>
      <span style="font-weight: 400;">Intensive Care Medicine</span>
    </em> 
    <span style="font-weight: 400;">&nbsp;2021; 47(11):1181-1247.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Levy MM, Evans LE, Rhodes A. The Surviving Sepsis Campaign Bundle: 2018 update.</span> 
    <em>
      <span style="font-weight: 400;">Intensive Care Medicine</span>
    </em> 
    <span style="font-weight: 400;">&nbsp;2018; 44:925-928.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Rhodes A, Evans LE, Alhazzani W, et al. Surviving Sepsis Campaign: International Guidelines for Management of Sepsis and Septic Shock: 2016.&nbsp;</span> 
    <em>
      <span style="font-weight: 400;">Intensive Care Medicine</span>
    </em> 
    <span style="font-weight: 400;">&nbsp;2017; 43(3):304-377.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Singer M, Deutschman CS, Seymour CW, et al. The Third International Consensus Definitions for Sepsis and Septic Shock (Sepsis-3). JAMA 2016;315(8):801-810.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">National Institute for Health and Care Excellence (2017). Sepsis: recognition, diagnosis and early management (NG51).</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Instituto Latino-Americano para Estudos da Sepse (ILAS). Sepse: um problema de sa\xFAde p\xFAblica. Bras\xEDlia: Conselho Federal de Medicina, 2015.</span>
  </li>
  <li style="font-weight: 400;" aria-level="1">
    <span style="font-weight: 400;">Instituto Latino-Americano para Estudos da Sepse (ILAS), Sociedade Beneficente Israelita Brasileira Hospital Albert Einstein, Minist\xE9rio da Sa\xFAde do Brasil. Controlando a infec\xE7\xE3o, sobrevivendo a sepse: Manual de abordagem inicial da sepse grave e choque s\xE9ptico. S\xE3o Paulo, 2012.</span>
  </li>
  <li>
    <span style="font-weight: 400;">Annane D, Pastores SM, et al. Guidelines for the diagnosis and management of critical illness-related corticosteroid insufficiency (CIRCI) in critically ill patients (Part I): Society of Critical Care Medicine (SCCM) and European Society of Intensive Care Medicine (ESICM) 2017.&nbsp; 
      <em>Intensive care medicine</em>&nbsp;2017; 43:1751-1763.
    </span> 
    <br>
  </li>
</ol>`,ordem:6}],videos:[],fluxogramas:[],tags:["Choque S\xE9ptico"]},{id:"db1b6993-0c0a-48f8-9cef-685a369ed6b6",nome:"S\xEDndrome do Intestino Irrit\xE1vel",categoria:2,termosDeBusca:"sindrome do intestino irritavel, sii, sindrome do colon irritavel, sci",favoritado:!1,ordem:0,especialidades:[{nome:"GASTROENTEROLOGIA"}],prescricoes:[{id:"eedba8fd-028c-4c3d-bb07-5a92551f12ea",nome:"SII - Sintomas Globais",favorito:!0,ordem:1,secoes:[{item:"DIETA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"052d499b-c3d5-4a39-ab84-447785953fd3",opcoes:[{id:"01c84de6-0388-40a2-a109-60b6a9a2ecd7",descr:`Dieta com suplementa\xE7\xE3o de fibra sol\xFAvel - iniciar com 3-4 g/dia\r
Prefer\xEAncia: psyllium, farelo de aveia, cevada`,recomendado:!0,favorito:!0,ordem:1}],ordem:1},{grupo:"Antiem\xE9tico",idGrupo:"1e2bf543-8b7f-46c9-b103-8d833b0756e4",opcoes:[{id:"83f67e1f-bf7f-41f9-b1a0-5f84d46620bd",descr:"Dieta com baixo teor de FODMAP",recomendado:!0,favorito:!0,ordem:1}],ordem:2}],academico:"\xDAtil para al\xEDvio dos sintomas de distens\xE3o e dor abdominal.",ordem:1},{item:"ANTIESPASM\xD3DICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"754e38c2-f74d-4a8e-87d5-f1884d06e782",opcoes:[{id:"5fbae074-233e-47fe-8501-e7052d77d309",descr:"Mebeverina XR (200mg/cp) 200 mg VO 12/12h (MEDGRUPO)",recomendado:!0,favorito:!0,ordem:1},{id:"73fdd475-3f36-44d0-b169-c898f7e5819c",descr:`Diciclomina (10mg/cp) 10-20 mg VO 6/6h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:2},{id:"80b38e57-ab83-4a77-a637-25ce25a03b4e",descr:`Diciclomina (5mg/mL) 10-20 mg VO 6/6h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:3},{id:"27487740-68ff-46f3-b1bf-4333c82aff83",descr:"Otil\xF4nio (40mg/cp) 40 mg VO 2-3x/dia",recomendado:!1,favorito:!1,ordem:4},{id:"ae01dd2d-6cda-43fb-8725-4fec451b89af",descr:`Mebeverina (135mg/cp) 135 mg VO 8/8h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:5},{id:"cc6da057-034f-4427-9ab9-dc1c25ef96a0",descr:"Escopolamina (10mg/cp) 10-20 mg VO 8/8h",recomendado:!1,favorito:!1,ordem:6},{id:"b380fc59-7a8c-4399-8f26-0b328bdd3a3e",descr:"Escopolamina (10mg/mL) 20-40 gotas (10-20 mg) VO 8/8h",recomendado:!1,favorito:!1,ordem:7},{id:"52cd255e-321f-4160-b76c-5a1c71be8fb6",descr:`Hiosciamina (0,125mg/cp) 0,125-0,25 mg VO 4/4h ou 8/8h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:8},{id:"35ee3923-b1a1-488b-81a2-ac131da5bbb6",descr:`Hiosciamina XR (0,375mg/cp) 0,375-0,75 mg VO 12/12h\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:9},{id:"db0b7d53-d22b-4eb5-8273-3406cc551c08",descr:"Trimebutina (200mg/cp) 200 mg VO 8/8h",recomendado:!1,favorito:!1,ordem:10}],ordem:1}],academico:"Op\xE7\xE3o de 1a linha, por\xE9m sem consenso absoluto sobre a validade de seu uso.",ordem:2},{item:"PROBI\xD3TICOS",grupos:[{grupo:"Analg\xE9sico",idGrupo:"7402ab11-f2cc-47e8-8b32-2d2085bdd372",opcoes:[{id:"6ec3929d-02f6-4e1f-b0ab-d7f31ad18163",descr:"",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 1a linha que pode ser administrada por at\xE9 12 semanas; com muitas op\xE7\xF5es no mercado e sem prefer\xEAncia entre elas.",ordem:3},{item:"\xD3LEO DE HORTEL\xC3-PIMENTA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"93b67bd2-01db-416e-8dd2-6942b0a5eb36",opcoes:[{id:"1bdbc7c2-f153-4819-8b0d-9a537e069583",descr:"\xD3leo de hortel\xE3-pimenta (750mg/cp) 750 mg VO 1-3x/dia",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 1a linha, por\xE9m pode provocar refluxo.",ordem:4},{item:"ANTIDEPRESSIVO TRIC\xCDCLICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"5016a611-7f09-4f13-a4d2-19a51284d414",opcoes:[{id:"49b465e5-6ca2-4b3a-9235-07111939aac2",descr:`Amitriptilina (10-75mg/cp) 10-25 mg VO 1x/dia ao deitar (MEDGRUPO)
Pode-se aumentar a dose a cada 3/4 sem at\xE9 m\xE1x 50-100 mg/dia`,recomendado:!0,favorito:!0,ordem:1},{id:"44a0ee46-027f-4440-93d5-49688e5b6cef",descr:`Imipramina (10-25mg/cp) 10-25 mg VO 1x/dia ao deitar\r
Pode-se aumentar a dose a cada 3/4 sem at\xE9 m\xE1x 50-100 mg/dia`,recomendado:!1,favorito:!1,ordem:2},{id:"6c184e64-def8-4d30-bcaa-9837752ba1ed",descr:`Nortriptilina (10-75mg/cp) 10-25 mg VO 1x/dia ao deitar\r
Pode-se aumentar a dose a cada 3/4 sem at\xE9 m\xE1x 25-75 mg/dia`,recomendado:!1,favorito:!1,ordem:3},{id:"d3022de4-00fd-4401-98c5-73dde5b45d65",descr:`Desipramina (10-100mg/cp) 10 mg VO 1x/dia ao deitar\r
Pode-se aumentar a dose a cada 3/4 sem at\xE9 m\xE1x 25-100 mg/dia\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:4}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha; iniciar em dose baixa com titula\xE7\xE3o gradual.",ordem:5}],conceitosPraticos:[{conceito:"Diagn\xF3stico (Roma IV): dor abdominal recorrente e que se associa com a evacuac\u0327a\u0303o e a mudanc\u0327a do ha\u0301bito intestinal (constipac\u0327a\u0303o, diarreia ou ambos alternadamente).",ordem:1},{conceito:"Objetivo: melhora dos sintomas globais (dor e distens\xE3o abdominal) e melhora espec\xEDfica da diarreia ou constipa\xE7\xE3o.",ordem:2},{conceito:"Estimular exerc\xEDcio f\xEDsico regular para todos os casos.",ordem:3}]},{id:"be4deed2-ec91-4849-89c8-ece7d3cb2017",nome:"SII - Predom\xEDnio de Constipa\xE7\xE3o",favorito:!1,ordem:2,secoes:[{item:"POLIETILENOGLICOL (MACROGOL)",grupos:[{grupo:"Analg\xE9sico",idGrupo:"3ee55309-2531-49de-b36c-bc07c323e17a",opcoes:[{id:"84df3d66-91b5-45c3-834f-a23a6206f03f",descr:"Polietilenoglicol ou Macrogol (8,5-17g/env) 8,5-17g dissolvidos em 200 mL de \xE1gua VO 1x/dia",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 1a linha.",ordem:1},{item:"ATIVADOR DE CANAL DE CLORETO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"e13306e4-c476-4aca-b623-bc9cdaffb64b",opcoes:[{id:"596c2de1-0df0-4760-a674-7101819e44cd",descr:"Lubiprostona (8-24mcg/cp) 8 mcg VO 12/12h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha; mais utilizado em mulheres \u2265 18 anos e pode causar n\xE1usea.",ordem:2},{item:"AGONISTA DE GUANILATO CICLASE",grupos:[{grupo:"Analg\xE9sico",idGrupo:"5b9b0858-77bc-4950-8c87-221d08f2024b",opcoes:[{id:"8caef97c-e69b-4b11-87d4-48a69452978d",descr:`Linaclotida (72-290mcg/cp) 290 mcg VO 1x/dia (MEDGRUPO)
Indispon\xEDvel no Brasil`,recomendado:!0,favorito:!0,ordem:1},{id:"870f85a0-d802-4897-8f17-67de6d74c395",descr:`Plecanatida (3mg/cp) 3 mg VO 1x/dia\r
Indispon\xEDvel no Brasil`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha.",ordem:3},{item:"INIBIDOR DO TROCADOR DE S\xD3DIO/HIDROG\xCANIO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"8ed083af-6d59-42f9-a4fe-f881abc5c76b",opcoes:[{id:"9149fa8d-f0c2-4e38-8132-834474a6be91",descr:`Tenapanor (50mg/cp) 50 mg VO 12/12h (antes do caf\xE9 e do jantar)\r
Indispon\xEDvel no Brasil`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha.",ordem:4},{item:"AGONISTA DO RECEPTOR 5-HT4",grupos:[{grupo:"Analg\xE9sico",idGrupo:"ba762690-d985-4386-99f5-22d9571b5055",opcoes:[{id:"e8d0a8e5-c8fa-4488-a652-df63fdf0e958",descr:"Tegaserode (6mg/cp) 6 mg VO 12/12h (antes do caf\xE9 e do jantar)",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha; indicado se mulher < 65 anos e \u2264 1 fator de risco cardiovascular.",ordem:5}],conceitosPraticos:[{conceito:"Diagn\xF3stico (Roma IV): dor abdominal recorrente e que se associa com a evacuac\u0327a\u0303o e a mudanc\u0327a do ha\u0301bito intestinal (constipac\u0327a\u0303o, diarreia ou ambos alternadamente).",ordem:1},{conceito:"Objetivo: melhora dos sintomas globais (dor e distens\xE3o abdominal) e melhora espec\xEDfica da diarreia ou constipa\xE7\xE3o.",ordem:2},{conceito:"Estimular exerc\xEDcio f\xEDsico regular para todos os casos.",ordem:3}]},{id:"bc39db30-5e3f-4386-8829-2aaefe4efa96",nome:"SII - Predom\xEDnio de Diarreia",favorito:!1,ordem:3,secoes:[{item:"ANTIDIARREICO",grupos:[{grupo:"Analg\xE9sico",idGrupo:"dde20b6c-dc98-4b31-93c4-abd756197224",opcoes:[{id:"38a4ed7d-d550-4783-b430-133f527809ea",descr:`Eluxadolina (75-100mg/cp) 100 mg VO 12/12h (se intolerante: 75 mg 12/12h) (MEDGRUPO)
Contraindica\xE7\xF5es: hist\xF3ria de pancreatite, colecistectomia ou alcoolismo
Indispon\xEDvel no Brasil`,recomendado:!0,favorito:!0,ordem:1},{id:"a836ed75-6af6-4002-b8e2-28698fc7aea5",descr:`Loperamida (2mg/cp) 2 mg VO (45 min antes das refei\xE7\xF5es e/ou ap\xF3s evacua\xE7\xE3o)\r
Dose m\xE1xima: 16 mg/dia`,recomendado:!1,favorito:!1,ordem:2}],ordem:1}],academico:"Op\xE7\xE3o de 1a linha.",ordem:1},{item:"RIFAXIMINA",grupos:[{grupo:"Analg\xE9sico",idGrupo:"d9a8790d-19df-41f3-89b6-f2bd5ff3494a",opcoes:[{id:"c1dcef93-6b2b-4b59-a583-513bc60431ea",descr:"Rifaximina (550mg/cp) 550 mg VO 8/8h durante 14 dias",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha.",ordem:2},{item:"ANTAGONISTA DO RECEPTOR 5-HT3 ",grupos:[{grupo:"Analg\xE9sico",idGrupo:"066741e2-a102-492e-a6c8-d2ae3caf6310",opcoes:[{id:"b37302d5-3d9e-450e-9053-30fa6faef899",descr:`Alosetrona (0,5-1mg/cp) 0,5-1 mg VO 12/12h (MEDGRUPO)
Indispon\xEDvel no Brasil`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha, classicamente mais indicado para mulheres com quadro refrat\xE1rio > 6 meses.",ordem:3},{item:"ANTAGONISTA DO RECEPTOR 5-HT4",grupos:[{grupo:"Analg\xE9sico",idGrupo:"c9127d39-6c82-4409-a656-2f97bfb896a3",opcoes:[{id:"61639c2f-f8b1-409c-b77e-e18d56cda156",descr:`Ramosetrona (2,5-5mcg/cp) 2,5-5 mcg VO 1x/dia\r
Indispon\xEDvel no Brasil`,recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha, classicamente mais indicado para mulheres com quadro refrat\xE1rio > 6 meses.",ordem:4},{item:"ANTAGONISTA DO RECEPTOR 5-HT5",grupos:[{grupo:"Analg\xE9sico",idGrupo:"9bf31e8e-d045-4d18-8d3d-baceaa111cc9",opcoes:[{id:"977cd9c6-0c11-4daa-b045-e53318287c53",descr:"Ondansetrona (4-8mg/cp) 4-8 mg VO 8/8h",recomendado:!0,favorito:!0,ordem:1}],ordem:1}],academico:"Op\xE7\xE3o de 2a linha, classicamente mais indicado para mulheres com quadro refrat\xE1rio > 6 meses.",ordem:5}],conceitosPraticos:[{conceito:"Diagn\xF3stico (Roma IV): dor abdominal recorrente e que se associa com a evacuac\u0327a\u0303o e a mudanc\u0327a do ha\u0301bito intestinal (constipac\u0327a\u0303o, diarreia ou ambos alternadamente).",ordem:1},{conceito:"Objetivo: melhora dos sintomas globais (dor e distens\xE3o abdominal) e melhora espec\xEDfica da diarreia ou constipa\xE7\xE3o.",ordem:2},{conceito:"Estimular exerc\xEDcio f\xEDsico regular para todos os casos.",ordem:3}]}],topicos:[],videos:[],fluxogramas:[],tags:["SII","S\xEDndrome do C\xF3lon Irrit\xE1vel","SCI"]}],validations:[],message:"Success",protocol:"79625495-9741-44ed-a497-c2a962112139",resultCode:200,isValid:!0,success:!0};var h=(()=>{let n=class n{constructor(){this.patologiasSubject=new c([]),this.patologias$=this.patologiasSubject.asObservable()}initializeFavoritosDb(){return r(this,null,function*(){let e=indexedDB.open("favoritos",1);return new Promise((i,s)=>{e.onupgradeneeded=a=>{let o=a.target.result;if(!o.objectStoreNames.contains("patologias")){let t=o.createObjectStore("patologias",{keyPath:"idPatologia",unique:!0})}if(!o.objectStoreNames.contains("prescricoes")){let t=o.createObjectStore("prescricoes",{keyPath:"idPatologia",unique:!0})}if(!o.objectStoreNames.contains("terapeuticas")){let t=o.createObjectStore("terapeuticas",{keyPath:"idGrupoSecao",unique:!0})}},e.onsuccess=a=>{this.dbFavoritos=a.target.result,console.log("Database connected:",this.dbFavoritos.name),i()},e.onerror=a=>{console.error("Database error:",e.error),s(e.error)}})})}initializeConteudoDb(){return r(this,null,function*(){let e=indexedDB.open("conteudos",1);return new Promise((i,s)=>{e.onupgradeneeded=a=>{let o=a.target.result;o.objectStoreNames.contains("patologias")||o.createObjectStore("patologias",{keyPath:"id"})},e.onsuccess=a=>{this.dbConteudos=a.target.result,console.log("Database connected:",this.dbConteudos.name),this.loadPatologias(),i()},e.onerror=a=>{console.error("Database error:",e.error),s(e.error)}})})}getObjectStore(e,i,s){return e.transaction([i],s).objectStore(i)}loadPatologias(){return r(this,null,function*(){let e=this.getObjectStore(this.dbConteudos,"patologias","readwrite");if((yield new Promise((s,a)=>{let o=e.count();o.onsuccess=()=>s(o.result),o.onerror=()=>a(o.error)}))===0){let s=this.dbConteudos.transaction([e.name],"readwrite"),a=s.objectStore(e.name),o=Object.values(p.data).map(t=>a.add(t));yield Promise.all(o),s.commit()}})}setPatologiasSubject(){return r(this,null,function*(){let e=yield this.getAllDataPatologias();this.patologiasSubject.next(e.sort((i,s)=>i.nome.localeCompare(s.nome)))})}getAllPatologiasFavoritas(){return r(this,null,function*(){return new Promise((e,i)=>{let a=this.getObjectStore(this.dbFavoritos,"patologias","readonly").getAll();a.onsuccess=()=>{e(a.result)},a.onerror=()=>{i(a.error)}})})}getAllDataPatologias(){return r(this,null,function*(){return new Promise((e,i)=>{let a=this.getObjectStore(this.dbConteudos,"patologias","readonly").getAll();a.onsuccess=()=>{e(a.result)},a.onerror=()=>{i(a.error)}})})}};n.\u0275fac=function(i){return new(i||n)},n.\u0275prov=m({token:n,factory:n.\u0275fac,providedIn:"root"});let d=n;return d})();export{h as a};
